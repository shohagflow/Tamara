<?php
/**
 * Island Experts Admin — users module.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_admin_get_users_query_args( $args = [] ) {
    $type   = sanitize_key( $args['type'] ?? 'all' );
    $search = sanitize_text_field( $args['search'] ?? '' );
    $status = sanitize_key( $args['status'] ?? '' );
    $paged  = max( 1, (int) ( $args['paged'] ?? 1 ) );
    $per    = max( 1, min( 100, (int) ( $args['per_page'] ?? 20 ) ) );

    $query_args = [
        'orderby' => 'registered',
        'order'   => 'DESC',
        'number'  => -1,
        'fields'  => 'all',
    ];

    if ( $search !== '' ) {
        $query_args['search']         = '*' . $search . '*';
        $query_args['search_columns'] = [ 'user_login', 'user_email', 'display_name', 'user_nicename' ];
    }

    $users = get_users( $query_args );
    if ( ! is_array( $users ) ) {
        $users = [];
    }

    if ( $type === 'customer' ) {
        $users = array_values( array_filter( $users, function ( $user ) {
            return ie_get_user_type( $user->ID ) === 'customer';
        } ) );
    } elseif ( $type === 'provider' ) {
        $users = array_values( array_filter( $users, function ( $user ) {
            return ie_get_user_type( $user->ID ) === 'provider';
        } ) );
    }

    if ( $status !== '' ) {
        $users = array_values( array_filter( $users, function ( $user ) use ( $status ) {
            return ie_get_user_account_status( $user->ID ) === $status;
        } ) );
    }

    $total = count( $users );
    $pages = (int) ceil( max( 1, $total ) / $per );
    $users = array_slice( $users, ( $paged - 1 ) * $per, $per );

    return [
        'users' => array_values( array_filter( array_map( 'ie_admin_format_user_row', $users ) ) ),
        'total' => $total,
        'pages' => $pages,
    ];
}

function ie_admin_format_user_row( $user ) {
    if ( ! $user instanceof WP_User ) {
        return [];
    }

    $type       = ie_get_user_type( $user->ID );
    $status     = ie_get_user_account_status( $user->ID );
    $subscription = ie_get_user_subscription( $user->ID );
    $provider   = ie_get_provider_post_by_user( $user->ID );

    return [
        'id'           => $user->ID,
        'name'         => $user->display_name ?: $user->user_login,
        'email'        => $user->user_email,
        'type'         => $type,
        'type_label'   => $type === 'provider' ? ie__( 'Service Provider' ) : ie__( 'Client' ),
        'registered'   => mysql2date( get_option( 'date_format' ), get_date_from_gmt( $user->user_registered ) ),
        'status'       => $status,
        'avatar'       => ie_get_user_profile_image_url( $user->ID, 'thumbnail' ),
        'provider_id'  => $provider ? $provider->ID : 0,
        'subscription' => $subscription['plan_label'],
        'sub_status'   => $subscription['status'],
    ];
}

function ie_admin_get_user_details( $user_id ) {
    $user = get_userdata( $user_id );
    if ( ! $user ) {
        return null;
    }

    $type        = ie_get_user_type( $user_id );
    $status      = ie_get_user_account_status( $user_id );
    $subscription = ie_get_user_subscription( $user_id );
    $provider    = ie_get_provider_post_by_user( $user_id );
    $profile_url = '';

    $data = [
        'id'         => $user_id,
        'name'       => $user->display_name ?: $user->user_login,
        'email'      => $user->user_email,
        'avatar'     => ie_get_user_profile_image_url( $user_id, 'medium' ),
        'type'       => $type,
        'type_label' => $type === 'provider' ? ie__( 'Service Provider' ) : ie__( 'Client' ),
        'registered' => mysql2date( get_option( 'date_format' ), get_date_from_gmt( $user->user_registered ) ),
        'status'     => $status,
        'profile_url'=> '',
    ];

    if ( $type === 'provider' && $provider ) {
        $services_raw = get_post_meta( $provider->ID, '_ie_services', true );
        $services      = json_decode( (string) $services_raw, true );
        $service_count = is_array( $services ) ? count( $services ) : 0;

        $data['phone']           = get_post_meta( $provider->ID, '_ie_phone', true ) ?: '—';
        $data['subscription']    = $subscription['plan_label'];
        $data['sub_status']      = $subscription['status_label'];
        $data['services_count']  = $service_count;
        $data['reviews_count']   = (int) get_post_meta( $provider->ID, '_ie_review_count', true );
        $data['rating']          = get_post_meta( $provider->ID, '_ie_rating', true ) ?: '0';
        $data['provider_id']     = $provider->ID;
        $data['profile_url']     = get_permalink( $provider->ID );
    } elseif ( $type === 'customer' ) {
        $data['profile_url'] = ie_get_theme_page_url( 'client-profile' );
    }

    return $data;
}

function ie_admin_suspend_user( $user_id ) {
    if ( get_current_user_id() === (int) $user_id ) {
        return new WP_Error( 'self_suspend', ie__( 'You cannot suspend your own account.' ) );
    }

    ie_set_user_account_status( $user_id, 'suspended' );
    return true;
}

function ie_admin_activate_user( $user_id ) {
    ie_set_user_account_status( $user_id, 'active' );
    return true;
}

function ie_admin_delete_user( $user_id ) {
    if ( get_current_user_id() === (int) $user_id ) {
        return new WP_Error( 'self_delete', ie__( 'You cannot delete your own account.' ) );
    }

    if ( user_can( $user_id, 'manage_options' ) ) {
        return new WP_Error( 'admin_delete', ie__( 'Administrator accounts cannot be deleted from here.' ) );
    }

    require_once ABSPATH . 'wp-admin/includes/user.php';

    $provider = ie_get_provider_post_by_user( $user_id );
    if ( $provider ) {
        wp_delete_post( $provider->ID, true );
    }

    return wp_delete_user( $user_id );
}

function ie_admin_render_user_table_row( $user ) {
    if ( empty( $user['id'] ) ) {
        return;
    }

    $avatar = ! empty( $user['avatar'] )
        ? '<img src="' . esc_url( $user['avatar'] ) . '" alt="">'
        : '<span class="dashicons dashicons-admin-users" aria-hidden="true"></span>';
    ?>
    <tr>
        <td>
            <div class="ie-ad-user-cell">
                <?php echo $avatar; ?>
                <div>
                    <strong><?php echo esc_html( $user['name'] ); ?></strong><br>
                    <small><?php echo esc_html( $user['email'] ); ?></small>
                </div>
            </div>
        </td>
        <td><?php echo esc_html( $user['type_label'] ); ?></td>
        <td><?php echo esc_html( $user['registered'] ); ?></td>
        <td><?php ie_admin_status_badge( $user['status'] ); ?></td>
        <td>
            <div class="ie-ad-actions">
                <button type="button" class="button ie-ad-view-user" data-id="<?php echo esc_attr( (string) $user['id'] ); ?>">
                    <?php echo esc_html( ie__( 'View' ) ); ?>
                </button>
                <?php if ( $user['status'] === 'active' ) : ?>
                    <button type="button" class="button ie-ad-user-action" data-action="suspend" data-id="<?php echo esc_attr( (string) $user['id'] ); ?>">
                        <?php echo esc_html( ie__( 'Suspend' ) ); ?>
                    </button>
                <?php else : ?>
                    <button type="button" class="button ie-ad-user-action" data-action="activate" data-id="<?php echo esc_attr( (string) $user['id'] ); ?>">
                        <?php echo esc_html( ie__( 'Activate' ) ); ?>
                    </button>
                <?php endif; ?>
                <button type="button" class="button ie-ad-user-action button-link-delete" data-action="delete" data-id="<?php echo esc_attr( (string) $user['id'] ); ?>">
                    <?php echo esc_html( ie__( 'Delete' ) ); ?>
                </button>
            </div>
        </td>
    </tr>
    <?php
}

function ie_admin_render_users_pagination( $page, $pages ) {
    if ( $pages <= 1 ) {
        return;
    }

    for ( $i = 1; $i <= $pages; $i++ ) {
        $class = $i === $page ? 'button button-primary' : 'button';
        printf(
            '<button type="button" class="%1$s ie-ad-users-page" data-page="%2$d">%2$d</button> ',
            esc_attr( $class ),
            (int) $i
        );
    }
}

function ie_admin_render_users_page() {
    if ( ! ie_admin_user_can() ) {
        return;
    }

    $current_page = ie_admin_get_current_page();
    ie_admin_render_shell_open( $current_page );

    $tabs = [
        'all'      => ie__( 'All Users' ),
        'customer' => ie__( 'Clients' ),
        'provider' => ie__( 'Service Providers' ),
    ];
    ?>
    <div class="ie-ad-users" data-section="users">
        <?php ie_admin_render_tabs( $tabs, 'all' ); ?>
        <script>
        (function () {
            var tab = 'all';

            try {
                tab = sessionStorage.getItem('ie_admin_users_active_tab') || 'all';
            } catch (e) {
                tab = 'all';
            }

            if (['all', 'customer', 'provider'].indexOf(tab) === -1) {
                tab = 'all';
            }

            var section = document.currentScript && document.currentScript.parentElement;
            if (!section) {
                return;
            }

            section.querySelectorAll('.ie-ad-tab').forEach(function (btn) {
                var active = btn.getAttribute('data-tab') === tab;
                btn.classList.toggle('is-active', active);
                btn.setAttribute('aria-selected', active ? 'true' : 'false');
            });
        }());
        </script>
        <?php
        ie_admin_render_toolbar(
            ie__( 'Search users by name or email...' ),
            [
                [
                    'id'      => 'ie-ad-user-status',
                    'options' => [
                        ''          => ie__( 'All Statuses' ),
                        'active'    => ie__( 'Active' ),
                        'suspended' => ie__( 'Suspended' ),
                    ],
                ],
            ]
        );
        ?>
        <div class="ie-ad-table-wrap">
            <table class="ie-ad-table" id="ie-ad-users-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html( ie__( 'User' ) ); ?></th>
                        <th><?php echo esc_html( ie__( 'Type' ) ); ?></th>
                        <th><?php echo esc_html( ie__( 'Registered' ) ); ?></th>
                        <th><?php echo esc_html( ie__( 'Status' ) ); ?></th>
                        <th><?php echo esc_html( ie__( 'Actions' ) ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="5"><?php echo esc_html( ie__( 'Loading...' ) ); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="ie-ad-pagination" id="ie-ad-users-pagination"></div>
    </div>
    <?php

    ie_admin_render_shell_close();
}

function ie_ajax_admin_get_users() {
    if ( ! ie_admin_user_can() ) {
        wp_send_json_error( [ 'message' => ie__( 'Permission denied.' ) ], 403 );
    }

    if ( ! check_ajax_referer( 'ie_admin_dashboard', 'nonce', false ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Invalid security token.' ) ], 403 );
    }

    if ( ! empty( $_POST['fetch_all'] ) ) {
        $result = ie_admin_get_users_query_args( [
            'type'     => 'all',
            'paged'    => 1,
            'per_page' => 10000,
        ] );

        wp_send_json_success( [
            'users' => $result['users'],
            'total' => $result['total'],
        ] );
    }

    $paged = max( 1, (int) ( $_POST['paged'] ?? 1 ) );

    $result = ie_admin_get_users_query_args( [
        'type'     => sanitize_key( wp_unslash( $_POST['type'] ?? 'all' ) ),
        'search'   => sanitize_text_field( wp_unslash( $_POST['search'] ?? '' ) ),
        'status'   => sanitize_key( wp_unslash( $_POST['status'] ?? '' ) ),
        'paged'    => $paged,
        'per_page' => 20,
    ] );

    ob_start();
    if ( ! $result['users'] ) {
        echo '<tr><td colspan="5">' . esc_html( ie__( 'No results found.' ) ) . '</td></tr>';
    } else {
        foreach ( $result['users'] as $user ) {
            ie_admin_render_user_table_row( $user );
        }
    }
    $rows = ob_get_clean();

    ob_start();
    ie_admin_render_users_pagination( $paged, $result['pages'] );
    $pagination = ob_get_clean();

    wp_send_json_success( [
        'html'            => $rows,
        'pagination_html' => $pagination,
        'pages'           => $result['pages'],
        'total'           => $result['total'],
        'empty'           => empty( $result['users'] ),
    ] );
}
add_action( 'wp_ajax_ie_admin_get_users', 'ie_ajax_admin_get_users' );

function ie_ajax_admin_get_user() {
    ie_admin_verify_request( 'ie_admin_dashboard', 'nonce' );

    $user_id = (int) ( $_POST['user_id'] ?? 0 );
    $data    = ie_admin_get_user_details( $user_id );

    if ( ! $data ) {
        wp_send_json_error( [ 'message' => ie__( 'User not found.' ) ], 404 );
    }

    wp_send_json_success( $data );
}
add_action( 'wp_ajax_ie_admin_get_user', 'ie_ajax_admin_get_user' );

function ie_ajax_admin_user_action() {
    ie_admin_verify_request( 'ie_admin_dashboard', 'nonce' );

    $user_id = (int) ( $_POST['user_id'] ?? 0 );
    $action  = sanitize_key( $_POST['user_action'] ?? '' );

    if ( ! $user_id ) {
        wp_send_json_error( [ 'message' => ie__( 'Invalid user.' ) ], 400 );
    }

    switch ( $action ) {
        case 'suspend':
            $result = ie_admin_suspend_user( $user_id );
            break;
        case 'activate':
            $result = ie_admin_activate_user( $user_id );
            break;
        case 'delete':
            $result = ie_admin_delete_user( $user_id );
            break;
        default:
            wp_send_json_error( [ 'message' => ie__( 'Invalid action.' ) ], 400 );
    }

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( [ 'message' => $result->get_error_message() ], 400 );
    }

    wp_send_json_success( [ 'message' => ie__( 'Action completed successfully.' ) ] );
}
add_action( 'wp_ajax_ie_admin_user_action', 'ie_ajax_admin_user_action' );

