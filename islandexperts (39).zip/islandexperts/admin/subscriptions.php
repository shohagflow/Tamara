﻿<?php
/**
 * Island Experts Admin — subscriptions module.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'IE_SUBSCRIPTION_PLANS_OPTION', 'ie_subscription_plans' );
define( 'IE_SUBSCRIPTION_SETTINGS_OPTION', 'ie_subscription_settings' );

function ie_admin_get_default_subscription_settings() {
    return [
        'yearly_discount_text'    => ie__( 'Save 17%' ),
        'default_show_all_users'  => '0',
        'free_trial_days'         => 0,
    ];
}

function ie_get_subscription_settings() {
    $settings = get_option( IE_SUBSCRIPTION_SETTINGS_OPTION, [] );

    if ( ! is_array( $settings ) || ! $settings ) {
        $settings = ie_admin_get_default_subscription_settings();
        update_option( IE_SUBSCRIPTION_SETTINGS_OPTION, $settings, false );
    }

    return wp_parse_args( $settings, ie_admin_get_default_subscription_settings() );
}

function ie_admin_sanitize_subscription_settings( $settings ) {
    $defaults = ie_admin_get_default_subscription_settings();
    $current  = ie_get_subscription_settings();
    $base     = wp_parse_args( $current, $defaults );

    if ( ! is_array( $settings ) ) {
        return $base;
    }

    $sanitized = $base;

    if ( array_key_exists( 'yearly_discount_text', $settings ) ) {
        $sanitized['yearly_discount_text'] = sanitize_text_field( $settings['yearly_discount_text'] );
    }

    if ( array_key_exists( 'default_show_all_users', $settings ) ) {
        $sanitized['default_show_all_users'] = ! empty( $settings['default_show_all_users'] ) ? '1' : '0';
    }

    if ( array_key_exists( 'free_trial_days', $settings ) ) {
        $sanitized['free_trial_days'] = max( 0, min( 365, (int) $settings['free_trial_days'] ) );
    }

    return wp_parse_args( $sanitized, $defaults );
}

function ie_get_subscription_yearly_discount_text() {
    $settings = ie_get_subscription_settings();

    return $settings['yearly_discount_text'] ?? '';
}

function ie_admin_get_plan_feature_icon_options() {
    return [
        'fa-solid fa-check' => ie__( 'Check' ),
        'fa-solid fa-xmark'  => ie__( 'Cross' ),
        'fa-solid fa-star'   => ie__( 'Star' ),
    ];
}

function ie_admin_resolve_plan_feature_icon( $icon ) {
    $icon    = sanitize_text_field( (string) $icon );
    $options = ie_admin_get_plan_feature_icon_options();

    return isset( $options[ $icon ] ) ? $icon : 'fa-solid fa-check';
}

function ie_admin_normalize_plan_feature( $feature ) {
    if ( is_array( $feature ) ) {
        $text = sanitize_text_field( $feature['text'] ?? '' );
        $icon = ie_admin_resolve_plan_feature_icon( $feature['icon'] ?? 'fa-solid fa-check' );
        $key  = sanitize_key( $feature['key'] ?? '' );

        if ( $key === '' && $text !== '' ) {
            $key = ie_resolve_plan_feature_key( $text );
        }

        return [
            'text' => $text,
            'icon' => $icon,
            'key'  => $key,
        ];
    }

    $text = sanitize_text_field( (string) $feature );

    return [
        'text' => $text,
        'icon' => 'fa-solid fa-check',
        'key'  => ie_resolve_plan_feature_key( $text ),
    ];
}

function ie_admin_get_plan_editor_features( $plan ) {
    $features = $plan['features'] ?? [];
    $normalized = [];

    if ( is_array( $features ) ) {
        foreach ( $features as $feature ) {
            $normalized[] = ie_admin_normalize_plan_feature( $feature );
        }
    }

    if ( ! $normalized ) {
        $normalized[] = [
            'text' => '',
            'icon' => 'fa-solid fa-check',
        ];
    }

    return $normalized;
}

function ie_admin_get_plan_feature_icon_modifier( $icon ) {
    $icon = ie_admin_resolve_plan_feature_icon( $icon );

    if ( $icon === 'fa-solid fa-xmark' ) {
        return 'is-cross';
    }

    if ( $icon === 'fa-solid fa-star' ) {
        return 'is-star';
    }

    return 'is-check';
}

function ie_admin_get_default_subscription_plans() {
    return [
        [
            'id'            => 'plan-basic',
            'name'          => ie__( 'Basic Plan' ),
            'description'   => ie__( 'Everything you need to get started and connect with local customers.' ),
            'billing_period' => 'monthly',
            'price'          => '9.99',
            'monthly_price'  => '9.99',
            'yearly_price'   => '0',
            'status'        => 'active',
            'features'      => [
                [
                    'text' => ie__( 'Limited messaging' ),
                    'icon' => 'fa-solid fa-check',
                ],
                [
                    'text' => ie__( 'Basic profile access' ),
                    'icon' => 'fa-solid fa-check',
                ],
            ],
        ],
        [
            'id'            => 'plan-premium',
            'name'          => ie__( 'Premium Plan' ),
            'description'   => ie__( 'Grow faster with premium visibility and unlimited messaging.' ),
            'billing_period' => 'monthly',
            'price'          => '13.99',
            'monthly_price'  => '13.99',
            'yearly_price'   => '0',
            'status'        => 'active',
            'features'      => [
                [
                    'text' => ie__( 'Unlimited Messaging' ),
                    'icon' => 'fa-solid fa-check',
                ],
                [
                    'text' => ie__( 'Access to All Providers' ),
                    'icon' => 'fa-solid fa-star',
                ],
                [
                    'text' => ie__( 'Favorites System' ),
                    'icon' => 'fa-solid fa-star',
                ],
                [
                    'text' => ie__( 'Featured Profile' ),
                    'icon' => 'fa-solid fa-star',
                ],
                [
                    'text' => ie__( 'Priority Support' ),
                    'icon' => 'fa-solid fa-check',
                ],
            ],
        ],
    ];
}

function ie_admin_get_plan_pricing_period_options() {
    return [
        'monthly' => ie__( 'Monthly' ),
        'yearly'  => ie__( 'Yearly' ),
    ];
}

function ie_admin_get_plan_billing( $plan ) {
    $period = sanitize_key( $plan['billing_period'] ?? '' );
    $price  = array_key_exists( 'price', $plan )
        ? ie_admin_sanitize_plan_price( $plan['price'] )
        : null;

    if ( ! in_array( $period, [ 'monthly', 'yearly' ], true ) ) {
        $monthly = ie_admin_sanitize_plan_price( $plan['monthly_price'] ?? '0' );
        $yearly  = ie_admin_sanitize_plan_price( $plan['yearly_price'] ?? '0' );

        if ( $yearly !== '0' && $monthly === '0' ) {
            $period = 'yearly';
            $price  = $yearly;
        } else {
            $period = 'monthly';
            $price  = $monthly !== '0' ? $monthly : $yearly;
        }
    }

    if ( $price === null || $price === '0' ) {
        $price = $period === 'yearly'
            ? ie_admin_sanitize_plan_price( $plan['yearly_price'] ?? '0' )
            : ie_admin_sanitize_plan_price( $plan['monthly_price'] ?? '0' );
    }

    if ( ! in_array( $period, [ 'monthly', 'yearly' ], true ) ) {
        $period = 'monthly';
    }

    return [
        'period' => $period,
        'price'  => $price,
    ];
}

function ie_admin_extract_plan_pricing( $plan, $existing = null ) {
    $existing_billing = $existing ? ie_admin_get_plan_billing( $existing ) : [
        'period' => 'monthly',
        'price'  => '0',
    ];

    $period = $existing_billing['period'];
    $price  = $existing_billing['price'];

    if ( ! empty( $plan['pricing'][0] ) && is_array( $plan['pricing'][0] ) ) {
        $row = $plan['pricing'][0];
        $period = sanitize_key( $row['period'] ?? $period );

        if ( ! in_array( $period, [ 'monthly', 'yearly' ], true ) ) {
            $period = 'monthly';
        }

        $price = ie_admin_sanitize_plan_price( $row['price'] ?? $price );
    } elseif ( array_key_exists( 'billing_period', $plan ) || array_key_exists( 'price', $plan ) ) {
        if ( array_key_exists( 'billing_period', $plan ) ) {
            $candidate = sanitize_key( $plan['billing_period'] );

            if ( in_array( $candidate, [ 'monthly', 'yearly' ], true ) ) {
                $period = $candidate;
            }
        }

        if ( array_key_exists( 'price', $plan ) ) {
            $price = ie_admin_sanitize_plan_price( $plan['price'] );
        }
    }

    return [
        'billing_period' => $period,
        'price'          => $price,
        'monthly_price'  => $period === 'monthly' ? $price : '0',
        'yearly_price'   => $period === 'yearly' ? $price : '0',
    ];
}

function ie_admin_sanitize_plan_price( $price ) {
    $price = sanitize_text_field( (string) $price );
    $price = str_replace( [ '$', ',', ' ' ], '', $price );

    if ( $price === '' ) {
        return '0';
    }

    if ( ! is_numeric( $price ) ) {
        $price = preg_replace( '/[^0-9.]/', '', $price );
    }

    return $price !== '' ? $price : '0';
}

function ie_format_subscription_price( $price ) {
    return '$' . ie_admin_sanitize_plan_price( $price );
}

function ie_get_active_subscription_plans() {
    $plans = ie_admin_get_subscription_plans();

    return array_values( array_filter( $plans, function ( $plan ) {
        return is_array( $plan ) && ( $plan['status'] ?? 'inactive' ) === 'active';
    } ) );
}

function ie_get_subscription_plan_slug( $plan_id ) {
    $slug = preg_replace( '/^plan-/', '', sanitize_key( (string) $plan_id ) );

    return $slug !== '' ? $slug : 'plan';
}

function ie_admin_get_subscription_plans() {
    $plans = get_option( IE_SUBSCRIPTION_PLANS_OPTION, [] );
    if ( ! is_array( $plans ) || ! $plans ) {
        $plans = ie_admin_get_default_subscription_plans();
        update_option( IE_SUBSCRIPTION_PLANS_OPTION, $plans, false );
    }

    $normalized = [];
    foreach ( $plans as $plan ) {
        $plan = ie_admin_normalize_subscription_plan( $plan );
        if ( ! empty( $plan['name'] ) ) {
            $normalized[] = $plan;
        }
    }

    return $normalized ?: ie_admin_get_default_subscription_plans();
}

function ie_admin_sanitize_subscription_plans( $plans ) {
    if ( ! is_array( $plans ) ) {
        return [];
    }

    $existing_by_id = [];
    foreach ( ie_admin_get_subscription_plans() as $existing_plan ) {
        if ( ! empty( $existing_plan['id'] ) ) {
            $existing_by_id[ $existing_plan['id'] ] = $existing_plan;
        }
    }

    $clean = [];
    foreach ( $plans as $plan ) {
        if ( ! is_array( $plan ) ) {
            continue;
        }

        $id       = sanitize_key( $plan['id'] ?? '' );
        $existing = ( $id !== '' && isset( $existing_by_id[ $id ] ) ) ? $existing_by_id[ $id ] : null;
        $normalized = ie_admin_normalize_subscription_plan( $plan, $existing );

        if ( ( $normalized['name'] ?? '' ) === '' ) {
            continue;
        }

        $clean[] = $normalized;
    }

    return array_values( $clean );
}

function ie_admin_normalize_subscription_plan( $plan, $existing = null ) {
    if ( ! is_array( $plan ) ) {
        return [];
    }

    $features = [];
    if ( ! empty( $plan['features'] ) && is_array( $plan['features'] ) ) {
        foreach ( $plan['features'] as $feature ) {
            $item = ie_admin_normalize_plan_feature( $feature );
            if ( $item['text'] !== '' ) {
                $features[] = $item;
            }
        }
    }

    $id = sanitize_key( $plan['id'] ?? '' );
    if ( $id === '' ) {
        $id = 'plan-' . wp_generate_password( 8, false, false );
    }

    $status = sanitize_key( $plan['status'] ?? 'active' );
    if ( ! in_array( $status, [ 'active', 'inactive' ], true ) ) {
        $status = 'inactive';
    }

    $pricing = ie_admin_extract_plan_pricing( $plan, $existing );

    return [
        'id'               => $id,
        'name'             => sanitize_text_field( $plan['name'] ?? '' ),
        'description'      => sanitize_textarea_field( $plan['description'] ?? '' ),
        'billing_period'   => $pricing['billing_period'],
        'price'            => $pricing['price'],
        'monthly_price'    => $pricing['monthly_price'],
        'yearly_price'     => $pricing['yearly_price'],
        'product_id'       => sanitize_text_field( $plan['product_id'] ?? ( $existing['product_id'] ?? '' ) ),
        'product_price_id' => sanitize_text_field( $plan['product_price_id'] ?? ( $existing['product_price_id'] ?? '' ) ),
        'status'           => $status,
        'features'         => $features,
    ];
}

function ie_admin_get_subscription_users( $args = [] ) {
    $search = sanitize_text_field( $args['search'] ?? '' );
    $status = sanitize_key( $args['status'] ?? '' );

    $query_args = [
        'meta_key'   => '_ie_user_type',
        'meta_value' => 'provider',
        'number'     => 100,
        'orderby'    => 'registered',
        'order'      => 'DESC',
    ];

    if ( $search !== '' ) {
        $query_args['search']         = '*' . $search . '*';
        $query_args['search_columns'] = [ 'user_login', 'user_email', 'display_name' ];
    }

    $users = get_users( $query_args );
    $rows  = [];

    foreach ( $users as $user ) {
        $sub = ie_get_user_subscription( $user->ID );

        if ( $status === 'active' && ! $sub['is_active'] ) {
            continue;
        }
        if ( $status === 'expired' && $sub['is_active'] ) {
            continue;
        }

        $rows[] = [
            'id'         => $user->ID,
            'name'       => $user->display_name,
            'email'      => $user->user_email,
            'plan'       => $sub['plan_label'],
            'billing'    => $sub['billing_label'],
            'status'     => $sub['is_active'] ? 'active' : 'expired',
            'registered' => mysql2date( get_option( 'date_format' ), get_date_from_gmt( $user->user_registered ) ),
        ];
    }

    return $rows;
}

function ie_admin_get_plan_label( $plan_id ) {
    $plans = ie_admin_get_subscription_plans();
    foreach ( $plans as $plan ) {
        if ( $plan['id'] === $plan_id ) {
            return $plan['name'];
        }
    }

    return $plan_id;
}

function ie_admin_render_subscription_user_rows( $rows ) {
    if ( ! $rows ) {
        echo '<tr><td colspan="7">' . esc_html( ie__( 'No subscription users found.' ) ) . '</td></tr>';
        return;
    }

    foreach ( $rows as $row ) {
        ?>
        <tr>
            <td><?php echo esc_html( $row['name'] ); ?></td>
            <td><?php echo esc_html( $row['email'] ); ?></td>
            <td><?php echo esc_html( $row['plan'] ); ?></td>
            <td><?php echo esc_html( $row['billing'] ); ?></td>
            <td><?php ie_admin_status_badge( $row['status'] ); ?></td>
            <td><?php echo esc_html( $row['registered'] ); ?></td>
            <td>
                <div class="ie-ad-actions">
                    <button type="button"
                            class="button button-link-delete ie-ad-sub-user-delete"
                            data-id="<?php echo esc_attr( (string) $row['id'] ); ?>">
                        <?php echo esc_html( ie__( 'Delete' ) ); ?>
                    </button>
                </div>
            </td>
        </tr>
        <?php
    }
}

function ie_admin_render_subscriptions_page() {
    if ( ! ie_admin_user_can() ) {
        return;
    }

    $current_page = ie_admin_get_current_page();
    $plans        = ie_admin_get_subscription_plans();
    $sub_settings = ie_get_subscription_settings();
    $sub_users    = ie_admin_get_subscription_users();
    $active_tab   = sanitize_key( wp_unslash( $_GET['sub_tab'] ?? 'users' ) );

    if ( ! in_array( $active_tab, [ 'users', 'plans', 'pricing-settings' ], true ) ) {
        $active_tab = 'users';
    }

    if ( isset( $_GET['plans-updated'] ) ) {
        $active_tab = 'plans';
    }

    ie_admin_render_shell_open( $current_page );

    if ( isset( $_GET['plans-updated'] ) ) {
        ie_admin_notice( ie__( 'Subscription plans saved successfully.' ) );
    }
    if ( isset( $_GET['pricing-settings-updated'] ) ) {
        $active_tab = 'pricing-settings';
        ie_admin_notice( ie__( 'Pricing page settings saved successfully.' ) );
    }
    if ( isset( $_GET['plans-error'] ) && $_GET['plans-error'] === 'empty' ) {
        ie_admin_notice( ie__( 'Please add at least one plan with a name before saving.' ), 'error' );
    }

    $tabs = [
        'users'            => ie__( 'Subscription Users' ),
        'plans'            => ie__( 'Manage Plans' ),
        'pricing-settings' => ie__( 'Pricing Page Settings' ),
    ];
    ?>
    <div class="ie-ad-subscriptions" data-section="subscriptions">
        <?php ie_admin_render_tabs( $tabs, $active_tab ); ?>

        <div class="ie-ad-tab-panel<?php echo $active_tab === 'users' ? ' is-active' : ''; ?>" data-tab-panel="users"<?php echo $active_tab === 'users' ? '' : ' hidden'; ?>>
            <?php
            ie_admin_render_toolbar(
                ie__( 'Search subscribers by name or email...' ),
                [
                    [
                        'id'      => 'ie-ad-sub-status',
                        'options' => [
                            ''        => ie__( 'All Statuses' ),
                            'active'  => ie__( 'Active' ),
                            'expired' => ie__( 'Expired' ),
                        ],
                    ],
                ]
            );
            ?>

            <div class="ie-ad-table-wrap">
                <table class="ie-ad-table" id="ie-ad-subscriptions-table">
                    <thead>
                        <tr>
                            <th><?php echo esc_html( ie__( 'Provider' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Email' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Plan' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Billing' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Status' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Registered' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Actions' ) ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php ie_admin_render_subscription_user_rows( $sub_users ); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="ie-ad-tab-panel<?php echo $active_tab === 'plans' ? ' is-active' : ''; ?>" data-tab-panel="plans"<?php echo $active_tab === 'plans' ? '' : ' hidden'; ?>>
            <div class="ie-ad-section-intro">
                <p><?php echo esc_html( ie__( 'Create and edit subscription plans, pricing, features, and availability. Active plans can be used on the pricing page.' ) ); ?></p>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="ie-ad-plans-form" novalidate>
                <?php wp_nonce_field( 'ie_save_subscription_plans', 'ie_subscription_plans_nonce' ); ?>
                <input type="hidden" name="action" value="ie_save_subscription_plans">

                <div class="ie-ad-card ie-ad-plans-board">
                    <div class="ie-ad-card-head ie-ad-plans-board__head">
                        <h3><?php echo esc_html( ie__( 'Subscription Plans' ) ); ?></h3>
                        <button type="button" class="button" id="ie-ad-add-plan">
                            <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
                            <?php echo esc_html( ie__( 'Add New Plan' ) ); ?>
                        </button>
                    </div>

                    <div class="ie-ad-plans-grid" id="ie-ad-plans-grid">
                        <?php foreach ( $plans as $index => $plan ) : ?>
                            <?php ie_admin_render_plan_grid_card( $plan, $index ); ?>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="ie-ad-actions-bar ie-ad-plans-form-actions">
                    <?php submit_button( ie__( 'Save Plans' ), 'primary', 'ie-ad-save-plans', false ); ?>
                </div>

                <div class="ie-ad-plan-editor-panel" id="ie-ad-plan-editor-panel" hidden>
                    <div class="ie-ad-card">
                        <div class="ie-ad-card-head">
                            <h3 id="ie-ad-plan-editor-title"><?php echo esc_html( ie__( 'Edit Plan' ) ); ?></h3>
                            <button type="button" class="ie-ad-plan-editor-close" aria-label="<?php echo esc_attr( ie__( 'Close' ) ); ?>">&times;</button>
                        </div>
                        <div id="ie-ad-plan-editor-slot"></div>
                        <div class="ie-ad-actions-bar ie-ad-actions-bar--split">
                            <button type="button" class="button ie-ad-plan-editor-close"><?php echo esc_html( ie__( 'Cancel' ) ); ?></button>
                            <?php submit_button( ie__( 'Save Plans' ), 'primary', 'submit', false ); ?>
                        </div>
                    </div>
                </div>

                <div id="ie-ad-plans-editors" class="ie-ad-plans-editors">
                    <?php foreach ( $plans as $index => $plan ) : ?>
                        <?php ie_admin_render_plan_editor( $plan, $index ); ?>
                    <?php endforeach; ?>
                </div>
            </form>

            <template id="ie-ad-plan-template">
                <?php ie_admin_render_plan_editor( [
                    'id'               => '',
                    'name'             => '',
                    'description'      => '',
                    'billing_period'   => 'monthly',
                    'price'            => '',
                    'monthly_price'    => '',
                    'yearly_price'     => '',
                    'product_id'       => '',
                    'product_price_id' => '',
                    'status'           => 'active',
                    'features'         => [
                        [
                            'text' => '',
                            'icon' => 'fa-solid fa-check',
                        ],
                    ],
                ], '__INDEX__' ); ?>
            </template>
        </div>

        <div class="ie-ad-tab-panel<?php echo $active_tab === 'pricing-settings' ? ' is-active' : ''; ?>" data-tab-panel="pricing-settings"<?php echo $active_tab === 'pricing-settings' ? '' : ' hidden'; ?>>
            <?php ie_admin_render_pricing_page_settings_tab( $sub_settings ); ?>
        </div>
    </div>
    <?php

    ie_admin_render_shell_close();
}

function ie_admin_render_pricing_page_settings_tab( $sub_settings ) {
    $trial_days = (int) ( $sub_settings['free_trial_days'] ?? 0 );
    $price_url  = ie_get_theme_page_url( 'price' );
    ?>
    <div class="ie-ad-pricing-settings">
        <div class="ie-ad-pricing-settings__hero">
            <div class="ie-ad-pricing-settings__hero-copy">
                <span class="ie-ad-pricing-settings__eyebrow"><?php echo esc_html( ie__( 'Configuration' ) ); ?></span>
                <h2 class="ie-ad-pricing-settings__title"><?php echo esc_html( ie__( 'Pricing Page Settings' ) ); ?></h2>
                <p class="ie-ad-pricing-settings__intro">
                    <?php echo esc_html( ie__( 'Control pricing page labels and the free trial experience for new service providers.' ) ); ?>
                </p>
            </div>
            <?php if ( $price_url ) : ?>
                <a href="<?php echo esc_url( $price_url ); ?>" class="button ie-ad-pricing-settings__preview" target="_blank" rel="noopener noreferrer">
                    <span class="dashicons dashicons-external" aria-hidden="true"></span>
                    <?php echo esc_html( ie__( 'View Pricing Page' ) ); ?>
                </a>
            <?php endif; ?>
        </div>

        <div class="ie-ad-pricing-settings__summary">
            <div class="ie-ad-pricing-settings__stat">
                <span class="ie-ad-pricing-settings__stat-label"><?php echo esc_html( ie__( 'Free Trial' ) ); ?></span>
                <strong class="ie-ad-pricing-settings__stat-value">
                    <?php
                    echo esc_html(
                        $trial_days > 0
                            ? sprintf( ie__( '%d days for new providers' ), $trial_days )
                            : ie__( 'Disabled' )
                    );
                    ?>
                </strong>
            </div>
            <div class="ie-ad-pricing-settings__stat">
                <span class="ie-ad-pricing-settings__stat-label"><?php echo esc_html( ie__( 'Yearly Badge' ) ); ?></span>
                <strong class="ie-ad-pricing-settings__stat-value">
                    <?php
                    $discount_text = trim( (string) ( $sub_settings['yearly_discount_text'] ?? '' ) );
                    echo esc_html( $discount_text !== '' ? $discount_text : ie__( 'Hidden' ) );
                    ?>
                </strong>
            </div>
        </div>

        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="ie-ad-pricing-settings-form" class="ie-ad-pricing-settings-form">
            <?php wp_nonce_field( 'ie_save_pricing_page_settings', 'ie_pricing_page_settings_nonce' ); ?>
            <input type="hidden" name="action" value="ie_save_pricing_page_settings">
            <input type="hidden" name="subscription_settings[__pricing_settings_form]" value="1">

            <div class="ie-ad-pricing-settings__sections">
                <section class="ie-ad-pricing-settings__section">
                    <header class="ie-ad-pricing-settings__section-head">
                        <span class="ie-ad-pricing-settings__section-icon" aria-hidden="true">
                            <span class="dashicons dashicons-tag"></span>
                        </span>
                        <div>
                            <h3><?php echo esc_html( ie__( 'Billing Display' ) ); ?></h3>
                            <p><?php echo esc_html( ie__( 'Customize how savings and billing options appear on the public pricing page.' ) ); ?></p>
                        </div>
                    </header>

                    <div class="ie-ad-pricing-settings__rows">
                        <div class="ie-ad-pricing-settings__row">
                            <div class="ie-ad-pricing-settings__row-copy">
                                <label for="ie-ad-yearly-discount-text"><?php echo esc_html( ie__( 'Yearly Discount Text' ) ); ?></label>
                                <p><?php echo esc_html( ie__( 'Shown beside the yearly billing toggle. Example: Save 17%. Leave blank to hide the badge.' ) ); ?></p>
                            </div>
                            <div class="ie-ad-pricing-settings__row-control">
                                <input type="text"
                                       class="regular-text ie-ad-pricing-settings__input"
                                       id="ie-ad-yearly-discount-text"
                                       name="subscription_settings[yearly_discount_text]"
                                       value="<?php echo esc_attr( $sub_settings['yearly_discount_text'] ?? '' ); ?>"
                                       placeholder="<?php echo esc_attr( ie__( 'Save 17%' ) ); ?>">
                            </div>
                        </div>
                    </div>
                </section>

                <section class="ie-ad-pricing-settings__section">
                    <header class="ie-ad-pricing-settings__section-head">
                        <span class="ie-ad-pricing-settings__section-icon" aria-hidden="true">
                            <span class="dashicons dashicons-clock"></span>
                        </span>
                        <div>
                            <h3><?php echo esc_html( ie__( 'Provider Free Trial' ) ); ?></h3>
                            <p><?php echo esc_html( ie__( 'Grant new service providers Basic Plan benefits automatically after registration.' ) ); ?></p>
                        </div>
                    </header>

                    <div class="ie-ad-pricing-settings__rows">
                        <div class="ie-ad-pricing-settings__row">
                            <div class="ie-ad-pricing-settings__row-copy">
                                <label for="ie-ad-free-trial-days"><?php echo esc_html( ie__( 'Free Trial Days' ) ); ?></label>
                                <p><?php echo esc_html( ie__( 'Type the trial duration in days (for example 7, 14, or 30). New providers receive Basic Plan benefits for that many days after registration. Enter 0 to disable free trials.' ) ); ?></p>
                            </div>
                            <div class="ie-ad-pricing-settings__row-control">
                                <input type="number"
                                       class="regular-text ie-ad-pricing-settings__input"
                                       id="ie-ad-free-trial-days"
                                       name="subscription_settings[free_trial_days]"
                                       min="0"
                                       max="365"
                                       step="1"
                                       value="<?php echo esc_attr( (string) $trial_days ); ?>"
                                       placeholder="<?php echo esc_attr( ie__( '14' ) ); ?>">
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <div class="ie-ad-pricing-settings__footer">
                <p class="ie-ad-pricing-settings__footer-note">
                    <span class="dashicons dashicons-info" aria-hidden="true"></span>
                    <?php echo esc_html( ie__( 'Changes are saved to the database and apply immediately across the site.' ) ); ?>
                </p>
                <?php submit_button( ie__( 'Save Settings' ), 'primary large', 'ie-ad-save-pricing-settings', false ); ?>
            </div>
        </form>
    </div>
    <?php
}

function ie_admin_render_plan_grid_card( $plan, $index ) {
    $features     = ie_admin_get_plan_editor_features( $plan );
    $billing      = ie_admin_get_plan_billing( $plan );
    $status       = $plan['status'] ?? 'active';
    $display_name = $plan['name'] ?? ie__( 'Untitled Plan' );
    $period_label = $billing['period'] === 'yearly' ? ie__( '/ year' ) : ie__( '/ month' );
    ?>
    <article class="ie-ad-sub-plan-card<?php echo $status !== 'active' ? ' is-inactive' : ''; ?>" data-plan-index="<?php echo esc_attr( (string) $index ); ?>">
        <div class="ie-ad-sub-plan-card__head">
            <h4 class="ie-ad-sub-plan-card__name"><?php echo esc_html( $display_name ); ?></h4>
            <div class="ie-ad-sub-plan-card__prices">
                <p class="ie-ad-sub-plan-card__price">
                    <strong><?php echo esc_html( ie_format_subscription_price( $billing['price'] ) ); ?></strong>
                    <span><?php echo esc_html( $period_label ); ?></span>
                </p>
            </div>
            <?php if ( $status !== 'active' ) : ?>
                <span class="ie-ad-sub-plan-card__badge"><?php echo esc_html( ie__( 'Inactive' ) ); ?></span>
            <?php endif; ?>
        </div>

        <ul class="ie-ad-sub-plan-card__features">
            <?php foreach ( $features as $feature ) : ?>
                <?php if ( ( $feature['text'] ?? '' ) === '' ) : ?>
                    <?php continue; ?>
                <?php endif; ?>
                <li>
                    <?php $icon = ie_admin_resolve_plan_feature_icon( $feature['icon'] ?? 'fa-solid fa-check' ); ?>
                    <span class="ie-ad-sub-plan-card__feat-icon <?php echo esc_attr( ie_admin_get_plan_feature_icon_modifier( $icon ) ); ?>" aria-hidden="true">
                        <i class="<?php echo esc_attr( $icon ); ?>"></i>
                    </span>
                    <?php echo esc_html( $feature['text'] ); ?>
                </li>
            <?php endforeach; ?>
        </ul>

        <div class="ie-ad-sub-plan-card__actions">
            <button type="button" class="button ie-ad-edit-plan">
                <span class="dashicons dashicons-edit" aria-hidden="true"></span>
                <?php echo esc_html( ie__( 'Edit' ) ); ?>
            </button>
            <button type="button" class="button ie-ad-remove-plan-grid">
                <span class="dashicons dashicons-trash" aria-hidden="true"></span>
                <?php echo esc_html( ie__( 'Delete' ) ); ?>
            </button>
        </div>
    </article>
    <?php
}

function ie_admin_render_plan_feature_row( $index, $feature_index, $feature ) {
    $feature  = ie_admin_normalize_plan_feature( $feature );
    $options  = ie_admin_get_plan_feature_icon_options();
    $selected = ie_admin_resolve_plan_feature_icon( $feature['icon'] );
    ?>
    <div class="ie-ad-repeater-row ie-ad-feature-row">
        <div class="ie-ad-feature-icon-field">
            <span class="ie-ad-feature-icon-preview <?php echo esc_attr( ie_admin_get_plan_feature_icon_modifier( $selected ) ); ?>" aria-hidden="true">
                <i class="<?php echo esc_attr( $selected ); ?>"></i>
            </span>
            <select class="ie-ad-feature-icon-select"
                    name="plans[<?php echo esc_attr( (string) $index ); ?>][features][<?php echo esc_attr( (string) $feature_index ); ?>][icon]"
                    aria-label="<?php echo esc_attr( ie__( 'Feature icon' ) ); ?>">
                <?php foreach ( $options as $icon_class => $label ) : ?>
                    <option value="<?php echo esc_attr( $icon_class ); ?>" <?php selected( $selected, $icon_class ); ?>>
                        <?php echo esc_html( $label ); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <input type="text"
               class="ie-ad-feature-text-input"
               name="plans[<?php echo esc_attr( (string) $index ); ?>][features][<?php echo esc_attr( (string) $feature_index ); ?>][text]"
               value="<?php echo esc_attr( $feature['text'] ); ?>"
               placeholder="<?php echo esc_attr( ie__( 'Feature text' ) ); ?>">
        <button type="button" class="button ie-ad-remove-feature"><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
    </div>
    <?php
}

function ie_admin_render_plan_pricing_fields( $index, $plan ) {
    $billing = ie_admin_get_plan_billing( $plan );
    $options = ie_admin_get_plan_pricing_period_options();
    ?>
    <div class="ie-ad-plan-pricing-fixed">
        <div class="ie-ad-pricing-row">
            <select class="ie-ad-pricing-period-select"
                    name="plans[<?php echo esc_attr( (string) $index ); ?>][pricing][0][period]"
                    aria-label="<?php echo esc_attr( ie__( 'Billing period' ) ); ?>">
                <?php foreach ( $options as $value => $label ) : ?>
                    <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $billing['period'], $value ); ?>>
                        <?php echo esc_html( $label ); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="text"
                   class="ie-ad-pricing-price-input"
                   name="plans[<?php echo esc_attr( (string) $index ); ?>][pricing][0][price]"
                   value="<?php echo esc_attr( $billing['price'] === '0' ? '' : $billing['price'] ); ?>"
                   placeholder="<?php echo esc_attr( ie__( 'Price' ) ); ?>"
                   aria-label="<?php echo esc_attr( ie__( 'Plan price' ) ); ?>">
        </div>
        <div class="ie-ad-grid ie-ad-grid-2 ie-ad-pricing-product-row">
            <div class="ie-ad-field">
                <label><?php echo esc_html( ie__( 'Product ID' ) ); ?></label>
                <input type="text"
                       name="plans[<?php echo esc_attr( (string) $index ); ?>][product_id]"
                       value="<?php echo esc_attr( $plan['product_id'] ?? '' ); ?>"
                       placeholder="<?php echo esc_attr( ie__( 'e.g. prod_...' ) ); ?>"
                       aria-label="<?php echo esc_attr( ie__( 'Product ID' ) ); ?>">
            </div>
            <div class="ie-ad-field">
                <label><?php echo esc_html( ie__( 'Product Price ID' ) ); ?></label>
                <input type="text"
                       name="plans[<?php echo esc_attr( (string) $index ); ?>][product_price_id]"
                       value="<?php echo esc_attr( $plan['product_price_id'] ?? '' ); ?>"
                       placeholder="<?php echo esc_attr( ie__( 'e.g. price_...' ) ); ?>"
                       aria-label="<?php echo esc_attr( ie__( 'Product Price ID' ) ); ?>">
            </div>
        </div>
    </div>
    <?php
}

function ie_admin_render_plan_editor( $plan, $index ) {
    $features = ie_admin_get_plan_editor_features( $plan );
    ?>
    <div class="ie-ad-plan-editor" data-plan-index="<?php echo esc_attr( (string) $index ); ?>" hidden>
        <input type="hidden" name="plans[<?php echo esc_attr( (string) $index ); ?>][id]" value="<?php echo esc_attr( $plan['id'] ?? '' ); ?>">

        <div class="ie-ad-grid ie-ad-grid-2">
            <div class="ie-ad-field">
                <label><?php echo esc_html( ie__( 'Plan Name' ) ); ?></label>
                <input type="text" name="plans[<?php echo esc_attr( (string) $index ); ?>][name]" value="<?php echo esc_attr( $plan['name'] ?? '' ); ?>">
            </div>
            <div class="ie-ad-field">
                <label><?php echo esc_html( ie__( 'Plan Status' ) ); ?></label>
                <select name="plans[<?php echo esc_attr( (string) $index ); ?>][status]">
                    <option value="active" <?php selected( $plan['status'] ?? '', 'active' ); ?>><?php echo esc_html( ie__( 'Active' ) ); ?></option>
                    <option value="inactive" <?php selected( $plan['status'] ?? '', 'inactive' ); ?>><?php echo esc_html( ie__( 'Inactive' ) ); ?></option>
                </select>
            </div>
        </div>

        <div class="ie-ad-field">
            <label><?php echo esc_html( ie__( 'Plan Description' ) ); ?></label>
            <textarea name="plans[<?php echo esc_attr( (string) $index ); ?>][description]" rows="2"><?php echo esc_textarea( $plan['description'] ?? '' ); ?></textarea>
        </div>

        <div class="ie-ad-field">
            <label><?php echo esc_html( ie__( 'Plan Pricing' ) ); ?></label>
            <p class="ie-ad-field-hint"><?php echo esc_html( ie__( 'Select Monthly or Yearly and enter the price.' ) ); ?></p>
            <?php ie_admin_render_plan_pricing_fields( $index, $plan ); ?>
        </div>

        <div class="ie-ad-field">
            <label><?php echo esc_html( ie__( 'Plan Features' ) ); ?></label>
            <p class="ie-ad-field-hint"><?php echo esc_html( ie__( 'Choose an icon (Check, Cross, or Star) for each feature.' ) ); ?></p>
            <div class="ie-ad-repeater ie-ad-features-repeater">
                <?php foreach ( $features as $feature_index => $feature ) : ?>
                    <?php ie_admin_render_plan_feature_row( $index, $feature_index, $feature ); ?>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button ie-ad-add-feature"><?php echo esc_html( ie__( 'Add Feature' ) ); ?></button>
        </div>

        <div class="ie-ad-actions-bar ie-ad-actions-bar--split">
            <button type="button" class="button-link-delete ie-ad-remove-plan"><?php echo esc_html( ie__( 'Delete Plan' ) ); ?></button>
        </div>
    </div>
    <?php
}

function ie_handle_save_subscription_plans() {
    ie_admin_verify_post( 'ie_save_subscription_plans', 'ie_subscription_plans_nonce' );

    $input = isset( $_POST['plans'] ) ? wp_unslash( $_POST['plans'] ) : [];
    $plans = ie_admin_sanitize_subscription_plans( $input );

    if ( ! $plans ) {
        wp_safe_redirect(
            add_query_arg(
                [
                    'plans-error' => 'empty',
                    'sub_tab'     => 'plans',
                ],
                admin_url( 'admin.php?page=ie-admin-subscriptions' )
            )
        );
        exit;
    }

    update_option( IE_SUBSCRIPTION_PLANS_OPTION, $plans, false );

    wp_safe_redirect(
        add_query_arg(
            [
                'plans-updated' => '1',
                'sub_tab'       => 'plans',
            ],
            admin_url( 'admin.php?page=ie-admin-subscriptions' )
        )
    );
    exit;
}
add_action( 'admin_post_ie_save_subscription_plans', 'ie_handle_save_subscription_plans' );

function ie_handle_save_pricing_page_settings() {
    ie_admin_verify_post( 'ie_save_pricing_page_settings', 'ie_pricing_page_settings_nonce' );

    $settings_input = isset( $_POST['subscription_settings'] ) ? wp_unslash( $_POST['subscription_settings'] ) : [];
    $settings       = ie_admin_sanitize_subscription_settings( $settings_input );

    update_option( IE_SUBSCRIPTION_SETTINGS_OPTION, $settings, false );

    wp_safe_redirect(
        add_query_arg(
            [
                'pricing-settings-updated' => '1',
                'sub_tab'                  => 'pricing-settings',
            ],
            admin_url( 'admin.php?page=ie-admin-subscriptions' )
        )
    );
    exit;
}
add_action( 'admin_post_ie_save_pricing_page_settings', 'ie_handle_save_pricing_page_settings' );

function ie_ajax_admin_get_subscription_users() {
    ie_admin_verify_request( 'ie_admin_dashboard', 'nonce' );

    $rows = ie_admin_get_subscription_users( [
        'search' => sanitize_text_field( wp_unslash( $_POST['search'] ?? '' ) ),
        'status' => sanitize_key( wp_unslash( $_POST['status'] ?? '' ) ),
    ] );

    ob_start();
    ie_admin_render_subscription_user_rows( $rows );
    $html = ob_get_clean();

    wp_send_json_success( [
        'html'  => $html,
        'total' => count( $rows ),
    ] );
}
add_action( 'wp_ajax_ie_admin_get_subscription_users', 'ie_ajax_admin_get_subscription_users' );

