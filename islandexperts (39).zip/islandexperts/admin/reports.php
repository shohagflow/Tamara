<?php
/**
 * Island Experts Admin — reports module.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_admin_get_date_range( $range, $custom_start = '', $custom_end = '' ) {
    $today = current_time( 'Y-m-d' );

    switch ( $range ) {
        case 'today':
            return [ $today, $today ];
        case '7days':
            return [ gmdate( 'Y-m-d', strtotime( '-6 days', current_time( 'timestamp' ) ) ), $today ];
        case '30days':
            return [ gmdate( 'Y-m-d', strtotime( '-29 days', current_time( 'timestamp' ) ) ), $today ];
        case 'custom':
            $start = $custom_start ?: $today;
            $end   = $custom_end ?: $today;
            return [ $start, $end ];
        default:
            return [ '', '' ];
    }
}

function ie_admin_get_report_rows( $report_type, $date_start = '', $date_end = '' ) {
    switch ( $report_type ) {
        case 'users_all':
            return ie_admin_get_report_users( '', $date_start, $date_end );
        case 'users_clients':
            return ie_admin_get_report_users( 'customer', $date_start, $date_end );
        case 'users_providers':
            return ie_admin_get_report_users( 'provider', $date_start, $date_end );
        case 'subs_active':
            return ie_admin_get_report_subscriptions( 'active', $date_start, $date_end );
        case 'subs_expired':
            return ie_admin_get_report_subscriptions( 'expired', $date_start, $date_end );
        case 'payments_success':
            return ie_admin_get_report_payments( 'success', $date_start, $date_end );
        case 'payments_failed':
            return ie_admin_get_report_payments( 'failed', $date_start, $date_end );
        case 'revenue':
            return ie_admin_get_report_revenue( $date_start, $date_end );
        default:
            return [];
    }
}

function ie_admin_get_report_users( $type = '', $date_start = '', $date_end = '' ) {
    $args = [ 'number' => 500, 'orderby' => 'registered', 'order' => 'DESC' ];

    if ( in_array( $type, [ 'customer', 'provider' ], true ) ) {
        $args['meta_query'] = [
            [ 'key' => '_ie_user_type', 'value' => $type ],
        ];
    }

    $users = get_users( $args );
    $rows  = [];

    foreach ( $users as $user ) {
        $registered = mysql2date( 'Y-m-d', get_date_from_gmt( $user->user_registered ) );
        if ( $date_start && $registered < $date_start ) {
            continue;
        }
        if ( $date_end && $registered > $date_end ) {
            continue;
        }

        $rows[] = [
            ie__( 'Name' )     => $user->display_name,
            ie__( 'Email' )    => $user->user_email,
            ie__( 'Type' )     => ie_get_user_type( $user->ID ),
            ie__( 'Status' )   => ie_get_user_account_status( $user->ID ),
            ie__( 'Registered' ) => $registered,
        ];
    }

    return $rows;
}

function ie_admin_get_report_subscriptions( $status, $date_start = '', $date_end = '' ) {
    $users = get_users( [
        'meta_key'   => '_ie_user_type',
        'meta_value' => 'provider',
        'number'     => 500,
    ] );

    $rows = [];
    foreach ( $users as $user ) {
        $sub = ie_get_user_subscription( $user->ID );
        $is_active = $sub['is_active'];

        if ( $status === 'active' && ! $is_active ) {
            continue;
        }
        if ( $status === 'expired' && $is_active ) {
            continue;
        }

        $registered = mysql2date( 'Y-m-d', get_date_from_gmt( $user->user_registered ) );
        if ( $date_start && $registered < $date_start ) {
            continue;
        }
        if ( $date_end && $registered > $date_end ) {
            continue;
        }

        $rows[] = [
            ie__( 'Provider' )   => $user->display_name,
            ie__( 'Email' )      => $user->user_email,
            ie__( 'Plan' )       => $sub['plan_label'],
            ie__( 'Billing' )    => $sub['billing_label'],
            ie__( 'Status' )    => $sub['status_label'],
            ie__( 'Registered' ) => $registered,
        ];
    }

    return $rows;
}

function ie_admin_get_report_payments( $status, $date_start = '', $date_end = '' ) {
    $logs = ie_admin_get_payment_logs( 200 );
    $rows = [];

    foreach ( $logs as $log ) {
        if ( ( $log['status'] ?? '' ) !== $status ) {
            continue;
        }

        $date = substr( (string) ( $log['date'] ?? '' ), 0, 10 );
        if ( $date_start && $date < $date_start ) {
            continue;
        }
        if ( $date_end && $date > $date_end ) {
            continue;
        }

        $rows[] = [
            ie__( 'Date' )    => $log['date'] ?? '',
            ie__( 'Status' )  => $log['status'] ?? '',
            ie__( 'Amount' )  => $log['amount'] ?? '0.00',
            ie__( 'Message' ) => $log['message'] ?? '',
        ];
    }

    return $rows;
}

function ie_admin_get_report_revenue( $date_start = '', $date_end = '' ) {
    $logs  = ie_admin_get_payment_logs( 200 );
    $total = 0;
    $rows  = [];

    foreach ( $logs as $log ) {
        if ( ( $log['status'] ?? '' ) !== 'success' ) {
            continue;
        }

        $date = substr( (string) ( $log['date'] ?? '' ), 0, 10 );
        if ( $date_start && $date < $date_start ) {
            continue;
        }
        if ( $date_end && $date > $date_end ) {
            continue;
        }

        $amount = (float) ( $log['amount'] ?? 0 );
        $total += $amount;

        $rows[] = [
            ie__( 'Date' )    => $log['date'] ?? '',
            ie__( 'Amount' )  => number_format( $amount, 2 ),
            ie__( 'Message' ) => $log['message'] ?? '',
        ];
    }

    array_unshift( $rows, [
        ie__( 'Date' )    => ie__( 'Total Revenue' ),
        ie__( 'Amount' )  => number_format( $total, 2 ),
        ie__( 'Message' ) => '',
    ] );

    return $rows;
}

function ie_admin_get_report_headers( $rows ) {
    if ( ! $rows ) {
        return [ ie__( 'No Data' ) ];
    }

    return array_keys( $rows[0] );
}

function ie_admin_export_csv( $filename, $rows ) {
    nocache_headers();
    header( 'Content-Type: text/csv; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '.csv"' );

    $output = fopen( 'php://output', 'w' );
    if ( ! $output ) {
        exit;
    }

    $headers = ie_admin_get_report_headers( $rows );
    fputcsv( $output, $headers );

    foreach ( $rows as $row ) {
        fputcsv( $output, array_values( $row ) );
    }

    fclose( $output );
    exit;
}

function ie_admin_export_pdf( $title, $rows ) {
    require_once get_template_directory() . '/inc/invoice-pdf-generator.php';

    $headers  = ie_admin_get_report_headers( $rows );
    $pdf      = ( new IE_Admin_Report_Pdf_Generator() )->generate( $title, $headers, $rows );
    $filename = sanitize_file_name( $title ) . '.pdf';

    nocache_headers();
    header( 'Content-Type: application/pdf' );
    header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
    header( 'Content-Length: ' . strlen( $pdf ) );
    header( 'X-Robots-Tag: noindex, nofollow', true );

    echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    exit;
}

class IE_Admin_Report_Pdf_Generator {
    private $objects = [];
    private $offsets = [];
    private $page_w  = 595.28;
    private $page_h  = 841.89;
    private $margin  = 42;
    private $primary = [ 45, 106, 143 ];
    private $light   = [ 232, 242, 247 ];

    public function generate( $title, array $headers, array $rows ) {
        $settings      = ie_get_theme_settings();
        $this->primary = ie_theme_hex_to_rgb( $settings['color_primary'] ?? '#2d6a8f' );
        $this->light   = ie_theme_hex_to_rgb( '#e8f2f7' );

        $pages_streams = $this->build_page_streams( $title, $headers, $rows );

        return $this->assemble_pdf( $pages_streams );
    }

    private function build_page_streams( $title, array $headers, array $rows ) {
        $streams      = [];
        $parts        = [];
        $col_count    = max( 1, count( $headers ) );
        $table_width  = $this->page_w - ( $this->margin * 2 );
        $col_width    = $table_width / $col_count;
        $bottom_limit = 72;
        $row_height   = 18;
        $is_first     = true;
        $y            = 0;

        $start_page = function () use ( &$parts, &$y, $title, &$is_first ) {
            $parts = [];
            $y     = $this->page_h - $this->margin;

            $this->rect_fill( $parts, 0, $this->page_h - 88, $this->page_w, 88, $this->primary );
            $this->text( $parts, $this->margin, $this->page_h - 42, '/F2', 18, $title, [ 255, 255, 255 ] );
            $this->text(
                $parts,
                $this->margin,
                $this->page_h - 62,
                '/F1',
                10,
                sprintf( ie__( 'Generated on %s' ), current_time( 'Y-m-d H:i' ) ),
                [ 255, 255, 255 ]
            );

            if ( ! $is_first ) {
                $this->text( $parts, $this->page_w - $this->margin - 80, $this->page_h - 42, '/F1', 9, ie__( 'Continued' ), [ 255, 255, 255 ] );
            }

            $y = $this->page_h - 108;
            $is_first = false;
        };

        $draw_table_header = function () use ( &$parts, &$y, $headers, $col_width, $row_height ) {
            $this->rect_fill( $parts, $this->margin, $y - 4, $this->page_w - ( $this->margin * 2 ), $row_height + 4, $this->primary );

            foreach ( $headers as $index => $header ) {
                $x = $this->margin + 8 + ( $index * $col_width );
                $this->text( $parts, $x, $y, '/F2', 9, strtoupper( (string) $header ), [ 255, 255, 255 ] );
            }

            $y -= ( $row_height + 8 );
        };

        $start_page();
        $draw_table_header();

        if ( ! $rows ) {
            $this->text( $parts, $this->margin + 8, $y, '/F1', 10, ie__( 'No records found.' ), [ 26, 35, 50 ] );
            $streams[] = implode( "\n", $parts );
            return $streams;
        }

        foreach ( $rows as $row_index => $row ) {
            if ( $y < $bottom_limit ) {
                $streams[] = implode( "\n", $parts );
                $start_page();
                $draw_table_header();
            }

            if ( $row_index % 2 === 1 ) {
                $this->rect_fill( $parts, $this->margin, $y - 4, $this->page_w - ( $this->margin * 2 ), $row_height, $this->light );
            }

            $values = array_values( $row );
            foreach ( $headers as $index => $header ) {
                $cell = isset( $values[ $index ] ) ? (string) $values[ $index ] : '';
                $x    = $this->margin + 8 + ( $index * $col_width );
                $this->text( $parts, $x, $y, '/F1', 9, $this->truncate_cell( $cell, $col_width ), [ 26, 35, 50 ] );
            }

            $y -= $row_height;
        }

        $streams[] = implode( "\n", $parts );

        return $streams;
    }

    private function truncate_cell( $text, $col_width ) {
        $text = wp_strip_all_tags( (string) $text );
        $max  = max( 8, (int) floor( $col_width / 5.5 ) );

        if ( strlen( $text ) <= $max ) {
            return $text;
        }

        return substr( $text, 0, max( 1, $max - 3 ) ) . '...';
    }

    private function assemble_pdf( array $pages_streams ) {
        $this->objects = [];
        $this->offsets = [];

        $font_regular = $this->add_object( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>' );
        $font_bold    = $this->add_object( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>' );
        $resources    = '<< /Font << /F1 ' . $font_regular . ' 0 R /F2 ' . $font_bold . ' 0 R >> >>';

        $page_objs = [];
        foreach ( $pages_streams as $stream ) {
            $content_obj = $this->add_object( '<< /Length ' . strlen( $stream ) . " >>\nstream\n" . $stream . "\nendstream" );
            $page_objs[] = $this->add_object(
                '<< /Type /Page /Parent PAGES_PLACEHOLDER /MediaBox [0 0 595.28 841.89] /Resources '
                . $resources . ' /Contents ' . $content_obj . ' 0 R >>'
            );
        }

        $kids      = implode( ' ', array_map( static function ( $object_id ) {
            return $object_id . ' 0 R';
        }, $page_objs ) );
        $pages_obj = $this->add_object( '<< /Type /Pages /Kids [' . $kids . '] /Count ' . count( $page_objs ) . ' >>' );

        foreach ( $page_objs as $page_obj ) {
            $this->objects[ $page_obj - 1 ] = str_replace( 'PAGES_PLACEHOLDER', $pages_obj . ' 0 R', $this->objects[ $page_obj - 1 ] );
        }

        $catalog_obj = $this->add_object( '<< /Type /Catalog /Pages ' . $pages_obj . ' 0 R >>' );

        $pdf = "%PDF-1.4\n";
        foreach ( $this->objects as $index => $object ) {
            $this->offsets[ $index + 1 ] = strlen( $pdf );
            $pdf .= ( $index + 1 ) . " 0 obj\n" . $object . "\nendobj\n";
        }

        $xref_offset = strlen( $pdf );
        $pdf .= "xref\n0 " . ( count( $this->objects ) + 1 ) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ( $i = 1; $i <= count( $this->objects ); $i++ ) {
            $pdf .= sprintf( "%010d 00000 n \n", $this->offsets[ $i ] );
        }

        $pdf .= "trailer\n<< /Size " . ( count( $this->objects ) + 1 ) . ' /Root ' . $catalog_obj . " 0 R >>\n";
        $pdf .= "startxref\n" . $xref_offset . "\n%%EOF";

        return $pdf;
    }

    private function add_object( $body ) {
        $this->objects[] = $body;
        return count( $this->objects );
    }

    private function rect_fill( array &$parts, $x, $y, $w, $h, array $rgb ) {
        $parts[] = sprintf( '%.3F %.3F %.3F rg', $rgb[0] / 255, $rgb[1] / 255, $rgb[2] / 255 );
        $parts[] = $x . ' ' . $y . ' ' . $w . ' ' . $h . ' re f';
    }

    private function text( array &$parts, $x, $y, $font, $size, $text, array $rgb ) {
        $parts[] = sprintf( '%.3F %.3F %.3F rg', $rgb[0] / 255, $rgb[1] / 255, $rgb[2] / 255 );
        $parts[] = 'BT';
        $parts[] = $font . ' ' . $size . ' Tf';
        $parts[] = '1 0 0 1 ' . $x . ' ' . $y . ' Tm';
        $parts[] = '(' . ie_invoice_pdf_escape_text( $text ) . ') Tj';
        $parts[] = 'ET';
    }
}

function ie_admin_get_dashboard_stats() {
    $users      = count_users();
    $clients    = count( get_users( [ 'meta_key' => '_ie_user_type', 'meta_value' => 'customer', 'fields' => 'ID' ] ) );
    $providers  = count( get_users( [ 'meta_key' => '_ie_user_type', 'meta_value' => 'provider', 'fields' => 'ID' ] ) );
    $reviews    = (int) get_comments( [ 'type' => 'ie_review', 'count' => true ] );
    $active_subs = count( ie_admin_get_subscription_users( [ 'status' => 'active' ] ) );
    $suspended  = count( get_users( [
        'meta_key'   => '_ie_account_status',
        'meta_value' => 'suspended',
        'fields'     => 'ID',
    ] ) );

    return [
        'total_users'      => (int) ( $users['total_users'] ?? 0 ),
        'clients'          => $clients,
        'providers'        => $providers,
        'reviews'          => $reviews,
        'active_subs'      => $active_subs,
        'suspended_users'  => $suspended,
        'payment_logs'     => count( ie_admin_get_payment_logs() ),
    ];
}

function ie_admin_render_reports_page() {
    if ( ! ie_admin_user_can() ) {
        return;
    }

    $current_page = ie_admin_get_current_page();
    ie_admin_render_shell_open( $current_page );

    $report_groups = [
        'users' => [
            'label'   => ie__( 'User Reports' ),
            'options' => [
                'users_all'       => ie__( 'All Users' ),
                'users_clients'   => ie__( 'Clients' ),
                'users_providers' => ie__( 'Service Providers' ),
            ],
        ],
        'subscriptions' => [
            'label'   => ie__( 'Subscription Reports' ),
            'options' => [
                'subs_active'  => ie__( 'Active Subscriptions' ),
                'subs_expired' => ie__( 'Expired Subscriptions' ),
            ],
        ],
        'payments' => [
            'label'   => ie__( 'Payment Reports' ),
            'options' => [
                'payments_success' => ie__( 'Successful Payments' ),
                'payments_failed'  => ie__( 'Failed Payments' ),
            ],
        ],
        'revenue' => [
            'label'   => ie__( 'Revenue Reports' ),
            'options' => [
                'revenue' => ie__( 'Revenue Summary' ),
            ],
        ],
    ];
    ?>
    <div class="ie-ad-reports" data-section="reports">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="ie-ad-export-form">
            <?php wp_nonce_field( 'ie_admin_export_report', 'ie_export_nonce' ); ?>
            <input type="hidden" name="action" value="ie_admin_export_report">

            <div class="ie-ad-grid ie-ad-grid-2">
                <div class="ie-ad-card">
                    <h3><?php echo esc_html( ie__( 'Report Type' ) ); ?></h3>
                    <div class="ie-ad-field">
                        <label for="ie-ad-report-type"><?php echo esc_html( ie__( 'Select Report' ) ); ?></label>
                        <select name="report_type" id="ie-ad-report-type">
                            <?php foreach ( $report_groups as $group ) : ?>
                                <optgroup label="<?php echo esc_attr( $group['label'] ); ?>">
                                    <?php foreach ( $group['options'] as $value => $label ) : ?>
                                        <option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="ie-ad-card">
                    <h3><?php echo esc_html( ie__( 'Date Filter' ) ); ?></h3>
                    <div class="ie-ad-field">
                        <label><?php echo esc_html( ie__( 'Range' ) ); ?></label>
                        <select name="date_range" id="ie-ad-date-range">
                            <option value=""><?php echo esc_html( ie__( 'All Time' ) ); ?></option>
                            <option value="today"><?php echo esc_html( ie__( 'Today' ) ); ?></option>
                            <option value="7days"><?php echo esc_html( ie__( 'Last 7 Days' ) ); ?></option>
                            <option value="30days"><?php echo esc_html( ie__( 'Last 30 Days' ) ); ?></option>
                            <option value="custom"><?php echo esc_html( ie__( 'Custom Date Range' ) ); ?></option>
                        </select>
                    </div>
                    <div class="ie-ad-grid ie-ad-grid-2 ie-ad-custom-dates" hidden>
                        <div class="ie-ad-field">
                            <label><?php echo esc_html( ie__( 'Start Date' ) ); ?></label>
                            <input type="date" name="date_start">
                        </div>
                        <div class="ie-ad-field">
                            <label><?php echo esc_html( ie__( 'End Date' ) ); ?></label>
                            <input type="date" name="date_end">
                        </div>
                    </div>
                </div>
            </div>

            <div class="ie-ad-actions-bar">
                <button type="submit" name="export_format" value="csv" class="button"><?php echo esc_html( ie__( 'Export CSV' ) ); ?></button>
                <button type="submit" name="export_format" value="pdf" class="button button-primary"><?php echo esc_html( ie__( 'Download PDF' ) ); ?></button>
            </div>
        </form>
    </div>
    <?php

    ie_admin_render_shell_close();
}

function ie_handle_admin_export_report() {
    ie_admin_verify_post( 'ie_admin_export_report', 'ie_export_nonce' );

    $report_type = sanitize_key( $_POST['report_type'] ?? 'users_all' );
    $date_range  = sanitize_key( $_POST['date_range'] ?? '' );
    $date_start  = sanitize_text_field( wp_unslash( $_POST['date_start'] ?? '' ) );
    $date_end    = sanitize_text_field( wp_unslash( $_POST['date_end'] ?? '' ) );
    $format      = sanitize_key( $_POST['export_format'] ?? 'csv' );

    [ $start, $end ] = ie_admin_get_date_range( $date_range, $date_start, $date_end );
    $rows             = ie_admin_get_report_rows( $report_type, $start, $end );
    $title            = ucwords( str_replace( '_', ' ', $report_type ) );

    if ( $format === 'pdf' ) {
        ie_admin_export_pdf( $title, $rows );
    }

    ie_admin_export_csv( $title, $rows );
}
add_action( 'admin_post_ie_admin_export_report', 'ie_handle_admin_export_report' );

function ie_admin_render_dashboard_page() {
    if ( ! ie_admin_user_can() ) {
        return;
    }

    $current_page = ie_admin_get_current_page();
    $stats        = ie_admin_get_dashboard_stats();

    ie_admin_render_shell_open( $current_page );
    ?>
    <div class="ie-ad-stats-grid">
        <?php
        $cards = [
            [ 'label' => ie__( 'Total Users' ), 'value' => $stats['total_users'], 'icon' => 'dashicons-groups' ],
            [ 'label' => ie__( 'Clients' ), 'value' => $stats['clients'], 'icon' => 'dashicons-admin-users' ],
            [ 'label' => ie__( 'Service Providers' ), 'value' => $stats['providers'], 'icon' => 'dashicons-businessman' ],
            [ 'label' => ie__( 'Active Subscriptions' ), 'value' => $stats['active_subs'], 'icon' => 'dashicons-tickets-alt' ],
            [ 'label' => ie__( 'Reviews' ), 'value' => $stats['reviews'], 'icon' => 'dashicons-star-filled' ],
            [ 'label' => ie__( 'Suspended Users' ), 'value' => $stats['suspended_users'], 'icon' => 'dashicons-lock' ],
        ];
        foreach ( $cards as $card ) :
            ?>
            <div class="ie-ad-stat-card">
                <span class="dashicons <?php echo esc_attr( $card['icon'] ); ?>" aria-hidden="true"></span>
                <div>
                    <strong><?php echo esc_html( (string) $card['value'] ); ?></strong>
                    <span><?php echo esc_html( $card['label'] ); ?></span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="ie-ad-quick-links">
        <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=ie-admin-users' ) ); ?>"><?php echo esc_html( ie__( 'Manage Users' ) ); ?></a>
        <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=ie-admin-subscriptions' ) ); ?>"><?php echo esc_html( ie__( 'Manage Subscriptions' ) ); ?></a>
        <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=ie-admin-reviews' ) ); ?>"><?php echo esc_html( ie__( 'Manage Reviews' ) ); ?></a>
        <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=ie-admin-reports' ) ); ?>"><?php echo esc_html( ie__( 'Export Reports' ) ); ?></a>
    </div>
    <?php

    ie_admin_render_shell_close();
}

