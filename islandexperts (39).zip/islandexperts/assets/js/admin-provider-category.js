(function ($) {
    'use strict';

    const i18n = window.IE_PROVIDER_CAT_ADMIN || {};

    function getImageDimensions() {
        const width = parseInt($('#ie_cat_icon_image_width').val(), 10) || 28;
        const height = parseInt($('#ie_cat_icon_image_height').val(), 10) || 28;

        return {
            width: Math.max(12, Math.min(120, width)),
            height: Math.max(12, Math.min(120, height)),
        };
    }

    function cssColorToHex(color) {
        const value = String(color || '').trim();

        if (/^#[0-9a-f]{3,8}$/i.test(value)) {
            return value.length === 4
                ? '#' + value[1] + value[1] + value[2] + value[2] + value[3] + value[3]
                : value.slice(0, 7);
        }

        const match = value.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)/i);
        if (!match) {
            return '#f0f4f8';
        }

        const r = parseInt(match[1], 10);
        const g = parseInt(match[2], 10);
        const b = parseInt(match[3], 10);
        const a = match[4] !== undefined ? parseFloat(match[4]) : 1;
        const blend = function (channel) {
            return Math.round(255 * (1 - a) + channel * a);
        };

        return (
            '#' +
            blend(r).toString(16).padStart(2, '0') +
            blend(g).toString(16).padStart(2, '0') +
            blend(b).toString(16).padStart(2, '0')
        );
    }

    function getBrowseSlug() {
        const slug = String($('#ie_cat_browse_slug').val() || '').trim();
        return slug.toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
    }

    function getDefaultBgColor() {
        const slug = getBrowseSlug();
        const defaults = i18n.bgDefaults || {};

        if (slug && defaults[slug]) {
            return defaults[slug];
        }

        return i18n.bgFallback || 'rgba(31, 111, 143, 0.12)';
    }

    function getEffectiveBgColor() {
        const custom = String($('#ie_cat_icon_bg_color').val() || '').trim();
        return custom || getDefaultBgColor();
    }

    function getDefaultColor() {
        const slug = getBrowseSlug();
        const defaults = i18n.colorDefaults || {};

        if (slug && defaults[slug]) {
            return defaults[slug];
        }

        return i18n.colorFallback || '#1f6f8f';
    }

    function getEffectiveIconColor() {
        const custom = String($('#ie_cat_icon_color').val() || '').trim();
        return custom || getDefaultColor();
    }

    function updateDefaultColorLabel() {
        const defaultColor = getDefaultColor();
        const label = i18n.defaultForLabel || 'Default for this category: %s';

        $('#ie-cat-icon-color-default-label')
            .attr('data-default', defaultColor)
            .text(label.replace('%s', defaultColor));

        $('#ie_cat_icon_color').attr('placeholder', defaultColor);
    }

    function updateIconColorPreview() {
        $('#ie-cat-fa-preview').css('color', getEffectiveIconColor());
    }

    function syncIconColorPickerFromInputs() {
        const custom = String($('#ie_cat_icon_color').val() || '').trim();
        const color = custom || getDefaultColor();

        $('#ie_cat_icon_color_picker').val(cssColorToHex(color));
        updateIconColorPreview();
    }

    function updateDefaultBgLabel() {
        const defaultColor = getDefaultBgColor();
        const label = i18n.defaultForLabel || 'Default for this category: %s';

        $('#ie-cat-icon-bg-default-label')
            .attr('data-default', defaultColor)
            .text(label.replace('%s', defaultColor));

        $('#ie_cat_icon_bg_color').attr('placeholder', defaultColor);
    }

    function updateIconBgPreview() {
        const bg = getEffectiveBgColor();

        $('.ie-cat-fa-preview-wrap, .ie-cat-icon-image-preview').css('background', bg);
    }

    function syncPickerFromInputs() {
        const custom = String($('#ie_cat_icon_bg_color').val() || '').trim();
        const color = custom || getDefaultBgColor();

        $('#ie_cat_icon_bg_color_picker').val(cssColorToHex(color));
        updateIconBgPreview();
    }

    function toggleIconFields() {
        const type = $('input[name="ie_cat_icon_type"]:checked').val() || 'fontawesome';
        $('.ie-cat-icon-fontawesome-row, .ie-cat-icon-color-row').toggle(type === 'fontawesome');
        $('.ie-cat-icon-image-row').toggle(type === 'image');
    }

    function updateFaPreview() {
        const iconClass = $('#ie_cat_icon_class').val() || 'fa-solid fa-screwdriver-wrench';
        $('#ie-cat-fa-preview').attr('class', iconClass);
        updateIconColorPreview();
    }

    function updateImagePreviewSize() {
        const dims = getImageDimensions();
        const $preview = $('.ie-cat-icon-image-preview');
        const $img = $preview.find('img');

        $preview.css({
            minWidth: dims.width + 16,
            minHeight: dims.height + 16,
        });

        if (!$img.length) {
            return;
        }

        $img.attr({
            width: dims.width,
            height: dims.height,
        }).css({
            width: dims.width + 'px',
            height: dims.height + 'px',
            objectFit: 'contain',
        });
    }

    function setIconImagePreview(url) {
        const $preview = $('.ie-cat-icon-image-preview');
        const noImageText = i18n.noImage || 'No image';
        const dims = getImageDimensions();

        if (url) {
            $preview.removeClass('is-empty').html(
                '<img src="' + url + '" alt="" width="' + dims.width + '" height="' + dims.height + '" style="width:' + dims.width + 'px;height:' + dims.height + 'px;object-fit:contain;">'
            );
            $('#ie-cat-remove-icon').show();
        } else {
            $preview.addClass('is-empty').text(noImageText);
            $('#ie-cat-remove-icon').hide();
        }

        $('#ie_cat_icon_image').val(url);
        updateImagePreviewSize();
        updateIconBgPreview();
    }

    function openIconMediaFrame() {
        const frame = wp.media({
            title: i18n.selectImage || 'Select Category Icon',
            button: { text: i18n.useImage || 'Use this icon' },
            library: { type: 'image' },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            setIconImagePreview(attachment.url || '');
        });

        frame.open();
    }

    $(document).on('change', 'input[name="ie_cat_icon_type"]', toggleIconFields);
    $(document).on('input change', '#ie_cat_icon_class', updateFaPreview);
    $(document).on('input change', '#ie_cat_icon_image_width, #ie_cat_icon_image_height', updateImagePreviewSize);
    $(document).on('input change', '#ie_cat_browse_slug', function () {
        updateDefaultBgLabel();
        updateDefaultColorLabel();
        syncPickerFromInputs();
        syncIconColorPickerFromInputs();
    });
    $(document).on('input change', '#ie_cat_icon_bg_color', syncPickerFromInputs);
    $(document).on('input change', '#ie_cat_icon_bg_color_picker', function () {
        $('#ie_cat_icon_bg_color').val($(this).val()).trigger('input');
    });
    $(document).on('click', '#ie-cat-reset-icon-bg', function (event) {
        event.preventDefault();
        $('#ie_cat_icon_bg_color').val('').trigger('input');
    });
    $(document).on('input change', '#ie_cat_icon_color', syncIconColorPickerFromInputs);
    $(document).on('input change', '#ie_cat_icon_color_picker', function () {
        $('#ie_cat_icon_color').val($(this).val()).trigger('input');
    });
    $(document).on('click', '#ie-cat-reset-icon-color', function (event) {
        event.preventDefault();
        $('#ie_cat_icon_color').val('').trigger('input');
    });
    $(document).on('change', '#ie_cat_icon_preset', function () {
        const value = $(this).val();
        if (!value) {
            return;
        }
        $('#ie_cat_icon_class').val(value).trigger('input');
    });
    $(document).on('click', '#ie-cat-upload-icon', function (event) {
        event.preventDefault();
        openIconMediaFrame();
    });
    $(document).on('click', '#ie-cat-remove-icon', function (event) {
        event.preventDefault();
        setIconImagePreview('');
    });

    $(function () {
        toggleIconFields();
        updateFaPreview();
        updateImagePreviewSize();
        updateDefaultBgLabel();
        updateDefaultColorLabel();
        syncPickerFromInputs();
        syncIconColorPickerFromInputs();
    });
}(jQuery));
