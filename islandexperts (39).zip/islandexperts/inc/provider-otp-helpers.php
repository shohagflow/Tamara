<?php
/**
 * Email OTP verification for service provider registration.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'IE_PROVIDER_OTP_EXPIRY', 2 * MINUTE_IN_SECONDS );
define( 'IE_PROVIDER_OTP_MAX_ATTEMPTS', 5 );
define( 'IE_PROVIDER_OTP_RESEND_COOLDOWN', 60 );
define( 'IE_PROVIDER_OTP_LENGTH', 6 );

function ie_provider_otp_transient_key( $context, $identifier ) {
    $context    = sanitize_key( (string) $context );
    $identifier = strtolower( trim( (string) $identifier ) );

    return 'ie_otp_' . $context . '_' . md5( $context . '|' . $identifier );
}

function ie_provider_otp_generate_code() {
    return str_pad( (string) wp_rand( 0, 999999 ), IE_PROVIDER_OTP_LENGTH, '0', STR_PAD_LEFT );
}

function ie_provider_otp_mask_email( $email ) {
    $email = sanitize_email( (string) $email );
    if ( ! $email || strpos( $email, '@' ) === false ) {
        return '';
    }

    [ $local, $domain ] = explode( '@', $email, 2 );
    $visible             = substr( $local, 0, min( 2, strlen( $local ) ) );
    $masked_local        = $visible . str_repeat( '*', max( 1, strlen( $local ) - strlen( $visible ) ) );

    return $masked_local . '@' . $domain;
}

function ie_provider_otp_send_email( $email, $code, $recipient_name = '' ) {
    $email = sanitize_email( (string) $email );
    if ( ! $email || ! is_email( $email ) ) {
        return new WP_Error( 'invalid_email', ie__( 'Invalid email address.' ) );
    }

    $site_name = get_bloginfo( 'name' );
    $greeting  = $recipient_name !== '' ? sprintf( ie__( 'Hi %s,' ), $recipient_name ) : ie__( 'Hi,' );
    $subject   = sprintf( ie__( '%1$s — Your verification code' ), $site_name );
    $message   = $greeting . "\n\n"
        . sprintf( ie__( 'Your verification code is: %s' ), $code ) . "\n\n"
        . ie__( 'This code expires in 2 minutes.' ) . "\n\n"
        . ie__( 'If you did not request this code, you can safely ignore this email.' ) . "\n\n"
        . $site_name . "\n"
        . home_url( '/' );

    $sent = wp_mail( $email, $subject, $message );
    if ( ! $sent ) {
        return new WP_Error( 'email_failed', ie__( 'Unable to send the verification email. Please try again later.' ) );
    }

    return true;
}

function ie_provider_otp_store( $context, $identifier, $email, $payload = [] ) {
    $email = sanitize_email( (string) $email );
    if ( ! $email || ! is_email( $email ) ) {
        return new WP_Error( 'invalid_email', ie__( 'Invalid email address.' ) );
    }

    $key      = ie_provider_otp_transient_key( $context, $identifier );
    $existing = get_transient( $key );
    $now      = time();

    if ( is_array( $existing ) && ! empty( $existing['sent_at'] ) ) {
        $elapsed = $now - (int) $existing['sent_at'];
        if ( $elapsed < IE_PROVIDER_OTP_RESEND_COOLDOWN ) {
            $wait = IE_PROVIDER_OTP_RESEND_COOLDOWN - $elapsed;
            return new WP_Error(
                'otp_cooldown',
                sprintf( ie__( 'Please wait %d seconds before requesting a new code.' ), max( 1, $wait ) )
            );
        }
    }

    $code = ie_provider_otp_generate_code();
    $data = [
        'hash'       => wp_hash_password( $code ),
        'email'      => $email,
        'expires'    => $now + IE_PROVIDER_OTP_EXPIRY,
        'sent_at'    => $now,
        'attempts'   => 0,
        'payload'    => is_array( $payload ) ? $payload : [],
    ];

    set_transient( $key, $data, IE_PROVIDER_OTP_EXPIRY );

    return $code;
}

function ie_provider_otp_verify( $context, $identifier, $email, $code ) {
    $email = sanitize_email( (string) $email );
    $code  = preg_replace( '/\D+/', '', (string) $code );

    if ( ! $email || ! is_email( $email ) ) {
        return new WP_Error( 'invalid_email', ie__( 'Invalid email address.' ) );
    }

    if ( strlen( $code ) !== IE_PROVIDER_OTP_LENGTH ) {
        return new WP_Error( 'invalid_otp', ie__( 'Please enter the 6-digit verification code.' ) );
    }

    $key  = ie_provider_otp_transient_key( $context, $identifier );
    $data = get_transient( $key );

    if ( ! is_array( $data ) || empty( $data['hash'] ) ) {
        return new WP_Error( 'otp_expired', ie__( 'This verification code has expired. Please request a new one.' ) );
    }

    if ( time() > (int) ( $data['expires'] ?? 0 ) ) {
        delete_transient( $key );
        return new WP_Error( 'otp_expired', ie__( 'This verification code has expired. Please request a new one.' ) );
    }

    if ( strtolower( (string) ( $data['email'] ?? '' ) ) !== strtolower( $email ) ) {
        return new WP_Error( 'otp_mismatch', ie__( 'Verification code does not match this email address.' ) );
    }

    $attempts = (int) ( $data['attempts'] ?? 0 );
    if ( $attempts >= IE_PROVIDER_OTP_MAX_ATTEMPTS ) {
        delete_transient( $key );
        return new WP_Error( 'otp_locked', ie__( 'Too many incorrect attempts. Please request a new verification code.' ) );
    }

    if ( ! wp_check_password( $code, (string) $data['hash'] ) ) {
        $data['attempts'] = $attempts + 1;
        $remaining        = IE_PROVIDER_OTP_MAX_ATTEMPTS - $data['attempts'];
        set_transient( $key, $data, max( 60, (int) $data['expires'] - time() ) );

        if ( $remaining <= 0 ) {
            delete_transient( $key );
            return new WP_Error( 'otp_locked', ie__( 'Too many incorrect attempts. Please request a new verification code.' ) );
        }

        return new WP_Error(
            'invalid_otp',
            sprintf( ie__( 'Incorrect verification code. %d attempt(s) remaining.' ), $remaining )
        );
    }

    $payload = is_array( $data['payload'] ?? null ) ? $data['payload'] : [];
    delete_transient( $key );

    return $payload;
}

function ie_provider_otp_clear( $context, $identifier ) {
    delete_transient( ie_provider_otp_transient_key( $context, $identifier ) );
}

function ie_validate_provider_account_registration_payload( $data ) {
    $data = is_array( $data ) ? $data : [];

    $first_name = sanitize_text_field( $data['first_name'] ?? '' );
    $last_name  = sanitize_text_field( $data['last_name'] ?? '' );
    $email      = sanitize_email( $data['email'] ?? '' );
    $password   = (string) ( $data['password'] ?? '' );
    $confirm    = (string) ( $data['confirm_password'] ?? '' );
    $user_type  = sanitize_text_field( $data['user_type'] ?? 'provider' );

    if ( $user_type !== 'provider' ) {
        return new WP_Error( 'invalid_type', ie__( 'OTP verification is only required for service provider accounts.' ) );
    }

    if ( ! $first_name || ! $email || ! $password || ! $confirm ) {
        return new WP_Error( 'missing_fields', ie__( 'Please fill in all required fields.' ) );
    }

    if ( ! is_email( $email ) ) {
        return new WP_Error( 'invalid_email', ie__( 'Invalid email address.' ) );
    }

    if ( email_exists( $email ) ) {
        return new WP_Error( 'email_exists', ie__( 'An account with this email already exists.' ) );
    }

    if ( strlen( $password ) < 6 ) {
        return new WP_Error( 'weak_password', ie__( 'Password must be at least 6 characters.' ) );
    }

    if ( $password !== $confirm ) {
        return new WP_Error( 'password_mismatch', ie__( 'Passwords do not match.' ) );
    }

    $service_name = sanitize_text_field( $data['service_name'] ?? '' );
    $experience   = sanitize_text_field( $data['experience'] ?? '' );
    $location     = sanitize_text_field( $data['location'] ?? '' );

    if ( ! $service_name || ! $experience || ! $location ) {
        return new WP_Error( 'missing_provider_fields', ie__( 'Please fill in your business name, experience, and location.' ) );
    }

    return [
        'first_name'        => $first_name,
        'last_name'         => $last_name,
        'email'             => $email,
        'password'          => $password,
        'confirm_password'  => $confirm,
        'user_type'         => 'provider',
        'service_name'      => $service_name,
        'experience'        => $experience,
        'location'          => $location,
    ];
}

function ie_create_provider_user_account( $payload ) {
    $payload = ie_validate_provider_account_registration_payload( $payload );
    if ( is_wp_error( $payload ) ) {
        return $payload;
    }

    if ( email_exists( $payload['email'] ) ) {
        return new WP_Error( 'email_exists', ie__( 'An account with this email already exists.' ) );
    }

    $username = sanitize_user( strtolower( $payload['first_name'] . $payload['last_name'] ) . wp_rand( 10, 99 ) );
    while ( username_exists( $username ) ) {
        $username = sanitize_user( strtolower( $payload['first_name'] . $payload['last_name'] ) . wp_rand( 100, 999 ) );
    }

    $user_id = wp_create_user( $username, $payload['password'], $payload['email'] );
    if ( is_wp_error( $user_id ) ) {
        return $user_id;
    }

    update_user_meta( $user_id, '_ie_user_type', 'provider' );
    update_user_meta( $user_id, '_ie_account_status', 'active' );

    wp_update_user(
        [
            'ID'           => $user_id,
            'first_name'   => $payload['first_name'],
            'last_name'    => $payload['last_name'],
            'display_name' => trim( $payload['first_name'] . ' ' . $payload['last_name'] ),
        ]
    );

    $pid = wp_insert_post(
        [
            'post_type'    => 'ie_provider',
            'post_status'  => 'publish',
            'post_title'   => $payload['service_name'],
            'post_content' => '',
            'post_author'  => $user_id,
        ]
    );

    if ( ! is_wp_error( $pid ) && $pid ) {
        ie_ensure_provider_slug( $pid );
        update_post_meta( $pid, '_ie_about', '' );
        update_post_meta( $pid, '_ie_service_area', $payload['location'] );
        update_post_meta( $pid, '_ie_experience_years', $payload['experience'] );
        update_post_meta( $pid, '_ie_email', $payload['email'] );
        update_post_meta( $pid, '_ie_availability', 'available_now' );
        update_post_meta( $pid, '_ie_rating', '0' );
        update_post_meta( $pid, '_ie_review_count', '0' );
        update_post_meta( $pid, '_ie_registered_listing', '1' );
    }

    wp_set_current_user( $user_id );
    wp_set_auth_cookie( $user_id );

    return [
        'user_id'       => $user_id,
        'display_name'  => trim( $payload['first_name'] . ' ' . $payload['last_name'] ),
        'email'         => $payload['email'],
        'avatar'        => strtoupper( $payload['first_name'][0] ?? 'P' ),
        'user_type'     => 'provider',
        'redirect_url'  => ie_get_user_profile_url( $user_id ),
    ];
}

function ie_ajax_send_provider_registration_otp() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! ie_is_provider_registration_otp_enabled() ) {
        wp_send_json_error( [ 'message' => ie__( 'Email verification is currently disabled.' ) ] );
    }

    $payload = ie_validate_provider_account_registration_payload( wp_unslash( $_POST ) );
    if ( is_wp_error( $payload ) ) {
        wp_send_json_error( [ 'message' => $payload->get_error_message() ] );
    }

    $code = ie_provider_otp_store( 'provider_account', $payload['email'], $payload['email'], $payload );
    if ( is_wp_error( $code ) ) {
        wp_send_json_error( [ 'message' => $code->get_error_message() ] );
    }

    $sent = ie_provider_otp_send_email( $payload['email'], $code, $payload['first_name'] );
    if ( is_wp_error( $sent ) ) {
        ie_provider_otp_clear( 'provider_account', $payload['email'] );
        wp_send_json_error( [ 'message' => $sent->get_error_message() ] );
    }

    wp_send_json_success(
        [
            'message'      => ie__( 'Verification code sent to your email.' ),
            'email'        => $payload['email'],
            'masked_email' => ie_provider_otp_mask_email( $payload['email'] ),
        ]
    );
}
add_action( 'wp_ajax_nopriv_ie_send_provider_registration_otp', 'ie_ajax_send_provider_registration_otp' );

function ie_ajax_verify_provider_registration() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! ie_is_provider_registration_otp_enabled() ) {
        wp_send_json_error( [ 'message' => ie__( 'Email verification is currently disabled.' ) ] );
    }

    $email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
    $otp   = sanitize_text_field( wp_unslash( $_POST['otp'] ?? '' ) );

    $payload = ie_provider_otp_verify( 'provider_account', $email, $email, $otp );
    if ( is_wp_error( $payload ) ) {
        wp_send_json_error( [ 'message' => $payload->get_error_message() ] );
    }

    if ( empty( $payload['confirm_password'] ) && ! empty( $payload['password'] ) ) {
        $payload['confirm_password'] = $payload['password'];
    }

    $result = ie_create_provider_user_account( $payload );
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( [ 'message' => $result->get_error_message() ] );
    }

    wp_send_json_success(
        [
            'message'      => ie__( 'Account created successfully!' ),
            'display_name' => $result['display_name'],
            'email'        => $result['email'],
            'avatar'       => $result['avatar'],
            'user_type'    => $result['user_type'],
            'redirect_url' => $result['redirect_url'],
        ]
    );
}
add_action( 'wp_ajax_nopriv_ie_verify_provider_registration', 'ie_ajax_verify_provider_registration' );

function ie_validate_provider_listing_registration_payload( $data ) {
    $data = is_array( $data ) ? $data : [];

    $name    = sanitize_text_field( $data['business_name'] ?? '' );
    $cat_id  = (int) ( $data['category_id'] ?? 0 );
    $about   = sanitize_textarea_field( $data['about'] ?? '' );
    $phone   = sanitize_text_field( $data['phone'] ?? '' );
    $email   = sanitize_email( $data['email'] ?? '' );
    $website = esc_url_raw( $data['website'] ?? '' );
    $area    = sanitize_text_field( $data['service_area'] ?? '' );
    $exp     = sanitize_text_field( $data['experience'] ?? '' );
    $price   = sanitize_text_field( $data['price_from'] ?? '' );
    $services = sanitize_text_field( $data['services'] ?? '' );

    if ( ! $name || ! $about || ! $phone || ! $email || ! $area || ! $exp || ! $price ) {
        return new WP_Error( 'missing_fields', ie__( 'Please fill in all required fields.' ) );
    }

    if ( ! is_email( $email ) ) {
        return new WP_Error( 'invalid_email', ie__( 'Invalid email address.' ) );
    }

    return [
        'business_name' => $name,
        'category_id'   => $cat_id,
        'about'         => $about,
        'phone'         => $phone,
        'email'         => $email,
        'website'       => $website,
        'service_area'  => $area,
        'experience'    => $exp,
        'price_from'    => $price,
        'services'      => $services,
    ];
}

function ie_complete_provider_listing_registration( $user_id, $payload ) {
    $user_id = (int) $user_id;
    $payload = ie_validate_provider_listing_registration_payload( $payload );

    if ( is_wp_error( $payload ) ) {
        return $payload;
    }

    $existing = get_posts(
        [
            'post_type'   => 'ie_provider',
            'author'      => $user_id,
            'post_status' => [ 'publish', 'pending' ],
            'numberposts' => 1,
            'fields'      => 'ids',
        ]
    );

    if ( $existing ) {
        return new WP_Error( 'already_listed', ie__( 'You already have a provider listing.' ) );
    }

    $name  = $payload['business_name'];
    $about = $payload['about'];

    $pid = wp_insert_post(
        [
            'post_type'    => 'ie_provider',
            'post_status'  => 'publish',
            'post_title'   => $name,
            'post_content' => $about,
            'post_author'  => $user_id,
        ]
    );

    if ( is_wp_error( $pid ) || ! $pid ) {
        return new WP_Error( 'create_failed', ie__( 'Failed to submit. Please try again.' ) );
    }

    ie_ensure_provider_slug( $pid );

    update_user_meta( $user_id, '_ie_user_type', 'provider' );
    update_user_meta( $user_id, '_ie_account_status', 'active' );

    if ( ! empty( $_COOKIE['ie_plan_id'] ) ) {
        $plan_id = sanitize_text_field( wp_unslash( $_COOKIE['ie_plan_id'] ) );
        $billing = strpos( $plan_id, 'annual' ) !== false ? 'yearly' : 'monthly';
        update_user_meta( $user_id, '_ie_subscription_plan', $plan_id );
        update_user_meta( $user_id, '_ie_subscription_billing', $billing );
        update_user_meta( $user_id, '_ie_subscription_status', 'active' );
    } else {
        ie_start_provider_free_trial( $user_id );
    }

    update_post_meta( $pid, '_ie_about', $about );
    update_post_meta( $pid, '_ie_phone', $payload['phone'] );
    update_post_meta( $pid, '_ie_email', $payload['email'] );
    update_post_meta( $pid, '_ie_website', $payload['website'] );
    update_post_meta( $pid, '_ie_service_area', $payload['service_area'] );
    update_post_meta( $pid, '_ie_experience_years', $payload['experience'] );
    update_post_meta( $pid, '_ie_price_from', $payload['price_from'] );
    update_post_meta( $pid, '_ie_services', $payload['services'] );
    update_post_meta( $pid, '_ie_availability', 'available_now' );
    update_post_meta( $pid, '_ie_rating', '0' );
    update_post_meta( $pid, '_ie_review_count', '0' );
    update_post_meta( $pid, '_ie_registered_listing', '1' );

    if ( $payload['category_id'] ) {
        wp_set_object_terms( $pid, $payload['category_id'], 'ie_category' );
    }

    if ( ! empty( $_FILES['photo']['name'] ) ) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        $attachment_id = media_handle_upload( 'photo', $pid );
        if ( ! is_wp_error( $attachment_id ) ) {
            set_post_thumbnail( $pid, $attachment_id );
        }
    }

    wp_mail(
        get_option( 'admin_email' ),
        'New Provider Listing: ' . $name,
        "A new service provider has joined Island Experts.\n\n"
        . "Name:  {$name}\n"
        . "Email: {$payload['email']}\n"
        . "Phone: {$payload['phone']}\n"
        . "Area:  {$payload['service_area']}\n\n"
        . "View listing:\n"
        . admin_url( 'post.php?post=' . $pid . '&action=edit' )
    );

    wp_mail(
        $payload['email'],
        'Your profile is live — Island Experts',
        "Hi {$name},\n\n"
        . "Thank you for joining Island Experts!\n\n"
        . "Your business profile is now live and visible to customers across St. Lucia.\n\n"
        . "You can update your profile any time from your provider dashboard.\n\n"
        . "Best regards,\nThe Island Experts Team\n"
        . home_url( '/' )
    );

    return [
        'provider_id'  => $pid,
        'redirect_url' => ie_get_user_profile_url( $user_id ),
    ];
}

function ie_ajax_send_provider_listing_otp() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! ie_is_provider_registration_otp_enabled() ) {
        wp_send_json_error( [ 'message' => ie__( 'Email verification is currently disabled.' ) ] );
    }

    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Please log in first.' ) ] );
    }

    $user_id = get_current_user_id();
    $payload = ie_validate_provider_listing_registration_payload( wp_unslash( $_POST ) );
    if ( is_wp_error( $payload ) ) {
        wp_send_json_error( [ 'message' => $payload->get_error_message() ] );
    }

    $code = ie_provider_otp_store( 'provider_listing', (string) $user_id, $payload['email'], $payload );
    if ( is_wp_error( $code ) ) {
        wp_send_json_error( [ 'message' => $code->get_error_message() ] );
    }

    $user  = wp_get_current_user();
    $sent  = ie_provider_otp_send_email( $payload['email'], $code, $user->display_name );
    if ( is_wp_error( $sent ) ) {
        ie_provider_otp_clear( 'provider_listing', (string) $user_id );
        wp_send_json_error( [ 'message' => $sent->get_error_message() ] );
    }

    wp_send_json_success(
        [
            'message'      => ie__( 'Verification code sent to your business email.' ),
            'email'        => $payload['email'],
            'masked_email' => ie_provider_otp_mask_email( $payload['email'] ),
        ]
    );
}
add_action( 'wp_ajax_ie_send_provider_listing_otp', 'ie_ajax_send_provider_listing_otp' );
