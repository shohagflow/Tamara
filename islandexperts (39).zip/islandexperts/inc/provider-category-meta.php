<?php
/**
 * Provider Categories CPT meta box, seeding, and admin UI.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_add_provider_category_meta_box() {
    add_meta_box(
        'ie_provider_category_details',
        ie__( 'Category Details' ),
        'ie_provider_category_meta_box_cb',
        'ie_provider_category',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'ie_add_provider_category_meta_box' );

function ie_provider_category_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_provider_category', 'ie_provider_category_nonce' );

    $short_desc  = get_post_meta( $post->ID, '_ie_cat_short_description', true );
    $browse_slug = get_post_meta( $post->ID, '_ie_cat_browse_slug', true );
    $icon_type   = get_post_meta( $post->ID, '_ie_cat_icon_type', true ) ?: 'fontawesome';
    $icon_class  = get_post_meta( $post->ID, '_ie_cat_icon_class', true ) ?: 'fa-solid fa-screwdriver-wrench';
    $icon_image  = get_post_meta( $post->ID, '_ie_cat_icon_image', true );
    $icon_dims        = ie_get_provider_category_image_dimensions( $post->ID );
    $icon_bg_custom    = ie_sanitize_provider_category_icon_bg_color( get_post_meta( $post->ID, '_ie_cat_icon_bg_color', true ) );
    $icon_color_custom = ie_sanitize_provider_category_icon_color( get_post_meta( $post->ID, '_ie_cat_icon_color', true ) );
    $resolved_slug     = $browse_slug ?: $post->post_name;
    $icon_bg_default   = ie_get_provider_category_default_icon_bg( $resolved_slug );
    $icon_color_default = ie_get_provider_category_default_icon_color( $resolved_slug );
    $icon_bg_picker    = $icon_bg_custom ?: ie_css_color_to_hex_for_picker( $icon_bg_default );
    $icon_color_picker = $icon_color_custom ?: ie_css_color_to_hex_for_picker( $icon_color_default );
    $icon_color_active = $icon_color_custom ?: $icon_color_default;
    $presets           = ie_get_provider_category_fa_presets();
    ?>
    <table class="form-table ie-provider-category-meta">
        <tr>
            <th scope="row"><label for="ie_cat_short_description"><?php echo esc_html( ie__( 'Short Description' ) ); ?></label></th>
            <td>
                <textarea id="ie_cat_short_description" name="ie_cat_short_description" rows="3" class="large-text"><?php echo esc_textarea( $short_desc ); ?></textarea>
                <p class="description"><?php echo esc_html( ie__( 'Shown on the home page category card.' ) ); ?></p>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="ie_cat_browse_slug"><?php echo esc_html( ie__( 'Browse Filter Slug' ) ); ?></label></th>
            <td>
                <input type="text" id="ie_cat_browse_slug" name="ie_cat_browse_slug" value="<?php echo esc_attr( $browse_slug ); ?>" class="regular-text">
                <p class="description"><?php echo esc_html( ie__( 'Links to the provider browse page (matches the provider category taxonomy slug).' ) ); ?></p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php echo esc_html( ie__( 'Icon Type' ) ); ?></th>
            <td>
                <label style="margin-right:16px;">
                    <input type="radio" name="ie_cat_icon_type" value="fontawesome" <?php checked( $icon_type, 'fontawesome' ); ?>>
                    <?php echo esc_html( ie__( 'Font Awesome Icon' ) ); ?>
                </label>
                <label>
                    <input type="radio" name="ie_cat_icon_type" value="image" <?php checked( $icon_type, 'image' ); ?>>
                    <?php echo esc_html( ie__( 'Upload Image' ) ); ?>
                </label>
            </td>
        </tr>
        <tr class="ie-cat-icon-bg-row">
            <th scope="row"><label for="ie_cat_icon_bg_color"><?php echo esc_html( ie__( 'Icon Background Color' ) ); ?></label></th>
            <td>
                <div class="ie-cat-icon-bg-field">
                    <input
                        type="color"
                        id="ie_cat_icon_bg_color_picker"
                        value="<?php echo esc_attr( $icon_bg_picker ); ?>"
                        aria-label="<?php echo esc_attr( ie__( 'Icon background color picker' ) ); ?>"
                    >
                    <input
                        type="text"
                        id="ie_cat_icon_bg_color"
                        name="ie_cat_icon_bg_color"
                        class="regular-text ie-cat-icon-bg-color-input"
                        value="<?php echo esc_attr( $icon_bg_custom ); ?>"
                        placeholder="<?php echo esc_attr( $icon_bg_default ); ?>"
                        style="max-width:180px;margin-left:8px;"
                    >
                    <button type="button" class="button" id="ie-cat-reset-icon-bg" style="margin-left:8px;">
                        <?php echo esc_html( ie__( 'Reset to default' ) ); ?>
                    </button>
                    <p class="description">
                        <?php echo esc_html( ie__( 'Background color for the icon box on the home page and category lists.' ) ); ?>
                        <span id="ie-cat-icon-bg-default-label" data-default="<?php echo esc_attr( $icon_bg_default ); ?>">
                            <?php echo esc_html( sprintf( ie__( 'Default for this category: %s' ), $icon_bg_default ) ); ?>
                        </span>
                    </p>
                </div>
            </td>
        </tr>
        <tr class="ie-cat-icon-color-row">
            <th scope="row"><label for="ie_cat_icon_color"><?php echo esc_html( ie__( 'Icon Color' ) ); ?></label></th>
            <td>
                <div class="ie-cat-icon-bg-field">
                    <input
                        type="color"
                        id="ie_cat_icon_color_picker"
                        value="<?php echo esc_attr( $icon_color_picker ); ?>"
                        aria-label="<?php echo esc_attr( ie__( 'Icon color picker' ) ); ?>"
                    >
                    <input
                        type="text"
                        id="ie_cat_icon_color"
                        name="ie_cat_icon_color"
                        class="regular-text ie-cat-icon-color-input"
                        value="<?php echo esc_attr( $icon_color_custom ); ?>"
                        placeholder="<?php echo esc_attr( $icon_color_default ); ?>"
                        style="max-width:180px;margin-left:8px;"
                    >
                    <button type="button" class="button" id="ie-cat-reset-icon-color" style="margin-left:8px;">
                        <?php echo esc_html( ie__( 'Reset to default' ) ); ?>
                    </button>
                    <p class="description">
                        <?php echo esc_html( ie__( 'Color for Font Awesome icons only (home page and category lists).' ) ); ?>
                        <span id="ie-cat-icon-color-default-label" data-default="<?php echo esc_attr( $icon_color_default ); ?>">
                            <?php echo esc_html( sprintf( ie__( 'Default for this category: %s' ), $icon_color_default ) ); ?>
                        </span>
                    </p>
                </div>
            </td>
        </tr>
        <tr class="ie-cat-icon-fontawesome-row">
            <th scope="row"><label for="ie_cat_icon_preset"><?php echo esc_html( ie__( 'Font Awesome Icon' ) ); ?></label></th>
            <td>
                <select id="ie_cat_icon_preset" class="regular-text" style="max-width:320px;margin-bottom:8px;">
                    <option value=""><?php echo esc_html( ie__( '— Select a preset —' ) ); ?></option>
                    <?php foreach ( $presets as $class => $label ) : ?>
                        <option value="<?php echo esc_attr( $class ); ?>" <?php selected( $icon_class, $class ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="text" id="ie_cat_icon_class" name="ie_cat_icon_class" value="<?php echo esc_attr( $icon_class ); ?>" class="regular-text" placeholder="fa-solid fa-wrench" style="max-width:320px;">
                <p class="description"><?php echo esc_html( ie__( 'Choose a preset or enter any Font Awesome class (e.g. fa-solid fa-wrench).' ) ); ?></p>
                <div class="ie-cat-icon-preview" style="margin-top:10px;">
                    <span class="ie-cat-fa-preview-wrap" style="display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;border-radius:12px;background:<?php echo esc_attr( $icon_bg_custom ?: $icon_bg_default ); ?>;">
                        <i id="ie-cat-fa-preview" class="<?php echo esc_attr( $icon_class ); ?>" aria-hidden="true" style="font-size:20px;color:<?php echo esc_attr( $icon_color_active ); ?>;"></i>
                    </span>
                </div>
            </td>
        </tr>
        <tr class="ie-cat-icon-image-row">
            <th scope="row"><?php echo esc_html( ie__( 'Icon Image' ) ); ?></th>
            <td>
                <div class="ie-cat-icon-image-field">
                    <div
                        class="ie-cat-icon-image-preview<?php echo $icon_image ? '' : ' is-empty'; ?>"
                        style="min-width:<?php echo esc_attr( (string) ( $icon_dims['width'] + 16 ) ); ?>px;min-height:<?php echo esc_attr( (string) ( $icon_dims['height'] + 16 ) ); ?>px;background:<?php echo esc_attr( $icon_bg_custom ?: $icon_bg_default ); ?>;"
                    >
                        <?php if ( $icon_image ) : ?>
                            <img
                                src="<?php echo esc_url( $icon_image ); ?>"
                                alt=""
                                width="<?php echo esc_attr( (string) $icon_dims['width'] ); ?>"
                                height="<?php echo esc_attr( (string) $icon_dims['height'] ); ?>"
                                style="width:<?php echo esc_attr( (string) $icon_dims['width'] ); ?>px;height:<?php echo esc_attr( (string) $icon_dims['height'] ); ?>px;object-fit:contain;"
                            >
                        <?php else : ?>
                            <?php echo esc_html( ie__( 'No image' ) ); ?>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" id="ie_cat_icon_image" name="ie_cat_icon_image" value="<?php echo esc_url( $icon_image ); ?>">
                    <p>
                        <button type="button" class="button" id="ie-cat-upload-icon"><?php echo esc_html( ie__( 'Upload Icon' ) ); ?></button>
                        <button type="button" class="button" id="ie-cat-remove-icon"<?php echo $icon_image ? '' : ' style="display:none;"'; ?>><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
                    </p>
                    <div class="ie-cat-icon-image-size-fields">
                        <p>
                            <label for="ie_cat_icon_image_width"><?php echo esc_html( ie__( 'Image Width (px)' ) ); ?></label><br>
                            <input
                                type="number"
                                id="ie_cat_icon_image_width"
                                name="ie_cat_icon_image_width"
                                class="small-text"
                                min="12"
                                max="120"
                                step="1"
                                value="<?php echo esc_attr( (string) $icon_dims['width'] ); ?>"
                            >
                        </p>
                        <p>
                            <label for="ie_cat_icon_image_height"><?php echo esc_html( ie__( 'Image Height (px)' ) ); ?></label><br>
                            <input
                                type="number"
                                id="ie_cat_icon_image_height"
                                name="ie_cat_icon_image_height"
                                class="small-text"
                                min="12"
                                max="120"
                                step="1"
                                value="<?php echo esc_attr( (string) $icon_dims['height'] ); ?>"
                            >
                        </p>
                    </div>
                    <p class="description"><?php echo esc_html( ie__( 'Set the display size for this uploaded icon on the home page and category lists.' ) ); ?></p>
                </div>
            </td>
        </tr>
    </table>
    <?php
}

function ie_save_provider_category_meta( $post_id ) {
    if ( ! isset( $_POST['ie_provider_category_nonce'] ) || ! wp_verify_nonce( $_POST['ie_provider_category_nonce'], 'ie_save_provider_category' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( get_post_type( $post_id ) !== 'ie_provider_category' ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['ie_cat_short_description'] ) ) {
        update_post_meta( $post_id, '_ie_cat_short_description', sanitize_textarea_field( wp_unslash( $_POST['ie_cat_short_description'] ) ) );
    }

    if ( isset( $_POST['ie_cat_browse_slug'] ) ) {
        update_post_meta( $post_id, '_ie_cat_browse_slug', sanitize_title( wp_unslash( $_POST['ie_cat_browse_slug'] ) ) );
    }

    $icon_type = isset( $_POST['ie_cat_icon_type'] ) ? sanitize_key( wp_unslash( $_POST['ie_cat_icon_type'] ) ) : 'fontawesome';
    if ( ! in_array( $icon_type, [ 'fontawesome', 'image' ], true ) ) {
        $icon_type = 'fontawesome';
    }
    update_post_meta( $post_id, '_ie_cat_icon_type', $icon_type );

    if ( isset( $_POST['ie_cat_icon_class'] ) ) {
        update_post_meta( $post_id, '_ie_cat_icon_class', sanitize_text_field( wp_unslash( $_POST['ie_cat_icon_class'] ) ) );
    }

    if ( isset( $_POST['ie_cat_icon_image'] ) ) {
        update_post_meta( $post_id, '_ie_cat_icon_image', esc_url_raw( wp_unslash( $_POST['ie_cat_icon_image'] ) ) );
    }

    if ( isset( $_POST['ie_cat_icon_image_width'] ) ) {
        update_post_meta( $post_id, '_ie_cat_icon_image_width', ie_sanitize_provider_category_image_dimension( wp_unslash( $_POST['ie_cat_icon_image_width'] ) ) );
    }

    if ( isset( $_POST['ie_cat_icon_image_height'] ) ) {
        update_post_meta( $post_id, '_ie_cat_icon_image_height', ie_sanitize_provider_category_image_dimension( wp_unslash( $_POST['ie_cat_icon_image_height'] ) ) );
    }

    if ( isset( $_POST['ie_cat_icon_bg_color'] ) ) {
        $bg_color = ie_sanitize_provider_category_icon_bg_color( wp_unslash( $_POST['ie_cat_icon_bg_color'] ) );

        if ( $bg_color === '' ) {
            delete_post_meta( $post_id, '_ie_cat_icon_bg_color' );
        } else {
            update_post_meta( $post_id, '_ie_cat_icon_bg_color', $bg_color );
        }
    }

    if ( isset( $_POST['ie_cat_icon_color'] ) && $icon_type === 'fontawesome' ) {
        $icon_color = ie_sanitize_provider_category_icon_color( wp_unslash( $_POST['ie_cat_icon_color'] ) );

        if ( $icon_color === '' ) {
            delete_post_meta( $post_id, '_ie_cat_icon_color' );
        } else {
            update_post_meta( $post_id, '_ie_cat_icon_color', $icon_color );
        }
    }
}
add_action( 'save_post_ie_provider_category', 'ie_save_provider_category_meta' );

function ie_provider_category_columns( $cols ) {
    return array_merge(
        array_slice( $cols, 0, 2 ),
        [
            'ie_cat_icon'  => ie__( 'Icon' ),
            'ie_cat_slug'  => ie__( 'Browse Slug' ),
            'ie_cat_order' => ie__( 'Order' ),
        ],
        array_slice( $cols, 2 )
    );
}
add_filter( 'manage_ie_provider_category_posts_columns', 'ie_provider_category_columns' );

function ie_provider_category_column_data( $col, $post_id ) {
    switch ( $col ) {
        case 'ie_cat_icon':
            ie_render_provider_category_icon_preview( ie_get_provider_category_data( $post_id ) );
            break;
        case 'ie_cat_slug':
            echo esc_html( get_post_meta( $post_id, '_ie_cat_browse_slug', true ) ?: '—' );
            break;
        case 'ie_cat_order':
            echo esc_html( (string) get_post( $post_id )->menu_order );
            break;
    }
}
add_action( 'manage_ie_provider_category_posts_custom_column', 'ie_provider_category_column_data', 10, 2 );

function ie_seed_provider_categories() {
    if ( get_option( 'ie_provider_categories_seeded' ) ) {
        return;
    }

    $removed_slugs = get_option( 'ie_provider_categories_removed_slugs', [] );
    if ( ! is_array( $removed_slugs ) ) {
        $removed_slugs = [];
    }

    foreach ( ie_get_default_provider_categories() as $index => $cat ) {
        if ( in_array( $cat['slug'], $removed_slugs, true ) ) {
            continue;
        }

        $existing = get_posts( [
            'post_type'      => 'ie_provider_category',
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_key'       => '_ie_cat_browse_slug',
            'meta_value'     => $cat['slug'],
        ] );

        if ( $existing ) {
            continue;
        }

        $post_id = wp_insert_post( [
            'post_title'  => $cat['title'],
            'post_name'   => $cat['slug'],
            'post_type'   => 'ie_provider_category',
            'post_status' => 'publish',
            'menu_order'  => $cat['menu_order'] ?? ( $index + 1 ),
        ] );

        if ( is_wp_error( $post_id ) || ! $post_id ) {
            continue;
        }

        update_post_meta( $post_id, '_ie_cat_icon_type', $cat['icon_type'] );
        update_post_meta( $post_id, '_ie_cat_icon_class', $cat['icon_class'] );
        update_post_meta( $post_id, '_ie_cat_short_description', $cat['short_description'] );
        update_post_meta( $post_id, '_ie_cat_browse_slug', $cat['slug'] );

        if ( ! term_exists( $cat['slug'], 'ie_category' ) ) {
            wp_insert_term( $cat['title'], 'ie_category', [ 'slug' => $cat['slug'] ] );
        }
    }

    update_option( 'ie_provider_categories_seeded', 1 );
}

function ie_track_deleted_provider_category( $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id || get_post_type( $post_id ) !== 'ie_provider_category' ) {
        return;
    }

    $slug = (string) get_post_meta( $post_id, '_ie_cat_browse_slug', true );
    if ( $slug === '' ) {
        $slug = (string) get_post_field( 'post_name', $post_id );
    }

    $slug = sanitize_title( $slug );
    if ( $slug === '' ) {
        return;
    }

    $default_slugs = wp_list_pluck( ie_get_default_provider_categories(), 'slug' );
    if ( ! in_array( $slug, $default_slugs, true ) ) {
        return;
    }

    $removed_slugs = get_option( 'ie_provider_categories_removed_slugs', [] );
    if ( ! is_array( $removed_slugs ) ) {
        $removed_slugs = [];
    }

    if ( in_array( $slug, $removed_slugs, true ) ) {
        return;
    }

    $removed_slugs[] = $slug;
    update_option( 'ie_provider_categories_removed_slugs', array_values( array_unique( $removed_slugs ) ) );
}
add_action( 'before_delete_post', 'ie_track_deleted_provider_category' );

function ie_migrate_provider_category_seed_lock() {
    if ( get_option( 'ie_provider_categories_seed_lock_v1' ) ) {
        return;
    }

    $has_categories = (bool) get_posts( [
        'post_type'      => 'ie_provider_category',
        'post_status'    => 'any',
        'posts_per_page' => 1,
        'fields'         => 'ids',
    ] );

    if ( $has_categories ) {
        update_option( 'ie_provider_categories_seeded', 1 );
    }

    update_option( 'ie_provider_categories_seed_lock_v1', 1 );
}
add_action( 'init', 'ie_migrate_provider_category_seed_lock', 20 );

function ie_enqueue_provider_category_admin_assets( $hook ) {
    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'ie_provider_category' ) {
        return;
    }

    if ( ! in_array( $hook, [ 'post.php', 'post-new.php', 'edit.php' ], true ) ) {
        return;
    }

    wp_enqueue_style(
        'font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
        [],
        '6.5.2'
    );

    if ( $hook === 'edit.php' ) {
        return;
    }

    wp_enqueue_style(
        'ie-admin-provider-category',
        ie_asset_uri( 'css/admin-provider-category.css' ),
        [],
        IE_THEME_VERSION
    );

    wp_enqueue_media();

    wp_enqueue_script(
        'ie-admin-provider-category',
        ie_asset_uri( 'js/admin-provider-category.js' ),
        [ 'jquery', 'media-editor' ],
        IE_THEME_VERSION,
        true
    );

    wp_localize_script(
        'ie-admin-provider-category',
        'IE_PROVIDER_CAT_ADMIN',
        [
            'selectImage'      => ie__( 'Select Category Icon' ),
            'useImage'         => ie__( 'Use this icon' ),
            'noImage'          => ie__( 'No image' ),
            'bgDefaults'       => ie_get_provider_category_icon_bg_defaults(),
            'bgFallback'       => ie_get_provider_category_default_icon_bg( '' ),
            'colorDefaults'    => ie_get_provider_category_icon_color_defaults(),
            'colorFallback'    => ie_get_provider_category_default_icon_color( '' ),
            'defaultForLabel'  => ie__( 'Default for this category: %s' ),
            'resetBg'          => ie__( 'Reset to default' ),
        ]
    );
}
add_action( 'admin_enqueue_scripts', 'ie_enqueue_provider_category_admin_assets' );
