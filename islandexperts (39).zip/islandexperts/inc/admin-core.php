<?php
/**
 * Island Experts admin core (capabilities, UI shell, menu, assets).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'IE_ADMIN_CAPABILITY', 'ie_manage_platform' );

function ie_admin_register_capabilities() {
    $role = get_role( 'administrator' );
    if ( $role && ! $role->has_cap( IE_ADMIN_CAPABILITY ) ) {
        $role->add_cap( IE_ADMIN_CAPABILITY );
    }
}
add_action( 'after_switch_theme', 'ie_admin_register_capabilities' );
add_action( 'admin_init', 'ie_admin_register_capabilities' );

function ie_admin_user_can() {
    return current_user_can( 'manage_options' ) || current_user_can( IE_ADMIN_CAPABILITY );
}

function ie_admin_verify_request( $nonce_action, $nonce_field = 'nonce' ) {
    if ( ! ie_admin_user_can() ) {
        wp_send_json_error( [ 'message' => ie__( 'Permission denied.' ) ], 403 );
    }

    if ( ! check_ajax_referer( $nonce_action, $nonce_field, false ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Invalid security token.' ) ], 403 );
    }
}

function ie_admin_verify_post( $nonce_action, $nonce_field ) {
    if ( ! ie_admin_user_can() ) {
        wp_die( esc_html( ie__( 'You do not have permission to access this page.' ) ) );
    }

    check_admin_referer( $nonce_action, $nonce_field );
}

function ie_get_user_account_status( $user_id ) {
    $status = get_user_meta( $user_id, '_ie_account_status', true );
    return in_array( $status, [ 'active', 'suspended' ], true ) ? $status : 'active';
}

function ie_set_user_account_status( $user_id, $status ) {
    if ( ! in_array( $status, [ 'active', 'suspended' ], true ) ) {
        return false;
    }

    return (bool) update_user_meta( $user_id, '_ie_account_status', $status );
}

function ie_block_suspended_user_login( $user, $username, $password ) {
    if ( $user instanceof WP_User && ie_get_user_account_status( $user->ID ) === 'suspended' ) {
        return new WP_Error(
            'ie_account_suspended',
            ie__( 'Your account has been suspended. Please contact support.' )
        );
    }

    return $user;
}
add_filter( 'authenticate', 'ie_block_suspended_user_login', 30, 3 );

function ie_admin_get_pages() {
    return [
        'ie-admin-dashboard' => [
            'section' => 'dashboard',
            'label'   => ie__( 'Dashboard' ),
            'title'   => ie__( 'Dashboard' ),
            'desc'    => ie__( 'Platform overview and quick stats.' ),
            'icon'    => 'dashicons-dashboard',
        ],
        'ie-admin-users' => [
            'section' => 'users',
            'label'   => ie__( 'User Management' ),
            'title'   => ie__( 'User Management' ),
            'desc'    => ie__( 'Manage clients and service providers.' ),
            'icon'    => 'dashicons-groups',
        ],
        'ie-admin-subscriptions' => [
            'section' => 'subscriptions',
            'label'   => ie__( 'Subscriptions' ),
            'title'   => ie__( 'Subscription Management' ),
            'desc'    => ie__( 'Manage plans and subscriber accounts.' ),
            'icon'    => 'dashicons-tickets-alt',
        ],
        'ie-admin-payments' => [
            'section' => 'payments',
            'label'   => ie__( 'Payment Settings' ),
            'title'   => ie__( 'Payment Gateway Settings' ),
            'desc'    => ie__( 'Configure Stripe and view payment logs.' ),
            'icon'    => 'dashicons-money-alt',
        ],
        'ie-admin-reviews' => [
            'section' => 'reviews',
            'label'   => ie__( 'Reviews' ),
            'title'   => ie__( 'Reviews Management' ),
            'desc'    => ie__( 'Moderate provider reviews.' ),
            'icon'    => 'dashicons-star-filled',
        ],
        'ie-admin-reports' => [
            'section' => 'reports',
            'label'   => ie__( 'Reports & Export' ),
            'title'   => ie__( 'Reports & Export' ),
            'desc'    => ie__( 'Export user, subscription, and payment reports.' ),
            'icon'    => 'dashicons-chart-bar',
        ],
    ];
}

function ie_admin_get_current_page() {
    $page  = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'ie-admin-dashboard';
    $pages = ie_admin_get_pages();

    return isset( $pages[ $page ] ) ? $page : 'ie-admin-dashboard';
}

function ie_admin_render_shell_open( $current_page ) {
    if ( ! ie_admin_user_can() ) {
        return;
    }

    $pages   = ie_admin_get_pages();
    $current = $pages[ $current_page ];
    ?>
    <div class="wrap ie-admin-dashboard">
        <div class="ie-ad-header">
            <div class="ie-ad-header-icon" aria-hidden="true">
                <span class="dashicons dashicons-palmtree"></span>
            </div>
            <div>
                <h1><?php echo esc_html( ie__( 'Admin dashboard' ) ); ?></h1>
                <p><?php echo esc_html( $current['desc'] ); ?></p>
            </div>
        </div>

        <div class="ie-ad-panel">
            <div class="ie-ad-panel-head">
                <h2><?php echo esc_html( $current['title'] ); ?></h2>
            </div>
            <div class="ie-ad-panel-body">
    <?php
}

function ie_admin_render_shell_close() {
    ?>
            </div>
        </div>
    </div>

    <div id="ie-admin-modal" class="ie-ad-modal" hidden aria-hidden="true">
        <div class="ie-ad-modal-backdrop" data-close-modal></div>
        <div class="ie-ad-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="ie-admin-modal-title">
            <div class="ie-ad-modal-header">
                <h3 id="ie-admin-modal-title"></h3>
                <button type="button" class="ie-ad-modal-close" data-close-modal aria-label="<?php echo esc_attr( ie__( 'Close' ) ); ?>">&times;</button>
            </div>
            <div class="ie-ad-modal-body"></div>
            <div class="ie-ad-modal-footer"></div>
        </div>
    </div>
    <?php
}

function ie_admin_render_tabs( $tabs, $active ) {
    ?>
    <div class="ie-ad-tabs" role="tablist">
        <?php foreach ( $tabs as $key => $label ) : ?>
            <button type="button"
                    class="ie-ad-tab<?php echo $active === $key ? ' is-active' : ''; ?>"
                    data-tab="<?php echo esc_attr( $key ); ?>"
                    role="tab"
                    aria-selected="<?php echo $active === $key ? 'true' : 'false'; ?>">
                <?php echo esc_html( $label ); ?>
            </button>
        <?php endforeach; ?>
    </div>
    <?php
}

function ie_admin_render_toolbar( $search_placeholder, $filters = [] ) {
    ?>
    <div class="ie-ad-toolbar">
        <div class="ie-ad-search">
            <span class="dashicons dashicons-search" aria-hidden="true"></span>
            <input type="search" id="ie-ad-search" placeholder="<?php echo esc_attr( $search_placeholder ); ?>">
        </div>
        <?php if ( $filters ) : ?>
            <div class="ie-ad-filters">
                <?php foreach ( $filters as $filter ) : ?>
                    <select id="<?php echo esc_attr( $filter['id'] ); ?>" class="ie-ad-filter">
                        <?php foreach ( $filter['options'] as $value => $label ) : ?>
                            <option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

function ie_admin_status_badge( $status ) {
    $map = [
        'active'    => 'is-success',
        'suspended' => 'is-danger',
        'inactive'  => 'is-muted',
        'pending'   => 'is-warning',
        'expired'   => 'is-danger',
        'success'   => 'is-success',
        'failed'    => 'is-danger',
    ];
    $class = $map[ $status ] ?? 'is-muted';
    ?>
    <span class="ie-ad-badge <?php echo esc_attr( $class ); ?>"><?php echo esc_html( ucfirst( $status ) ); ?></span>
    <?php
}

function ie_admin_notice( $message, $type = 'success' ) {
    printf(
        '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
        esc_attr( $type ),
        esc_html( $message )
    );
}

function ie_admin_register_menu() {
    add_menu_page(
        ie__( 'Admin dashboard' ),
        ie__( 'Admin dashboard' ),
        'manage_options',
        'ie-admin-dashboard',
        'ie_admin_render_dashboard_page',
        'dashicons-palmtree',
        3
    );

    remove_submenu_page( 'ie-admin-dashboard', 'ie-admin-dashboard' );

    $submenus = [
        'ie-admin-dashboard'     => [
            'callback' => 'ie_admin_render_dashboard_page',
            'label'    => ie__( 'Dashboard' ),
            'title'    => ie__( 'Dashboard' ),
        ],
        'ie-admin-users'         => [
            'callback' => 'ie_admin_render_users_page',
            'label'    => ie__( 'User Management' ),
            'title'    => ie__( 'User Management' ),
        ],
        'ie-admin-subscriptions' => [
            'callback' => 'ie_admin_render_subscriptions_page',
            'label'    => ie__( 'Subscriptions' ),
            'title'    => ie__( 'Subscription Management' ),
        ],
        'ie-admin-payments'      => [
            'callback' => 'ie_admin_render_payments_page',
            'label'    => ie__( 'Payment Settings' ),
            'title'    => ie__( 'Payment Gateway Settings' ),
        ],
        'ie-admin-reviews'       => [
            'callback' => 'ie_admin_render_reviews_page',
            'label'    => ie__( 'Reviews' ),
            'title'    => ie__( 'Reviews Management' ),
        ],
        'ie-admin-reports'       => [
            'callback' => 'ie_admin_render_reports_page',
            'label'    => ie__( 'Reports & Export' ),
            'title'    => ie__( 'Reports & Export' ),
        ],
    ];

    foreach ( $submenus as $slug => $item ) {
        add_submenu_page(
            'ie-admin-dashboard',
            $item['title'],
            $item['label'],
            'manage_options',
            $slug,
            $item['callback']
        );
    }
}
add_action( 'admin_menu', 'ie_admin_register_menu' );

function ie_admin_enqueue_assets( $hook ) {
    if ( strpos( $hook, 'ie-admin' ) === false && strpos( $hook, 'ie-theme-settings' ) === false ) {
        return;
    }

    wp_enqueue_style(
        'font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
        [],
        '6.5.2'
    );

    wp_enqueue_style(
        'ie-admin',
        ie_asset_uri( 'css/admin.css' ),
        [ 'wp-admin', 'dashicons', 'font-awesome' ],
        IE_THEME_VERSION
    );

    wp_add_inline_style( 'ie-admin', ie_get_theme_brand_root_css() );

    if ( strpos( $hook, 'ie-admin' ) !== false ) {
        wp_enqueue_script(
            'ie-admin-dashboard',
            ie_asset_uri( 'js/admin-dashboard.js' ),
            [ 'jquery' ],
            IE_THEME_VERSION,
            true
        );

        wp_localize_script(
            'ie-admin-dashboard',
            'IE_ADMIN',
            [
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'ie_admin_dashboard' ),
                'strings' => [
                    'confirmDelete'  => ie__( 'Are you sure you want to delete this item? This cannot be undone.' ),
                    'confirmSuspend' => ie__( 'Suspend this user account?' ),
                    'loading'        => ie__( 'Loading...' ),
                    'noResults'      => ie__( 'No results found.' ),
                    'view'           => ie__( 'View' ),
                    'suspend'        => ie__( 'Suspend' ),
                    'activate'       => ie__( 'Activate' ),
                    'delete'         => ie__( 'Delete' ),
                    'clientInfo'     => ie__( 'Client Information' ),
                    'providerInfo'   => ie__( 'Service Provider Information' ),
                    'adminActions'   => ie__( 'Admin Actions' ),
                    'viewProfile'    => ie__( 'View Full Profile' ),
                    'fullName'       => ie__( 'Full Name' ),
                    'email'          => ie__( 'Email' ),
                    'phone'          => ie__( 'Phone Number' ),
                    'registered'     => ie__( 'Registration Date' ),
                    'status'         => ie__( 'Account Status' ),
                    'subscription'   => ie__( 'Subscription Plan' ),
                    'services'       => ie__( 'Services Created' ),
                    'reviews'        => ie__( 'Total Reviews' ),
                    'rating'         => ie__( 'Rating' ),
                    'actionSuccess'  => ie__( 'Action completed successfully.' ),
                    'actionFailed'   => ie__( 'Action failed. Please try again.' ),
                    'stripeTesting'  => ie__( 'Testing Stripe connection...' ),
                    'editPlan'       => ie__( 'Edit Plan' ),
                    'addPlan'        => ie__( 'Add New Plan' ),
                    'cancel'         => ie__( 'Cancel' ),
                    'savePlans'      => ie__( 'Save Plans' ),
                    'planRequired'   => ie__( 'At least one plan is required.' ),
                    'featureIcon'    => ie__( 'Feature icon' ),
                    'featureText'    => ie__( 'Feature text' ),
                    'removeFeature'  => ie__( 'Remove' ),
                    'billingPeriod'  => ie__( 'Billing period' ),
                    'price'            => ie__( 'Price' ),
                    'addPrice'         => ie__( 'Add Price' ),
                    'removePrice'      => ie__( 'Remove' ),
                    'monthly'          => ie__( 'Monthly' ),
                    'yearly'           => ie__( 'Yearly' ),
                ],
                'featureIcons' => ie_admin_get_plan_feature_icon_options(),
                'pricingPeriods' => ie_admin_get_plan_pricing_period_options(),
            ]
        );
    }
}
add_action( 'admin_enqueue_scripts', 'ie_admin_enqueue_assets' );

function ie_admin_load_modules() {
    $dir = get_template_directory() . '/admin';
    require_once $dir . '/users.php';
    require_once $dir . '/subscriptions.php';
    require_once $dir . '/payments.php';
    require_once $dir . '/reviews.php';
    require_once $dir . '/reports.php';
}
ie_admin_load_modules();
