<?php
/**
 * Island Experts - functions.php (v2.3)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'IE_THEME_VERSION', '2.19.1' );
define( 'IE_TEXT_DOMAIN', 'island-experts' );
define( 'IE_THEME_PREFIX', 'ie_' );

require_once get_template_directory() . '/inc/faq-helpers.php';
require_once get_template_directory() . '/inc/faq-meta.php';
require_once get_template_directory() . '/inc/contact-helpers.php';
require_once get_template_directory() . '/inc/contact-meta.php';
require_once get_template_directory() . '/inc/browse-helpers.php';
require_once get_template_directory() . '/inc/browse-meta.php';
require_once get_template_directory() . '/inc/price-helpers.php';
require_once get_template_directory() . '/inc/price-meta.php';
require_once get_template_directory() . '/inc/terms-helpers.php';
require_once get_template_directory() . '/inc/terms-meta.php';
require_once get_template_directory() . '/inc/privacy-helpers.php';
require_once get_template_directory() . '/inc/privacy-meta.php';
require_once get_template_directory() . '/inc/home-helpers.php';
require_once get_template_directory() . '/inc/home-meta.php';
require_once get_template_directory() . '/inc/provider-category-helpers.php';
require_once get_template_directory() . '/inc/provider-category-meta.php';
require_once get_template_directory() . '/inc/theme-settings-helpers.php';
require_once get_template_directory() . '/inc/theme-settings-admin.php';
require_once get_template_directory() . '/inc/header-nav.php';
require_once get_template_directory() . '/inc/admin-core.php';

function ie__( $text ) {
    return __( $text, IE_TEXT_DOMAIN );
}

function ie_esc_html__( $text ) {
    return esc_html__( $text, IE_TEXT_DOMAIN );
}

function ie_esc_attr__( $text ) {
    return esc_attr__( $text, IE_TEXT_DOMAIN );
}

function ie_provider_count_label( $count ) {
    return sprintf(
        _n( '%d provider', '%d providers', (int) $count, IE_TEXT_DOMAIN ),
        (int) $count
    );
}

function ie_get_availability_labels() {
    return [
        'available_now'  => ie__( 'Available Now' ),
        'available_week' => ie__( 'Available This Week' ),
        'busy'           => ie__( 'Busy – Book Ahead' ),
    ];
}

function ie_asset_uri( $path = '' ) {
    return get_template_directory_uri() . '/assets/' . ltrim( $path, '/' );
}

function ie_image_uri( $filename ) {
    return ie_asset_uri( 'images/' . ltrim( $filename, '/' ) );
}

function ie_theme_setup() {
    load_theme_textdomain( IE_TEXT_DOMAIN, get_template_directory() . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'gallery', 'caption' ] );
    add_theme_support( 'custom-logo', [ 'width' => 200, 'height' => 70 ] );
    register_nav_menus( [ 'primary' => ie__( 'Primary Menu' ) ] );
}
add_action( 'after_setup_theme', 'ie_theme_setup' );

function ie_enqueue_assets() {
    wp_enqueue_style( 'google-fonts', ie_get_theme_google_fonts_url(), [], ie_get_theme_google_fonts_version() );
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', [], '6.5.2' );
    wp_enqueue_style( 'island-experts-style', ie_asset_uri( 'css/main.css' ), [ 'google-fonts', 'font-awesome' ], IE_THEME_VERSION );
    wp_enqueue_script( 'island-experts-main', ie_asset_uri( 'js/main.js' ), [ 'jquery' ], IE_THEME_VERSION, true );
    wp_localize_script( 'island-experts-main', 'IE_AJAX', [
        'url'   => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'ie_nonce' ),
        'urls'  => [
            'home'            => ie_get_theme_page_url( 'home' ),
            'browse'          => ie_get_theme_page_url( 'browse' ),
            'account'         => ie_get_theme_page_url( 'account' ),
            'clientProfile'   => ie_get_theme_page_url( 'client-profile' ),
            'providerProfile' => ie_get_theme_page_url( 'provider-profile' ),
        ],
        'logoutFallback' => wp_logout_url( ie_get_theme_page_url( 'home' ) ),
    ] );
    wp_localize_script( 'island-experts-main', 'IE_I18N', [
        'loading'              => ie__( 'Loading...' ),
        'loadingProviders'     => ie__( 'Loading providers...' ),
        'loadingBookings'      => ie__( 'Loading your bookings...' ),
        'loadingSaved'         => ie__( 'Loading saved providers...' ),
        'providersFound'       => ie__( '%d providers found' ),
        'providerFound'        => ie__( '1 provider found' ),
        'saveProvider'         => ie__( 'Save provider' ),
        'verified'             => ie__( 'Verified' ),
        'yrsExp'               => ie__( 'yrs exp' ),
        'fromPrice'            => ie__( 'From' ),
        'perService'           => ie__( '/ service' ),
        'cancel'               => ie__( 'Cancel' ),
        'connectionError'      => ie__( 'Connection error. Please try again.' ),
        'fillRequired'         => ie__( 'Please fill in all required fields.' ),
        'selectDate'           => ie__( 'Please select a preferred date.' ),
        'confirmCancelBooking' => ie__( 'Are you sure you want to cancel this booking?' ),
        'confirmLogout'        => ie__( 'Are you sure you want to log out?' ),
        'sending'              => ie__( 'Sending...' ),
        'sendMessage'          => ie__( 'Send Message →' ),
        'contactSuccess'       => ie__( 'Thank you! Your message has been sent. We\'ll get back to you within 24 hours.' ),
        'contactFailed'        => ie__( 'Failed to send. Please try again.' ),
        'noProviders'          => ie__( 'No providers found' ),
        'tryFilters'           => ie__( 'Try different filters or search terms.' ),
        'failedLoad'           => ie__( 'Failed to load' ),
        'browseProviders'      => ie__( 'Browse Providers' ),
        'chat'                 => ie__( 'Chat' ),
        'viewProfile'          => ie__( 'View Profile' ),
        'reviews'              => ie__( 'reviews' ),
        'profileComplete'      => ie__( 'Your profile information is 100% complete.' ),
        'profileIncomplete'    => ie__( 'Fill in all profile information to reach 100%.' ),
        'paginationPrevious'   => ie__( 'Previous' ),
        'paginationNext'       => ie__( 'Next' ),
        'paginationShowing'    => ie__( 'Showing %1$d–%2$d of %3$d providers' ),
        'paginationShowingFavorites' => ie__( 'Showing %1$d–%2$d of %3$d saved providers' ),
        'conversations'        => ie__( 'Conversations' ),
        'searchChat'           => ie__( 'Search chat...' ),
        'writeMessage'         => ie__( 'Write a message...' ),
        'selectConversation'   => ie__( 'Select a conversation to start chatting.' ),
        'noConversations'      => ie__( 'No conversations yet' ),
        'startChatHint'        => ie__( 'Browse providers and send a message to start a conversation.' ),
        'messageSent'          => ie__( 'Message sent!' ),
        'loadingMessages'      => ie__( 'Loading messages...' ),
        'specialist'           => ie__( 'Specialist' ),
        'backToConversations'  => ie__( 'Back to conversations' ),
        'customerInquiries'    => ie__( 'Customer Inquiries' ),
        'addService'           => ie__( 'Add Service' ),
        'saveServices'         => ie__( 'Save Services' ),
        'servicesUpdated'      => ie__( 'Services updated successfully!' ),
        'replyToCustomers'     => ie__( 'Reply to customer inquiries here.' ),
        'noCustomerMessages'   => ie__( 'No customer messages yet' ),
        'workGalleryMax'       => ie__( 'You can upload up to 10 work preview images.' ),
        'download'             => ie__( 'Download' ),
        'removeAttachment'     => ie__( 'Remove attachment' ),
        'deleteConversation'   => ie__( 'Delete conversation' ),
        'deleteUser'           => ie__( 'Delete user' ),
        'confirmDeleteChat'    => ie__( 'Delete this conversation and all messages with this provider?' ),
        'confirmDeleteCustomerChat' => ie__( 'Delete this conversation and all messages with this customer?' ),
        'conversationDeleted'  => ie__( 'Conversation deleted.' ),
        'chatOptions'          => ie__( 'Chat options' ),
        'newMessages'          => ie__( 'New messages' ),
        'viewMessages'         => ie__( 'View messages' ),
        'accountMenu'          => ie__( 'Account menu' ),
    ]);

    $wishlist_items = is_user_logged_in() ? ie_get_user_wishlist() : [];
    wp_localize_script( 'island-experts-main', 'IE_WISHLIST', [
        'ids'   => array_values( array_map( 'intval', array_filter( $wishlist_items, 'is_numeric' ) ) ),
        'slugs' => array_values( array_filter( $wishlist_items, function( $item ) {
            return ! is_numeric( $item ) && $item;
        } ) ),
    ] );
}
add_action( 'wp_enqueue_scripts', 'ie_enqueue_assets' );

function ie_register_cpts() {
    register_post_type( 'ie_provider', [
        'labels'       => [
            'name'          => ie__( 'Providers' ),
            'singular_name' => ie__( 'Provider' ),
            'add_new_item'  => ie__( 'Add New Provider' ),
            'edit_item'     => ie__( 'Edit Provider' ),
            'menu_name'     => ie__( 'Providers' ),
        ],
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => [ 'slug' => 'providers' ],
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt' ],
        'show_in_rest' => true,
        'show_ui'      => false,
    ] );
    register_post_type( 'ie_booking', [
        'labels'   => [
            'name'          => ie__( 'Bookings' ),
            'singular_name' => ie__( 'Booking' ),
        ],
        'public'   => false,
        'show_ui'  => false,
        'supports' => [ 'title' ],
    ] );
    register_post_type( 'ie_message', [
        'labels'   => [
            'name'          => ie__( 'Messages' ),
            'singular_name' => ie__( 'Message' ),
        ],
        'public'          => false,
        'show_ui'         => true,
        'supports'        => [ 'title', 'editor' ],
        'menu_icon'       => 'dashicons-email-alt',
        'capability_type' => 'ie_message',
        'map_meta_cap'    => true,
    ] );
    register_post_type( 'ie_provider_category', [
        'labels'       => [
            'name'               => ie__( 'Provider Categories' ),
            'singular_name'      => ie__( 'Provider Category' ),
            'add_new'            => ie__( 'Add New' ),
            'add_new_item'       => ie__( 'Add New Category' ),
            'edit_item'          => ie__( 'Edit Category' ),
            'new_item'           => ie__( 'New Category' ),
            'view_item'          => ie__( 'View Category' ),
            'search_items'       => ie__( 'Search Categories' ),
            'not_found'          => ie__( 'No categories found' ),
            'not_found_in_trash' => ie__( 'No categories found in Trash' ),
            'menu_name'          => ie__( 'Provider Categories' ),
        ],
        'public'       => false,
        'show_ui'      => true,
        'supports'     => [ 'title', 'page-attributes' ],
        'menu_icon'    => 'dashicons-category',
    ] );
}
add_action( 'init', 'ie_register_cpts' );

function ie_user_can_use_messaging( $user_id = 0 ) {
    $user_id = (int) ( $user_id ?: get_current_user_id() );
    if ( $user_id < 1 ) {
        return false;
    }

    return in_array( ie_get_user_type( $user_id ), [ 'customer', 'provider' ], true );
}

function ie_user_is_message_participant( $user_id, $message_id ) {
    $user_id     = (int) $user_id;
    $message_id  = (int) $message_id;
    $customer_id = (int) get_post_meta( $message_id, '_ie_user_id', true );
    $provider_id = (int) get_post_meta( $message_id, '_ie_provider_id', true );

    if ( $customer_id === $user_id ) {
        return true;
    }

    if ( ie_get_user_type( $user_id ) === 'provider' ) {
        $provider_post = ie_get_provider_post_by_user( $user_id );

        return $provider_post && (int) $provider_post->ID === $provider_id;
    }

    return false;
}

function ie_map_ie_message_cap( $caps, $cap, $user_id, $args ) {
    $message_caps = [
        'edit_ie_message',
        'read_ie_message',
        'delete_ie_message',
        'edit_ie_messages',
        'edit_others_ie_messages',
        'publish_ie_messages',
        'read_private_ie_messages',
        'delete_ie_messages',
        'create_ie_messages',
    ];

    if ( ! in_array( $cap, $message_caps, true ) ) {
        return $caps;
    }

    if ( ! ie_user_can_use_messaging( $user_id ) ) {
        return $caps;
    }

    $post_id = isset( $args[0] ) ? (int) $args[0] : 0;
    if ( $post_id > 0 ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_type !== 'ie_message' ) {
            return $caps;
        }

        if ( ie_user_is_message_participant( $user_id, $post_id ) || user_can( $user_id, 'manage_options' ) ) {
            return [ 'read' ];
        }

        return [ 'do_not_allow' ];
    }

    if ( in_array( $cap, [ 'edit_ie_messages', 'create_ie_messages', 'publish_ie_messages' ], true ) ) {
        return [ 'read' ];
    }

    return $caps;
}
add_filter( 'map_meta_cap', 'ie_map_ie_message_cap', 10, 4 );

function ie_register_taxonomies() {
    register_taxonomy( 'ie_category', 'ie_provider', [
        'labels' => [
            'name'          => ie__( 'Categories' ),
            'singular_name' => ie__( 'Category' ),
        ],
        'hierarchical' => true,
        'rewrite'      => [ 'slug' => 'provider-category' ],
        'show_in_rest' => true,
        'show_ui'      => false,
    ] );
    register_taxonomy( 'ie_location', 'ie_provider', [
        'labels' => [
            'name'          => ie__( 'Locations' ),
            'singular_name' => ie__( 'Location' ),
        ],
        'hierarchical' => false,
        'rewrite'      => [ 'slug' => 'provider-location' ],
        'show_in_rest' => true,
        'show_ui'      => false,
    ] );
}
add_action( 'init', 'ie_register_taxonomies' );

/* === PROVIDER META BOX === */
function ie_add_provider_meta_box() {
    add_meta_box( 'ie_provider_details', ie__( 'Provider Details' ), 'ie_provider_meta_box_cb', 'ie_provider', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'ie_add_provider_meta_box' );

function ie_provider_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_provider', 'ie_provider_nonce' );
    $text_fields = [
        '_ie_rating'           => [ 'label' => ie__( 'Rating (e.g. 4.9)' ), 'type' => 'text' ],
        '_ie_review_count'     => [ 'label' => ie__( 'Review Count' ), 'type' => 'number' ],
        '_ie_price_from'       => [ 'label' => ie__( 'Starting Price ($)' ), 'type' => 'text' ],
        '_ie_experience_years' => [ 'label' => ie__( 'Experience (years)' ), 'type' => 'number' ],
        '_ie_service_area'     => [ 'label' => ie__( 'Service Area' ), 'type' => 'text' ],
        '_ie_phone'            => [ 'label' => ie__( 'Phone' ), 'type' => 'text' ],
        '_ie_email'            => [ 'label' => ie__( 'Email' ), 'type' => 'email' ],
        '_ie_website'          => [ 'label' => ie__( 'Website URL' ), 'type' => 'url' ],
        '_ie_chat_link'        => [ 'label' => ie__( 'Chat Link (WhatsApp/etc)' ), 'type' => 'url' ],
    ];
    $textarea_fields = [
        '_ie_about'    => ie__( 'About (description)' ),
        '_ie_services' => ie__( 'Services & Pricing (JSON)' ),
    ];
    $availability = get_post_meta( $post->ID, '_ie_availability', true ) ?: 'available_now';
    $verified     = get_post_meta( $post->ID, '_ie_verified', true );
    $premium      = get_post_meta( $post->ID, '_ie_premium',  true );

    echo '<table class="form-table" style="width:100%">';
    foreach ( $text_fields as $key => $field ) {
        $val = esc_attr( get_post_meta( $post->ID, $key, true ) );
        echo "<tr><th><label for='{$key}'>{$field['label']}</label></th><td><input type='{$field['type']}' id='{$key}' name='{$key}' value='{$val}' style='width:100%'></td></tr>";
    }
    foreach ( $textarea_fields as $key => $label ) {
        $val = esc_textarea( get_post_meta( $post->ID, $key, true ) );
        echo "<tr><th><label for='{$key}'>{$label}</label></th><td><textarea id='{$key}' name='{$key}' rows='4' style='width:100%'>{$val}</textarea></td></tr>";
    }
    echo '</table>';
    echo '<p><label><b>' . esc_html( ie__( 'Availability:' ) ) . '</b></label><br><select name="_ie_availability" style="margin-top:6px">';
    foreach ( ie_get_availability_labels() as $val => $label ) {
        echo "<option value='{$val}'" . selected( $availability, $val, false ) . '>' . esc_html( $label ) . '</option>';
    }
    echo '</select></p>';
    echo '<p><label><input type="checkbox" name="_ie_verified" value="1"' . checked( $verified, '1', false ) . '> <b>' . esc_html( ie__( 'Verified Provider' ) ) . '</b></label></p>';
    echo '<p><label><input type="checkbox" name="_ie_premium" value="1"' . checked( $premium, '1', false ) . '> <b>' . esc_html( ie__( 'Premium Provider' ) ) . '</b></label></p>';
}

function ie_save_provider_meta( $post_id ) {
    if ( !isset($_POST['ie_provider_nonce']) || !wp_verify_nonce($_POST['ie_provider_nonce'],'ie_save_provider') ) return;
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
    if ( get_post_type($post_id) !== 'ie_provider' ) return;
    foreach ( ['_ie_rating','_ie_review_count','_ie_price_from','_ie_experience_years','_ie_service_area','_ie_phone','_ie_email','_ie_website','_ie_availability','_ie_chat_link'] as $f ) {
        if ( isset($_POST[$f]) ) update_post_meta($post_id,$f,sanitize_text_field($_POST[$f]));
    }
    if ( isset($_POST['_ie_about']) )    update_post_meta($post_id,'_ie_about',   sanitize_textarea_field($_POST['_ie_about']));
    if ( isset($_POST['_ie_services']) ) update_post_meta($post_id,'_ie_services',sanitize_textarea_field($_POST['_ie_services']));
    update_post_meta($post_id,'_ie_verified',isset($_POST['_ie_verified'])?'1':'');
    update_post_meta($post_id,'_ie_premium', isset($_POST['_ie_premium']) ?'1':'');
}
add_action( 'save_post', 'ie_save_provider_meta' );

/* === PROVIDER ADMIN COLUMNS === */
function ie_provider_columns( $cols ) {
    return array_merge(
        array_slice( $cols, 0, 2 ),
        [
            'category' => ie__( 'Category' ),
            'rating'   => ie__( 'Rating' ),
            'price'    => ie__( 'Price From' ),
            'verified' => ie__( 'Verified' ),
            'premium'  => ie__( 'Premium' ),
        ],
        array_slice( $cols, 2 )
    );
}
add_filter('manage_ie_provider_posts_columns','ie_provider_columns');
function ie_provider_column_data($col,$post_id) {
    switch($col) {
        case 'category': $t=get_the_terms($post_id,'ie_category'); echo $t?esc_html($t[0]->name):'—'; break;
        case 'rating':   $r=get_post_meta($post_id,'_ie_rating',true); $c=get_post_meta($post_id,'_ie_review_count',true); echo $r?"⭐{$r}({$c})":'—'; break;
        case 'price':    $p=get_post_meta($post_id,'_ie_price_from',true); echo $p?'$'.esc_html($p):'—'; break;
        case 'verified': echo get_post_meta($post_id,'_ie_verified',true)?'✅':'—'; break;
        case 'premium':  echo get_post_meta($post_id,'_ie_premium', true)?'⭐':'—'; break;
    }
}
add_action('manage_ie_provider_posts_custom_column','ie_provider_column_data',10,2);

/* === BOOKING ADMIN META BOX === */
function ie_add_booking_meta_box() {
    add_meta_box( 'ie_booking_details', ie__( 'Booking Details' ), 'ie_booking_meta_box_cb', 'ie_booking', 'normal', 'high' );
}
add_action('add_meta_boxes','ie_add_booking_meta_box');
function ie_booking_meta_box_cb($post) {
    $bid=$post->ID; $provider_id=get_post_meta($bid,'_ie_provider_id',true); $user_id=get_post_meta($bid,'_ie_user_id',true);
    $status=get_post_meta($bid,'_ie_status',true)?:'pending'; $user_obj=$user_id?get_user_by('id',$user_id):null;
    wp_nonce_field('ie_save_booking','ie_booking_nonce');
    echo '<table class="form-table">';
    echo '<tr><th>' . esc_html( ie__( 'Provider' ) ) . '</th><td>' . esc_html( $provider_id ? get_the_title( $provider_id ) : ie__( 'Unknown' ) ) . '</td></tr>';
    echo '<tr><th>' . esc_html( ie__( 'Customer' ) ) . '</th><td>' . esc_html( $user_obj ? $user_obj->display_name . ' (' . $user_obj->user_email . ')' : ie__( 'Unknown' ) ) . '</td></tr>';
    echo '<tr><th>' . esc_html( ie__( 'Service' ) ) . '</th><td>' . esc_html( get_post_meta( $bid, '_ie_service', true ) ) . '</td></tr>';
    echo '<tr><th>' . esc_html( ie__( 'Date' ) ) . '</th><td>' . esc_html( get_post_meta( $bid, '_ie_date', true ) ) . '</td></tr>';
    echo '<tr><th>' . esc_html( ie__( 'Time' ) ) . '</th><td>' . esc_html( get_post_meta( $bid, '_ie_time', true ) ) . '</td></tr>';
    echo '<tr><th>' . esc_html( ie__( 'Notes' ) ) . '</th><td>' . esc_html( get_post_meta( $bid, '_ie_notes', true ) ) . '</td></tr>';
    echo '<tr><th>' . esc_html( ie__( 'Created' ) ) . '</th><td>' . esc_html( get_post_meta( $bid, '_ie_created_at', true ) ) . '</td></tr>';
    echo '<tr><th>' . esc_html( ie__( 'Status' ) ) . '</th><td><select name="_ie_booking_status">';
    foreach ( [
        'pending'   => ie__( 'Pending' ),
        'confirmed' => ie__( 'Confirmed' ),
        'completed' => ie__( 'Completed' ),
        'cancelled' => ie__( 'Cancelled' ),
    ] as $v => $l ) {
        echo "<option value='$v'" . selected( $status, $v, false ) . '>' . esc_html( $l ) . '</option>';
    }
    echo '</select></td></tr></table>';
}
function ie_save_booking_meta($post_id) {
    if(!isset($_POST['ie_booking_nonce'])||!wp_verify_nonce($_POST['ie_booking_nonce'],'ie_save_booking')) return;
    if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE) return;
    if(get_post_type($post_id)!=='ie_booking') return;
    if(isset($_POST['_ie_booking_status'])) update_post_meta($post_id,'_ie_status',sanitize_text_field($_POST['_ie_booking_status']));
}
add_action('save_post','ie_save_booking_meta');

/* === BOOKING ADMIN COLUMNS === */
function ie_booking_columns( $cols ) {
    return [
        'cb'          => $cols['cb'],
        'title'       => ie__( 'Booking' ),
        'provider'    => ie__( 'Provider' ),
        'customer'    => ie__( 'Customer' ),
        'date_booked' => ie__( 'Date' ),
        'status'      => ie__( 'Status' ),
        'date'        => $cols['date'],
    ];
}
add_filter('manage_ie_booking_posts_columns','ie_booking_columns');
function ie_booking_column_data($col,$post_id) {
    switch($col) {
        case 'provider': $pid=get_post_meta($post_id,'_ie_provider_id',true); echo $pid?'<a href="'.get_edit_post_link($pid).'">'.esc_html(get_the_title($pid)).'</a>':'—'; break;
        case 'customer': $u=get_user_by('id',get_post_meta($post_id,'_ie_user_id',true)); echo $u?esc_html($u->display_name):'—'; break;
        case 'date_booked': echo esc_html(get_post_meta($post_id,'_ie_date',true)?:'—'); break;
        case 'status': $s=get_post_meta($post_id,'_ie_status',true)?:'pending'; $c=['pending'=>'#f59e0b','confirmed'=>'#10b981','completed'=>'#3b82f6','cancelled'=>'#ef4444']; $bg=$c[$s]??'#6b7280'; echo "<span style='background:{$bg};color:white;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600;text-transform:capitalize'>$s</span>"; break;
    }
}
add_action('manage_ie_booking_posts_custom_column','ie_booking_column_data',10,2);

/* === HELPER: GET PROVIDER DATA === */
function ie_get_provider_data($post_id) {
    $p=get_post($post_id); if(!$p) return null;
    $cat_terms=get_the_terms($post_id,'ie_category'); $loc_terms=get_the_terms($post_id,'ie_location');
    $avail=get_post_meta($post_id,'_ie_availability',true)?:'available_now'; $area=get_post_meta($post_id,'_ie_service_area',true);
    $avail_labels = ie_get_availability_labels();
    return [
        'id'=>$post_id,'title'=>get_the_title($post_id),'permalink'=>ie_get_provider_single_url( '', $post_id ),
        'excerpt'=>wp_trim_words($p->post_content,15),'thumbnail'=>get_the_post_thumbnail_url($post_id,'large')?:'',
        'category'=>$cat_terms?$cat_terms[0]->name:'','category_slug'=>$cat_terms?$cat_terms[0]->slug:'',
        'location'=>$loc_terms?$loc_terms[0]->name:($area?:''),'availability'=>$avail,
        'avail_label'=>$avail_labels[$avail]??ie__( 'Available Now' ),
        'rating'=>ie_get_provider_rating_value( $post_id ),
        'reviews'=>ie_get_provider_review_count_value( $post_id ),
        'price'=>get_post_meta($post_id,'_ie_price_from',true)?:'0',
        'experience'=>get_post_meta($post_id,'_ie_experience_years',true)?:'0',
        'verified'=>(bool)get_post_meta($post_id,'_ie_verified',true),
        'premium'=>(bool)get_post_meta($post_id,'_ie_premium',true),
        'about'=>get_post_meta($post_id,'_ie_about',true),
        'services'=>get_post_meta($post_id,'_ie_services',true),
        'chat'=>get_post_meta($post_id,'_ie_chat_link',true),
        'phone'=>get_post_meta($post_id,'_ie_phone',true),
        'email'=>get_post_meta($post_id,'_ie_email',true),
        'website'=>get_post_meta($post_id,'_ie_website',true),
    ];
}

function ie_get_provider_rating_value( $post_id ) {
    $value = get_post_meta( (int) $post_id, '_ie_rating', true );

    if ( $value === '' || $value === false || $value === null ) {
        return '0';
    }

    return (string) $value;
}

function ie_get_provider_review_count_value( $post_id ) {
    $value = get_post_meta( (int) $post_id, '_ie_review_count', true );

    if ( $value === '' || $value === false || $value === null ) {
        return '0';
    }

    return (string) $value;
}

function ie_format_provider_rating( $rating ) {
    $rating = (float) $rating;

    if ( $rating <= 0 ) {
        return '0';
    }

    return rtrim( rtrim( number_format( $rating, 1, '.', '' ), '0' ), '.' ) ?: '0';
}

function ie_get_provider_bio_text( $post_id, $data = null ) {
    if ( ! $data ) {
        $data = ie_get_provider_data( $post_id );
    }

    if ( ! $data ) {
        return '';
    }

    if ( ! empty( $data['about'] ) ) {
        return wp_strip_all_tags( $data['about'] );
    }

    $post = get_post( (int) $post_id );
    if ( $post && $post->post_content ) {
        return wp_strip_all_tags( $post->post_content );
    }

    return wp_strip_all_tags( $data['excerpt'] ?? '' );
}

function ie_get_provider_profile_image_url( $provider_id, $size = 'medium' ) {
    $provider_id = (int) $provider_id;
    $post        = get_post( $provider_id );

    if ( ! $post ) {
        return '';
    }

    $profile = get_post_meta( $provider_id, '_ie_profile_image', true );
    if ( $profile ) {
        if ( is_numeric( $profile ) ) {
            $url = wp_get_attachment_image_url( (int) $profile, $size );
            if ( $url ) {
                return $url;
            }
        } elseif ( filter_var( $profile, FILTER_VALIDATE_URL ) ) {
            return $profile;
        }
    }

    $user_url = ie_get_user_profile_image_url( (int) $post->post_author, $size );
    if ( $user_url ) {
        return $user_url;
    }

    return ie_get_provider_avatar_url( $post->post_title );
}

function ie_is_registered_provider_listing( $post_id ) {
    $post_id = (int) $post_id;
    $post    = get_post( $post_id );

    if ( ! $post || $post->post_type !== 'ie_provider' ) {
        return false;
    }

    if ( get_post_meta( $post_id, '_ie_is_sample', true ) ) {
        return false;
    }

    $author_id = (int) $post->post_author;
    if ( $author_id < 1 ) {
        return false;
    }

    $user = get_userdata( $author_id );
    if ( ! $user ) {
        return false;
    }

    if ( in_array( 'administrator', (array) $user->roles, true ) ) {
        return false;
    }

    if ( get_user_meta( $author_id, '_ie_user_type', true ) !== 'provider' ) {
        return false;
    }

    if ( ie_is_dummy_provider_user( $author_id ) ) {
        return false;
    }

    if ( ! get_post_meta( $post_id, '_ie_registered_listing', true ) ) {
        if ( get_user_meta( $author_id, '_ie_user_type', true ) === 'provider' ) {
            update_post_meta( $post_id, '_ie_registered_listing', '1' );
            return true;
        }

        return false;
    }

    return true;
}

function ie_is_dummy_provider_user( $user_id ) {
    $user_id = (int) $user_id;
    if ( $user_id < 1 ) {
        return false;
    }

    if ( get_user_meta( $user_id, '_ie_is_dummy_subscriber', true ) ) {
        return true;
    }

    $user = get_userdata( $user_id );
    if ( ! $user || ! is_email( $user->user_email ) ) {
        return false;
    }

    return (bool) preg_match( '/@islandexperts\.local$/i', $user->user_email );
}

function ie_get_category_service_image( $slug ) {
    $slug = sanitize_title( $slug );
    $file = 'services/' . $slug . '.jpg';
    $path = get_template_directory() . '/assets/images/' . $file;

    if ( ! file_exists( $path ) ) {
        $file = 'services/default.jpg';
    }

    return ie_image_uri( $file );
}

function ie_get_service_banner_placeholder_uri() {
    static $uri = null;

    if ( null !== $uri ) {
        return $uri;
    }

    $candidates = [
        'services/placeholder.svg',
        'services/placeholder.jpg',
        'services/placeholder.png',
    ];

    foreach ( $candidates as $file ) {
        $path = get_template_directory() . '/assets/images/' . $file;
        if ( file_exists( $path ) ) {
            $uri = ie_image_uri( $file );
            return $uri;
        }
    }

    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="480" viewBox="0 0 640 480"><rect width="640" height="480" fill="#eef2f7"/><g fill="none" stroke="#94a3b8" stroke-width="6" transform="translate(220 140)"><rect x="40" y="50" width="120" height="90" rx="10"/><circle cx="70" cy="85" r="12" fill="#94a3b8" stroke="none"/><path d="M20 180 L70 120 L110 150 L170 80 L220 180 Z"/></g></svg>';
    $uri = 'data:image/svg+xml,' . rawurlencode( $svg );

    return $uri;
}

function ie_provider_has_service_banner( $provider_id ) {
    return ie_get_provider_uploaded_service_image_url( (int) $provider_id, 'large' ) !== '';
}

function ie_is_placeholder_service_image( $url ) {
    if ( empty( $url ) ) {
        return true;
    }

    $url = strtolower( (string) $url );

    if ( strpos( $url, 'picsum.photos' ) !== false || strpos( $url, 'placehold' ) !== false ) {
        return true;
    }

    if ( strpos( $url, 'images.unsplash.com' ) !== false ) {
        return true;
    }

    $upload_dir = wp_upload_dir();
    if ( ! empty( $upload_dir['baseurl'] ) && strpos( $url, strtolower( $upload_dir['baseurl'] ) ) !== false ) {
        return false;
    }

    return false;
}

function ie_get_featured_service_image( $slug, $custom = '' ) {
    if ( ! empty( $custom ) && ! ie_is_placeholder_service_image( $custom ) ) {
        return $custom;
    }

    return ie_get_category_service_image( $slug );
}

function ie_get_provider_public_service_image( $provider_id, $category_slug = '', $fallback_thumbnail = '' ) {
    $provider_id = (int) $provider_id;

    if ( $provider_id ) {
        $services_raw = get_post_meta( $provider_id, '_ie_services', true );
        $services     = $services_raw ? json_decode( $services_raw, true ) : [];

        if ( is_array( $services ) ) {
            foreach ( $services as $service ) {
                if ( empty( $service['show_publicly'] ) ) {
                    continue;
                }

                $image_id = (int) ( $service['image_id'] ?? 0 );
                if ( ! $image_id || ! wp_attachment_is_image( $image_id ) ) {
                    continue;
                }

                $url = wp_get_attachment_image_url( $image_id, 'large' );
                if ( $url ) {
                    return $url;
                }
            }
        }
    }

    return ie_get_featured_service_image( $category_slug, $fallback_thumbnail );
}

function ie_get_provider_service_placeholder_image( $provider_id ) {
    unset( $provider_id );

    return ie_get_service_banner_placeholder_uri();
}

function ie_get_provider_uploaded_service_image_url( $provider_id, $size = 'large' ) {
    $provider_id = (int) $provider_id;
    if ( ! $provider_id ) {
        return '';
    }

    $services_raw = get_post_meta( $provider_id, '_ie_services', true );
    $services     = $services_raw ? json_decode( $services_raw, true ) : [];

    if ( ! is_array( $services ) || ! $services ) {
        return '';
    }

    $fallback_image_id = 0;

    foreach ( $services as $service ) {
        $image_id = (int) ( $service['image_id'] ?? 0 );
        if ( ! $image_id || ! wp_attachment_is_image( $image_id ) ) {
            continue;
        }

        if ( ! empty( $service['show_publicly'] ) ) {
            $url = wp_get_attachment_image_url( $image_id, $size );
            if ( $url ) {
                return $url;
            }
        }

        if ( ! $fallback_image_id ) {
            $fallback_image_id = $image_id;
        }
    }

    if ( $fallback_image_id ) {
        $url = wp_get_attachment_image_url( $fallback_image_id, $size );
        if ( $url ) {
            return $url;
        }
    }

    return '';
}

function ie_get_featured_provider_card_image( $provider_id, $category_slug = '' ) {
    unset( $category_slug );
    $provider_id = (int) $provider_id;
    $uploaded    = ie_get_provider_uploaded_service_image_url( $provider_id, 'large' );

    if ( $uploaded ) {
        return $uploaded;
    }

    return ie_get_service_banner_placeholder_uri();
}

function ie_render_provider_service_row( $service, $placeholder_image = '' ) {
    $image_id      = (int) ( $service['image_id'] ?? 0 );
    $image_url     = $image_id ? wp_get_attachment_image_url( $image_id, 'medium' ) : '';
    $preview_url   = $image_url ?: $placeholder_image;
    $show_publicly = ! empty( $service['show_publicly'] );
    ?>
    <div class="provider-service-row">
        <div class="form-group">
            <label class="form-label"><?php echo esc_html( ie__( 'Service Name' ) ); ?></label>
            <input type="text" class="form-control svc-name" value="<?php echo esc_attr( $service['name'] ?? '' ); ?>">
        </div>
        <div class="form-group">
            <label class="form-label"><?php echo esc_html( ie__( 'Price' ) ); ?></label>
            <input type="text" class="form-control svc-price" value="<?php echo esc_attr( $service['price'] ?? '' ); ?>">
        </div>
        <div class="form-group provider-service-media">
            <label class="form-label"><?php echo esc_html( ie__( 'Service Image' ) ); ?></label>
            <div class="provider-service-image-field">
                <div class="featured-provider-service-image provider-service-image-preview">
                    <img src="<?php echo esc_url( $preview_url ); ?>" alt="" class="svc-image-preview">
                </div>
                <input type="file" class="form-control form-control-file svc-image-input" accept="image/jpeg,image/png,image/webp">
                <input type="hidden" class="svc-image-id" value="<?php echo esc_attr( (string) $image_id ); ?>">
            </div>
            <label class="provider-service-public-toggle">
                <input type="checkbox" class="svc-show-publicly" <?php checked( $show_publicly ); ?>>
                <span><?php echo esc_html( ie__( 'Show banner' ) ); ?></span>
            </label>
            <p class="form-hint"><?php echo esc_html( ie__( 'Upload a banner image here. Enable "Show banner" to display it on your provider card and profile page.' ) ); ?></p>
        </div>
        <button type="button" class="provider-service-remove" aria-label="<?php echo esc_attr( ie__( 'Remove service' ) ); ?>">
            <i class="fa-solid fa-trash-can" aria-hidden="true"></i>
        </button>
    </div>
    <?php
}

function ie_get_provider_avatar_url( $name, $profile_image = '' ) {
    if ( $profile_image ) {
        return $profile_image;
    }

    return 'https://ui-avatars.com/api/?name=' . rawurlencode( $name ) . '&background=2d6a8f&color=fff&size=128&bold=true';
}

function ie_get_user_profile_image_id( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    if ( ! $user_id ) {
        return 0;
    }

    return (int) get_user_meta( $user_id, '_ie_profile_image', true );
}

function ie_get_user_profile_image_url( $user_id = null, $size = 'medium' ) {
    $user_id = $user_id ?: get_current_user_id();
    if ( ! $user_id ) {
        return '';
    }

    $attachment_id = ie_get_user_profile_image_id( $user_id );
    if ( $attachment_id ) {
        $url = wp_get_attachment_image_url( $attachment_id, $size );
        if ( $url ) {
            return $url;
        }
    }

    $user = get_userdata( $user_id );
    if ( ! $user ) {
        return '';
    }

    return ie_get_provider_avatar_url( $user->display_name ?: $user->user_email );
}

function ie_provider_has_social_links( $provider_id, $minimum = 1 ) {
    $socials = ie_get_provider_socials( (int) $provider_id );

    return count( $socials ) >= max( 1, (int) $minimum );
}

function ie_provider_has_work_gallery_images( $provider_id, $minimum = 1 ) {
    $ids = ie_get_provider_work_gallery_ids( (int) $provider_id );

    return count( $ids ) >= max( 1, (int) $minimum );
}

function ie_get_provider_profile_completion( $provider_id, $user_id = null ) {
    $provider_id = (int) $provider_id;
    $post        = get_post( $provider_id );

    if ( ! $post || $post->post_type !== 'ie_provider' ) {
        return [
            'percent'     => 0,
            'completed'   => 0,
            'total'       => 0,
            'is_complete' => false,
            'fields'      => [],
        ];
    }

    $user_id = $user_id ? (int) $user_id : (int) $post->post_author;
    $user    = get_userdata( $user_id );

    $about = trim( (string) get_post_meta( $provider_id, '_ie_about', true ) );
    if ( $about === '' ) {
        $about = trim( (string) $post->post_content );
    }

    $experience = get_post_meta( $provider_id, '_ie_experience_years', true );

    $fields = [
        'profile_photo'  => ie_get_user_profile_image_id( $user_id ) > 0,
        'first_name'     => $user && trim( (string) $user->first_name ) !== '',
        'last_name'      => $user && trim( (string) $user->last_name ) !== '',
        'email_address'  => $user && is_email( $user->user_email ),
        'service_name'   => trim( (string) $post->post_title ) !== '',
        'about'          => $about !== '',
        'phone'          => trim( (string) get_post_meta( $provider_id, '_ie_phone', true ) ) !== '',
        'service_area'   => trim( (string) get_post_meta( $provider_id, '_ie_service_area', true ) ) !== '',
        'experience'     => $experience !== '' && $experience !== false && $experience !== null,
        'social_links'   => ie_provider_has_social_links( $provider_id ),
    ];

    $total     = count( $fields );
    $completed = count( array_filter( $fields ) );
    $percent   = $total ? (int) round( ( $completed / $total ) * 100 ) : 0;

    return [
        'percent'     => $percent,
        'completed'   => $completed,
        'total'       => $total,
        'is_complete' => $percent >= 100,
        'fields'      => $fields,
    ];
}

function ie_is_provider_profile_complete( $provider_id, $user_id = null ) {
    $progress = ie_get_provider_profile_completion( $provider_id, $user_id );

    return ! empty( $progress['is_complete'] );
}

function ie_is_provider_profile_progress_dismissed( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();

    return (bool) get_user_meta( (int) $user_id, '_ie_profile_progress_dismissed', true );
}

function ie_should_show_provider_profile_progress( $provider_id, $user_id = null ) {
    $provider_id = (int) $provider_id;
    $user_id     = $user_id ? (int) $user_id : (int) get_post_field( 'post_author', $provider_id );
    $progress    = ie_get_provider_profile_completion( $provider_id, $user_id );

    if ( ! $progress['is_complete'] ) {
        if ( $user_id ) {
            delete_user_meta( $user_id, '_ie_profile_progress_dismissed' );
        }

        return true;
    }

    return ! ie_is_provider_profile_progress_dismissed( $user_id );
}

function ie_dismiss_provider_profile_progress( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    if ( ! $user_id ) {
        return false;
    }

    update_user_meta( (int) $user_id, '_ie_profile_progress_dismissed', '1' );

    return true;
}

function ie_render_provider_profile_progress( $provider_id, $user_id = null ) {
    if ( ! ie_should_show_provider_profile_progress( $provider_id, $user_id ) ) {
        return;
    }

    $progress  = ie_get_provider_profile_completion( $provider_id, $user_id );
    $has_photo = ! empty( $progress['fields']['profile_photo'] ) ? 1 : 0;
    ?>
    <div class="provider-profile-progress<?php echo $progress['is_complete'] ? ' is-complete' : ''; ?>"
         id="provider-profile-progress"
         data-has-photo="<?php echo esc_attr( (string) $has_photo ); ?>"
         data-auto-hide="<?php echo $progress['is_complete'] ? '1' : '0'; ?>">
        <div class="provider-profile-progress__head">
            <span class="provider-profile-progress__label"><?php echo esc_html( ie__( 'Profile Completion' ) ); ?></span>
            <strong class="provider-profile-progress__value"><?php echo esc_html( $progress['percent'] ); ?>%</strong>
        </div>
        <div class="provider-profile-progress__track" role="progressbar"
             aria-valuemin="0"
             aria-valuemax="100"
             aria-valuenow="<?php echo esc_attr( (string) $progress['percent'] ); ?>"
             aria-label="<?php echo esc_attr( ie__( 'Profile completion progress' ) ); ?>">
            <div class="provider-profile-progress__bar" style="width: <?php echo esc_attr( (string) $progress['percent'] ); ?>%;"></div>
        </div>
        <p class="provider-profile-progress__hint">
            <?php
            if ( $progress['is_complete'] ) {
                echo esc_html( ie__( 'Your profile information is 100% complete.' ) );
            } else {
                echo esc_html(
                    sprintf(
                        ie__( '%1$d of %2$d required fields completed. Fill in all profile information to reach 100%%.' ),
                        (int) $progress['completed'],
                        (int) $progress['total']
                    )
                );
            }
            ?>
        </p>
    </div>
    <?php
}

function ie_handle_user_profile_photo_upload( $user_id, $file_key = 'profile_photo' ) {
    if ( empty( $_FILES[ $file_key ]['name'] ) ) {
        return 0;
    }

    $file = $_FILES[ $file_key ];
    $allowed_types = [ 'image/jpeg', 'image/png', 'image/webp' ];
    $file_type     = wp_check_filetype( $file['name'] );

    if ( ! in_array( $file['type'], $allowed_types, true ) && ! in_array( $file_type['type'], $allowed_types, true ) ) {
        return new WP_Error( 'invalid_type', ie__( 'Please upload a JPG, PNG, or WEBP image.' ) );
    }

    if ( $file['size'] > 5 * 1024 * 1024 ) {
        return new WP_Error( 'file_too_large', ie__( 'Image must be smaller than 5MB.' ) );
    }

    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $attachment_id = media_handle_upload( $file_key, 0 );
    if ( is_wp_error( $attachment_id ) ) {
        return $attachment_id;
    }

    $old_id = ie_get_user_profile_image_id( $user_id );
    if ( $old_id && $old_id !== (int) $attachment_id ) {
        wp_delete_attachment( $old_id, true );
    }

    update_user_meta( $user_id, '_ie_profile_image', (int) $attachment_id );

    return (int) $attachment_id;
}

function ie_get_browse_price_ranges() {
    return [
        ''         => ie__( 'Any Price' ),
        'under_50' => ie__( 'Under $50' ),
        '50_100'   => ie__( '$50 – $100' ),
        '100_200'  => ie__( '$100 – $200' ),
        'over_200' => ie__( '$200+' ),
    ];
}

function ie_provider_matches_price_filter( $price, $filter ) {
    if ( ! $filter ) {
        return true;
    }

    $price = (float) $price;
    if ( $price <= 0 ) {
        return false;
    }

    switch ( $filter ) {
        case 'under_50':
            return $price < 50;
        case '50_100':
            return $price >= 50 && $price <= 100;
        case '100_200':
            return $price >= 100 && $price <= 200;
        case 'over_200':
            return $price >= 200;
        default:
            return true;
    }
}

function ie_get_provider_browse_search_text( $post_id, $data = null ) {
    $post_id = (int) $post_id;

    if ( ! $data ) {
        $data = ie_get_provider_data( $post_id );
    }

    if ( ! $data ) {
        return '';
    }

    $parts = [
        get_the_title( $post_id ),
        $data['title'] ?? '',
        $data['about'] ?? '',
        $data['excerpt'] ?? '',
        $data['category'] ?? '',
        $data['location'] ?? '',
        ie_get_provider_card_display_name( $post_id, $data ),
    ];

    $service = ie_get_provider_card_service_name( $post_id, $data );
    $parts[] = $service['name'] ?? '';

    $services_raw = get_post_meta( $post_id, '_ie_services', true );
    $services     = $services_raw ? json_decode( $services_raw, true ) : [];

    if ( is_array( $services ) ) {
        foreach ( $services as $service_item ) {
            $parts[] = $service_item['name'] ?? '';
        }
    }

    $author = get_userdata( (int) get_post_field( 'post_author', $post_id ) );
    if ( $author ) {
        $parts[] = $author->display_name;
        $parts[] = trim( $author->first_name . ' ' . $author->last_name );
        $parts[] = $author->user_email;
    }

    return strtolower( wp_strip_all_tags( implode( ' ', array_filter( $parts ) ) ) );
}

function ie_provider_matches_browse_search( $post_id, $search, $data = null ) {
    $search = strtolower( trim( (string) $search ) );

    if ( $search === '' ) {
        return true;
    }

    return strpos( ie_get_provider_browse_search_text( $post_id, $data ), $search ) !== false;
}

function ie_provider_matches_category_filter( $post_id, $category_slug, $data = null ) {
    if ( ! $category_slug || $category_slug === 'all' ) {
        return true;
    }

    $category_slug = sanitize_title( $category_slug );
    $post_id       = (int) $post_id;

    if ( ! $data ) {
        $data = ie_get_provider_data( $post_id );
    }

    $cat_terms = get_the_terms( $post_id, 'ie_category' );
    if ( $cat_terms && ! is_wp_error( $cat_terms ) ) {
        foreach ( $cat_terms as $term ) {
            if ( $term->slug === $category_slug || sanitize_title( $term->name ) === $category_slug ) {
                return true;
            }
        }
    }

    if ( $data ) {
        if ( sanitize_title( $data['category_slug'] ?? '' ) === $category_slug ) {
            return true;
        }

        if ( sanitize_title( $data['category'] ?? '' ) === $category_slug ) {
            return true;
        }
    }

    $service = ie_get_provider_card_service_name( $post_id, $data );
    if ( sanitize_title( $service['slug'] ?? '' ) === $category_slug || sanitize_title( $service['name'] ?? '' ) === $category_slug ) {
        return true;
    }

    $services_raw = get_post_meta( $post_id, '_ie_services', true );
    $services     = $services_raw ? json_decode( $services_raw, true ) : [];

    if ( is_array( $services ) ) {
        foreach ( $services as $service_item ) {
            $name = trim( (string) ( $service_item['name'] ?? '' ) );
            if ( $name !== '' && sanitize_title( $name ) === $category_slug ) {
                return true;
            }
        }
    }

    return false;
}

function ie_get_provider_card_display_name( $provider_id, $data = null ) {
    $post = get_post( (int) $provider_id );
    if ( ! $post ) {
        return '';
    }

    $author = get_userdata( (int) $post->post_author );
    if ( $author ) {
        $display_name = trim( (string) $author->display_name );
        if ( $display_name !== '' ) {
            return $display_name;
        }

        $full_name = trim( $author->first_name . ' ' . $author->last_name );
        if ( $full_name !== '' ) {
            return $full_name;
        }
    }

    if ( ! $data ) {
        $data = ie_get_provider_data( $provider_id );
    }

    return trim( (string) ( $data['title'] ?? $post->post_title ) );
}

function ie_get_provider_card_service_name( $provider_id, $data = null ) {
    if ( ! $data ) {
        $data = ie_get_provider_data( $provider_id );
    }

    if ( ! $data ) {
        return [
            'name' => '',
            'slug' => '',
        ];
    }

    $service_title = trim( (string) ( $data['title'] ?? '' ) );
    if ( $service_title !== '' ) {
        return [
            'name' => $service_title,
            'slug' => $data['category_slug'] ?: sanitize_title( $service_title ),
        ];
    }

    if ( ! empty( $data['category'] ) ) {
        return [
            'name' => $data['category'],
            'slug' => $data['category_slug'] ?: sanitize_title( $data['category'] ),
        ];
    }

    $services_raw = get_post_meta( (int) $provider_id, '_ie_services', true );
    $services     = $services_raw ? json_decode( $services_raw, true ) : [];

    if ( is_array( $services ) ) {
        foreach ( $services as $service ) {
            $name = trim( (string) ( $service['name'] ?? '' ) );
            if ( $name !== '' ) {
                return [
                    'name' => $name,
                    'slug' => sanitize_title( $name ),
                ];
            }
        }
    }

    return [
        'name' => '',
        'slug' => '',
    ];
}

function ie_parse_service_price_amount( $price ) {
    $price = trim( (string) $price );

    if ( $price === '' ) {
        return 0.0;
    }

    $normalized = preg_replace( '/[^0-9.]/', '', $price );

    if ( $normalized === '' || ! is_numeric( $normalized ) ) {
        return 0.0;
    }

    return (float) $normalized;
}

function ie_get_provider_services_lowest_price( $provider_id ) {
    $provider_id = (int) $provider_id;

    if ( ! $provider_id ) {
        return 0;
    }

    $services_raw = get_post_meta( $provider_id, '_ie_services', true );
    $services     = $services_raw ? json_decode( $services_raw, true ) : [];

    if ( ! is_array( $services ) || ! $services ) {
        return 0;
    }

    $lowest = 0;

    foreach ( $services as $service ) {
        $amount = ie_parse_service_price_amount( $service['price'] ?? '' );
        if ( $amount <= 0 ) {
            continue;
        }

        if ( $lowest <= 0 || $amount < $lowest ) {
            $lowest = $amount;
        }
    }

    return $lowest;
}

function ie_format_provider_card_price( $price ) {
    $price = (float) $price;

    if ( $price <= 0 ) {
        return '';
    }

    $formatted = rtrim( rtrim( number_format( $price, 2, '.', '' ), '0' ), '.' );

    return sprintf( '%s $%s', ie__( 'From' ), $formatted );
}

function ie_get_provider_card_price_label( $provider_id ) {
    return ie_format_provider_card_price( ie_get_provider_services_lowest_price( $provider_id ) );
}

function ie_format_featured_provider( $d ) {
    $slug = $d['category_slug'] ?: sanitize_title( $d['category'] );
    $provider_id   = (int) $d['id'];
    ie_repair_provider_slug_collisions( $provider_id );
    $provider_slug = ie_ensure_provider_slug( $provider_id );
    $service         = ie_get_provider_card_service_name( (int) $d['id'], $d );

    return [
        'id'                => (int) $d['id'],
        'slug'              => $provider_slug,
        'name'              => ie_get_provider_card_display_name( (int) $d['id'], $d ),
        'rating'            => ie_format_provider_rating( $d['rating'] ),
        'reviews'           => (string) (int) $d['reviews'],
        'category'          => $d['category'],
        'category_slug'     => $slug,
        'service_name'      => $service['name'],
        'service_name_slug' => $service['slug'],
        'bio'               => ie_get_provider_bio_text( (int) $d['id'], $d ),
        'service_image'     => ie_get_featured_provider_card_image( (int) $d['id'], $slug ),
        'has_service_banner' => ie_provider_has_service_banner( (int) $d['id'] ),
        'profile_image'     => ie_get_provider_profile_image_url( (int) $d['id'] ),
        'permalink'         => ie_get_provider_single_url( $provider_slug, (int) $d['id'] ),
        'chat_url'          => ie_get_provider_chat_url( (int) $d['id'], $provider_slug ),
        'price'             => ie_get_provider_services_lowest_price( (int) $d['id'] ),
    ];
}

function ie_get_top_rated_providers( $limit = 0 ) {
    $query = new WP_Query( [
        'post_type'      => 'ie_provider',
        'post_status'    => [ 'publish', 'pending' ],
        'posts_per_page' => -1,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'no_found_rows'  => true,
    ] );

    $providers    = [];
    $seen_authors = [];

    while ( $query->have_posts() ) {
        $query->the_post();
        $post_id   = get_the_ID();
        $author_id = (int) get_post_field( 'post_author', $post_id );

        if ( isset( $seen_authors[ $author_id ] ) ) {
            continue;
        }

        $data = ie_get_provider_data( $post_id );
        if ( ! $data || ! ie_is_registered_provider_listing( $post_id ) ) {
            continue;
        }

        $seen_authors[ $author_id ] = true;
        $providers[] = ie_format_featured_provider( $data );
    }
    wp_reset_postdata();

    usort(
        $providers,
        static function ( $a, $b ) {
            $rating_cmp = (float) $b['rating'] <=> (float) $a['rating'];
            if ( $rating_cmp !== 0 ) {
                return $rating_cmp;
            }

            $review_cmp = (int) $b['reviews'] <=> (int) $a['reviews'];
            if ( $review_cmp !== 0 ) {
                return $review_cmp;
            }

            return (int) $b['id'] <=> (int) $a['id'];
        }
    );

    if ( $limit > 0 ) {
        $providers = array_slice( $providers, 0, max( 1, (int) $limit ) );
    }

    return $providers;
}

function ie_get_user_wishlist( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    if ( ! $user_id ) {
        return [];
    }

    $wishlist = get_user_meta( $user_id, '_ie_wishlist', true );

    return is_array( $wishlist ) ? $wishlist : [];
}

function ie_user_has_in_wishlist( $user_id, $provider_id = 0, $provider_slug = '' ) {
    $wishlist = ie_get_user_wishlist( $user_id );
    if ( ! $wishlist ) {
        return false;
    }

    if ( $provider_id ) {
        foreach ( $wishlist as $item ) {
            if ( is_numeric( $item ) && (int) $item === (int) $provider_id ) {
                return true;
            }
        }
    }

    $provider_slug = sanitize_title( $provider_slug );
    if ( $provider_slug ) {
        return in_array( $provider_slug, $wishlist, true );
    }

    return false;
}

function ie_wishlist_item_to_featured( $item ) {
    if ( is_numeric( $item ) ) {
        $data = ie_get_provider_data( (int) $item );

        return $data ? ie_format_featured_provider( $data ) : null;
    }

    $slug = sanitize_title( (string) $item );
    if ( ! $slug ) {
        return null;
    }

    $posts = get_posts( [
        'post_type'      => 'ie_provider',
        'name'           => $slug,
        'post_status'    => 'publish',
        'posts_per_page' => 1,
    ] );

    if ( $posts ) {
        $data = ie_get_provider_data( $posts[0]->ID );

        return $data ? ie_format_featured_provider( $data ) : null;
    }

    return null;
}

function ie_render_featured_wishlist_button( $provider_id = 0, $provider_slug = '' ) {
    $active = false;
    if ( is_user_logged_in() ) {
        $active = ie_user_has_in_wishlist( get_current_user_id(), $provider_id, $provider_slug );
    }

    $icon_class = $active ? 'fa-solid' : 'fa-regular';
    ?>
    <button type="button"
            class="featured-wishlist-btn wishlist-btn<?php echo $active ? ' active' : ''; ?>"
            <?php if ( $provider_id ) : ?>data-id="<?php echo esc_attr( $provider_id ); ?>"<?php endif; ?>
            <?php if ( $provider_slug ) : ?>data-slug="<?php echo esc_attr( $provider_slug ); ?>"<?php endif; ?>
            onclick="event.preventDefault();event.stopPropagation();IEApp.toggleFeaturedWishlist(this)"
            aria-label="<?php echo esc_attr( ie__( 'Save provider' ) ); ?>"
            title="<?php echo esc_attr( ie__( 'Save provider' ) ); ?>">
        <i class="<?php echo esc_attr( $icon_class ); ?> fa-heart" aria-hidden="true"></i>
    </button>
    <?php
}

function ie_ensure_provider_slug( $post_id ) {
    $post_id = (int) $post_id;
    $post    = get_post( $post_id );

    if ( ! $post || $post->post_type !== 'ie_provider' ) {
        return '';
    }

    $slug = sanitize_title( $post->post_name );
    if ( $slug ) {
        return $slug;
    }

    $slug = sanitize_title( $post->post_title );
    if ( ! $slug ) {
        $slug = 'provider-' . $post_id;
    }

    $slug = wp_unique_post_slug( $slug, $post_id, $post->post_status, $post->post_type, (int) $post->post_parent );

    wp_update_post(
        [
            'ID'        => $post_id,
            'post_name' => $slug,
        ]
    );

    clean_post_cache( $post_id );

    return $slug;
}

function ie_repair_provider_slug_collisions( $provider_id ) {
    $provider_id = (int) $provider_id;
    $post        = get_post( $provider_id );

    if ( ! $post || $post->post_type !== 'ie_provider' ) {
        return '';
    }

    $preferred = sanitize_title( $post->post_title );
    if ( ! $preferred || $post->post_name === $preferred ) {
        return (string) $post->post_name;
    }

    $attachments = get_posts(
        [
            'post_type'      => 'attachment',
            'name'           => $preferred,
            'post_parent'    => $provider_id,
            'post_status'    => 'inherit',
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ]
    );

    if ( ! $attachments ) {
        return (string) $post->post_name;
    }

    $attachment_id = (int) $attachments[0];
    $new_attachment_slug = wp_unique_post_slug(
        $preferred . '-work-' . $attachment_id,
        $attachment_id,
        'inherit',
        'attachment',
        $provider_id
    );

    wp_update_post(
        [
            'ID'        => $attachment_id,
            'post_name' => $new_attachment_slug,
        ]
    );

    $provider_slug = wp_unique_post_slug(
        $preferred,
        $provider_id,
        $post->post_status,
        $post->post_type,
        (int) $post->post_parent
    );

    wp_update_post(
        [
            'ID'        => $provider_id,
            'post_name' => $provider_slug,
        ]
    );

    clean_post_cache( $provider_id );

    return $provider_slug;
}

function ie_get_provider_single_url( $slug = '', $post_id = 0 ) {
    $post_id = (int) $post_id;

    if ( $post_id ) {
        ie_repair_provider_slug_collisions( $post_id );
        $slug = ie_ensure_provider_slug( $post_id );
    }

    $slug = sanitize_title( $slug );
    $base = ie_get_theme_page_url( 'service-provider' );

    if ( ! $slug ) {
        return $base;
    }

    return add_query_arg( 'ie_provider_slug', $slug, $base );
}

function ie_resolve_provider_id_by_slug( $slug ) {
    $view = ie_resolve_provider_for_single( sanitize_title( $slug ) );

    return $view ? (int) ( $view['id'] ?? 0 ) : 0;
}

function ie_get_provider_chat_url( $provider_id = 0, $provider_slug = '' ) {
    $provider_id = (int) $provider_id;

    if ( ! $provider_id && $provider_slug ) {
        $provider_id = ie_resolve_provider_id_by_slug( $provider_slug );
    }

    if ( ! $provider_slug && $provider_id ) {
        $provider_slug = ie_ensure_provider_slug( $provider_id );
    }

    if ( ! $provider_id ) {
        return ie_get_provider_single_url( $provider_slug, 0 ) . '#sp-contact';
    }

    $messages_url = add_query_arg(
        [
            'tab'      => 'messages',
            'provider' => $provider_id,
        ],
        ie_get_theme_page_url( 'client-profile' )
    );

    if ( is_user_logged_in() && ie_get_user_type() === 'customer' ) {
        return $messages_url;
    }

    if ( ! is_user_logged_in() ) {
        return add_query_arg( 'redirect_to', rawurlencode( $messages_url ), ie_get_theme_page_url( 'account' ) );
    }

    return ie_get_provider_single_url( $provider_slug, $provider_id ) . '#sp-contact';
}

function ie_prepend_provider_conversation( $conversations, $provider_id ) {
    $provider_id = (int) $provider_id;

    if ( ! $provider_id ) {
        return $conversations;
    }

    $matched = null;
    $rest    = [];

    foreach ( $conversations as $conversation ) {
        if ( (int) ( $conversation['id'] ?? 0 ) === $provider_id ) {
            $matched = $conversation;
            continue;
        }

        $rest[] = $conversation;
    }

    if ( $matched ) {
        return array_merge( [ $matched ], $rest );
    }

    $provider = ie_get_provider_conversation_meta( $provider_id );
    if ( ! $provider ) {
        return $conversations;
    }

    return array_merge(
        [
            array_merge(
                $provider,
                [
                    'last_message' => ie__( 'Start a conversation' ),
                    'last_time'    => '',
                    'has_messages' => false,
                ]
            ),
        ],
        $conversations
    );
}

function ie_get_requested_provider_slug() {
    $slug = get_query_var( 'ie_provider_slug' );
    if ( $slug ) {
        return sanitize_title( (string) $slug );
    }

    if ( isset( $_GET['ie_provider_slug'] ) && $_GET['ie_provider_slug'] !== '' ) {
        return sanitize_title( wp_unslash( (string) $_GET['ie_provider_slug'] ) );
    }

    $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
    $path        = (string) parse_url( $request_uri, PHP_URL_PATH );
    $path        = trim( $path, '/' );

    if ( preg_match( '#(?:^|/)service-provider/([^/]+)/?$#', $path, $matches ) ) {
        return sanitize_title( $matches[1] );
    }

    return '';
}

function ie_get_provider_social_links( $provider_id, $slug ) {
    if ( ! $provider_id ) {
        return [];
    }

    return ie_get_provider_socials( $provider_id );
}

function ie_normalize_provider_social_links( $socials ) {
    if ( ! is_array( $socials ) ) {
        return [];
    }

    if ( isset( $socials['facebook'] ) || isset( $socials['instagram'] ) || isset( $socials['youtube'] ) ) {
        $legacy_map = [
            'facebook'  => [ 'icon' => 'fa-brands fa-facebook-f', 'label' => ie__( 'Facebook' ) ],
            'instagram' => [ 'icon' => 'fa-brands fa-instagram', 'label' => ie__( 'Instagram' ) ],
            'youtube'   => [ 'icon' => 'fa-brands fa-youtube', 'label' => ie__( 'YouTube' ) ],
        ];
        $normalized = [];

        foreach ( $legacy_map as $key => $cfg ) {
            $url = trim( (string) ( $socials[ $key ] ?? '' ) );
            if ( $url === '' ) {
                continue;
            }
            $normalized[] = [
                'icon'  => $cfg['icon'],
                'url'   => $url,
                'label' => $cfg['label'],
            ];
        }

        return $normalized;
    }

    return ie_sanitize_provider_socials_list( $socials );
}

function ie_get_provider_socials( $provider_id ) {
    $provider_id = (int) $provider_id;
    if ( ! $provider_id ) {
        return [];
    }

    $raw = get_post_meta( $provider_id, '_ie_socials', true );
    if ( $raw ) {
        $socials = json_decode( $raw, true );
        if ( is_array( $socials ) ) {
            return ie_sanitize_provider_socials_list( $socials );
        }
    }

    $legacy = [];
    $legacy_map = [
        '_ie_facebook'  => [ 'icon' => 'fa-brands fa-facebook-f', 'label' => ie__( 'Facebook' ) ],
        '_ie_instagram' => [ 'icon' => 'fa-brands fa-instagram', 'label' => ie__( 'Instagram' ) ],
        '_ie_youtube'   => [ 'icon' => 'fa-brands fa-youtube', 'label' => ie__( 'YouTube' ) ],
    ];

    foreach ( $legacy_map as $meta_key => $cfg ) {
        $url = trim( (string) get_post_meta( $provider_id, $meta_key, true ) );
        if ( $url === '' ) {
            continue;
        }
        $legacy[] = [
            'icon'  => $cfg['icon'],
            'url'   => $url,
            'label' => $cfg['label'],
        ];
    }

    return $legacy;
}

function ie_sanitize_provider_socials_list( $socials ) {
    if ( ! is_array( $socials ) ) {
        return [];
    }

    $presets = ie_get_theme_social_icon_presets();
    $clean   = [];

    foreach ( $socials as $social ) {
        $url = esc_url_raw( $social['url'] ?? '' );
        if ( $url === '' ) {
            continue;
        }

        $icon = sanitize_text_field( $social['icon'] ?? '' );
        if ( ! array_key_exists( $icon, $presets ) ) {
            $icon = 'fa-solid fa-link';
        }

        $clean[] = [
            'icon'  => $icon,
            'url'   => $url,
            'label' => sanitize_text_field( $social['label'] ?? ( $presets[ $icon ] ?? '' ) ),
        ];
    }

    return $clean;
}

function ie_render_provider_social_row( $social, $presets ) {
    $icon = $social['icon'] ?? '';
    $url  = $social['url'] ?? '';
    ?>
    <div class="provider-social-row">
        <div class="form-group">
            <label class="form-label"><?php echo esc_html( ie__( 'Social Media' ) ); ?></label>
            <select class="form-control social-icon">
                <option value=""><?php echo esc_html( ie__( '— Select —' ) ); ?></option>
                <?php foreach ( $presets as $class => $label ) : ?>
                    <option value="<?php echo esc_attr( $class ); ?>" <?php selected( $icon, $class ); ?>><?php echo esc_html( $label ); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label"><?php echo esc_html( ie__( 'URL' ) ); ?></label>
            <input type="url" class="form-control social-url" value="<?php echo esc_url( $url ); ?>" placeholder="https://">
        </div>
        <button type="button" class="provider-social-remove" aria-label="<?php echo esc_attr( ie__( 'Remove social link' ) ); ?>">
            <i class="fa-solid fa-trash-can" aria-hidden="true"></i>
        </button>
    </div>
    <?php
}

function ie_get_provider_services_for_editor( $provider_id ) {
    $services_raw = get_post_meta( (int) $provider_id, '_ie_services', true );
    $services     = $services_raw ? json_decode( $services_raw, true ) : [];
    if ( ! is_array( $services ) ) {
        return [];
    }

    $placeholder = ie_get_provider_service_placeholder_image( $provider_id );
    $prepared    = [];

    foreach ( $services as $service ) {
        $image_id = (int) ( $service['image_id'] ?? 0 );
        $image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'medium' ) : $placeholder;

        $prepared[] = [
            'name'          => $service['name'] ?? '',
            'price'         => $service['price'] ?? '',
            'unit'          => $service['unit'] ?? '',
            'image_id'      => $image_id,
            'image_url'     => $image_url ?: $placeholder,
            'show_publicly' => ! empty( $service['show_publicly'] ),
        ];
    }

    return $prepared;
}

function ie_get_provider_work_gallery_max() {
    return 10;
}

function ie_get_provider_work_gallery_ids( $provider_id ) {
    $raw = get_post_meta( (int) $provider_id, '_ie_work_gallery', true );
    if ( ! $raw ) {
        return [];
    }

    $ids = json_decode( $raw, true );
    if ( ! is_array( $ids ) ) {
        return [];
    }

    return array_values( array_filter( array_map( 'intval', $ids ) ) );
}

function ie_get_provider_work_gallery( $provider_id, $size = 'medium' ) {
    $gallery = [];

    foreach ( ie_get_provider_work_gallery_ids( $provider_id ) as $attachment_id ) {
        if ( ! wp_attachment_is_image( $attachment_id ) ) {
            continue;
        }

        $url = wp_get_attachment_image_url( $attachment_id, $size );
        if ( ! $url ) {
            continue;
        }

        $gallery[] = [
            'id'    => $attachment_id,
            'url'   => $url,
            'full'  => wp_get_attachment_image_url( $attachment_id, 'large' ) ?: $url,
            'thumb' => wp_get_attachment_image_url( $attachment_id, 'thumbnail' ) ?: $url,
        ];
    }

    return $gallery;
}

function ie_get_provider_previous_work( $provider_id, $category_slug = '', $slug = '' ) {
    $provider_id = (int) $provider_id;

    if ( $provider_id <= 0 ) {
        return [];
    }

    return ie_get_provider_work_gallery( $provider_id, 'medium' );
}

function ie_get_provider_reviews_list( $provider_id, $slug ) {
    $provider_id = (int) $provider_id;

    if ( ! $provider_id ) {
        return [];
    }

    $comments = get_comments( [
        'post_id' => $provider_id,
        'status'  => 'approve',
        'number'  => 5,
        'orderby' => 'comment_date',
        'order'   => 'DESC',
    ] );

    if ( ! $comments ) {
        return [];
    }

    $list = [];
    foreach ( $comments as $comment ) {
        $list[] = [
            'author' => $comment->comment_author,
            'rating' => (int) ( get_comment_meta( $comment->comment_ID, '_ie_review_rating', true ) ?: 5 ),
            'date'   => date_i18n( 'M j, Y', strtotime( $comment->comment_date ) ),
            'text'   => $comment->comment_content,
        ];
    }

    return $list;
}

function ie_user_can_manage_provider_gallery_attachment( $attachment_id, $provider_id ) {
    $attachment_id = (int) $attachment_id;
    $provider_id   = (int) $provider_id;

    if ( ! $attachment_id || ! wp_attachment_is_image( $attachment_id ) ) {
        return false;
    }

    $provider = get_post( $provider_id );
    if ( ! $provider || (int) $provider->post_author !== get_current_user_id() ) {
        return false;
    }

    $attachment = get_post( $attachment_id );
    if ( ! $attachment ) {
        return false;
    }

    if ( (int) $attachment->post_author === get_current_user_id() ) {
        return true;
    }

    return (int) $attachment->post_parent === $provider_id;
}

function ie_upload_provider_work_gallery_file( $provider_id, $file ) {
    $allowed_types = [ 'image/jpeg', 'image/png', 'image/webp' ];
    $file_type     = wp_check_filetype( $file['name'] ?? '' );

    if (
        ! in_array( $file['type'] ?? '', $allowed_types, true )
        && ! in_array( $file_type['type'] ?? '', $allowed_types, true )
    ) {
        return new WP_Error( 'invalid_type', ie__( 'Please upload JPG, PNG, or WEBP images only.' ) );
    }

    if ( (int) ( $file['size'] ?? 0 ) > 5 * 1024 * 1024 ) {
        return new WP_Error( 'file_too_large', ie__( 'Each image must be smaller than 5MB.' ) );
    }

    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $upload = wp_handle_upload( $file, [ 'test_form' => false ] );
    if ( isset( $upload['error'] ) ) {
        return new WP_Error( 'upload_error', $upload['error'] );
    }

    $attachment_id = wp_insert_attachment(
        [
            'post_mime_type' => $upload['type'],
            'post_title'     => sanitize_file_name( pathinfo( $file['name'], PATHINFO_FILENAME ) ),
            'post_content'   => '',
            'post_status'    => 'inherit',
            'post_parent'    => (int) $provider_id,
            'post_author'    => get_current_user_id(),
        ],
        $upload['file'],
        (int) $provider_id
    );

    if ( is_wp_error( $attachment_id ) ) {
        return $attachment_id;
    }

    $metadata = wp_generate_attachment_metadata( $attachment_id, $upload['file'] );
    wp_update_attachment_metadata( $attachment_id, $metadata );

    $base_name = sanitize_title( pathinfo( $file['name'], PATHINFO_FILENAME ) );
    if ( ! $base_name ) {
        $base_name = 'work';
    }

    $unique_slug = wp_unique_post_slug(
        $base_name . '-work-' . (int) $provider_id . '-' . wp_rand( 1000, 9999 ),
        (int) $attachment_id,
        'inherit',
        'attachment',
        (int) $provider_id
    );

    wp_update_post(
        [
            'ID'        => (int) $attachment_id,
            'post_name' => $unique_slug,
        ]
    );

    return (int) $attachment_id;
}

function ie_save_provider_work_gallery( $provider_id, $keep_ids = null ) {
    $provider_id = (int) $provider_id;
    $max_images  = ie_get_provider_work_gallery_max();

    if ( null === $keep_ids && isset( $_POST['work_gallery_ids'] ) ) {
        $keep_ids = json_decode( wp_unslash( $_POST['work_gallery_ids'] ), true );
    }

    if ( ! is_array( $keep_ids ) ) {
        $keep_ids = [];
    }

    $valid_keep = [];
    foreach ( $keep_ids as $id ) {
        $id = (int) $id;
        if ( $id && ie_user_can_manage_provider_gallery_attachment( $id, $provider_id ) ) {
            $valid_keep[] = $id;
        }
    }

    if ( ! empty( $_FILES['work_gallery_files']['name'] ) ) {
        $files = $_FILES['work_gallery_files'];
        $count = is_array( $files['name'] ) ? count( $files['name'] ) : 0;

        for ( $i = 0; $i < $count; $i++ ) {
            if ( empty( $files['name'][ $i ] ) || (int) ( $files['error'][ $i ] ?? UPLOAD_ERR_NO_FILE ) !== UPLOAD_ERR_OK ) {
                continue;
            }

            if ( count( $valid_keep ) >= $max_images ) {
                break;
            }

            $uploaded = ie_upload_provider_work_gallery_file(
                $provider_id,
                [
                    'name'     => $files['name'][ $i ],
                    'type'     => $files['type'][ $i ],
                    'tmp_name' => $files['tmp_name'][ $i ],
                    'error'    => $files['error'][ $i ],
                    'size'     => $files['size'][ $i ],
                ]
            );

            if ( is_wp_error( $uploaded ) ) {
                return $uploaded;
            }

            $valid_keep[] = $uploaded;
        }
    }

    $valid_keep = array_values( array_unique( array_slice( $valid_keep, 0, $max_images ) ) );
    $old_ids    = ie_get_provider_work_gallery_ids( $provider_id );

    foreach ( $old_ids as $old_id ) {
        $old_id = (int) $old_id;

        if ( in_array( $old_id, $valid_keep, true ) ) {
            continue;
        }

        if ( $old_id === $provider_id || ! wp_attachment_is_image( $old_id ) ) {
            continue;
        }

        if ( ie_user_can_manage_provider_gallery_attachment( $old_id, $provider_id ) ) {
            wp_delete_attachment( $old_id, true );
        }
    }

    update_post_meta( $provider_id, '_ie_work_gallery', wp_json_encode( $valid_keep ) );

    return $valid_keep;
}

function ie_build_provider_single_view( $post_id, $slug = '' ) {
    $post_id = (int) $post_id;
    ie_repair_provider_slug_collisions( $post_id );
    ie_ensure_provider_slug( $post_id );
    $post    = get_post( $post_id );

    if ( ! $post || $post->post_type !== 'ie_provider' ) {
        return null;
    }

    if ( ! in_array( $post->post_status, [ 'publish', 'pending' ], true ) ) {
        return null;
    }

    if ( get_post_meta( $post_id, '_ie_is_sample', true ) || ! ie_is_registered_provider_listing( $post_id ) ) {
        return null;
    }

    $d = ie_get_provider_data( $post_id );
    if ( ! $d ) {
        return null;
    }

    $slug     = $slug ?: ie_ensure_provider_slug( $post_id );
    $cat_slug = $d['category_slug'] ?: sanitize_title( $d['category'] );
    $services = $d['services'] ? json_decode( $d['services'], true ) : [];
    $service  = ie_get_provider_card_service_name( $post_id, $d );

    return [
        'id'                => $post_id,
        'slug'              => $slug,
        'title'             => ie_get_provider_card_display_name( $post_id, $d ),
        'service_name'      => $service['name'],
        'service_name_slug' => $service['slug'],
        'business_name'     => $d['title'],
        'rating'            => ie_format_provider_rating( $d['rating'] ),
        'reviews'           => (string) (int) ie_get_provider_review_count_value( $post_id ),
        'category'          => $d['category'],
        'category_slug'     => $cat_slug,
        'bio'               => ie_get_provider_bio_text( $post_id, $d ),
        'about'             => ie_get_provider_bio_text( $post_id, $d ),
        'service_image'     => ie_get_featured_provider_card_image( $post_id, $cat_slug ),
        'has_service_banner' => ie_provider_has_service_banner( $post_id ),
        'profile_image'     => ie_get_provider_profile_image_url( $post_id ),
        'location'          => $d['location'],
        'experience'        => $d['experience'],
        'price'             => $d['price'],
        'phone'             => $d['phone'],
        'email'             => $d['email'],
        'website'           => $d['website'],
        'verified'          => $d['verified'],
        'premium'           => $d['premium'],
        'availability'      => $d['availability'],
        'avail_label'       => $d['avail_label'],
        'services'          => is_array( $services ) ? $services : [],
        'reviews_list'      => ie_get_provider_reviews_list( $post_id, $slug ),
        'social'            => ie_get_provider_social_links( $post_id, $slug ),
        'previous_work'     => ie_get_provider_previous_work( $post_id, $cat_slug, $slug ),
    ];
}

function ie_find_provider_id_by_attachment_slug( $slug ) {
    $slug = sanitize_title( $slug );

    if ( ! $slug ) {
        return 0;
    }

    $attachments = get_posts(
        [
            'post_type'              => 'attachment',
            'name'                   => $slug,
            'post_status'            => 'inherit',
            'posts_per_page'         => 1,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]
    );

    if ( ! $attachments ) {
        return 0;
    }

    $parent_id = (int) $attachments[0]->post_parent;

    if ( ! $parent_id || get_post_type( $parent_id ) !== 'ie_provider' ) {
        return 0;
    }

    return $parent_id;
}

function ie_resolve_provider_for_single( $slug ) {
    $slug = sanitize_title( $slug );
    if ( ! $slug ) {
        return null;
    }

    $posts = get_posts( [
        'post_type'      => 'ie_provider',
        'name'           => $slug,
        'post_status'    => [ 'publish', 'pending' ],
        'posts_per_page' => 1,
    ] );

    if ( $posts ) {
        $view = ie_build_provider_single_view( $posts[0]->ID, $slug );
        if ( $view ) {
            return $view;
        }
    }

    $registered_providers = get_posts(
        [
            'post_type'      => 'ie_provider',
            'post_status'    => [ 'publish', 'pending' ],
            'posts_per_page' => 100,
            'meta_query'     => [
                [
                    'key'   => '_ie_registered_listing',
                    'value' => '1',
                ],
            ],
        ]
    );

    foreach ( $registered_providers as $candidate ) {
        ie_repair_provider_slug_collisions( $candidate->ID );
        $candidate_slug = ie_ensure_provider_slug( $candidate->ID );

        if ( $candidate_slug !== $slug ) {
            continue;
        }

        $view = ie_build_provider_single_view( $candidate->ID, $slug );
        if ( $view ) {
            return $view;
        }
    }

    $attachment_parent_id = ie_find_provider_id_by_attachment_slug( $slug );
    if ( $attachment_parent_id ) {
        $view = ie_build_provider_single_view( $attachment_parent_id, ie_ensure_provider_slug( $attachment_parent_id ) );
        if ( $view ) {
            return $view;
        }
    }

    if ( preg_match( '/^provider-(\d+)$/', $slug, $matches ) ) {
        $view = ie_build_provider_single_view( (int) $matches[1], $slug );
        if ( $view ) {
            return $view;
        }
    }

    return null;
}

function ie_register_provider_single_rewrites() {
    add_rewrite_tag( '%ie_provider_slug%', '([^&]+)' );
    add_rewrite_rule(
        '^service-provider/([^/]+)/?$',
        'index.php?pagename=service-provider&ie_provider_slug=$matches[1]',
        'top'
    );
}
add_action( 'init', 'ie_register_provider_single_rewrites' );

function ie_register_provider_query_vars( $vars ) {
    $vars[] = 'ie_provider_slug';
    return $vars;
}
add_filter( 'query_vars', 'ie_register_provider_query_vars' );

function ie_ensure_service_provider_page() {
    $page = get_page_by_path( 'service-provider' );
    if ( $page ) {
        if ( get_post_meta( $page->ID, '_wp_page_template', true ) !== 'service-provider-single.php' ) {
            update_post_meta( $page->ID, '_wp_page_template', 'service-provider-single.php' );
        }
        return;
    }

    $id = wp_insert_post( [
        'post_title'   => ie__( 'Service Provider' ),
        'post_name'    => 'service-provider',
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_content' => '',
    ] );

    if ( ! is_wp_error( $id ) ) {
        update_post_meta( $id, '_wp_page_template', 'service-provider-single.php' );
    }
}
add_action( 'init', 'ie_ensure_service_provider_page', 20 );

function ie_maybe_flush_provider_rewrites() {
    if ( get_option( 'ie_provider_single_rewrites_v2' ) ) {
        return;
    }
    flush_rewrite_rules( false );
    update_option( 'ie_provider_single_rewrites_v2', '1' );
    delete_option( 'ie_provider_single_rewrites_v1' );
}
add_action( 'init', 'ie_maybe_flush_provider_rewrites', 99 );

function ie_render_featured_provider_card( $provider ) {
    $provider_id    = (int) ( $provider['id'] ?? 0 );
    $service_slug   = preg_replace( '/[^a-z0-9-]/', '', strtolower( $provider['service_name_slug'] ?? $provider['category_slug'] ?? '' ) );
    $has_banner     = ! empty( $provider['has_service_banner'] ) || ( $provider_id && ie_provider_has_service_banner( $provider_id ) );
    $service_image  = $has_banner
        ? ( $provider['service_image'] ?? ie_get_provider_uploaded_service_image_url( $provider_id, 'large' ) )
        : ie_get_service_banner_placeholder_uri();
    $placeholder    = ie_get_service_banner_placeholder_uri();
    $service_label  = $provider['service_name'] ?? $provider['category'] ?? '';
    $price_label    = $provider_id ? ie_get_provider_card_price_label( $provider_id ) : ie_format_provider_card_price( $provider['price'] ?? '' );
    ?>
    <article class="featured-provider-card">
        <div class="featured-provider-service-image<?php echo $has_banner ? '' : ' is-placeholder'; ?>">
            <?php
            $provider_slug = $provider['slug'] ?? sanitize_title( basename( untrailingslashit( $provider['permalink'] ?? '' ) ) );
            ie_render_featured_wishlist_button( $provider_id, $provider_slug );
            ?>
            <img src="<?php echo esc_url( $service_image ); ?>"
                 alt="<?php echo $has_banner ? esc_attr( $provider['name'] ) : ''; ?>"
                 loading="lazy"
                 onerror="this.onerror=null;this.src='<?php echo esc_url( $placeholder ); ?>';">
        </div>
        <div class="featured-provider-profile-wrap">
            <img class="featured-provider-avatar"
                 src="<?php echo esc_url( $provider['profile_image'] ); ?>"
                 alt="<?php echo esc_attr( $provider['name'] ); ?>"
                 loading="lazy"
                 onerror="this.onerror=null;this.src='<?php echo esc_url( ie_get_provider_avatar_url( $provider['name'] ) ); ?>';">
        </div>
        <div class="featured-provider-body">
            <h3 class="featured-provider-name"><?php echo esc_html( $provider['name'] ); ?></h3>
            <div class="featured-provider-rating">
                <i class="fa-solid fa-star" aria-hidden="true"></i>
                <span class="featured-provider-rating-value"><?php echo esc_html( $provider['rating'] ); ?></span>
                <span class="featured-provider-review-count">(<?php echo esc_html( $provider['reviews'] ); ?> <?php echo esc_html( ie__( 'reviews' ) ); ?>)</span>
            </div>
            <?php if ( $service_label !== '' || $price_label !== '' ) : ?>
                <div class="featured-provider-service-row">
                    <?php if ( $service_label !== '' ) : ?>
                        <span class="featured-provider-service-name tag tag-<?php echo esc_attr( $service_slug ); ?>"><?php echo esc_html( $service_label ); ?></span>
                    <?php endif; ?>
                    <?php if ( $price_label !== '' ) : ?>
                        <span class="featured-provider-price"><?php echo esc_html( $price_label ); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if ( ! empty( $provider['bio'] ) ) : ?>
                <p class="featured-provider-bio"><?php echo esc_html( $provider['bio'] ); ?></p>
            <?php endif; ?>
            <div class="featured-provider-actions">
                <a href="<?php echo esc_url( $provider['chat_url'] ); ?>" class="btn-featured-chat">
                    <i class="fa-regular fa-comment-dots" aria-hidden="true"></i>
                    <?php echo esc_html( ie__( 'Chat' ) ); ?>
                </a>
                <a href="<?php echo esc_url( $provider['permalink'] ); ?>" class="btn-featured-profile">
                    <?php echo esc_html( ie__( 'View Profile' ) ); ?>
                    <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    </article>
    <?php
}

/* === HELPER: GET USER TYPE === */
function ie_get_user_type($user_id=null) {
    if(!$user_id) $user_id=get_current_user_id();
    if(!$user_id) return '';

    if ( ie_get_provider_post_by_user( $user_id ) ) {
        $type = get_user_meta( $user_id, '_ie_user_type', true );
        if ( $type !== 'provider' ) {
            update_user_meta( $user_id, '_ie_user_type', 'provider' );
        }
        return 'provider';
    }

    $type=get_user_meta($user_id,'_ie_user_type',true);
    return in_array($type,['customer','provider'])?$type:'customer';
}

function ie_get_user_profile_url( $user_id = null ) {
    if ( ! $user_id ) {
        $user_id = get_current_user_id();
    }
    if ( ! $user_id ) {
        return ie_get_theme_page_url( 'account' );
    }

    return ( ie_get_user_type( $user_id ) === 'customer' )
        ? ie_get_theme_page_url( 'client-profile' )
        : ie_get_theme_page_url( 'provider-profile' );
}

function ie_get_provider_post_by_user( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    if ( ! $user_id ) {
        return null;
    }

    $posts = get_posts( [
        'post_type'      => 'ie_provider',
        'author'         => $user_id,
        'post_status'    => [ 'publish', 'pending', 'draft' ],
        'posts_per_page' => 1,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ] );

    return $posts[0] ?? null;
}

function ie_get_user_subscription( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    $plan    = sanitize_text_field( get_user_meta( $user_id, '_ie_subscription_plan', true ) ?: '' );
    $billing = sanitize_text_field( get_user_meta( $user_id, '_ie_subscription_billing', true ) ?: '' );
    $status  = sanitize_text_field( get_user_meta( $user_id, '_ie_subscription_status', true ) ?: 'none' );

    $plan_labels = [
        'basic-monthly'   => ie__( 'Basic Plan (Monthly)' ),
        'basic-annual'    => ie__( 'Basic Plan (Yearly)' ),
        'premium-monthly' => ie__( 'Premium Plan (Monthly)' ),
        'premium-annual'  => ie__( 'Premium Plan (Yearly)' ),
    ];

    $is_active = $status === 'active' && $plan;

    return [
        'plan'          => $plan,
        'billing'       => $billing,
        'status'        => $status,
        'is_active'     => $is_active,
        'plan_label'    => $plan_labels[ $plan ] ?? ie__( 'No active plan' ),
        'billing_label' => $billing === 'yearly' ? ie__( 'Yearly' ) : ( $billing === 'monthly' ? ie__( 'Monthly' ) : '—' ),
        'status_label'  => $is_active ? ie__( 'Active' ) : ie__( 'Inactive' ),
    ];
}

function ie_get_provider_inbox_conversations( $provider_id ) {
    $provider_id = (int) $provider_id;
    $threads     = [];

    $messages = get_posts( [
        'post_type'      => 'ie_message',
        'post_status'    => 'publish',
        'posts_per_page' => 200,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'meta_query'     => [
            [
                'key'   => '_ie_provider_id',
                'value' => $provider_id,
            ],
        ],
    ] );

    foreach ( $messages as $message ) {
        $customer_id = (int) get_post_meta( $message->ID, '_ie_user_id', true );
        if ( ! $customer_id ) {
            $customer_id = (int) $message->post_author;
        }
        if ( ! $customer_id || isset( $threads[ $customer_id ] ) ) {
            continue;
        }

        $user = get_userdata( $customer_id );
        if ( ! $user ) {
            continue;
        }

        $avatar_url = ie_get_user_profile_image_url( $customer_id, 'thumbnail' );
        $threads[ $customer_id ] = [
            'id'           => $customer_id,
            'name'         => $user->display_name,
            'avatar'       => $avatar_url ?: ie_get_provider_avatar_url( $user->display_name ),
            'last_message' => ie_get_chat_message_preview( $message ),
            'last_time'    => get_post_meta( $message->ID, '_ie_created_at', true ) ?: $message->post_date,
        ];
    }

    $real = array_values( $threads );

    return $real;
}

function ie_get_provider_customer_thread_messages( $provider_id, $customer_id ) {
    $provider_id = (int) $provider_id;
    $customer_id = (int) $customer_id;

    $messages = get_posts( [
        'post_type'      => 'ie_message',
        'post_status'    => 'publish',
        'posts_per_page' => 100,
        'orderby'        => 'date',
        'order'          => 'ASC',
        'meta_query'     => [
            'relation' => 'AND',
            [
                'key'   => '_ie_provider_id',
                'value' => $provider_id,
            ],
            [
                'key'   => '_ie_user_id',
                'value' => $customer_id,
            ],
        ],
    ] );

    $out = [];
    foreach ( $messages as $message ) {
        $out[] = ie_format_chat_message_row( $message );
    }

    return $out;
}

function ie_save_provider_reply_message( $customer_id, $provider_id, $body, $attachment_id = 0 ) {
    $customer_id   = (int) $customer_id;
    $provider_id   = (int) $provider_id;
    $attachment_id = (int) $attachment_id;
    $body          = sanitize_textarea_field( $body );

    if ( ! $customer_id || ! $provider_id || ( ! $body && ! $attachment_id ) ) {
        return 0;
    }

    $message_id = wp_insert_post( [
        'post_type'    => 'ie_message',
        'post_status'  => 'publish',
        'post_author'  => $customer_id,
        'post_content' => $body,
        'post_title'   => $attachment_id
            ? sprintf( 'Attachment — customer %d', $customer_id )
            : sprintf( 'Reply — customer %d', $customer_id ),
    ] );

    if ( is_wp_error( $message_id ) || ! $message_id ) {
        return 0;
    }

    update_post_meta( $message_id, '_ie_user_id', $customer_id );
    update_post_meta( $message_id, '_ie_provider_id', $provider_id );
    update_post_meta( $message_id, '_ie_sender', 'provider' );
    update_post_meta( $message_id, '_ie_created_at', current_time( 'mysql' ) );

    if ( $attachment_id ) {
        update_post_meta( $message_id, '_ie_attachment_id', $attachment_id );
    }

    return (int) $message_id;
}

function ie_publish_registered_provider_listings() {
    $pending = get_posts(
        [
            'post_type'      => 'ie_provider',
            'post_status'    => 'pending',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => [
                [
                    'key'   => '_ie_registered_listing',
                    'value' => '1',
                ],
            ],
        ]
    );

    foreach ( $pending as $post_id ) {
        $author_id = (int) get_post_field( 'post_author', $post_id );
        if ( get_user_meta( $author_id, '_ie_user_type', true ) !== 'provider' || ie_is_dummy_provider_user( $author_id ) ) {
            continue;
        }

        wp_update_post(
            [
                'ID'          => (int) $post_id,
                'post_status' => 'publish',
            ]
        );
    }
}

/* === AJAX: SEARCH PROVIDERS === */
function ie_ajax_search_providers() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    ie_publish_registered_provider_listings();

    $search   = sanitize_text_field( $_POST['search'] ?? '' );
    $category = sanitize_text_field( $_POST['category'] ?? '' );
    $rating   = sanitize_text_field( $_POST['rating'] ?? '' );
    $price    = sanitize_text_field( $_POST['price'] ?? '' );
    $sort     = sanitize_text_field( $_POST['sort'] ?? 'rating' );
    $page     = max( 1, intval( $_POST['page'] ?? 1 ) );
    $per_page = 6;
    $min_rating = in_array( $rating, [ '4', '4.5', '5' ], true ) ? (float) $rating : 0;

    if ( ! array_key_exists( $price, ie_get_browse_price_ranges() ) ) {
        $price = '';
    }

    $args = [
        'post_type'      => 'ie_provider',
        'post_status'    => [ 'publish', 'pending' ],
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ];

    $query        = new WP_Query( $args );
    $providers    = [];
    $seen_authors = [];

    while ( $query->have_posts() ) {
        $query->the_post();
        $post_id   = get_the_ID();
        $author_id = (int) get_post_field( 'post_author', $post_id );

        if ( isset( $seen_authors[ $author_id ] ) ) {
            continue;
        }

        if ( ! ie_is_registered_provider_listing( $post_id ) ) {
            continue;
        }

        $data = ie_get_provider_data( $post_id );
        if ( ! $data ) {
            continue;
        }

        if ( ! ie_provider_matches_browse_search( $post_id, $search, $data ) ) {
            continue;
        }

        if ( ! ie_provider_matches_category_filter( $post_id, $category, $data ) ) {
            continue;
        }

        if ( $min_rating && (float) $data['rating'] < $min_rating ) {
            continue;
        }

        if ( ! ie_provider_matches_price_filter( ie_get_provider_services_lowest_price( $post_id ), $price ) ) {
            continue;
        }

        $seen_authors[ $author_id ] = true;
        $providers[] = ie_format_featured_provider( $data );
    }
    wp_reset_postdata();

    if ( $sort === 'name' ) {
        usort(
            $providers,
            static function ( $a, $b ) {
                return strcasecmp( $a['name'], $b['name'] );
            }
        );
    } elseif ( $sort === 'price_low' ) {
        usort(
            $providers,
            static function ( $a, $b ) {
                return (float) ( $a['price'] ?? 0 ) <=> (float) ( $b['price'] ?? 0 );
            }
        );
    } elseif ( $sort === 'price_high' ) {
        usort(
            $providers,
            static function ( $a, $b ) {
                return (float) ( $b['price'] ?? 0 ) <=> (float) ( $a['price'] ?? 0 );
            }
        );
    } else {
        usort(
            $providers,
            static function ( $a, $b ) {
                $rating_cmp = (float) $b['rating'] <=> (float) $a['rating'];
                if ( $rating_cmp !== 0 ) {
                    return $rating_cmp;
                }

                return (int) $b['reviews'] <=> (int) $a['reviews'];
            }
        );
    }

    $total       = count( $providers );
    $total_pages = (int) ceil( $total / $per_page );
    $offset      = ( $page - 1 ) * $per_page;
    $providers   = array_slice( $providers, $offset, $per_page );
    $showing_from = $total ? $offset + 1 : 0;
    $showing_to   = $total ? min( $offset + $per_page, $total ) : 0;

    wp_send_json_success(
        [
            'providers'    => $providers,
            'total'        => $total,
            'total_pages'  => $total_pages,
            'current_page' => $page,
            'per_page'     => $per_page,
            'showing_from' => $showing_from,
            'showing_to'   => $showing_to,
        ]
    );
}
add_action('wp_ajax_ie_search_providers','ie_ajax_search_providers');
add_action('wp_ajax_nopriv_ie_search_providers','ie_ajax_search_providers');

/* === AJAX: WISHLIST === */
function ie_ajax_toggle_wishlist() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Please log in to save providers.' ) ] );
    }

    $uid          = get_current_user_id();
    $provider_id  = intval( $_POST['provider_id'] ?? 0 );
    $provider_slug = sanitize_title( $_POST['provider_slug'] ?? '' );
    $item         = $provider_id > 0 ? $provider_id : ( $provider_slug ?: null );

    if ( $item === null ) {
        wp_send_json_error( [ 'message' => ie__( 'Invalid provider.' ) ] );
    }

    $wishlist = ie_get_user_wishlist( $uid );
    $found_key = null;

    foreach ( $wishlist as $key => $saved ) {
        if ( is_numeric( $saved ) && is_numeric( $item ) && (int) $saved === (int) $item ) {
            $found_key = $key;
            break;
        }
        if ( ! is_numeric( $saved ) && ! is_numeric( $item ) && (string) $saved === (string) $item ) {
            $found_key = $key;
            break;
        }
    }

    if ( $found_key !== null ) {
        unset( $wishlist[ $found_key ] );
        update_user_meta( $uid, '_ie_wishlist', array_values( $wishlist ) );
        wp_send_json_success( [ 'action' => 'removed', 'message' => ie__( 'Removed from saved.' ) ] );
    }

    $wishlist[] = $item;
    update_user_meta( $uid, '_ie_wishlist', $wishlist );
    wp_send_json_success( [ 'action' => 'added', 'message' => ie__( 'Provider saved!' ) ] );
}
add_action( 'wp_ajax_ie_toggle_wishlist', 'ie_ajax_toggle_wishlist' );

function ie_ajax_get_wishlist() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Not logged in.' ) ] );
    }

    $providers = [];
    foreach ( ie_get_user_wishlist() as $item ) {
        $featured = ie_wishlist_item_to_featured( $item );
        if ( $featured ) {
            $providers[] = $featured;
        }
    }

    wp_send_json_success( [ 'providers' => $providers ] );
}
add_action( 'wp_ajax_ie_get_wishlist', 'ie_ajax_get_wishlist' );

/* === AJAX: BOOKINGS === */
function ie_ajax_create_booking() {
    check_ajax_referer('ie_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error(['message'=> ie__( 'Please log in to book.' )]);
    $pid=intval($_POST['provider_id']??0); $date=sanitize_text_field($_POST['date']??''); $uid=get_current_user_id();
    if(!$pid||!$date) wp_send_json_error(['message'=> ie__( 'Please fill in all required fields.' )]);
    $p=get_post($pid); if(!$p||$p->post_type!=='ie_provider') wp_send_json_error(['message'=> ie__( 'Invalid provider.' )]);
    $bid=wp_insert_post(['post_type'=>'ie_booking','post_status'=>'publish','post_title'=>'Booking #'.time().' - '.get_the_title($pid),'post_author'=>$uid]);
    if(is_wp_error($bid)) wp_send_json_error(['message'=> ie__( 'Failed to create booking.' )]);
    update_post_meta($bid,'_ie_provider_id',$pid); update_post_meta($bid,'_ie_user_id',$uid);
    update_post_meta($bid,'_ie_service',sanitize_text_field($_POST['service']??''));
    update_post_meta($bid,'_ie_date',$date); update_post_meta($bid,'_ie_time',sanitize_text_field($_POST['time']??''));
    update_post_meta($bid,'_ie_notes',sanitize_textarea_field($_POST['notes']??''));
    update_post_meta($bid,'_ie_status','pending'); update_post_meta($bid,'_ie_created_at',current_time('mysql'));
    wp_send_json_success(['message'=> ie__( 'Booking request sent successfully!' ),'booking_id'=>$bid]);
}
add_action('wp_ajax_ie_create_booking','ie_ajax_create_booking');

function ie_ajax_get_bookings() {
    check_ajax_referer('ie_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error(['message'=> ie__( 'Not logged in.' )]);
    $uid=get_current_user_id(); $filter=sanitize_text_field($_POST['filter']??'all');
    $args=['post_type'=>'ie_booking','post_status'=>'publish','posts_per_page'=>-1,'author'=>$uid,'orderby'=>'date','order'=>'DESC'];
    if($filter!=='all') $args['meta_query']=[['key'=>'_ie_status','value'=>$filter]];
    $query=new WP_Query($args); $bookings=[];
    while($query->have_posts()){$query->the_post();$bid=get_the_ID();$pid=get_post_meta($bid,'_ie_provider_id',true);$prov=ie_get_provider_data($pid);
        $bookings[]=['id'=>$bid,'provider_id'=>$pid,'provider_name'=>$prov?$prov['title']: ie__( 'Unknown Provider' ),'provider_thumb'=>$prov?$prov['thumbnail']:'','provider_cat'=>$prov?$prov['category']:'','service'=>get_post_meta($bid,'_ie_service',true),'date'=>get_post_meta($bid,'_ie_date',true),'time'=>get_post_meta($bid,'_ie_time',true),'notes'=>get_post_meta($bid,'_ie_notes',true),'status'=>get_post_meta($bid,'_ie_status',true)?:'pending','created_at'=>get_post_meta($bid,'_ie_created_at',true)];
    }
    wp_reset_postdata(); wp_send_json_success(['bookings'=>$bookings]);
}
add_action('wp_ajax_ie_get_bookings','ie_ajax_get_bookings');

function ie_ajax_cancel_booking() {
    check_ajax_referer('ie_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error(['message'=> ie__( 'Not logged in.' )]);
    $bid=intval($_POST['booking_id']??0); $b=get_post($bid);
    if(!$b||$b->post_author!=get_current_user_id()) wp_send_json_error(['message'=> ie__( 'Permission denied.' )]);
    $s=get_post_meta($bid,'_ie_status',true); if(in_array($s,['completed','cancelled'])) wp_send_json_error(['message'=> ie__( 'Cannot cancel this booking.' )]);
    update_post_meta($bid,'_ie_status','cancelled'); wp_send_json_success(['message'=> ie__( 'Booking cancelled.' )]);
}
add_action('wp_ajax_ie_cancel_booking','ie_ajax_cancel_booking');

/* =============================================
   AJAX: AUTH - REGISTER (FIXED)
============================================= */
function ie_ajax_register() {
    check_ajax_referer('ie_nonce','nonce');
    $first_name = sanitize_text_field($_POST['first_name']??'');
    $last_name  = sanitize_text_field($_POST['last_name']??'');
    $email      = sanitize_email($_POST['email']??'');
    $password   = $_POST['password']??'';
    $confirm    = $_POST['confirm_password'] ?? '';
    $user_type  = sanitize_text_field($_POST['user_type']??'customer');

    // Validate user_type
    if(!in_array($user_type,['customer','provider'])) $user_type='customer';

    if(!$first_name||!$email||!$password||!$confirm) wp_send_json_error(['message'=> ie__( 'Please fill in all required fields.' )]);
    if(!is_email($email)) wp_send_json_error(['message'=> ie__( 'Invalid email address.' )]);
    if(strlen($password)<6) wp_send_json_error(['message'=> ie__( 'Password must be at least 6 characters.' )]);
    if($password !== $confirm) wp_send_json_error(['message'=> ie__( 'Passwords do not match.' )]);
    if(email_exists($email)) wp_send_json_error(['message'=> ie__( 'An account with this email already exists.' )]);

    $service_name = sanitize_text_field( $_POST['service_name'] ?? '' );
    $experience   = sanitize_text_field( $_POST['experience'] ?? '' );
    $location     = sanitize_text_field( $_POST['location'] ?? '' );

    if ( $user_type === 'provider' ) {
        if ( ! $service_name || ! $experience || ! $location ) {
            wp_send_json_error( [ 'message' => ie__( 'Please fill in your business name, experience, and location.' ) ] );
        }
    }

    $username=sanitize_user(strtolower($first_name.$last_name).rand(10,99));
    while(username_exists($username)) $username=sanitize_user(strtolower($first_name.$last_name).rand(100,999));

    // Create user first
    $user_id=wp_create_user($username,$password,$email);

    // Check error BEFORE saving meta
    if(is_wp_error($user_id)) {
        wp_send_json_error(['message'=>$user_id->get_error_message()]);
        return;
    }

    // Save user_type AFTER successful creation
    update_user_meta($user_id,'_ie_user_type',$user_type);
    update_user_meta( $user_id, '_ie_account_status', 'active' );

    wp_update_user(['ID'=>$user_id,'first_name'=>$first_name,'last_name'=>$last_name,'display_name'=>$first_name.' '.$last_name]);
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id);

    if ( $user_type === 'provider' ) {
        $pid = wp_insert_post( [
            'post_type'    => 'ie_provider',
            'post_status'  => 'publish',
            'post_title'   => $service_name,
            'post_content' => '',
            'post_author'  => $user_id,
        ] );

        if ( ! is_wp_error( $pid ) ) {
            ie_ensure_provider_slug( $pid );
            update_post_meta( $pid, '_ie_about', '' );
            update_post_meta( $pid, '_ie_service_area', $location );
            update_post_meta( $pid, '_ie_experience_years', $experience );
            update_post_meta( $pid, '_ie_email', $email );
            update_post_meta( $pid, '_ie_availability', 'available_now' );
            update_post_meta( $pid, '_ie_rating', '0' );
            update_post_meta( $pid, '_ie_review_count', '0' );
            update_post_meta( $pid, '_ie_registered_listing', '1' );
        }
    }

    wp_send_json_success( [
        'message'       => ie__( 'Account created successfully!' ),
        'display_name'  => $first_name . ' ' . $last_name,
        'email'         => $email,
        'avatar'        => strtoupper( $first_name[0] ),
        'user_type'     => $user_type,
        'redirect_url'  => ie_get_user_profile_url( $user_id ),
    ] );
}
add_action('wp_ajax_nopriv_ie_register','ie_ajax_register');

/* === AJAX: LOGIN === */
function ie_ajax_login() {
    check_ajax_referer('ie_nonce','nonce');
    $email=sanitize_email($_POST['email']??''); $password=$_POST['password']??'';
    if(!$email||!$password) wp_send_json_error(['message'=> ie__( 'Please enter your email and password.' )]);
    $user=get_user_by('email',$email); if(!$user) wp_send_json_error(['message'=> ie__( 'No account found with this email.' )]);
    $result=wp_signon(['user_login'=>$user->user_login,'user_password'=>$password,'remember'=>true],false);
    if(is_wp_error($result)) wp_send_json_error(['message'=> ie__( 'Incorrect password. Please try again.' )]);
    wp_set_current_user( $result->ID );

    wp_send_json_success( [
        'message'      => sprintf( ie__( 'Welcome back, %s!' ), $result->display_name ),
        'display_name' => $result->display_name,
        'email'        => $result->user_email,
        'avatar'       => strtoupper( $result->display_name[0] ),
        'user_type'    => ie_get_user_type( $result->ID ),
        'redirect_url' => ie_get_theme_page_url( 'home' ),
    ] );
}
add_action('wp_ajax_nopriv_ie_login','ie_ajax_login');
add_action('wp_ajax_ie_login','ie_ajax_login');

/* === AJAX: LOGOUT === */
function ie_ajax_logout() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    $redirect = ie_get_theme_page_url( 'home' );
    wp_logout();
    nocache_headers();

    wp_send_json_success( [
        'message'      => ie__( 'Logged out.' ),
        'redirect_url' => $redirect,
    ] );
}
add_action( 'wp_ajax_ie_logout', 'ie_ajax_logout' );

function ie_ajax_logout_nopriv() {
    wp_send_json_success( [
        'message'      => ie__( 'Logged out.' ),
        'redirect_url' => ie_get_theme_page_url( 'home' ),
    ] );
}
add_action( 'wp_ajax_nopriv_ie_logout', 'ie_ajax_logout_nopriv' );

/* === AJAX: UPDATE PROFILE === */
function ie_ajax_update_profile(){
    check_ajax_referer('ie_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error(['message'=> ie__( 'Not logged in.' )]);
    $uid=get_current_user_id();
    $first_name = sanitize_text_field($_POST['first_name']??'');
    $last_name  = sanitize_text_field($_POST['last_name']??'');
    wp_update_user(['ID'=>$uid,'first_name'=>$first_name,'last_name'=>$last_name,'display_name'=>trim($first_name.' '.$last_name)]);

    if ( ! empty( $_FILES['profile_photo']['name'] ) ) {
        $upload = ie_handle_user_profile_photo_upload( $uid, 'profile_photo' );
        if ( is_wp_error( $upload ) ) {
            wp_send_json_error( [ 'message' => $upload->get_error_message() ] );
        }
    }

    wp_send_json_success([
        'message'     => ie__( 'Profile updated successfully!' ),
        'avatar_url'  => ie_get_user_profile_image_url( $uid, 'medium' ),
        'display_name'=> trim( $first_name . ' ' . $last_name ),
    ]);
}
add_action('wp_ajax_ie_update_profile','ie_ajax_update_profile');

/* === AJAX: CHANGE PASSWORD === */
function ie_ajax_change_password(){
    check_ajax_referer('ie_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error(['message'=> ie__( 'Not logged in.' )]);
    $uid=get_current_user_id(); $cp=$_POST['current_password']??''; $np=$_POST['new_password']??''; $conf=$_POST['confirm_password']??'';
    if(!$cp||!$np||!$conf) wp_send_json_error(['message'=> ie__( 'All fields are required.' )]);
    if($np!==$conf) wp_send_json_error(['message'=> ie__( 'New passwords do not match.' )]);
    if(strlen($np)<6) wp_send_json_error(['message'=> ie__( 'Password must be at least 6 characters.' )]);
    $user=get_user_by('id',$uid); if(!wp_check_password($cp,$user->user_pass,$uid)) wp_send_json_error(['message'=> ie__( 'Current password is incorrect.' )]);
    wp_set_password($np,$uid); wp_set_auth_cookie($uid); wp_send_json_success(['message'=> ie__( 'Password updated successfully!' )]);
}
add_action('wp_ajax_ie_change_password','ie_ajax_change_password');

/* === AJAX: GET CATEGORIES === */
function ie_ajax_get_categories(){
    check_ajax_referer('ie_nonce','nonce'); $terms=get_terms(['taxonomy'=>'ie_category','hide_empty'=>false]); $d=[];
    foreach($terms as $t) $d[]=['slug'=>$t->slug,'name'=>$t->name,'count'=>$t->count];
    wp_send_json_success(['categories'=>$d]);
}
add_action('wp_ajax_ie_get_categories','ie_ajax_get_categories');
add_action('wp_ajax_nopriv_ie_get_categories','ie_ajax_get_categories');

/* === AJAX: GET USER INFO === */
function ie_ajax_get_user_info(){
    check_ajax_referer('ie_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error(['logged_in'=>false]);
    $user=wp_get_current_user();
    wp_send_json_success(['logged_in'=>true,'display_name'=>$user->display_name,'email'=>$user->user_email,'avatar'=>strtoupper(substr($user->display_name?:$user->user_email,0,1)),'avatar_url'=>ie_get_user_profile_image_url($user->ID,'thumbnail'),'user_type'=>ie_get_user_type($user->ID)]);
}
add_action('wp_ajax_ie_get_user_info','ie_ajax_get_user_info');

/* === MESSAGING === */
function ie_get_chat_attachment_max_bytes() {
    $max = (int) wp_max_upload_size();
    $cap = 25 * 1024 * 1024;

    return min( $max > 0 ? $max : $cap, $cap );
}

function ie_get_chat_allowed_mimes() {
    return [
        'jpg|jpeg|jpe' => 'image/jpeg',
        'png'          => 'image/png',
        'gif'          => 'image/gif',
        'webp'         => 'image/webp',
        'mp4'          => 'video/mp4',
        'webm'         => 'video/webm',
        'mov|qt'       => 'video/quicktime',
        'pdf'          => 'application/pdf',
        'doc'          => 'application/msword',
        'docx'         => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls'          => 'application/vnd.ms-excel',
        'xlsx'         => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt'          => 'application/vnd.ms-powerpoint',
        'pptx'         => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'rtf'          => 'application/rtf',
        'zip'          => 'application/zip',
        'txt'          => 'text/plain',
        'csv'          => 'text/csv',
    ];
}

function ie_allow_chat_upload_mimes( $mimes ) {
    return array_merge( $mimes, ie_get_chat_allowed_mimes() );
}

function ie_grant_messaging_upload_cap( $allcaps, $caps, $args, $user ) {
    if ( empty( $args[0] ) || 'upload_files' !== $args[0] ) {
        return $allcaps;
    }

    if ( ! ie_user_can_use_messaging( $user->ID ) ) {
        return $allcaps;
    }

    if ( wp_doing_ajax() && ! empty( $_POST['action'] ) && in_array( $_POST['action'], [ 'ie_send_chat_message', 'ie_send_provider_chat_message' ], true ) ) {
        $allcaps['upload_files'] = true;
    }

    return $allcaps;
}
add_filter( 'user_has_cap', 'ie_grant_messaging_upload_cap', 10, 4 );

function ie_validate_chat_attachment_file( $file ) {
    $allowed = ie_get_chat_allowed_mimes();
    $check   = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], $allowed );

    if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
        $fallback = wp_check_filetype( $file['name'], $allowed );
        if ( ! empty( $fallback['ext'] ) && ! empty( $fallback['type'] ) ) {
            $check = $fallback;
        }
    }

    if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
        return new WP_Error( 'invalid_type', ie__( 'This file type is not allowed.' ) );
    }

    return $check;
}

function ie_handle_chat_attachment_upload( $file_key = 'chat_attachment' ) {
    if ( empty( $_FILES[ $file_key ]['name'] ) ) {
        return new WP_Error( 'no_file', ie__( 'No file selected.' ) );
    }

    $file = $_FILES[ $file_key ];
    if ( ! empty( $file['error'] ) ) {
        return new WP_Error( 'upload_error', ie__( 'File upload failed. Please try again.' ) );
    }

    if ( (int) $file['size'] > ie_get_chat_attachment_max_bytes() ) {
        return new WP_Error(
            'file_too_large',
            sprintf( ie__( 'File must be smaller than %s.' ), size_format( ie_get_chat_attachment_max_bytes() ) )
        );
    }

    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $validated = ie_validate_chat_attachment_file( $file );
    if ( is_wp_error( $validated ) ) {
        return $validated;
    }

    add_filter( 'upload_mimes', 'ie_allow_chat_upload_mimes' );
    $attachment_id = media_handle_upload( $file_key, 0 );
    remove_filter( 'upload_mimes', 'ie_allow_chat_upload_mimes' );

    if ( is_wp_error( $attachment_id ) ) {
        return $attachment_id;
    }

    return (int) $attachment_id;
}

function ie_get_chat_attachment_type( $mime ) {
    $mime = (string) $mime;

    if ( 0 === strpos( $mime, 'image/' ) ) {
        return 'image';
    }

    if ( 0 === strpos( $mime, 'video/' ) ) {
        return 'video';
    }

    return 'file';
}

function ie_get_chat_message_attachment( $message_id ) {
    $attachment_id = (int) get_post_meta( $message_id, '_ie_attachment_id', true );
    if ( ! $attachment_id ) {
        return null;
    }

    $url = wp_get_attachment_url( $attachment_id );
    if ( ! $url ) {
        return null;
    }

    $mime = get_post_mime_type( $attachment_id );
    $file = get_attached_file( $attachment_id );
    $name = $file ? basename( $file ) : get_the_title( $attachment_id );
    $size = ( $file && file_exists( $file ) ) ? (int) filesize( $file ) : 0;

    return [
        'id'           => $attachment_id,
        'url'          => $url,
        'download_url' => ie_get_chat_attachment_download_url( $message_id ),
        'name'         => $name,
        'mime'         => $mime,
        'type'         => ie_get_chat_attachment_type( $mime ?: '' ),
        'size'         => $size,
        'size_label'   => $size ? size_format( $size ) : '',
        'icon'         => ie_get_chat_file_icon_class( $name ),
    ];
}

function ie_get_chat_attachment_download_url( $message_id ) {
    $message_id = (int) $message_id;
    if ( ! $message_id ) {
        return '';
    }

    return add_query_arg(
        [
            'action'     => 'ie_download_chat_attachment',
            'message_id' => $message_id,
            'nonce'      => wp_create_nonce( 'ie_download_chat_' . $message_id ),
        ],
        admin_url( 'admin-ajax.php' )
    );
}

function ie_get_chat_file_icon_class( $filename ) {
    $ext = strtolower( pathinfo( (string) $filename, PATHINFO_EXTENSION ) );
    $map = [
        'pdf'  => 'fa-file-pdf',
        'doc'  => 'fa-file-word',
        'docx' => 'fa-file-word',
        'xls'  => 'fa-file-excel',
        'xlsx' => 'fa-file-excel',
        'ppt'  => 'fa-file-powerpoint',
        'pptx' => 'fa-file-powerpoint',
        'zip'  => 'fa-file-zipper',
        'txt'  => 'fa-file-lines',
        'csv'  => 'fa-file-csv',
        'rtf'  => 'fa-file-lines',
        'mp4'  => 'fa-file-video',
        'webm' => 'fa-file-video',
        'mov'  => 'fa-file-video',
        'jpg'  => 'fa-file-image',
        'jpeg' => 'fa-file-image',
        'png'  => 'fa-file-image',
        'gif'  => 'fa-file-image',
        'webp' => 'fa-file-image',
    ];

    return $map[ $ext ] ?? 'fa-file-lines';
}

function ie_user_can_download_chat_attachment( $message_id, $user_id = 0 ) {
    $message_id = (int) $message_id;
    $user_id    = (int) ( $user_id ?: get_current_user_id() );

    if ( ! $message_id || ! $user_id || ! is_user_logged_in() ) {
        return false;
    }

    $message = get_post( $message_id );
    if ( ! $message || $message->post_type !== 'ie_message' ) {
        return false;
    }

    if ( ! get_post_meta( $message_id, '_ie_attachment_id', true ) ) {
        return false;
    }

    return ie_user_is_message_participant( $user_id, $message_id ) || user_can( $user_id, 'manage_options' );
}

function ie_ajax_download_chat_attachment() {
    $message_id = (int) ( $_GET['message_id'] ?? 0 );
    $nonce      = sanitize_text_field( wp_unslash( $_GET['nonce'] ?? '' ) );

    if ( ! $message_id || ! wp_verify_nonce( $nonce, 'ie_download_chat_' . $message_id ) ) {
        wp_die( esc_html( ie__( 'Invalid download link.' ) ), esc_html( ie__( 'Download failed' ) ), [ 'response' => 403 ] );
    }

    if ( ! ie_user_can_download_chat_attachment( $message_id ) ) {
        wp_die( esc_html( ie__( 'You are not allowed to download this file.' ) ), esc_html( ie__( 'Download failed' ) ), [ 'response' => 403 ] );
    }

    $attachment_id = (int) get_post_meta( $message_id, '_ie_attachment_id', true );
    $file_path     = get_attached_file( $attachment_id );

    if ( ! $file_path || ! file_exists( $file_path ) ) {
        wp_die( esc_html( ie__( 'File not found.' ) ), esc_html( ie__( 'Download failed' ) ), [ 'response' => 404 ] );
    }

    $filename = basename( $file_path );
    $mime     = get_post_mime_type( $attachment_id ) ?: 'application/octet-stream';

    if ( ob_get_length() ) {
        ob_end_clean();
    }

    nocache_headers();
    header( 'Content-Type: ' . $mime );
    header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
    header( 'Content-Length: ' . filesize( $file_path ) );
    header( 'X-Content-Type-Options: nosniff' );

    readfile( $file_path );
    exit;
}
add_action( 'wp_ajax_ie_download_chat_attachment', 'ie_ajax_download_chat_attachment' );

function ie_render_chat_attachment_download_link( $message_id, $att, $label = '' ) {
    $download_url = ! empty( $att['download_url'] ) ? $att['download_url'] : ie_get_chat_attachment_download_url( $message_id );
    $label        = $label ?: ie__( 'Download' );

    if ( ! $download_url ) {
        return '';
    }

    return '<a href="' . esc_url( $download_url ) . '" class="client-messages-bubble__doc-download">' .
        '<i class="fa-solid fa-download" aria-hidden="true"></i>' .
        '<span>' . esc_html( $label ) . '</span>' .
        '</a>';
}

function ie_render_chat_attachment_block( $message_id, $att ) {
    if ( empty( $att['url'] ) ) {
        return '';
    }

    $message_id = (int) $message_id;
    $name       = $att['name'] ?? ie__( 'File' );
    $size_label = $att['size_label'] ?? '';
    $icon       = $att['icon'] ?? ie_get_chat_file_icon_class( $name );
    $type       = $att['type'] ?? 'file';

    if ( $type === 'image' ) {
        $html  = '<div class="client-messages-bubble__media-wrap">';
        $html .= '<a href="' . esc_url( $att['url'] ) . '" class="client-messages-bubble__media-link" target="_blank" rel="noopener noreferrer">';
        $html .= '<img src="' . esc_url( $att['url'] ) . '" alt="' . esc_attr( $name ) . '" class="client-messages-bubble__media client-messages-bubble__media--image">';
        $html .= '</a>';
        $html .= ie_render_chat_attachment_download_link( $message_id, $att );
        $html .= '</div>';

        return $html;
    }

    if ( $type === 'video' ) {
        $html  = '<div class="client-messages-bubble__media-wrap">';
        $html .= '<video class="client-messages-bubble__media client-messages-bubble__media--video" controls preload="metadata" src="' . esc_url( $att['url'] ) . '"></video>';
        $html .= ie_render_chat_attachment_download_link( $message_id, $att );
        $html .= '</div>';

        return $html;
    }

    $html  = '<div class="client-messages-bubble__doc">';
    $html .= '<div class="client-messages-bubble__doc-icon"><i class="fa-solid ' . esc_attr( $icon ) . '" aria-hidden="true"></i></div>';
    $html .= '<div class="client-messages-bubble__doc-info">';
    $html .= '<strong class="client-messages-bubble__doc-name">' . esc_html( $name ) . '</strong>';
    if ( $size_label ) {
        $html .= '<span class="client-messages-bubble__doc-size">' . esc_html( $size_label ) . '</span>';
    }
    $html .= '</div>';
    $html .= ie_render_chat_attachment_download_link( $message_id, $att );
    $html .= '</div>';

    return $html;
}

function ie_format_chat_message_row( $message ) {
    return [
        'id'         => $message->ID,
        'body'       => $message->post_content,
        'sender'     => get_post_meta( $message->ID, '_ie_sender', true ) ?: 'customer',
        'time'       => get_post_meta( $message->ID, '_ie_created_at', true ) ?: $message->post_date,
        'attachment' => ie_get_chat_message_attachment( $message->ID ),
    ];
}

function ie_get_chat_message_preview( $message ) {
    $attachment = ie_get_chat_message_attachment( $message->ID );
    if ( $attachment ) {
        if ( $attachment['type'] === 'image' ) {
            return ie__( 'Photo' );
        }
        if ( $attachment['type'] === 'video' ) {
            return ie__( 'Video' );
        }

        return $attachment['name'] ?: ie__( 'File' );
    }

    $text = trim( wp_strip_all_tags( $message->post_content ) );
    if ( ! $text ) {
        return ie__( 'Message' );
    }

    return wp_trim_words( $text, 12, '…' );
}

function ie_render_chat_message_bubble_inner( $message ) {
    $html = '';

    if ( ! empty( $message['attachment']['url'] ) ) {
        $html .= ie_render_chat_attachment_block( (int) ( $message['id'] ?? 0 ), $message['attachment'] );
    }

    if ( ! empty( $message['body'] ) ) {
        $html .= '<div class="client-messages-bubble__text">' . esc_html( $message['body'] ) . '</div>';
    }

    if ( ! $html ) {
        $html = '<div class="client-messages-bubble__text">' . esc_html( ie__( 'Attachment' ) ) . '</div>';
    }

    return $html;
}

function ie_save_chat_message( $user_id, $provider_id, $body, $sender = 'customer', $attachment_id = 0 ) {
    $provider_id   = (int) $provider_id;
    $user_id       = (int) $user_id;
    $attachment_id = (int) $attachment_id;
    $body          = sanitize_textarea_field( $body );

    if ( ! $user_id || ! $provider_id || ( ! $body && ! $attachment_id ) ) {
        return 0;
    }

    $message_id = wp_insert_post( [
        'post_type'    => 'ie_message',
        'post_status'  => 'publish',
        'post_author'  => $user_id,
        'post_content' => $body,
        'post_title'   => $attachment_id
            ? sprintf( 'Attachment — provider %d', $provider_id )
            : sprintf( 'Message — provider %d', $provider_id ),
    ] );

    if ( is_wp_error( $message_id ) || ! $message_id ) {
        return 0;
    }

    update_post_meta( $message_id, '_ie_user_id', $user_id );
    update_post_meta( $message_id, '_ie_provider_id', $provider_id );
    update_post_meta( $message_id, '_ie_sender', $sender === 'provider' ? 'provider' : 'customer' );
    update_post_meta( $message_id, '_ie_created_at', current_time( 'mysql' ) );

    if ( $attachment_id ) {
        update_post_meta( $message_id, '_ie_attachment_id', $attachment_id );
    }

    return (int) $message_id;
}

function ie_get_provider_conversation_meta( $provider_id ) {
    $provider_id = (int) $provider_id;
    $post        = get_post( $provider_id );

    if ( ! $post || $post->post_type !== 'ie_provider' ) {
        return null;
    }

    $data = ie_get_provider_data( $provider_id );
    if ( ! $data ) {
        return null;
    }

    return [
        'id'            => $provider_id,
        'name'          => ie_get_provider_card_display_name( $provider_id, $data ),
        'category'      => $data['category'],
        'avatar'        => ie_get_provider_profile_image_url( $provider_id ) ?: ie_get_provider_avatar_url( $data['title'] ),
        'permalink'     => $data['permalink'],
    ];
}

function ie_get_client_chat_read_time( $user_id, $provider_id ) {
    return (string) get_user_meta( (int) $user_id, '_ie_chat_read_' . (int) $provider_id, true );
}

function ie_get_provider_inbox_read_time( $provider_id, $customer_id ) {
    $provider_post = get_post( (int) $provider_id );

    if ( ! $provider_post ) {
        return '';
    }

    return (string) get_user_meta( (int) $provider_post->post_author, '_ie_inbox_read_' . (int) $customer_id, true );
}

function ie_mark_client_chat_read( $user_id, $provider_id ) {
    $user_id     = (int) $user_id;
    $provider_id = (int) $provider_id;

    if ( ! $user_id || ! $provider_id ) {
        return;
    }

    update_user_meta( $user_id, '_ie_chat_read_' . $provider_id, current_time( 'mysql' ) );
}

function ie_mark_provider_inbox_read( $provider_id, $customer_id ) {
    $provider_post = get_post( (int) $provider_id );
    $customer_id   = (int) $customer_id;

    if ( ! $provider_post || ! $customer_id ) {
        return;
    }

    update_user_meta( (int) $provider_post->post_author, '_ie_inbox_read_' . $customer_id, current_time( 'mysql' ) );
}

function ie_is_chat_message_unread( $message_time, $read_time ) {
    if ( ! $message_time ) {
        return false;
    }

    if ( ! $read_time ) {
        return true;
    }

    return strtotime( $message_time ) > strtotime( $read_time );
}

function ie_get_client_unread_message_count( $user_id ) {
    $user_id = (int) $user_id;

    if ( ! $user_id ) {
        return 0;
    }

    $messages = get_posts( [
        'post_type'      => 'ie_message',
        'post_status'    => 'publish',
        'posts_per_page' => 500,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'meta_query'     => [
            'relation' => 'AND',
            [
                'key'   => '_ie_user_id',
                'value' => $user_id,
            ],
            [
                'key'   => '_ie_sender',
                'value' => 'provider',
            ],
        ],
    ] );

    $count = 0;

    foreach ( $messages as $message ) {
        $provider_id = (int) get_post_meta( $message->ID, '_ie_provider_id', true );
        if ( ! $provider_id ) {
            continue;
        }

        $msg_time  = get_post_meta( $message->ID, '_ie_created_at', true ) ?: $message->post_date;
        $read_time = ie_get_client_chat_read_time( $user_id, $provider_id );

        if ( ie_is_chat_message_unread( $msg_time, $read_time ) ) {
            $count++;
        }
    }

    return $count;
}

function ie_get_provider_unread_message_count( $provider_id ) {
    $provider_id = (int) $provider_id;

    if ( ! $provider_id ) {
        return 0;
    }

    $messages = get_posts( [
        'post_type'      => 'ie_message',
        'post_status'    => 'publish',
        'posts_per_page' => 500,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'meta_query'     => [
            'relation' => 'AND',
            [
                'key'   => '_ie_provider_id',
                'value' => $provider_id,
            ],
            [
                'key'   => '_ie_sender',
                'value' => 'customer',
            ],
        ],
    ] );

    $count = 0;

    foreach ( $messages as $message ) {
        $customer_id = (int) get_post_meta( $message->ID, '_ie_user_id', true );
        if ( ! $customer_id ) {
            continue;
        }

        $msg_time  = get_post_meta( $message->ID, '_ie_created_at', true ) ?: $message->post_date;
        $read_time = ie_get_provider_inbox_read_time( $provider_id, $customer_id );

        if ( ie_is_chat_message_unread( $msg_time, $read_time ) ) {
            $count++;
        }
    }

    return $count;
}

function ie_get_current_user_unread_message_count( $user_id = null ) {
    if ( ! $user_id ) {
        $user_id = get_current_user_id();
    }

    if ( ! $user_id ) {
        return 0;
    }

    if ( ie_get_user_type( $user_id ) === 'provider' ) {
        $provider_post = ie_get_provider_post_by_user( $user_id );

        return $provider_post ? ie_get_provider_unread_message_count( $provider_post->ID ) : 0;
    }

    return ie_get_client_unread_message_count( $user_id );
}

function ie_get_user_messages_url( $user_id = null ) {
    return add_query_arg( 'tab', 'messages', ie_get_user_profile_url( $user_id ) );
}

function ie_is_user_dashboard_page() {
    if ( ! is_page() ) {
        return false;
    }

    $template = get_page_template_slug( get_queried_object_id() );

    if ( in_array( $template, [ 'client-profile.php', 'provider-profile.php' ], true ) ) {
        return true;
    }

    $page = get_queried_object();

    return $page instanceof WP_Post
        && in_array( $page->post_name, [ 'client-profile', 'provider-profile' ], true );
}

function ie_add_user_dashboard_body_class( $classes ) {
    if ( ie_is_user_dashboard_page() ) {
        $classes[] = 'ie-user-dashboard';
    }

    return $classes;
}
add_filter( 'body_class', 'ie_add_user_dashboard_body_class' );

function ie_delete_chat_thread_messages( $customer_id, $provider_id ) {
    $customer_id = (int) $customer_id;
    $provider_id = (int) $provider_id;

    if ( ! $customer_id || ! $provider_id ) {
        return false;
    }

    $messages = get_posts(
        [
            'post_type'      => 'ie_message',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => [
                'relation' => 'AND',
                [
                    'key'   => '_ie_user_id',
                    'value' => $customer_id,
                ],
                [
                    'key'   => '_ie_provider_id',
                    'value' => $provider_id,
                ],
            ],
        ]
    );

    foreach ( $messages as $message_id ) {
        $attachment_id = (int) get_post_meta( $message_id, '_ie_attachment_id', true );
        if ( $attachment_id ) {
            wp_delete_attachment( $attachment_id, true );
        }
        wp_delete_post( (int) $message_id, true );
    }

    return true;
}

function ie_delete_customer_chat_conversation( $user_id, $provider_id ) {
    $user_id     = (int) $user_id;
    $provider_id = (int) $provider_id;

    if ( ! $user_id || ! $provider_id ) {
        return false;
    }

    ie_delete_chat_thread_messages( $user_id, $provider_id );

    $wishlist = get_user_meta( $user_id, '_ie_wishlist', true ) ?: [];
    if ( is_array( $wishlist ) && $wishlist ) {
        $wishlist = array_values(
            array_filter(
                array_map( 'intval', $wishlist ),
                static function ( $id ) use ( $provider_id ) {
                    return $id !== $provider_id;
                }
            )
        );
        update_user_meta( $user_id, '_ie_wishlist', $wishlist );
    }

    return true;
}

function ie_delete_provider_customer_chat_conversation( $provider_id, $customer_id ) {
    $provider_id = (int) $provider_id;
    $customer_id = (int) $customer_id;

    if ( ! $provider_id || ! $customer_id ) {
        return false;
    }

    return ie_delete_chat_thread_messages( $customer_id, $provider_id );
}

function ie_ajax_delete_chat_conversation() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() || ie_get_user_type() !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $provider_id = (int) ( $_POST['provider_id'] ?? 0 );
    if ( ! $provider_id ) {
        wp_send_json_error( [ 'message' => ie__( 'Provider not found.' ) ] );
    }

    $provider = get_post( $provider_id );
    if ( ! $provider || $provider->post_type !== 'ie_provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Provider not found.' ) ] );
    }

    ie_delete_customer_chat_conversation( get_current_user_id(), $provider_id );

    wp_send_json_success( [ 'message' => ie__( 'Conversation deleted.' ) ] );
}
add_action( 'wp_ajax_ie_delete_chat_conversation', 'ie_ajax_delete_chat_conversation' );

function ie_ajax_delete_provider_chat_conversation() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $customer_id = (int) ( $_POST['customer_id'] ?? 0 );
    if ( ! $customer_id ) {
        wp_send_json_error( [ 'message' => ie__( 'Customer not found.' ) ] );
    }

    $customer = get_userdata( $customer_id );
    if ( ! $customer || ie_get_user_type( $customer_id ) !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Customer not found.' ) ] );
    }

    $provider_post = ie_get_provider_post_by_user();
    if ( ! $provider_post ) {
        wp_send_json_error( [ 'message' => ie__( 'Provider profile not found.' ) ] );
    }

    ie_delete_provider_customer_chat_conversation( $provider_post->ID, $customer_id );

    wp_send_json_success( [ 'message' => ie__( 'Conversation deleted.' ) ] );
}
add_action( 'wp_ajax_ie_delete_provider_chat_conversation', 'ie_ajax_delete_provider_chat_conversation' );

function ie_get_user_conversations( $user_id, $target_provider_id = 0 ) {
    $user_id  = (int) $user_id;
    $threads  = [];
    $messages = get_posts( [
        'post_type'      => 'ie_message',
        'post_status'    => 'publish',
        'posts_per_page' => 200,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'meta_query'     => [
            [
                'key'   => '_ie_user_id',
                'value' => $user_id,
            ],
        ],
    ] );

    foreach ( $messages as $message ) {
        $provider_id = (int) get_post_meta( $message->ID, '_ie_provider_id', true );
        if ( ! $provider_id || isset( $threads[ $provider_id ] ) ) {
            continue;
        }

        $provider = ie_get_provider_conversation_meta( $provider_id );
        if ( ! $provider ) {
            continue;
        }

        $preview = ie_get_chat_message_preview( $message );
        $threads[ $provider_id ] = array_merge( $provider, [
            'last_message' => $preview,
            'last_time'    => get_post_meta( $message->ID, '_ie_created_at', true ) ?: $message->post_date,
            'has_messages' => true,
        ] );
    }

    $wishlist = get_user_meta( $user_id, '_ie_wishlist', true ) ?: [];
    foreach ( $wishlist as $provider_id ) {
        $provider_id = (int) $provider_id;
        if ( isset( $threads[ $provider_id ] ) ) {
            continue;
        }

        $provider = ie_get_provider_conversation_meta( $provider_id );
        if ( ! $provider ) {
            continue;
        }

        $threads[ $provider_id ] = array_merge( $provider, [
            'last_message' => ie__( 'Start a conversation' ),
            'last_time'    => '',
            'has_messages' => false,
        ] );
    }

    $conversations = array_values( $threads );

    return ie_prepend_provider_conversation( $conversations, (int) $target_provider_id );
}

function ie_get_chat_thread_messages( $user_id, $provider_id ) {
    $user_id     = (int) $user_id;
    $provider_id = (int) $provider_id;

    $messages = get_posts( [
        'post_type'      => 'ie_message',
        'post_status'    => 'publish',
        'posts_per_page' => 100,
        'orderby'        => 'date',
        'order'          => 'ASC',
        'meta_query'     => [
            'relation' => 'AND',
            [
                'key'   => '_ie_user_id',
                'value' => $user_id,
            ],
            [
                'key'   => '_ie_provider_id',
                'value' => $provider_id,
            ],
        ],
    ] );

    $out = [];
    foreach ( $messages as $message ) {
        $out[] = ie_format_chat_message_row( $message );
    }

    return $out;
}

function ie_ajax_get_conversations() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Not logged in.' ) ] );
    }

    $target_provider_id = (int) ( $_POST['target_provider'] ?? 0 );
    $conversations      = ie_get_user_conversations( get_current_user_id(), $target_provider_id );
    wp_send_json_success( [
        'conversations' => $conversations,
        'count'         => count( $conversations ),
        'unread'        => ie_get_client_unread_message_count( get_current_user_id() ),
    ] );
}
add_action( 'wp_ajax_ie_get_conversations', 'ie_ajax_get_conversations' );

function ie_ajax_get_unread_message_count() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Not logged in.' ) ] );
    }

    if ( ie_get_user_type() === 'provider' ) {
        $provider_post = ie_get_provider_post_by_user();
        $unread        = $provider_post ? ie_get_provider_unread_message_count( $provider_post->ID ) : 0;
    } else {
        $unread = ie_get_client_unread_message_count( get_current_user_id() );
    }

    wp_send_json_success( [
        'unread' => (int) $unread,
    ] );
}
add_action( 'wp_ajax_ie_get_unread_message_count', 'ie_ajax_get_unread_message_count' );

function ie_ajax_get_chat_thread() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Not logged in.' ) ] );
    }

    $provider_id = sanitize_text_field( $_POST['provider_id'] ?? '' );
    $provider_id = (int) $provider_id;
    $provider    = ie_get_provider_conversation_meta( $provider_id );

    if ( ! $provider ) {
        wp_send_json_error( [ 'message' => ie__( 'Provider not found.' ) ] );
    }

    ie_mark_client_chat_read( get_current_user_id(), $provider_id );

    wp_send_json_success( [
        'provider' => $provider,
        'messages' => ie_get_chat_thread_messages( get_current_user_id(), $provider_id ),
    ] );
}
add_action( 'wp_ajax_ie_get_chat_thread', 'ie_ajax_get_chat_thread' );

function ie_ajax_send_chat_message() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Not logged in.' ) ] );
    }

    if ( ie_get_user_type() !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Only customers can start chats from provider listings.' ) ] );
    }

    $provider_id = (int) ( $_POST['provider_id'] ?? 0 );
    $message     = sanitize_textarea_field( $_POST['message'] ?? '' );
    $user        = wp_get_current_user();
    $attachment_id = 0;

    if ( ! empty( $_FILES['chat_attachment']['name'] ) ) {
        $upload = ie_handle_chat_attachment_upload( 'chat_attachment' );
        if ( is_wp_error( $upload ) ) {
            wp_send_json_error( [ 'message' => $upload->get_error_message() ] );
        }
        $attachment_id = (int) $upload;
    }

    if ( ! $provider_id || ( ! $message && ! $attachment_id ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Please write a message or choose a file.' ) ] );
    }

    $provider = get_post( $provider_id );
    if ( ! $provider || $provider->post_type !== 'ie_provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Invalid provider.' ) ] );
    }

    if ( ! ie_is_registered_provider_listing( $provider_id ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Provider not found.' ) ] );
    }

    $provider_email = get_post_meta( $provider_id, '_ie_email', true );
    if ( $provider_email ) {
        wp_mail(
            $provider_email,
            sprintf( ie__( 'New message from %1$s via Island Experts' ), $user->display_name ),
            sprintf(
                "Name: %s\nEmail: %s\n\nMessage:\n%s",
                $user->display_name,
                $user->user_email,
                $message
            )
        );
    }

    $message_id = ie_save_chat_message( $user->ID, $provider_id, $message, 'customer', $attachment_id );
    if ( ! $message_id ) {
        wp_send_json_error( [ 'message' => ie__( 'Failed to send message. Please try again.' ) ] );
    }

    $saved = get_post( $message_id );
    $row   = $saved ? ie_format_chat_message_row( $saved ) : null;

    wp_send_json_success( [
        'message' => ie__( 'Message sent!' ),
        'chat'    => $row ?: [
            'id'     => $message_id,
            'body'   => $message,
            'sender' => 'customer',
            'time'   => current_time( 'mysql' ),
        ],
    ] );
}
add_action( 'wp_ajax_ie_send_chat_message', 'ie_ajax_send_chat_message' );

/* === AJAX: SEND MESSAGE === */
function ie_ajax_send_message(){
    check_ajax_referer('ie_nonce','nonce');
    $pid=intval($_POST['provider_id']??0); $name=sanitize_text_field($_POST['name']??''); $email=sanitize_email($_POST['email']??'');
    $phone=sanitize_text_field($_POST['phone']??''); $msg=sanitize_textarea_field($_POST['message']??''); $pe=get_post_meta($pid,'_ie_email',true);
    if(!$name||!$email||!$msg) wp_send_json_error(['message'=> ie__( 'Please fill in all required fields.' )]);
    if(!$pe) wp_send_json_error(['message'=> ie__( 'Provider contact not available.' )]);
    wp_mail($pe,sprintf( ie__( 'New message from %1$s via Island Experts' ), $name ),"Name: {$name}\nEmail: {$email}\nPhone: {$phone}\n\nMessage:\n{$msg}");

    if ( is_user_logged_in() && $pid ) {
        ie_save_chat_message( get_current_user_id(), $pid, $msg, 'customer' );
    }

    wp_send_json_success(['message'=> ie__( 'Message sent!' )]);
}
add_action('wp_ajax_ie_send_message','ie_ajax_send_message');
add_action('wp_ajax_nopriv_ie_send_message','ie_ajax_send_message');

/* === AJAX: SUBMIT REVIEW === */
function ie_ajax_submit_review(){
    check_ajax_referer('ie_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error(['message'=> ie__( 'Please log in to leave a review.' )]);
    $pid=intval($_POST['provider_id']??0); $rating=min(5,max(1,intval($_POST['rating']??5))); $review=sanitize_textarea_field($_POST['review']??''); $user=wp_get_current_user();
    if(!$review) wp_send_json_error(['message'=> ie__( 'Please write your review.' )]);
    $hb=get_posts(['post_type'=>'ie_booking','author'=>get_current_user_id(),'numberposts'=>1,'meta_query'=>[['key'=>'_ie_provider_id','value'=>$pid],['key'=>'_ie_status','value'=>'completed']]]);
    if(!$hb) wp_send_json_error(['message'=> ie__( 'Only customers with a completed booking can leave a review.' )]);
    $already=get_comments(['post_id'=>$pid,'user_id'=>get_current_user_id(),'count'=>true]);
    if($already>0) wp_send_json_error(['message'=> ie__( 'You have already reviewed this provider.' )]);
    $cid=wp_insert_comment(['comment_post_ID'=>$pid,'comment_author'=>$user->display_name,'comment_author_email'=>$user->user_email,'comment_content'=>$review,'comment_type'=>'ie_review','comment_approved'=>1,'user_id'=>get_current_user_id()]);
    if(!$cid) wp_send_json_error(['message'=> ie__( 'Failed to submit review.' )]);
    add_comment_meta($cid,'_ie_review_rating',$rating);
    $all=get_comments(['post_id'=>$pid,'status'=>'approve','type'=>'ie_review']); $total=0; $count=count($all);
    foreach($all as $r) $total+=intval(get_comment_meta($r->comment_ID,'_ie_review_rating',true)?:5);
    $avg=$count>0?round($total/$count,1):0; update_post_meta($pid,'_ie_rating',$avg); update_post_meta($pid,'_ie_review_count',$count);
    wp_send_json_success(['message'=> ie__( 'Thank you! Your review has been submitted.' )]);
}
add_action('wp_ajax_ie_submit_review','ie_ajax_submit_review');

/* === AJAX: REGISTER PROVIDER === */
function ie_ajax_register_provider(){
    check_ajax_referer('ie_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error(['message'=> ie__( 'Please log in first.' )]);
    $uid=get_current_user_id(); $name=sanitize_text_field($_POST['business_name']??''); $cat_id=intval($_POST['category_id']??0);
    $about=sanitize_textarea_field($_POST['about']??''); $phone=sanitize_text_field($_POST['phone']??'');
    $email=sanitize_email($_POST['email']??''); $website=esc_url_raw($_POST['website']??'');
    $area=sanitize_text_field($_POST['service_area']??''); $exp=sanitize_text_field($_POST['experience']??'');
    $price=sanitize_text_field($_POST['price_from']??''); $services=sanitize_text_field($_POST['services']??'');
    if(!$name||!$about||!$phone||!$email||!$area) wp_send_json_error(['message'=> ie__( 'Please fill in all required fields.' )]);

    $pid=wp_insert_post(['post_type'=>'ie_provider','post_status'=>'publish','post_title'=>$name,'post_content'=>$about,'post_author'=>$uid]);
    if(is_wp_error($pid)) wp_send_json_error(['message'=> ie__( 'Failed to submit. Please try again.' )]);

    ie_ensure_provider_slug( $pid );

    update_user_meta( $uid, '_ie_user_type', 'provider' );
    update_user_meta( $uid, '_ie_account_status', 'active' );

    if ( ! empty( $_COOKIE['ie_plan_id'] ) ) {
        $plan_id = sanitize_text_field( wp_unslash( $_COOKIE['ie_plan_id'] ) );
        $billing = strpos( $plan_id, 'annual' ) !== false ? 'yearly' : 'monthly';
        update_user_meta( $uid, '_ie_subscription_plan', $plan_id );
        update_user_meta( $uid, '_ie_subscription_billing', $billing );
        update_user_meta( $uid, '_ie_subscription_status', 'active' );
    }

    update_post_meta($pid,'_ie_about',$about); update_post_meta($pid,'_ie_phone',$phone); update_post_meta($pid,'_ie_email',$email);
    update_post_meta($pid,'_ie_website',$website); update_post_meta($pid,'_ie_service_area',$area);
    update_post_meta($pid,'_ie_experience_years',$exp); update_post_meta($pid,'_ie_price_from',$price);
    update_post_meta($pid,'_ie_services',$services); update_post_meta($pid,'_ie_availability','available_now');
    update_post_meta($pid,'_ie_rating','0'); update_post_meta($pid,'_ie_review_count','0');
    update_post_meta( $pid, '_ie_registered_listing', '1' );
    if($cat_id) wp_set_object_terms($pid,$cat_id,'ie_category');
    if(!empty($_FILES['photo']['name'])){require_once ABSPATH.'wp-admin/includes/image.php';require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';$ai=media_handle_upload('photo',$pid);if(!is_wp_error($ai)) set_post_thumbnail($pid,$ai);}

    wp_mail(
        get_option('admin_email'),
        'New Provider Listing: ' . $name,
        "A new service provider has joined Island Experts.\n\n" .
        "Name:  {$name}\n" .
        "Email: {$email}\n" .
        "Phone: {$phone}\n" .
        "Area:  {$area}\n\n" .
        "View listing:\n" .
        admin_url('post.php?post=' . $pid . '&action=edit')
    );

    // Provider confirmation mail
    wp_mail(
        $email,
        'Your profile is live — Island Experts',
        "Hi {$name},\n\n" .
        "Thank you for joining Island Experts!\n\n" .
        "Your business profile is now live and visible to customers across St. Lucia.\n\n" .
        "You can update your profile any time from your provider dashboard.\n\n" .
        "Best regards,\nThe Island Experts Team\n" .
        home_url('/')
    );

    wp_send_json_success( [
        'message'       => ie__( 'Your application has been submitted successfully!' ),
        'redirect_url'  => ie_get_user_profile_url( $uid ),
    ] );
}
add_action('wp_ajax_ie_register_provider','ie_ajax_register_provider');

/* === AJAX: UPDATE PROVIDER === */
function ie_ajax_update_provider(){
    check_ajax_referer('ie_nonce','nonce'); if(!is_user_logged_in()) wp_send_json_error(['message'=> ie__( 'Not logged in.' )]);
    $pid=intval($_POST['provider_id']??0); $p=get_post($pid);
    if(!$p||$p->post_author!=get_current_user_id()) wp_send_json_error(['message'=> ie__( 'Permission denied.' )]);
    $business_name = sanitize_text_field( $_POST['business_name'] ?? '' );
    if ( $business_name !== '' ) {
        wp_update_post( [ 'ID' => $pid, 'post_title' => $business_name ] );
    }
    ie_ensure_provider_slug( $pid );
    ie_repair_provider_slug_collisions( $pid );
    $map=['_ie_about'=>['key'=>'about','fn'=>'sanitize_textarea_field'],'_ie_phone'=>['key'=>'phone','fn'=>'sanitize_text_field'],'_ie_email'=>['key'=>'email','fn'=>'sanitize_email'],'_ie_service_area'=>['key'=>'service_area','fn'=>'sanitize_text_field'],'_ie_price_from'=>['key'=>'price_from','fn'=>'sanitize_text_field'],'_ie_experience_years'=>['key'=>'experience','fn'=>'sanitize_text_field'],'_ie_availability'=>['key'=>'availability','fn'=>'sanitize_text_field']];
    foreach($map as $mk=>$cfg){if(isset($_POST[$cfg['key']])) update_post_meta($pid,$mk,$cfg['fn']($_POST[$cfg['key']]));}
    if ( isset( $_POST['socials'] ) ) {
        $socials = json_decode( wp_unslash( $_POST['socials'] ), true );
        if ( ! is_array( $socials ) ) {
            wp_send_json_error( [ 'message' => ie__( 'Invalid social links data.' ) ] );
        }
        update_post_meta( $pid, '_ie_socials', wp_json_encode( ie_sanitize_provider_socials_list( $socials ) ) );
    }
    if ( isset( $_POST['work_gallery_ids'] ) || ! empty( $_FILES['work_gallery_files']['name'] ) ) {
        $gallery_result = ie_save_provider_work_gallery( $pid );
        if ( is_wp_error( $gallery_result ) ) {
            wp_send_json_error( [ 'message' => $gallery_result->get_error_message() ] );
        }
    }
    wp_send_json_success([
        'message'      => ie__( 'Business info updated successfully!' ),
        'work_gallery' => ie_get_provider_work_gallery( $pid, 'medium' ),
    ]);
}
add_action('wp_ajax_ie_update_provider','ie_ajax_update_provider');

function ie_ajax_dismiss_profile_progress() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Not logged in.' ) ] );
    }

    $user_id  = get_current_user_id();
    $provider = ie_get_provider_post_by_user( $user_id );

    if ( ! $provider || ! ie_is_provider_profile_complete( $provider->ID, $user_id ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Profile is not complete yet.' ) ] );
    }

    ie_dismiss_provider_profile_progress( $user_id );

    wp_send_json_success( [ 'message' => ie__( 'Profile completion notice dismissed.' ) ] );
}
add_action( 'wp_ajax_ie_dismiss_profile_progress', 'ie_ajax_dismiss_profile_progress' );

function ie_ajax_update_provider_services() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Not logged in.' ) ] );
    }

    $pid = intval( $_POST['provider_id'] ?? 0 );
    $post = get_post( $pid );
    if ( ! $post || $post->post_author != get_current_user_id() ) {
        wp_send_json_error( [ 'message' => ie__( 'Permission denied.' ) ] );
    }

    ie_ensure_provider_slug( $pid );

    $services_json = wp_unslash( $_POST['services'] ?? '[]' );
    $services      = json_decode( $services_json, true );
    if ( ! is_array( $services ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Invalid services data.' ) ] );
    }

    $upload_map = [];
    if ( ! empty( $_FILES['service_images']['name'] ) && is_array( $_FILES['service_images']['name'] ) ) {
        foreach ( $_FILES['service_images']['name'] as $index => $filename ) {
            if (
                empty( $filename )
                || (int) ( $_FILES['service_images']['error'][ $index ] ?? UPLOAD_ERR_NO_FILE ) !== UPLOAD_ERR_OK
            ) {
                continue;
            }

            $uploaded = ie_upload_provider_work_gallery_file(
                $pid,
                [
                    'name'     => $_FILES['service_images']['name'][ $index ],
                    'type'     => $_FILES['service_images']['type'][ $index ],
                    'tmp_name' => $_FILES['service_images']['tmp_name'][ $index ],
                    'error'    => $_FILES['service_images']['error'][ $index ],
                    'size'     => $_FILES['service_images']['size'][ $index ],
                ]
            );

            if ( is_wp_error( $uploaded ) ) {
                wp_send_json_error( [ 'message' => $uploaded->get_error_message() ] );
            }

            $upload_map[ (int) $index ] = (int) $uploaded;
        }
    }

    $clean = [];
    foreach ( $services as $service ) {
        $name = sanitize_text_field( $service['name'] ?? '' );
        if ( $name === '' ) {
            continue;
        }

        $index    = (int) ( $service['index'] ?? -1 );
        $image_id = (int) ( $service['image_id'] ?? 0 );

        if ( isset( $upload_map[ $index ] ) ) {
            $image_id = (int) $upload_map[ $index ];
        } elseif ( $image_id && ! ie_user_can_manage_provider_gallery_attachment( $image_id, $pid ) ) {
            $image_id = 0;
        }

        $clean[] = [
            'name'          => $name,
            'price'         => sanitize_text_field( $service['price'] ?? '' ),
            'unit'          => sanitize_text_field( $service['unit'] ?? '' ),
            'image_id'      => $image_id,
            'show_publicly' => ! empty( $service['show_publicly'] ),
        ];
    }

    update_post_meta( $pid, '_ie_services', wp_json_encode( $clean ) );
    wp_send_json_success(
        [
            'message'  => ie__( 'Services updated successfully!' ),
            'services' => ie_get_provider_services_for_editor( $pid ),
        ]
    );
}
add_action( 'wp_ajax_ie_update_provider_services', 'ie_ajax_update_provider_services' );

function ie_ajax_get_provider_conversations() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $provider_post = ie_get_provider_post_by_user();
    if ( ! $provider_post ) {
        wp_send_json_success( [
            'conversations' => [],
            'count'         => 0,
        ] );
    }

    $conversations = ie_get_provider_inbox_conversations( $provider_post->ID );
    wp_send_json_success( [
        'conversations' => $conversations,
        'count'         => count( $conversations ),
        'unread'        => ie_get_provider_unread_message_count( $provider_post->ID ),
    ] );
}
add_action( 'wp_ajax_ie_get_provider_conversations', 'ie_ajax_get_provider_conversations' );

function ie_ajax_get_provider_customer_thread() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $customer_id = sanitize_text_field( $_POST['customer_id'] ?? '' );
    $customer_id_int = (int) $customer_id;

    $provider_post = ie_get_provider_post_by_user();
    if ( ! $provider_post ) {
        wp_send_json_error( [ 'message' => ie__( 'Provider profile not found.' ) ] );
    }

    $customer = get_userdata( $customer_id_int );
    if ( ! $customer || ie_get_user_type( $customer_id_int ) !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Customer not found.' ) ] );
    }

    ie_mark_provider_inbox_read( $provider_post->ID, $customer_id_int );

    $avatar_url = ie_get_user_profile_image_url( $customer_id_int, 'thumbnail' );
    wp_send_json_success( [
        'customer' => [
            'id'     => $customer_id_int,
            'name'   => $customer->display_name,
            'avatar' => $avatar_url ?: ie_get_provider_avatar_url( $customer->display_name ),
        ],
        'messages' => ie_get_provider_customer_thread_messages( $provider_post->ID, $customer_id_int ),
    ] );
}
add_action( 'wp_ajax_ie_get_provider_customer_thread', 'ie_ajax_get_provider_customer_thread' );

function ie_ajax_send_provider_chat_message() {
    check_ajax_referer( 'ie_nonce', 'nonce' );
    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $customer_id = (int) ( $_POST['customer_id'] ?? 0 );
    $message     = sanitize_textarea_field( $_POST['message'] ?? '' );
    $attachment_id = 0;

    if ( ! empty( $_FILES['chat_attachment']['name'] ) ) {
        $upload = ie_handle_chat_attachment_upload( 'chat_attachment' );
        if ( is_wp_error( $upload ) ) {
            wp_send_json_error( [ 'message' => $upload->get_error_message() ] );
        }
        $attachment_id = (int) $upload;
    }

    if ( ! $customer_id || ( ! $message && ! $attachment_id ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Please write a message or choose a file.' ) ] );
    }

    $provider_post = ie_get_provider_post_by_user();
    if ( ! $provider_post ) {
        wp_send_json_error( [ 'message' => ie__( 'Provider profile not found.' ) ] );
    }

    $customer = get_userdata( $customer_id );
    if ( ! $customer || ie_get_user_type( $customer_id ) !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Customer not found.' ) ] );
    }

    $message_id = ie_save_provider_reply_message( $customer_id, $provider_post->ID, $message, $attachment_id );
    if ( ! $message_id ) {
        wp_send_json_error( [ 'message' => ie__( 'Failed to send message. Please try again.' ) ] );
    }

    $saved = get_post( $message_id );
    $row   = $saved ? ie_format_chat_message_row( $saved ) : null;

    wp_send_json_success( [
        'message' => ie__( 'Message sent!' ),
        'chat'    => $row ?: [
            'id'     => $message_id,
            'body'   => $message,
            'sender' => 'provider',
            'time'   => current_time( 'mysql' ),
        ],
    ] );
}
add_action( 'wp_ajax_ie_send_provider_chat_message', 'ie_ajax_send_provider_chat_message' );

/* === PAGE TEMPLATE LOADER === */
function ie_get_theme_pages_config() {
    return [
        'home' => [
            'title'    => ie__( 'Home' ),
            'slug'     => 'home',
            'template' => 'home.php',
            'is_front' => true,
        ],
        'browse' => [
            'title'    => ie__( 'Browse' ),
            'slug'     => 'browse',
            'template' => 'browse.php',
        ],
        'price' => [
            'title'    => ie__( 'Price' ),
            'slug'     => 'price',
            'template' => 'price.php',
        ],
        'account' => [
            'title'    => ie__( 'Account' ),
            'slug'     => 'account',
            'template' => 'account.php',
        ],
        'client-profile' => [
            'title'    => ie__( 'My Profile' ),
            'slug'     => 'client-profile',
            'template' => 'client-profile.php',
        ],
        'provider-profile' => [
            'title'    => ie__( 'Provider Dashboard' ),
            'slug'     => 'provider-profile',
            'template' => 'provider-profile.php',
        ],
        'faq' => [
            'title'    => ie__( 'FAQ' ),
            'slug'     => 'faq',
            'template' => 'faq.php',
        ],
        'contact' => [
            'title'    => ie__( 'Contact Us' ),
            'slug'     => 'contact',
            'template' => 'contact.php',
        ],
        'terms' => [
            'title'    => ie__( 'Terms & Conditions' ),
            'slug'     => 'terms-and-conditions',
            'template' => 'terms.php',
        ],
        'privacy' => [
            'title'    => ie__( 'Privacy Policy' ),
            'slug'     => 'privacy-policy',
            'template' => 'privacy.php',
        ],
        'service-provider' => [
            'title'    => ie__( 'Service Provider' ),
            'slug'     => 'service-provider',
            'template' => 'service-provider-single.php',
        ],
    ];
}

function ie_get_theme_page_url( $key ) {
    $pages = ie_get_theme_pages_config();
    if ( ! isset( $pages[ $key ] ) ) {
        return home_url( '/' );
    }

    if ( ! empty( $pages[ $key ]['is_front'] ) ) {
        $front_id = (int) get_option( 'page_on_front' );
        if ( $front_id ) {
            return get_permalink( $front_id );
        }
    }

    $page = get_page_by_path( $pages[ $key ]['slug'] );
    if ( $page ) {
        return get_permalink( $page );
    }

    return home_url( '/' . $pages[ $key ]['slug'] . '/' );
}

function ie_get_provider_register_url() {
    return add_query_arg(
        [
            'mode' => 'register',
            'type' => 'provider',
        ],
        ie_get_theme_page_url( 'account' )
    );
}

function ie_get_header_nav_items() {
    return [
        ie__( 'Home' )    => ie_get_theme_page_url( 'home' ),
        ie__( 'Browse' )  => ie_get_theme_page_url( 'browse' ),
        ie__( 'Pricing' ) => ie_get_theme_page_url( 'price' ),
    ];
}

function ie_render_header_user_menu( $context = 'desktop' ) {
    $user          = wp_get_current_user();
    $profile_url   = ie_get_user_profile_url();
    $messages_url  = ie_get_user_messages_url();
    $avatar_url    = ie_get_user_profile_image_url( $user->ID, 'thumbnail' );
    $initial       = strtoupper( substr( $user->display_name ?: $user->user_email, 0, 1 ) );
    $user_type     = ie_get_user_type( $user->ID );
    $show_messages = in_array( $user_type, [ 'customer', 'provider' ], true );
    $unread_count  = $show_messages ? ie_get_current_user_unread_message_count( $user->ID ) : 0;
    $show_header_unread = $unread_count > 0 && ! ie_is_user_dashboard_page();
    $suffix        = ( $context === 'mobile' ) ? 'mobile' : 'desktop';
    $menu_id       = 'header-user-menu-' . $suffix;
    $toggle_id     = 'header-user-menu-toggle-' . $suffix;
    $logout_id     = 'header-btn-logout-' . $suffix;
    ?>
    <div class="header-user-menu" id="<?php echo esc_attr( $menu_id ); ?>" data-context="<?php echo esc_attr( $context ); ?>">
        <button
            type="button"
            class="header-user-menu__toggle<?php echo $show_header_unread ? ' has-unread' : ''; ?>"
            id="<?php echo esc_attr( $toggle_id ); ?>"
            aria-expanded="false"
            aria-haspopup="true"
            aria-controls="<?php echo esc_attr( $menu_id ); ?>-dropdown"
            aria-label="<?php echo esc_attr( $show_header_unread ? sprintf( ie__( 'Account menu, %d new messages' ), $unread_count ) : ie__( 'Account menu' ) ); ?>"
        >
            <?php if ( ie_get_user_profile_image_id( $user->ID ) ) : ?>
                <img src="<?php echo esc_url( $avatar_url ); ?>" alt="<?php echo esc_attr( $user->display_name ); ?>" class="header-user-menu__avatar">
            <?php else : ?>
                <span class="header-user-menu__avatar header-user-menu__avatar--letter" aria-hidden="true"><?php echo esc_html( $initial ); ?></span>
            <?php endif; ?>
            <?php if ( $show_messages ) : ?>
                <span class="header-user-menu__notify-badge" data-header-notify-badge<?php echo $show_header_unread ? '' : ' hidden'; ?>><?php echo esc_html( $unread_count > 99 ? '99+' : (string) $unread_count ); ?></span>
            <?php endif; ?>
        </button>

        <div class="header-user-menu__dropdown" id="<?php echo esc_attr( $menu_id ); ?>-dropdown">
            <div class="header-user-menu__profile">
                <?php if ( ie_get_user_profile_image_id( $user->ID ) ) : ?>
                    <img src="<?php echo esc_url( $avatar_url ); ?>" alt="" class="header-user-menu__profile-avatar">
                <?php else : ?>
                    <span class="header-user-menu__profile-avatar header-user-menu__profile-avatar--letter" aria-hidden="true"><?php echo esc_html( $initial ); ?></span>
                <?php endif; ?>
                <div class="header-user-menu__profile-text">
                    <strong class="header-user-menu__name"><?php echo esc_html( $user->display_name ); ?></strong>
                    <span class="header-user-menu__email"><?php echo esc_html( $user->user_email ); ?></span>
                </div>
            </div>

            <nav class="header-user-menu__nav" aria-label="<?php echo esc_attr( ie__( 'Account menu' ) ); ?>">
                <a href="<?php echo esc_url( $profile_url ); ?>" class="header-user-menu__link">
                    <span class="header-user-menu__link-label">
                        <i class="fa-regular fa-user" aria-hidden="true"></i>
                        <?php echo esc_html( ie__( 'Profile' ) ); ?>
                    </span>
                </a>
                <?php if ( $show_messages ) : ?>
                    <a href="<?php echo esc_url( $messages_url ); ?>" class="header-user-menu__link header-user-menu__link--messages">
                        <span class="header-user-menu__link-label">
                            <i class="fa-regular fa-envelope" aria-hidden="true"></i>
                            <?php echo esc_html( ie__( 'Messages' ) ); ?>
                        </span>
                        <span class="header-user-menu__link-badge" data-header-notify-badge<?php echo $show_header_unread ? '' : ' hidden'; ?>><?php echo esc_html( $unread_count > 99 ? '99+' : (string) $unread_count ); ?></span>
                    </a>
                <?php endif; ?>
                <button type="button" class="header-user-menu__link header-user-menu__logout" id="<?php echo esc_attr( $logout_id ); ?>" data-ie-logout data-logout-home="<?php echo esc_url( ie_get_theme_page_url( 'home' ) ); ?>">
                    <span class="header-user-menu__link-label">
                        <i class="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i>
                        <?php echo esc_html( ie__( 'Log out' ) ); ?>
                    </span>
                </button>
            </nav>
        </div>
    </div>
    <?php
}

function ie_render_header_auth_actions( $context = 'desktop' ) {
    $account_url  = ie_get_theme_page_url( 'account' );
    $is_account   = is_page( 'account' );
    $is_register  = $is_account && sanitize_text_field( $_GET['mode'] ?? '' ) === 'register';
    $login_class  = 'btn-header-login' . ( $is_account && ! $is_register ? ' active' : '' );
    $register_class = 'btn-header-register' . ( $is_register ? ' active' : '' );

    if ( is_user_logged_in() ) {
        ie_render_header_user_menu( $context );
        return;
    }
    ?>
    <a href="<?php echo esc_url( $account_url ); ?>" class="<?php echo esc_attr( $login_class ); ?>">
        <?php echo esc_html( ie__( 'Log in' ) ); ?>
    </a>
    <a href="<?php echo esc_url( add_query_arg( 'mode', 'register', $account_url ) ); ?>" class="<?php echo esc_attr( $register_class ); ?>">
        <?php echo esc_html( ie__( 'Get Started' ) ); ?>
    </a>
    <?php
}

function ie_is_header_nav_active( $label ) {
    if ( $label === ie__( 'Home' ) && is_front_page() ) {
        return true;
    }
    if ( $label === ie__( 'Browse' ) && is_page( 'browse' ) ) {
        return true;
    }
    if ( $label === ie__( 'Pricing' ) && is_page( 'price' ) ) {
        return true;
    }

    return false;
}

function ie_normalize_page_template_slug( $template ) {
    if ( ! $template || $template === 'default' ) {
        return '';
    }

    return basename( str_replace( '\\', '/', (string) $template ) );
}

function ie_get_page_template_slug_map() {
    return [
        'home'                   => 'home.php',
        'browse'                 => 'browse.php',
        'price'                  => 'price.php',
        'account'                => 'account.php',
        'client-profile'         => 'client-profile.php',
        'provider-profile'       => 'provider-profile.php',
        'faq'                    => 'faq.php',
        'contact'                => 'contact.php',
        'terms-and-conditions'   => 'terms.php',
        'privacy-policy'         => 'privacy.php',
        'service-provider'       => 'service-provider-single.php',
    ];
}

function ie_get_effective_page_template( $post_id ) {
    $template = get_post_meta( $post_id, '_wp_page_template', true );

    if ( isset( $_POST['page_template'] ) ) {
        $posted = sanitize_text_field( wp_unslash( $_POST['page_template'] ) );
        if ( $posted && $posted !== 'default' ) {
            $template = $posted;
        }
    }

    $template = ie_normalize_page_template_slug( $template );

    if ( ! $template ) {
        $slug = get_post_field( 'post_name', $post_id );
        $map  = ie_get_page_template_slug_map();
        if ( isset( $map[ $slug ] ) ) {
            $template = $map[ $slug ];
        }
    }

    return $template;
}

function ie_page_uses_template( $post_id, $template_file ) {
    return ie_get_effective_page_template( $post_id ) === ie_normalize_page_template_slug( $template_file );
}

function ie_register_theme_page_templates( $templates ) {
    $dir = get_template_directory() . '/templates/';
    if ( ! is_dir( $dir ) ) {
        return $templates;
    }

    foreach ( glob( $dir . '*.php' ) as $file ) {
        $headers = get_file_data( $file, [ 'Template Name' => 'Template Name' ] );
        if ( empty( $headers['Template Name'] ) ) {
            continue;
        }

        $templates[ 'templates/' . basename( $file ) ] = $headers['Template Name'];
    }

    return $templates;
}
add_filter( 'theme_page_templates', 'ie_register_theme_page_templates' );

function ie_load_page_templates( $template ) {
    if ( ! is_page() ) {
        return $template;
    }

    $slug_map = ie_get_page_template_slug_map();

    $tpl = get_post_meta( get_the_ID(), '_wp_page_template', true );
    if ( ! $tpl || $tpl === 'default' ) {
        $slug = get_post_field( 'post_name', get_the_ID() );
        if ( isset( $slug_map[ $slug ] ) ) {
            $tpl = $slug_map[ $slug ];
        }
    }

    $tpl = ie_normalize_page_template_slug( $tpl );
    if ( $tpl ) {
        $path = get_template_directory() . '/templates/' . $tpl;
        if ( file_exists( $path ) ) {
            return $path;
        }
    }

    return $template;
}
add_filter( 'template_include', 'ie_load_page_templates' );

function ie_redirect_legacy_provider_single() {
    if ( ! is_singular( 'ie_provider' ) ) {
        return;
    }

    $slug = get_post_field( 'post_name', get_queried_object_id() );
    if ( ! $slug ) {
        $slug = ie_ensure_provider_slug( get_queried_object_id() );
    }
    if ( $slug ) {
        wp_safe_redirect( ie_get_provider_single_url( $slug, get_queried_object_id() ), 301 );
        exit;
    }
}
add_action( 'template_redirect', 'ie_redirect_legacy_provider_single', 5 );

function ie_redirect_legacy_bookings_page() {
    if ( is_page( 'bookings' ) ) {
        wp_safe_redirect( ie_get_theme_page_url( 'account' ), 301 );
        exit;
    }
}
add_action( 'template_redirect', 'ie_redirect_legacy_bookings_page', 5 );

function ie_redirect_legacy_list_business_page() {
    if ( is_page( 'list-business' ) ) {
        wp_safe_redirect( ie_get_theme_page_url( 'price' ), 301 );
        exit;
    }
}
add_action( 'template_redirect', 'ie_redirect_legacy_list_business_page', 5 );

function ie_admin_fix_user_roles() {
    if ( ! isset( $_GET['ie_fix_roles'] ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $uid  = intval( $_GET['uid'] ?? 0 );
    $type = sanitize_text_field( $_GET['type'] ?? 'customer' );
    if ( $uid && in_array( $type, [ 'customer', 'provider' ], true ) ) {
        update_user_meta( $uid, '_ie_user_type', $type );
        wp_die(
            sprintf(
                ie__( 'Done! User %1$d set as %2$s.' ),
                $uid,
                $type
            ) . ' <a href="' . esc_url( admin_url( 'users.php' ) ) . '">' . esc_html( ie__( 'Back to Users' ) ) . '</a>'
        );
    }
    wp_die( esc_html( ie__( 'Invalid params.' ) ) );
}
add_action( 'init', 'ie_admin_fix_user_roles' );

function ie_theme_activate() {
    ie_ensure_theme_pages( true );
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'ie_theme_activate' );

function ie_ensure_theme_pages( $create_menu = false ) {
    $page_ids = [];
    $front_id = 0;

    foreach ( ie_get_theme_pages_config() as $key => $pg ) {
        $existing = get_page_by_path( $pg['slug'] );
        if ( $existing ) {
            $id = $existing->ID;
        } else {
            $id = wp_insert_post( [
                'post_title'   => $pg['title'],
                'post_name'    => $pg['slug'],
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_content' => '',
            ] );
            if ( is_wp_error( $id ) ) {
                continue;
            }
        }

        $page_ids[ $key ] = $id;

        if ( ! ie_page_uses_template( $id, $pg['template'] ) ) {
            update_post_meta( $id, '_wp_page_template', 'templates/' . $pg['template'] );
        }

        if ( $key === 'faq' ) {
            ie_seed_faq_page_defaults( $id );
        }

        if ( $key === 'contact' ) {
            ie_seed_contact_page_defaults( $id );
        }

        if ( $key === 'browse' ) {
            ie_seed_browse_page_defaults( $id );
        }

        if ( $key === 'price' ) {
            ie_seed_price_page_defaults( $id );
        }

        if ( $key === 'terms' ) {
            ie_seed_terms_page_defaults( $id );
        }

        if ( $key === 'privacy' ) {
            ie_seed_privacy_page_defaults( $id );
        }

        if ( $key === 'home' ) {
            ie_seed_home_page_defaults( $id );
        }

        if ( ! empty( $pg['is_front'] ) ) {
            $front_id = $id;
        }
    }

    ie_seed_provider_categories();

    if ( $front_id ) {
        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', $front_id );
    }

    if ( $create_menu ) {
        $mn = ie__( 'Primary Menu' );
        if ( ! wp_get_nav_menu_object( $mn ) ) {
            $mid = wp_create_nav_menu( $mn );
            $i   = 0;
            foreach ( ie_get_theme_pages_config() as $key => $pg ) {
                if ( ! isset( $page_ids[ $key ] ) ) {
                    continue;
                }
                wp_update_nav_menu_item( $mid, 0, [
                    'menu-item-title'     => $pg['title'],
                    'menu-item-object'    => 'page',
                    'menu-item-type'      => 'post_type',
                    'menu-item-object-id' => $page_ids[ $key ],
                    'menu-item-status'    => 'publish',
                    'menu-item-position'  => ++$i,
                ] );
            }
            $locs           = get_theme_mod( 'nav_menu_locations', [] );
            $locs['primary'] = $mid;
            set_theme_mod( 'nav_menu_locations', $locs );
        }
    }

    if ( ! get_option( 'ie_theme_pages_ready_v3' ) ) {
        flush_rewrite_rules( false );
        update_option( 'ie_theme_pages_ready_v3', 1 );
    }
}
add_action( 'init', 'ie_ensure_theme_pages', 15 );

function ie_flush_rewrite_rules_on_switch() {
    flush_rewrite_rules();
}
add_action( 'switch_theme', 'ie_flush_rewrite_rules_on_switch' );

function ie_maybe_hide_admin_bar() {
    if ( ! current_user_can( 'manage_options' ) ) {
        show_admin_bar( false );
    }
}
add_action( 'after_setup_theme', 'ie_maybe_hide_admin_bar' );

/* === AJAX: CONTACT FORM === */
function ie_ajax_contact_form() {
    check_ajax_referer('ie_nonce','nonce');
    $name    = sanitize_text_field($_POST['name']    ?? '');
    $email   = sanitize_email($_POST['email']        ?? '');
    $phone   = sanitize_text_field($_POST['phone']   ?? '');
    $subject = sanitize_text_field($_POST['subject'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');

    if (!$name || !$email || !$subject || !$message)
        wp_send_json_error(['message' => ie__( 'Please fill in all required fields.' )]);

    wp_mail(
        'islandexperts758@gmail.com',
        sprintf( ie__( 'Contact Form: %s' ), $subject ),
        "Name:    {$name}\nEmail:   {$email}\nPhone:   {$phone}\nSubject: {$subject}\n\nMessage:\n{$message}"
    );
    wp_send_json_success(['message' => ie__( 'Message sent!' )]);
}
add_action('wp_ajax_ie_contact_form',        'ie_ajax_contact_form');
add_action('wp_ajax_nopriv_ie_contact_form', 'ie_ajax_contact_form');