<?php
/**
 * Template Name: Service Provider Single
 */
get_header();

$slug     = ie_get_requested_provider_slug();
$provider = ie_resolve_provider_for_single( $slug );

if ( ! $provider ) {
    ?>
    <section class="sp-single-page">
        <div class="container sp-single-wrap">
            <div class="sp-not-found">
                <h1><?php echo esc_html( ie__( 'Provider not found' ) ); ?></h1>
                <p><?php echo esc_html( ie__( 'This service provider profile could not be found.' ) ); ?></p>
                <a href="<?php echo esc_url( ie_get_theme_page_url( 'browse' ) ); ?>" class="btn-featured-profile"><?php echo esc_html( ie__( 'Browse Providers' ) ); ?></a>
            </div>
        </div>
    </section>
    <?php
    get_footer();
    return;
}

$cat_slug           = preg_replace( '/[^a-z0-9-]/', '', strtolower( $provider['category_slug'] ?? '' ) );
$placeholder        = ie_get_service_banner_placeholder_uri();
$has_service_banner = ! empty( $provider['has_service_banner'] ) || ie_provider_has_service_banner( (int) ( $provider['id'] ?? 0 ) );
$hero_image         = $has_service_banner
    ? ie_get_provider_uploaded_service_image_url( (int) ( $provider['id'] ?? 0 ), 'large' )
    : $placeholder;
?>

<section class="sp-single-page">
    <div class="container sp-single-wrap">
        <a href="<?php echo esc_url( home_url( '/#top-providers' ) ); ?>" class="sp-back-link">
            <i class="fa-solid fa-arrow-left" aria-hidden="true"></i>
            <?php echo esc_html( ie__( 'Back' ) ); ?>
        </a>

        <div class="sp-hero-card">
            <div class="sp-hero-image<?php echo $has_service_banner ? '' : ' is-placeholder'; ?>">
                <img src="<?php echo esc_url( $hero_image ); ?>"
                     alt="<?php echo $has_service_banner ? esc_attr( $provider['title'] ) : ''; ?>"
                     onerror="this.onerror=null;this.src='<?php echo esc_url( $placeholder ); ?>';">
            </div>

            <div class="sp-hero-body">
                <div class="sp-profile-row">
                    <img class="sp-avatar"
                         src="<?php echo esc_url( $provider['profile_image'] ); ?>"
                         alt="<?php echo esc_attr( $provider['title'] ); ?>"
                         onerror="this.onerror=null;this.src='<?php echo esc_url( ie_get_provider_avatar_url( $provider['title'] ) ); ?>';">
                    <div class="sp-title-block">
                        <div class="sp-title-row">
                            <h1><?php echo esc_html( $provider['title'] ); ?></h1>
                            <?php if ( ! empty( $provider['verified'] ) ) : ?>
                                <span class="sp-verified"><i class="fa-solid fa-circle-check" aria-hidden="true"></i> <?php echo esc_html( ie__( 'Verified' ) ); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="sp-rating">
                            <i class="fa-solid fa-star" aria-hidden="true"></i>
                            <strong><?php echo esc_html( $provider['rating'] ); ?></strong>
                            <span>(<?php echo esc_html( $provider['reviews'] ); ?> <?php echo esc_html( ie__( 'reviews' ) ); ?>)</span>
                        </div>
                        <div class="sp-tags">
                            <?php
                            $service_slug = preg_replace( '/[^a-z0-9-]/', '', strtolower( $provider['service_name_slug'] ?? $provider['category_slug'] ?? '' ) );
                            if ( ! empty( $provider['service_name'] ) ) :
                                ?>
                                <span class="tag tag-<?php echo esc_attr( $service_slug ); ?>"><?php echo esc_html( $provider['service_name'] ); ?></span>
                            <?php elseif ( ! empty( $provider['category'] ) ) : ?>
                                <span class="tag tag-<?php echo esc_attr( $cat_slug ); ?>"><?php echo esc_html( $provider['category'] ); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="sp-meta-grid">
                    <?php if ( ! empty( $provider['location'] ) ) : ?>
                        <div class="sp-meta-item">
                            <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                            <?php echo esc_html( $provider['location'] ); ?>
                        </div>
                    <?php endif; ?>
                    <?php if ( ! empty( $provider['experience'] ) && $provider['experience'] !== '0' ) : ?>
                        <div class="sp-meta-item">
                            <i class="fa-solid fa-clock" aria-hidden="true"></i>
                            <?php echo esc_html( $provider['experience'] ); ?> <?php echo esc_html( ie__( 'years experience' ) ); ?>
                        </div>
                    <?php endif; ?>
                    <?php if ( ! empty( $provider['price'] ) && $provider['price'] !== '0' ) : ?>
                        <div class="sp-meta-item sp-price">
                            <i class="fa-solid fa-tag" aria-hidden="true"></i>
                            <?php echo esc_html( ie__( 'From' ) ); ?> <strong>$<?php echo esc_html( $provider['price'] ); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="sp-contact-inline" id="sp-contact">
                    <a href="<?php echo esc_url( ie_get_provider_chat_url( (int) $provider['id'], $provider['slug'] ?? '' ) ); ?>" class="btn-featured-chat sp-contact-chat">
                        <i class="fa-regular fa-comment-dots" aria-hidden="true"></i>
                        <?php echo esc_html( ie__( 'Chat' ) ); ?>
                    </a>

                    <?php if ( ! empty( $provider['phone'] ) ) : ?>
                        <a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $provider['phone'] ) ); ?>" class="sp-contact-link">
                            <i class="fa-solid fa-phone" aria-hidden="true"></i>
                            <?php echo esc_html( $provider['phone'] ); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ( ! empty( $provider['email'] ) ) : ?>
                        <a href="mailto:<?php echo esc_attr( $provider['email'] ); ?>" class="sp-contact-link">
                            <i class="fa-solid fa-envelope" aria-hidden="true"></i>
                            <?php echo esc_html( $provider['email'] ); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ( ! empty( $provider['social'] ) ) : ?>
                        <div class="sp-social-links">
                            <?php foreach ( $provider['social'] as $social ) :
                                if ( empty( $social['url'] ) ) {
                                    continue;
                                }
                                ?>
                                <a href="<?php echo esc_url( $social['url'] ); ?>" class="sp-social-btn" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $social['label'] ?? ie__( 'Social link' ) ); ?>">
                                    <i class="<?php echo esc_attr( $social['icon'] ?? 'fa-solid fa-link' ); ?>" aria-hidden="true"></i>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="sp-content-grid">
            <div class="sp-main">
                <?php if ( ! empty( $provider['about'] ) ) : ?>
                    <div class="sp-panel">
                        <h2><?php echo esc_html( ie__( 'About' ) ); ?></h2>
                        <p><?php echo esc_html( $provider['about'] ); ?></p>
                    </div>
                <?php endif; ?>

                <?php if ( ! empty( $provider['services'] ) ) : ?>
                    <div class="sp-panel">
                        <h2><?php echo esc_html( ie__( 'Services & Pricing' ) ); ?></h2>
                        <ul class="sp-services-list">
                            <?php foreach ( $provider['services'] as $svc ) : ?>
                                <li>
                                    <span><?php echo esc_html( $svc['name'] ); ?></span>
                                    <strong>$<?php echo esc_html( $svc['price'] ); ?> / <?php echo esc_html( $svc['unit'] ?? 'job' ); ?></strong>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ( ! empty( $provider['previous_work'] ) ) : ?>
                    <div class="sp-panel">
                        <h2><?php echo esc_html( ie__( 'Previous Work' ) ); ?></h2>
                        <div class="sp-work-gallery sp-previous-work-gallery">
                            <?php foreach ( $provider['previous_work'] as $image ) : ?>
                                <a href="<?php echo esc_url( $image['full'] ); ?>" class="sp-work-gallery-item" target="_blank" rel="noopener noreferrer">
                                    <img src="<?php echo esc_url( $image['url'] ); ?>" alt="<?php echo esc_attr( $provider['title'] ); ?>" loading="lazy">
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ( ! empty( $provider['reviews_list'] ) ) : ?>
                    <div class="sp-panel sp-reviews-panel">
                        <div class="sp-reviews-header">
                            <h2><?php echo esc_html( ie__( 'Reviews' ) ); ?></h2>
                            <span class="sp-reviews-count"><?php echo esc_html( $provider['reviews'] ); ?> <?php echo esc_html( ie__( 'total' ) ); ?></span>
                        </div>
                        <div class="sp-reviews-list">
                            <?php foreach ( $provider['reviews_list'] as $review ) :
                                $stars = str_repeat( '★', (int) $review['rating'] ) . str_repeat( '☆', 5 - (int) $review['rating'] );
                                $initial = strtoupper( substr( $review['author'], 0, 1 ) );
                            ?>
                                <article class="sp-review-item">
                                    <div class="sp-review-top">
                                        <div class="sp-review-avatar"><?php echo esc_html( $initial ); ?></div>
                                        <div class="sp-review-meta">
                                            <strong><?php echo esc_html( $review['author'] ); ?></strong>
                                            <div class="sp-review-stars">
                                                <span class="sp-stars" aria-hidden="true"><?php echo esc_html( $stars ); ?></span>
                                                <span class="sp-review-date"><?php echo esc_html( $review['date'] ); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <p><?php echo esc_html( $review['text'] ); ?></p>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
