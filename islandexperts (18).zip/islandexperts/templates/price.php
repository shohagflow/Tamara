<?php

/**

 * Template Name: Price

 */

get_header();



$price_data           = ie_get_price_page_data( ie_get_price_content_post_id() );

$yearly_discount_text = ie_get_subscription_yearly_discount_text();

?>



<div class="pricing-page-wrap">

    <div class="container">



        <?php ie_render_price_intro( $price_data['intro'] ); ?>



        <div class="pricing-billing-toggle" role="tablist" aria-label="<?php echo esc_attr( ie__( 'Billing period' ) ); ?>">

            <button type="button" class="pricing-billing-option is-active" data-billing="monthly" role="tab" aria-selected="true">

                <?php echo esc_html( ie__( 'Monthly' ) ); ?>

            </button>

            <button type="button" class="pricing-billing-option" data-billing="yearly" role="tab" aria-selected="false">

                <?php echo esc_html( ie__( 'Yearly' ) ); ?>

                <?php if ( $yearly_discount_text !== '' ) : ?>

                    <span class="pricing-save-badge"><?php echo esc_html( $yearly_discount_text ); ?></span>

                <?php endif; ?>

            </button>

        </div>



        <div class="pricing-grid subscription-cards">

            <?php ie_render_subscription_pricing_cards(); ?>

        </div>



    </div>

</div>



<div class="modal-overlay" id="paypal-modal">

    <div class="modal-box" style="max-width:420px;text-align:center">

        <div class="modal-header">

            <h3 class="modal-title"><?php echo esc_html( ie__( 'Complete Payment' ) ); ?></h3>

            <button type="button" class="modal-close" id="close-paypal-modal" aria-label="<?php echo esc_attr( ie__( 'Close' ) ); ?>">✕</button>

        </div>

        <div class="paypal-plan-summary">

            <div class="paypal-plan-name" id="paypal-plan-name"></div>

            <div class="paypal-plan-price" id="paypal-plan-price"></div>

        </div>

        <p style="font-size:0.875rem;color:var(--color-text-muted);margin-bottom:20px;">

            <?php echo esc_html( ie__( "You will be redirected to PayPal to complete your payment securely. After payment, you'll return here to complete your business profile." ) ); ?>

        </p>

        <a href="#" id="paypal-checkout-link" target="_self" class="btn-paypal" style="text-decoration:none;display:flex;">

            <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M7.5 5h9c.9 0 1.6.3 2.1.8.5.5.7 1.2.6 2.1-.4 2.7-2.4 4.1-5.5 4.1H12l-.8 5H8.3L9.8 5zm2.1 4.8h1.6c1.5 0 2.3-.7 2.5-2-.1-.5-.3-.8-.6-1-.3-.2-.7-.3-1.2-.3H10.7l-.5 2.3z"/></svg>

            <?php echo esc_html( ie__( 'Pay with PayPal' ) ); ?>

        </a>

        <p style="font-size:0.75rem;color:var(--color-text-muted);margin-top:12px;">

            <?php echo esc_html( ie__( 'Secure payment via PayPal' ) ); ?>

        </p>

    </div>

</div>



<script>

(function($) {

    var billingPeriod = 'monthly';



    function setBillingPeriod(period) {

        billingPeriod = period;

        $('.pricing-billing-option').each(function() {

            var isActive = $(this).data('billing') === period;

            $(this).toggleClass('is-active', isActive).attr('aria-selected', isActive ? 'true' : 'false');

        });

        $('.subscription-card').each(function() {

            var cardPeriod = $(this).data('billingPeriod');

            $(this).toggleClass('is-billing-active', cardPeriod === period);

        });

        $('.pricing-empty-message--monthly').prop('hidden', period !== 'monthly' || $('.subscription-card[data-billing-period="monthly"]').length > 0);

        $('.pricing-empty-message--yearly').prop('hidden', period !== 'yearly' || $('.subscription-card[data-billing-period="yearly"]').length > 0);

    }



    $('.pricing-billing-option').on('click', function() {

        setBillingPeriod($(this).data('billing'));

    });



    $(document).on('click', '.ie-choose-plan', function() {

        var $btn   = $(this);

        var plan   = $btn.data('plan');

        var price  = $btn.data('price');

        var planId = $btn.data('planId');

        var paypal = $btn.data('paypal');



        sessionStorage.setItem('ie_selected_plan', plan);

        sessionStorage.setItem('ie_selected_plan_id', planId);



        $('#paypal-plan-name').text(plan);

        $('#paypal-plan-price').text(price);



        var returnUrl = '<?php echo esc_url( ie_get_theme_page_url( 'price' ) ); ?>?payment=success'

            + '&plan=' + encodeURIComponent(plan)

            + '&plan_id=' + encodeURIComponent(planId);



        var paypalUrl = paypal && paypal !== '#'

            ? paypal + '&return=' + encodeURIComponent(returnUrl)

            : returnUrl;



        $('#paypal-checkout-link').attr('href', paypalUrl);

        $('#paypal-modal').addClass('open');

        $('body').css('overflow', 'hidden');

    });



    $('#close-paypal-modal').on('click', function() {

        $('#paypal-modal').removeClass('open');

        $('body').css('overflow', '');

    });



    $('#paypal-modal').on('click', function(e) {

        if ($(e.target).is('#paypal-modal')) {

            $('#paypal-modal').removeClass('open');

            $('body').css('overflow', '');

        }

    });



    var urlParams = new URLSearchParams(window.location.search);

    if (urlParams.get('payment') === 'success') {

        var plan   = sessionStorage.getItem('ie_selected_plan') || decodeURIComponent(urlParams.get('plan') || 'Basic Plan');

        var planId = sessionStorage.getItem('ie_selected_plan_id') || decodeURIComponent(urlParams.get('plan_id') || '');



        var expires = new Date(Date.now() + 3600000).toUTCString();

        document.cookie = 'ie_plan=' + encodeURIComponent(plan) + '; path=/; expires=' + expires;

        document.cookie = 'ie_plan_id=' + encodeURIComponent(planId) + '; path=/; expires=' + expires;



        sessionStorage.removeItem('ie_selected_plan');

        sessionStorage.removeItem('ie_selected_plan_id');



        window.location.href = '<?php echo esc_url( home_url( '/register-provider/' ) ); ?>?from_payment=1';

    }

})(jQuery);

</script>



<?php get_footer(); ?>

