<?php
/**
 * Template Name: Provider Profile
 */

if ( ! is_user_logged_in() ) {
    wp_safe_redirect( ie_get_theme_page_url( 'account' ) );
    exit;
}

if ( ie_get_user_type() !== 'provider' ) {
    wp_safe_redirect( ie_get_theme_page_url( 'client-profile' ) );
    exit;
}

$user              = wp_get_current_user();
$avatar            = strtoupper( substr( $user->display_name ?: $user->user_email, 0, 1 ) );
$profile_image_url = ie_get_user_profile_image_url( $user->ID, 'medium' );
$has_profile_image = ie_get_user_profile_image_id( $user->ID ) > 0;
$provider_post     = ie_get_provider_post_by_user( $user->ID );
$provider_id       = $provider_post ? $provider_post->ID : 0;
$provider_data     = $provider_id ? ie_get_provider_data( $provider_id ) : null;
$subscription      = ie_get_user_subscription( $user->ID );
$social_presets    = ie_get_theme_social_icon_presets();
$socials           = $provider_id ? ie_get_provider_socials( $provider_id ) : [];
if ( ! $socials ) {
    $socials = [ [ 'icon' => '', 'url' => '' ] ];
}
$work_gallery = $provider_id ? ie_get_provider_work_gallery( $provider_id, 'medium' ) : [];

$active_tab = sanitize_key( $_GET['tab'] ?? 'profile' );
$valid_tabs = [ 'profile', 'services', 'messages', 'subscription', 'settings' ];
if ( ! in_array( $active_tab, $valid_tabs, true ) ) {
    $active_tab = 'profile';
}

$conversations         = $provider_id ? ie_get_provider_inbox_conversations( $provider_id ) : [];
$active_conversation   = $conversations[0] ?? null;
$active_messages = [];
if ( $active_conversation && $provider_id ) {
    $active_messages = ie_get_provider_customer_thread_messages( $provider_id, (int) $active_conversation['id'] );
}

if ( $active_tab === 'messages' && $active_conversation && $provider_id ) {
    ie_mark_provider_inbox_read( $provider_id, (int) $active_conversation['id'] );
}

$unread_message_count = $provider_id ? ie_get_provider_unread_message_count( $provider_id ) : 0;

$services_raw = $provider_id ? get_post_meta( $provider_id, '_ie_services', true ) : '';
$services     = $services_raw ? json_decode( $services_raw, true ) : [];
if ( ! is_array( $services ) ) {
    $services = [];
}

$provider_cat_terms          = $provider_id ? get_the_terms( $provider_id, 'ie_category' ) : false;
$provider_category_slug      = ( $provider_cat_terms && ! is_wp_error( $provider_cat_terms ) ) ? $provider_cat_terms[0]->slug : '';
$service_placeholder_image   = ie_get_provider_service_placeholder_image( $provider_id );

$categories = get_terms( [
    'taxonomy'   => 'ie_category',
    'hide_empty' => false,
] );
if ( is_wp_error( $categories ) ) {
    $categories = [];
}

get_header();
?>

<div class="account-page-wrap client-profile-page provider-profile-page">
    <div class="container">

        <header class="client-profile-header">
            <div class="client-profile-header__text">
                <h1 class="client-profile-title"><?php echo esc_html( sprintf( ie__( 'Welcome back, %s' ), $user->first_name ?: $user->display_name ) ); ?></h1>
                <p class="client-profile-subtitle"><?php echo esc_html( ie__( 'Manage your business profile, services, messages, and subscription from one dashboard.' ) ); ?></p>
            </div>
        </header>

        <div class="dashboard-layout client-dashboard-layout">
            <aside class="dashboard-sidebar">
                <div class="dashboard-user-info">
                    <div class="dashboard-avatar<?php echo $has_profile_image ? ' has-image' : ''; ?>" id="sidebar-avatar">
                        <?php if ( $has_profile_image ) : ?>
                            <img src="<?php echo esc_url( $profile_image_url ); ?>" alt="<?php echo esc_attr( $user->display_name ); ?>" id="sidebar-avatar-img">
                        <?php else : ?>
                            <span id="sidebar-avatar-letter"><?php echo esc_html( $avatar ); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="dashboard-user-name"><?php echo esc_html( $user->display_name ); ?></div>
                    <div class="dashboard-user-email"><?php echo esc_html( $user->user_email ); ?></div>
                    <span class="client-profile-badge provider-profile-badge"><?php echo esc_html( ie__( 'Service Provider' ) ); ?></span>
                </div>

                <nav class="dashboard-nav" aria-label="<?php echo esc_attr( ie__( 'Provider navigation' ) ); ?>">
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'profile' ? ' active' : ''; ?>" data-panel="profile">
                        <span class="nav-icon"><i class="fa-regular fa-user" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Edit Profile' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'services' ? ' active' : ''; ?>" data-panel="services">
                        <span class="nav-icon"><i class="fa-solid fa-briefcase" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Manage Services' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'messages' ? ' active' : ''; ?><?php echo $unread_message_count > 0 ? ' has-unread' : ''; ?>" data-panel="messages">
                        <span class="nav-icon"><i class="fa-regular fa-envelope" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Messages' ) ); ?>
                        <span class="dashboard-nav-badge" id="dashboard-nav-message-count"<?php echo $unread_message_count > 0 ? '' : ' hidden'; ?>><?php echo esc_html( $unread_message_count > 99 ? '99+' : (string) $unread_message_count ); ?></span>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'subscription' ? ' active' : ''; ?>" data-panel="subscription">
                        <span class="nav-icon"><i class="fa-solid fa-credit-card" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Subscription Management' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'settings' ? ' active' : ''; ?>" data-panel="settings">
                        <span class="nav-icon"><i class="fa-solid fa-gear" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Account Settings' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item logout-btn" id="btn-logout" data-ie-logout data-logout-home="<?php echo esc_url( ie_get_theme_page_url( 'home' ) ); ?>">
                        <span class="nav-icon"><i class="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Log Out' ) ); ?>
                    </button>
                </nav>
            </aside>

            <div class="dashboard-content client-dashboard-content">
                <!-- Edit Profile -->
                <div class="dashboard-panel<?php echo $active_tab === 'profile' ? ' active' : ''; ?>" id="panel-profile">
                    <div class="dashboard-panel-head dashboard-panel-head--with-notify">
                        <div class="dashboard-panel-head__text">
                            <h2 class="panel-title"><?php echo esc_html( ie__( 'Edit Profile' ) ); ?></h2>
                            <p class="panel-desc"><?php echo esc_html( ie__( 'Keep your personal and business profile information up to date.' ) ); ?></p>
                        </div>
                        <button
                            type="button"
                            class="profile-message-notify<?php echo $unread_message_count > 0 ? ' has-unread' : ''; ?>"
                            id="btn-profile-message-notify"
                            aria-label="<?php echo esc_attr( ie__( 'View messages' ) ); ?>"
                            title="<?php echo esc_attr( ie__( 'View messages' ) ); ?>"
                        >
                            <i class="fa-regular fa-envelope" aria-hidden="true"></i>
                            <span class="profile-message-notify__badge" id="profile-message-notify-count"<?php echo $unread_message_count > 0 ? '' : ' hidden'; ?>><?php echo esc_html( $unread_message_count > 99 ? '99+' : (string) $unread_message_count ); ?></span>
                        </button>
                    </div>

                    <?php if ( ! $provider_id ) : ?>
                        <div class="dashboard-panel-body">
                            <div class="provider-profile-notice">
                                <p><?php echo esc_html( ie__( 'Your business listing has not been created yet. Please contact support or complete provider registration.' ) ); ?></p>
                            </div>
                        </div>
                    <?php else : ?>
                        <?php ie_render_provider_profile_progress( $provider_id, $user->ID ); ?>
                        <div class="dashboard-panel-body">
                            <input type="hidden" id="provider-id" value="<?php echo esc_attr( $provider_id ); ?>">
                            <div class="profile-form-grid">
                                <div class="form-group full-width">
                                    <label class="form-label" for="profile-photo"><?php echo esc_html( ie__( 'Profile Photo' ) ); ?></label>
                                    <input type="file" id="profile-photo" class="form-control form-control-file" accept="image/jpeg,image/png,image/webp">
                                    <p class="form-hint"><?php echo esc_html( ie__( 'JPG, PNG or WEBP — max 5MB' ) ); ?></p>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="profile-firstname"><?php echo esc_html( ie__( 'First Name' ) ); ?></label>
                                    <input type="text" id="profile-firstname" class="form-control" value="<?php echo esc_attr( $user->first_name ); ?>" autocomplete="given-name">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="profile-lastname"><?php echo esc_html( ie__( 'Last Name' ) ); ?></label>
                                    <input type="text" id="profile-lastname" class="form-control" value="<?php echo esc_attr( $user->last_name ); ?>" autocomplete="family-name">
                                </div>
                                <div class="form-group full-width">
                                    <label class="form-label" for="profile-email"><?php echo esc_html( ie__( 'Email Address' ) ); ?></label>
                                    <input type="email" id="profile-email" class="form-control is-readonly" value="<?php echo esc_attr( $user->user_email ); ?>" disabled>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="biz-name"><?php echo esc_html( ie__( 'Service Name' ) ); ?></label>
                                    <input type="text" id="biz-name" class="form-control" value="<?php echo esc_attr( $provider_data['title'] ?? '' ); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="biz-exp"><?php echo esc_html( ie__( 'Years of Experience' ) ); ?></label>
                                    <input type="number" id="biz-exp" class="form-control" min="0" max="60" value="<?php echo esc_attr( get_post_meta( $provider_id, '_ie_experience_years', true ) ); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="biz-phone"><?php echo esc_html( ie__( 'Phone' ) ); ?></label>
                                    <input type="text" id="biz-phone" class="form-control" value="<?php echo esc_attr( get_post_meta( $provider_id, '_ie_phone', true ) ); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="biz-area"><?php echo esc_html( ie__( 'Service Area' ) ); ?></label>
                                    <input type="text" id="biz-area" class="form-control" value="<?php echo esc_attr( get_post_meta( $provider_id, '_ie_service_area', true ) ); ?>">
                                </div>
                                <div class="form-group full-width">
                                    <label class="form-label" for="biz-about"><?php echo esc_html( ie__( 'About Your Business' ) ); ?></label>
                                    <textarea id="biz-about" class="form-control" rows="4"><?php echo esc_textarea( get_post_meta( $provider_id, '_ie_about', true ) ?: ( $provider_post->post_content ?? '' ) ); ?></textarea>
                                </div>
                                <div class="form-group full-width provider-social-section">
                                    <div class="provider-social-head">
                                        <label class="form-label"><?php echo esc_html( ie__( 'Social Media Links' ) ); ?></label>
                                        <button type="button" class="btn-provider-add-service" id="btn-add-social-link">
                                            <i class="fa-solid fa-plus" aria-hidden="true"></i>
                                            <?php echo esc_html( ie__( 'Add Social Link' ) ); ?>
                                        </button>
                                    </div>
                                    <div class="provider-social-list" id="provider-social-list">
                                        <?php foreach ( $socials as $social ) : ?>
                                            <?php ie_render_provider_social_row( $social, $social_presets ); ?>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="form-group full-width provider-work-gallery-section">
                                    <div class="provider-social-head">
                                        <label class="form-label"><?php echo esc_html( ie__( 'Work Preview Images' ) ); ?></label>
                                        <button type="button" class="btn-provider-add-service" id="btn-add-work-images">
                                            <i class="fa-solid fa-plus" aria-hidden="true"></i>
                                            <?php echo esc_html( ie__( 'Add Images' ) ); ?>
                                        </button>
                                    </div>
                                    <input type="file" id="work-gallery-input" class="provider-work-gallery-input" accept="image/jpeg,image/png,image/webp" multiple hidden>
                                    <div class="provider-work-gallery" id="provider-work-gallery" data-max-images="<?php echo esc_attr( (string) ie_get_provider_work_gallery_max() ); ?>">
                                        <?php foreach ( $work_gallery as $image ) : ?>
                                            <div class="provider-work-gallery-item" data-id="<?php echo esc_attr( (string) $image['id'] ); ?>">
                                                <img src="<?php echo esc_url( $image['thumb'] ); ?>" alt="">
                                                <button type="button" class="provider-work-gallery-remove" aria-label="<?php echo esc_attr( ie__( 'Remove image' ) ); ?>">
                                                    <i class="fa-solid fa-trash-can" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <p class="form-hint"><?php echo esc_html( sprintf( ie__( 'Optional. Upload up to %d images for the Previous Work section on your public profile page.' ), ie_get_provider_work_gallery_max() ) ); ?></p>
                                </div>
                            </div>

                            <div class="form-error" id="profile-error"></div>
                        </div>

                        <div class="dashboard-panel-actions">
                            <button type="button" class="btn-save-profile" id="btn-save-provider-profile"><?php echo esc_html( ie__( 'Save Changes' ) ); ?></button>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Manage Services -->
                <div class="dashboard-panel<?php echo $active_tab === 'services' ? ' active' : ''; ?>" id="panel-services">
                    <div class="dashboard-panel-head">
                        <h2 class="panel-title"><?php echo esc_html( ie__( 'Manage Services' ) ); ?></h2>
                        <p class="panel-desc"><?php echo esc_html( ie__( 'Add the services you offer and set pricing for each.' ) ); ?></p>
                    </div>

                    <?php if ( ! $provider_id ) : ?>
                        <div class="dashboard-panel-body">
                            <div class="provider-profile-notice">
                                <p><?php echo esc_html( ie__( 'Create your business profile first to manage services.' ) ); ?></p>
                            </div>
                        </div>
                    <?php else : ?>
                        <div class="dashboard-panel-body">
                            <div class="provider-services-list" id="provider-services-list" data-placeholder-image="<?php echo esc_url( $service_placeholder_image ); ?>">
                                <?php if ( $services ) : ?>
                                    <?php foreach ( $services as $service ) : ?>
                                        <?php ie_render_provider_service_row( $service, $service_placeholder_image ); ?>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>

                            <button type="button" class="btn-provider-add-service" id="btn-add-service">
                                <i class="fa-solid fa-plus" aria-hidden="true"></i>
                                <?php echo esc_html( ie__( 'Add Service' ) ); ?>
                            </button>

                            <div class="form-error" id="services-error"></div>
                        </div>

                        <div class="dashboard-panel-actions">
                            <button type="button" class="btn-save-profile" id="btn-save-services"><?php echo esc_html( ie__( 'Save Services' ) ); ?></button>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Messages -->
                <div class="dashboard-panel dashboard-panel--messages<?php echo $active_tab === 'messages' ? ' active' : ''; ?>" id="panel-messages"<?php echo $active_conversation ? ' data-active-customer="' . esc_attr( $active_conversation['id'] ) . '"' : ''; ?>>
                    <div class="client-messages-layout">
                        <aside class="client-messages-sidebar">
                            <div class="client-messages-sidebar__head">
                                <h3 class="client-messages-sidebar__title"><?php echo esc_html( ie__( 'Customer Inquiries' ) ); ?></h3>
                                <span class="client-messages-count" id="provider-messages-count"><?php echo esc_html( count( $conversations ) ); ?></span>
                            </div>
                            <div class="client-messages-search">
                                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                                <input type="search" id="provider-messages-search" class="client-messages-search__input" placeholder="<?php echo esc_attr( ie__( 'Search chat...' ) ); ?>" autocomplete="off">
                            </div>
                            <div class="client-messages-list" id="provider-messages-conversation-list">
                                <?php if ( $conversations ) : ?>
                                    <?php foreach ( $conversations as $index => $conversation ) : ?>
                                        <button
                                            type="button"
                                            class="client-messages-item<?php echo ( $index === 0 ) ? ' is-active' : ''; ?>"
                                            data-customer-id="<?php echo esc_attr( $conversation['id'] ); ?>"
                                        >
                                            <img src="<?php echo esc_url( $conversation['avatar'] ); ?>" alt="<?php echo esc_attr( $conversation['name'] ); ?>" class="client-messages-item__avatar">
                                            <span class="client-messages-item__content">
                                                <span class="client-messages-item__top">
                                                    <strong class="client-messages-item__name"><?php echo esc_html( $conversation['name'] ); ?></strong>
                                                    <span class="client-messages-item__time" data-time="<?php echo esc_attr( $conversation['last_time'] ); ?>"></span>
                                                </span>
                                                <span class="client-messages-item__preview"><?php echo esc_html( $conversation['last_message'] ); ?></span>
                                            </span>
                                        </button>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <div class="client-messages-list__empty">
                                        <p><?php echo esc_html( ie__( 'No customer messages yet' ) ); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </aside>

                        <div class="client-messages-chat" id="provider-messages-chat-area">
                            <div class="client-messages-chat__active" id="provider-messages-chat-active">
                                <header class="client-messages-chat__head">
                                    <button type="button" class="client-messages-chat__back" id="btn-provider-messages-back" aria-label="<?php echo esc_attr( ie__( 'Back to conversations' ) ); ?>">
                                        <i class="fa-solid fa-arrow-left" aria-hidden="true"></i>
                                    </button>
                                    <div class="client-messages-chat__head-user">
                                        <?php if ( $active_conversation ) : ?>
                                            <img src="<?php echo esc_url( $active_conversation['avatar'] ); ?>" alt="<?php echo esc_attr( $active_conversation['name'] ); ?>" class="client-messages-chat__head-avatar" id="provider-chat-head-avatar">
                                            <div class="client-messages-chat__head-user-text">
                                                <strong class="client-messages-chat__head-name" id="provider-chat-head-name"><?php echo esc_html( $active_conversation['name'] ); ?></strong>
                                                <span class="client-messages-chat__head-role" id="provider-chat-head-role"><?php echo esc_html( ie__( 'Customer' ) ); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="client-messages-chat__head-menu" id="provider-chat-head-menu">
                                        <button type="button" class="client-messages-chat__head-link" id="btn-provider-chat-head-menu" aria-label="<?php echo esc_attr( ie__( 'Chat options' ) ); ?>" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa-solid fa-ellipsis-vertical" aria-hidden="true"></i>
                                        </button>
                                        <div class="client-messages-chat__head-dropdown" id="provider-chat-head-dropdown" hidden>
                                            <button type="button" class="client-messages-chat__head-dropdown-item client-messages-chat__head-dropdown-item--danger" id="btn-delete-provider-chat-conversation">
                                                <i class="fa-solid fa-trash" aria-hidden="true"></i>
                                                <span><?php echo esc_html( ie__( 'Delete user' ) ); ?></span>
                                            </button>
                                        </div>
                                    </div>
                                </header>

                                <div class="client-messages-chat__body" id="provider-messages-chat-body">
                                    <?php if ( $active_messages ) : ?>
                                        <?php foreach ( $active_messages as $message ) : ?>
                                            <div class="client-messages-bubble-wrap<?php echo ( $message['sender'] === 'provider' ) ? ' is-mine' : ''; ?>">
                                                <div class="client-messages-bubble"><?php echo ie_render_chat_message_bubble_inner( $message ); ?></div>
                                                <span class="client-messages-bubble__time" data-time="<?php echo esc_attr( $message['time'] ); ?>"></span>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else : ?>
                                        <div class="client-messages-chat__thread-empty">
                                            <p><?php echo esc_html( ie__( 'Reply to customer inquiries here.' ) ); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <footer class="client-messages-chat__composer">
                                    <div class="client-messages-chat__attachment-preview" id="provider-chat-attachment-preview" hidden></div>
                                    <button type="button" class="client-messages-chat__attach" id="btn-provider-chat-attach" aria-label="<?php echo esc_attr( ie__( 'Attach file' ) ); ?>">
                                        <i class="fa-solid fa-paperclip" aria-hidden="true"></i>
                                    </button>
                                    <input type="file" id="provider-chat-attachment-input" class="client-messages-chat__file-input" hidden accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.txt,.csv,.rtf">
                                    <div class="client-messages-chat__input-wrap">
                                        <input type="text" id="provider-chat-message-input" class="client-messages-chat__input" placeholder="<?php echo esc_attr( ie__( 'Write a message...' ) ); ?>" autocomplete="off">
                                        <button type="button" class="client-messages-chat__send" id="btn-provider-send-chat" aria-label="<?php echo esc_attr( ie__( 'Send message' ) ); ?>">
                                            <i class="fa-solid fa-paper-plane" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </footer>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Subscription -->
                <div class="dashboard-panel<?php echo $active_tab === 'subscription' ? ' active' : ''; ?>" id="panel-subscription">
                    <div class="dashboard-panel-head">
                        <h2 class="panel-title"><?php echo esc_html( ie__( 'Subscription Management' ) ); ?></h2>
                        <p class="panel-desc"><?php echo esc_html( ie__( 'View your current plan and upgrade options.' ) ); ?></p>
                    </div>

                    <div class="dashboard-panel-body">
                        <div class="provider-subscription-card<?php echo $subscription['is_active'] ? ' is-active' : ''; ?>">
                            <div class="provider-subscription-card__icon">
                                <i class="fa-solid fa-crown" aria-hidden="true"></i>
                            </div>
                            <div class="provider-subscription-card__content">
                                <span class="provider-subscription-card__label"><?php echo esc_html( ie__( 'Current Plan' ) ); ?></span>
                                <h3 class="provider-subscription-card__plan"><?php echo esc_html( $subscription['plan_label'] ); ?></h3>
                                <p class="provider-subscription-card__meta">
                                    <?php if ( $subscription['is_active'] ) : ?>
                                        <?php echo esc_html( sprintf( ie__( '%1$s billing · Status: %2$s' ), $subscription['billing_label'], $subscription['status_label'] ) ); ?>
                                    <?php else : ?>
                                        <?php echo esc_html( ie__( 'You are not subscribed yet. Choose a plan to unlock full provider features.' ) ); ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <div class="provider-subscription-card__actions">
                                <a href="<?php echo esc_url( ie_get_theme_page_url( 'price' ) ); ?>" class="btn-save-profile">
                                    <?php echo esc_html( $subscription['is_active'] ? ie__( 'Change Plan' ) : ie__( 'View Plans' ) ); ?>
                                </a>
                            </div>
                        </div>

                        <ul class="provider-subscription-features">
                            <li><i class="fa-solid fa-check" aria-hidden="true"></i> <?php echo esc_html( ie__( 'Public business profile on Island Experts' ) ); ?></li>
                            <li><i class="fa-solid fa-check" aria-hidden="true"></i> <?php echo esc_html( ie__( 'Customer messaging inbox' ) ); ?></li>
                            <li><i class="fa-solid fa-check" aria-hidden="true"></i> <?php echo esc_html( ie__( 'Service listing management' ) ); ?></li>
                        </ul>
                    </div>
                </div>

                <!-- Account Settings -->
                <div class="dashboard-panel<?php echo $active_tab === 'settings' ? ' active' : ''; ?>" id="panel-settings">
                    <div class="dashboard-panel-head">
                        <h2 class="panel-title"><?php echo esc_html( ie__( 'Account Settings' ) ); ?></h2>
                        <p class="panel-desc"><?php echo esc_html( ie__( 'Keep your account secure by updating your password regularly.' ) ); ?></p>
                    </div>

                    <div class="dashboard-panel-body">
                        <div class="client-settings-section">
                            <h3 class="client-settings-heading"><?php echo esc_html( ie__( 'Change Password' ) ); ?></h3>
                            <div class="form-group">
                                <label class="form-label" for="curr-password"><?php echo esc_html( ie__( 'Current Password' ) ); ?></label>
                                <div class="input-with-toggle">
                                    <input type="password" id="curr-password" class="form-control" autocomplete="current-password">
                                    <button class="password-toggle" type="button" data-target="curr-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                        <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="profile-form-grid">
                                <div class="form-group">
                                    <label class="form-label" for="new-password"><?php echo esc_html( ie__( 'New Password' ) ); ?></label>
                                    <div class="input-with-toggle">
                                        <input type="password" id="new-password" class="form-control" autocomplete="new-password">
                                        <button class="password-toggle" type="button" data-target="new-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="confirm-new-password"><?php echo esc_html( ie__( 'Confirm New Password' ) ); ?></label>
                                    <div class="input-with-toggle">
                                        <input type="password" id="confirm-new-password" class="form-control" autocomplete="new-password">
                                        <button class="password-toggle" type="button" data-target="confirm-new-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="form-error" id="password-error"></div>
                        </div>
                    </div>

                    <div class="dashboard-panel-actions">
                        <button type="button" class="btn-save-profile" id="btn-change-password"><?php echo esc_html( ie__( 'Update Password' ) ); ?></button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php if ( $provider_id ) : ?>
    <script type="text/html" id="provider-social-row-template"><?php ob_start(); ie_render_provider_social_row( [ 'icon' => '', 'url' => '' ], $social_presets ); echo trim( ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
    <script type="text/html" id="provider-service-row-template"><?php ob_start(); ie_render_provider_service_row( [ 'name' => '', 'price' => '', 'image_id' => 0, 'show_publicly' => false ], $service_placeholder_image ); echo trim( ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
<?php endif; ?>

<?php get_footer(); ?>
