(function ($) {
    'use strict';

    var cfg = window.IE_ADMIN || {};
    var searchTimer = null;

    function ajax(action, data) {
        data = data || {};
        data.action = action;
        data.nonce = cfg.nonce;
        return $.ajax({
            url: cfg.ajaxUrl,
            method: 'POST',
            dataType: 'json',
            data: data,
        });
    }

    function loadUsers(page) {
        var $section = $('.ie-ad-users');
        if (!$section.length) return;

        var type = $section.find('.ie-ad-tab.is-active').attr('data-tab') || 'all';
        var search = $section.find('#ie-ad-search').val() || '';
        var status = $section.find('#ie-ad-user-status').val() || '';
        var $tbody = $('#ie-ad-users-table tbody');
        var $pagination = $('#ie-ad-users-pagination');

        $tbody.html('<tr><td colspan="5">' + cfg.strings.loading + '</td></tr>');

        ajax('ie_admin_get_users', {
            type: type,
            search: search,
            status: status,
            paged: page || 1,
        }).done(function (res) {
            if (!res || !res.success) {
                var message = (res && res.data && res.data.message) ? res.data.message : cfg.strings.actionFailed;
                $tbody.html('<tr><td colspan="5">' + message + '</td></tr>');
                $pagination.empty();
                return;
            }

            $tbody.html(res.data.html || '<tr><td colspan="5">' + cfg.strings.noResults + '</td></tr>');
            $pagination.html(res.data.pagination_html || '');
        }).fail(function () {
            $tbody.html('<tr><td colspan="5">' + cfg.strings.actionFailed + '</td></tr>');
            $pagination.empty();
        });
    }

    function badge(status) {
        var cls = 'is-muted';
        if (status === 'active' || status === 'success') cls = 'is-success';
        if (status === 'suspended' || status === 'failed' || status === 'expired') cls = 'is-danger';
        if (status === 'pending') cls = 'is-warning';
        return '<span class="ie-ad-badge ' + cls + '">' + status + '</span>';
    }

    function openModal(title, body, footer) {
        $('#ie-admin-modal-title').text(title);
        $('#ie-admin-modal .ie-ad-modal-body').html(body);
        $('#ie-admin-modal .ie-ad-modal-footer').html(footer || '');
        $('#ie-admin-modal').removeAttr('hidden').attr('aria-hidden', 'false');
    }

    function closeModal() {
        $('#ie-admin-modal').attr('hidden', true).attr('aria-hidden', 'true');
    }

    function initTabs() {
        $(document).on('click', '.ie-ad-tab', function () {
            if ($(this).closest('.ie-ad-users, .ie-ad-subscriptions').length) {
                return;
            }

            var tab = $(this).data('tab');
            var $wrap = $(this).closest('[data-section]');

            $wrap.find('.ie-ad-tab').removeClass('is-active').attr('aria-selected', 'false');
            $(this).addClass('is-active').attr('aria-selected', 'true');

            $wrap.find('[data-tab-panel]').each(function () {
                var active = $(this).data('tab-panel') === tab;
                $(this).prop('hidden', !active).toggleClass('is-active', active);
            });
        });
    }

    function renderPagination($el, page, pages, callback) {
        $el.empty();
        if (pages <= 1) return;

        for (var i = 1; i <= pages; i++) {
            var btn = $('<button type="button" class="button">' + i + '</button>');
            if (i === page) btn.addClass('button-primary');
            btn.on('click', (function (p) {
                return function () { callback(p); };
            })(i));
            $el.append(btn);
        }
    }

    function renderUserModal(user) {
        var isProvider = user.type === 'provider';
        var title = isProvider ? cfg.strings.providerInfo : cfg.strings.clientInfo;

        var body = '<div class="ie-ad-modal-profile">' +
            (user.avatar ? '<img src="' + user.avatar + '" alt="">' : '') +
            '<div><strong>' + user.name + '</strong><br>' + user.email + '</div></div>';

        body += '<div class="ie-ad-modal-section"><dl class="ie-ad-detail-grid">';
        body += '<dt>' + cfg.strings.fullName + '</dt><dd>' + user.name + '</dd>';
        body += '<dt>' + cfg.strings.email + '</dt><dd>' + user.email + '</dd>';
        body += '<dt>' + cfg.strings.registered + '</dt><dd>' + user.registered + '</dd>';
        body += '<dt>' + cfg.strings.status + '</dt><dd>' + badge(user.status) + '</dd>';

        if (isProvider) {
            body += '<dt>' + cfg.strings.phone + '</dt><dd>' + (user.phone || '—') + '</dd>';
            body += '<dt>' + cfg.strings.subscription + '</dt><dd>' + (user.subscription || '—') + '</dd>';
            body += '<dt>' + cfg.strings.services + '</dt><dd>' + (user.services_count || 0) + '</dd>';
            body += '<dt>' + cfg.strings.reviews + '</dt><dd>' + (user.reviews_count || 0) + '</dd>';
            body += '<dt>' + cfg.strings.rating + '</dt><dd><span class="ie-ad-stars">★ ' + (user.rating || '0') + '</span></dd>';
        }

        body += '</dl></div>';

        var footer = '<strong>' + cfg.strings.adminActions + '</strong>';
        footer += '<div class="ie-ad-actions" style="margin-left:auto;">';

        if (user.status === 'active') {
            footer += '<button type="button" class="button ie-ad-user-action" data-action="suspend" data-id="' + user.id + '">' + cfg.strings.suspend + '</button>';
        } else {
            footer += '<button type="button" class="button ie-ad-user-action" data-action="activate" data-id="' + user.id + '">' + cfg.strings.activate + '</button>';
        }

        footer += '<button type="button" class="button button-link-delete ie-ad-user-action" data-action="delete" data-id="' + user.id + '">' + cfg.strings.delete + '</button>';

        if (user.profile_url) {
            footer += '<a class="button button-primary" href="' + user.profile_url + '" target="_blank" rel="noopener">' + cfg.strings.viewProfile + '</a>';
        }

        footer += '</div>';

        openModal(title, body, footer);
    }

    function userAction(action, userId) {
        var confirmMsg = action === 'delete' ? cfg.strings.confirmDelete : (action === 'suspend' ? cfg.strings.confirmSuspend : '');
        if (confirmMsg && !window.confirm(confirmMsg)) return;

        ajax('ie_admin_user_action', { user_action: action, user_id: userId }).done(function (res) {
            if (res.success) {
                closeModal();
                window.location.reload();
            } else {
                window.alert((res.data && res.data.message) || cfg.strings.actionFailed);
            }
        });
    }

    function loadReviews(page) {
        var $section = $('.ie-ad-reviews');
        if (!$section.length) return;

        var search = $('#ie-ad-search').val() || '';
        var rating = $('#ie-ad-review-rating').val() || 0;
        var $tbody = $('#ie-ad-reviews-table tbody');

        $tbody.html('<tr><td colspan="5">' + cfg.strings.loading + '</td></tr>');

        ajax('ie_admin_get_reviews', { search: search, rating: rating, paged: page || 1 }).done(function (res) {
            if (!res.success) {
                $tbody.html('<tr><td colspan="5">' + cfg.strings.actionFailed + '</td></tr>');
                return;
            }

            var reviews = res.data.reviews || [];
            if (!reviews.length) {
                $tbody.html('<tr><td colspan="5">' + cfg.strings.noResults + '</td></tr>');
                return;
            }

            $tbody.html(reviews.map(function (review) {
                return '<tr>' +
                    '<td>' + review.provider_name + '</td>' +
                    '<td><span class="ie-ad-stars">★ ' + review.rating + '</span></td>' +
                    '<td>' + review.comment + '</td>' +
                    '<td>' + review.date + '</td>' +
                    '<td><button type="button" class="button button-link-delete ie-ad-delete-review" data-id="' + review.id + '">' + cfg.strings.delete + '</button></td>' +
                    '</tr>';
            }).join(''));

            renderPagination($('#ie-ad-reviews-pagination'), page || 1, res.data.pages || 1, loadReviews);
        });
    }

    function initUsers() {
        if (!$('.ie-ad-users').length) return;

        $(document).on('click', '.ie-ad-users .ie-ad-tab', function (e) {
            e.preventDefault();
            var $wrap = $(this).closest('.ie-ad-users');

            $wrap.find('.ie-ad-tab').removeClass('is-active').attr('aria-selected', 'false');
            $(this).addClass('is-active').attr('aria-selected', 'true');

            loadUsers(1);
        });

        $(document).on('click', '.ie-ad-users-page', function () {
            loadUsers(parseInt($(this).data('page'), 10) || 1);
        });

        $('.ie-ad-users #ie-ad-search, .ie-ad-users #ie-ad-user-status').on('input change', function () {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(function () { loadUsers(1); }, 300);
        });

        $(document).on('click', '.ie-ad-view-user', function () {
            var id = $(this).data('id');
            ajax('ie_admin_get_user', { user_id: id }).done(function (res) {
                if (res.success) renderUserModal(res.data);
            });
        });

        $(document).on('click', '.ie-ad-user-action', function () {
            userAction($(this).data('action'), $(this).data('id'));
        });
    }

    function initReviews() {
        if (!$('.ie-ad-reviews').length) return;

        loadReviews(1);

        $('#ie-ad-search, #ie-ad-review-rating').on('input change', function () {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(function () { loadReviews(1); }, 300);
        });

        $(document).on('click', '.ie-ad-delete-review', function () {
            if (!window.confirm(cfg.strings.confirmDelete)) return;
            var id = $(this).data('id');
            ajax('ie_admin_delete_review', { review_id: id }).done(function (res) {
                if (res.success) loadReviews(1);
            });
        });
    }

    function loadSubscriptionUsers() {
        var $section = $('.ie-ad-subscriptions');
        if (!$section.length) return;

        var search = $section.find('#ie-ad-search').val() || '';
        var status = $section.find('#ie-ad-sub-status').val() || '';
        var $tbody = $('#ie-ad-subscriptions-table tbody');

        $tbody.html('<tr><td colspan="7">' + cfg.strings.loading + '</td></tr>');

        ajax('ie_admin_get_subscription_users', {
            search: search,
            status: status,
        }).done(function (res) {
            if (!res || !res.success) {
                $tbody.html('<tr><td colspan="7">' + cfg.strings.actionFailed + '</td></tr>');
                return;
            }

            $tbody.html(res.data.html || '<tr><td colspan="7">' + cfg.strings.noResults + '</td></tr>');
        }).fail(function () {
            $tbody.html('<tr><td colspan="7">' + cfg.strings.actionFailed + '</td></tr>');
        });
    }

    function initSubscriptions() {
        var $section = $('.ie-ad-subscriptions');
        if (!$section.length) return;

        function switchSubscriptionTab(tab) {
            $section.find('.ie-ad-tab').removeClass('is-active').attr('aria-selected', 'false');
            $section.find('.ie-ad-tab[data-tab="' + tab + '"]').addClass('is-active').attr('aria-selected', 'true');

            $section.find('[data-tab-panel]').each(function () {
                var active = $(this).data('tab-panel') === tab;
                $(this).prop('hidden', !active).toggleClass('is-active', active);
            });
        }

        $(document).on('click', '.ie-ad-subscriptions .ie-ad-tab', function (e) {
            e.preventDefault();
            switchSubscriptionTab($(this).data('tab'));
        });

        $section.find('#ie-ad-search, #ie-ad-sub-status').on('input change', function () {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(function () { loadSubscriptionUsers(); }, 300);
        });

        $(document).on('click', '.ie-ad-sub-user-delete', function () {
            if (!window.confirm(cfg.strings.confirmDelete)) {
                return;
            }

            var userId = $(this).data('id');

            ajax('ie_admin_user_action', {
                user_action: 'delete',
                user_id: userId,
            }).done(function (res) {
                if (res.success) {
                    loadSubscriptionUsers();
                    return;
                }

                window.alert((res.data && res.data.message) || cfg.strings.actionFailed);
            }).fail(function () {
                window.alert(cfg.strings.actionFailed);
            });
        });

        var $form = $('#ie-ad-plans-form');
        if (!$form.length) return;

        var $editorPanel = $('#ie-ad-plan-editor-panel');
        var $editorSlot = $('#ie-ad-plan-editor-slot');
        var $editorsWrap = $('#ie-ad-plans-editors');

        function buildIconSelect(planIndex, featureIndex, selectedIcon) {
            selectedIcon = selectedIcon || 'fa-solid fa-check';
            var icons = cfg.featureIcons || { 'fa-solid fa-check': 'Check' };
            var html = '<select class="ie-ad-feature-icon-select" name="plans[' + planIndex + '][features][' + featureIndex + '][icon]" aria-label="' + cfg.strings.featureIcon + '">';

            $.each(icons, function (value, label) {
                html += '<option value="' + value + '"' + (value === selectedIcon ? ' selected' : '') + '>' + label + '</option>';
            });

            html += '</select>';
            return html;
        }

        function updateFeatureIconPreview($field, iconClass) {
            iconClass = iconClass || 'fa-solid fa-check';
            var $preview = $field.find('.ie-ad-feature-icon-preview');
            $preview.find('i').attr('class', iconClass);
            $preview.removeClass('is-check is-cross is-star');

            if (iconClass === 'fa-solid fa-xmark') {
                $preview.addClass('is-cross');
            } else if (iconClass === 'fa-solid fa-star') {
                $preview.addClass('is-star');
            } else {
                $preview.addClass('is-check');
            }
        }

        function buildFeatureRow(planIndex, featureIndex, text, icon) {
            text = text || '';
            icon = icon || 'fa-solid fa-check';
            var modifier = 'is-check';
            if (icon === 'fa-solid fa-xmark') modifier = 'is-cross';
            if (icon === 'fa-solid fa-star') modifier = 'is-star';

            return (
                '<div class="ie-ad-repeater-row ie-ad-feature-row">' +
                '<div class="ie-ad-feature-icon-field">' +
                '<span class="ie-ad-feature-icon-preview ' + modifier + '" aria-hidden="true"><i class="' + icon + '"></i></span>' +
                buildIconSelect(planIndex, featureIndex, icon) +
                '</div>' +
                '<input type="text" class="ie-ad-feature-text-input" name="plans[' + planIndex + '][features][' + featureIndex + '][text]" value="' + text + '" placeholder="' + cfg.strings.featureText + '">' +
                '<button type="button" class="button ie-ad-remove-feature">' + cfg.strings.removeFeature + '</button>' +
                '</div>'
            );
        }

        function mountEditorsInForm() {
            if (!$editorsWrap.parent().is($form)) {
                $form.append($editorsWrap);
            }
        }

        function mountEditorsInPanel() {
            if (!$editorsWrap.parent().is($editorSlot)) {
                $editorSlot.append($editorsWrap);
            }
        }

        function reindexPlans() {
            $editorsWrap.find('.ie-ad-plan-editor').each(function (planIndex) {
                $(this).attr('data-plan-index', planIndex);
                $(this).find('[name^="plans["]').each(function () {
                    var name = $(this).attr('name').replace(/plans\[\d+\]/, 'plans[' + planIndex + ']');
                    $(this).attr('name', name);
                });

                $(this).find('.ie-ad-features-repeater .ie-ad-feature-row').each(function (featureIndex) {
                    $(this).find('[name*="[features]["]').each(function () {
                        var fieldName = $(this).attr('name').replace(/\[features\]\[\d+\]/, '[features][' + featureIndex + ']');
                        $(this).attr('name', fieldName);
                    });
                });
            });

            $('#ie-ad-plans-grid .ie-ad-sub-plan-card').each(function (planIndex) {
                $(this).attr('data-plan-index', planIndex);
            });
        }

        function preparePlansFormSubmit() {
            mountEditorsInForm();

            $editorsWrap.find('.ie-ad-plan-editor').each(function () {
                var $editor = $(this);
                var name = $.trim($editor.find('input[name$="[name]"]').val());
                var id = $.trim($editor.find('input[name$="[id]"]').val());

                if (!name && !id) {
                    var idx = $editor.data('plan-index');
                    $('.ie-ad-sub-plan-card[data-plan-index="' + idx + '"]').remove();
                    $editor.remove();
                }
            });

            reindexPlans();
        }

        $form.on('submit', function () {
            preparePlansFormSubmit();
        });

        $(document).on('click', '#ie-ad-save-plans, #ie-ad-plans-form input[type="submit"]', function () {
            preparePlansFormSubmit();
        });

        function closePlanEditor() {
            mountEditorsInForm();
            $editorsWrap.find('.ie-ad-plan-editor').prop('hidden', true);
            $editorPanel.prop('hidden', true);
        }

        function openPlanEditor(index) {
            var $editor = $editorsWrap.find('.ie-ad-plan-editor[data-plan-index="' + index + '"]');
            if (!$editor.length) {
                return;
            }

            mountEditorsInPanel();
            $editorsWrap.find('.ie-ad-plan-editor').prop('hidden', true);
            $editor.prop('hidden', false);

            var planName = $.trim($editor.find('input[name$="[name]"]').val());
            var title = planName ? cfg.strings.editPlan + ': ' + planName : cfg.strings.addPlan;
            $('#ie-ad-plan-editor-title').text(title);
            $editorPanel.prop('hidden', false);

            $('html, body').animate({ scrollTop: $editorPanel.offset().top - 40 }, 200);
        }

        function removePlan(index) {
            if ($editorsWrap.find('.ie-ad-plan-editor').length <= 1) {
                window.alert(cfg.strings.planRequired);
                return;
            }

            if (!window.confirm(cfg.strings.confirmDelete)) {
                return;
            }

            $('.ie-ad-sub-plan-card[data-plan-index="' + index + '"]').remove();
            $editorsWrap.find('.ie-ad-plan-editor[data-plan-index="' + index + '"]').remove();
            closePlanEditor();
            reindexPlans();
        }

        $('#ie-ad-add-plan').on('click', function () {
            var tpl = $('#ie-ad-plan-template').html();
            var index = $editorsWrap.find('.ie-ad-plan-editor').length;
            tpl = tpl.replace(/__INDEX__/g, index);
            $editorsWrap.append(tpl);
            openPlanEditor(index);
        });

        $(document).on('click', '.ie-ad-edit-plan', function () {
            openPlanEditor($(this).closest('.ie-ad-sub-plan-card').data('plan-index'));
        });

        $(document).on('click', '.ie-ad-remove-plan-grid, .ie-ad-remove-plan', function () {
            var $card = $(this).closest('.ie-ad-sub-plan-card');
            var $editor = $(this).closest('.ie-ad-plan-editor');
            var index = $card.length ? $card.data('plan-index') : $editor.data('plan-index');
            removePlan(index);
        });

        $(document).on('click', '.ie-ad-plan-editor-close', function () {
            closePlanEditor();
        });

        $(document).on('click', '.ie-ad-add-feature', function () {
            var $repeater = $(this).siblings('.ie-ad-features-repeater');
            var $editor = $(this).closest('.ie-ad-plan-editor');
            var index = $editor.data('plan-index');
            var featureIndex = $repeater.find('.ie-ad-feature-row').length;
            $repeater.append(buildFeatureRow(index, featureIndex, '', 'fa-solid fa-check'));
        });

        $(document).on('click', '.ie-ad-remove-feature', function () {
            var $repeater = $(this).closest('.ie-ad-features-repeater');
            if ($repeater.find('.ie-ad-feature-row').length <= 1) {
                var $row = $(this).closest('.ie-ad-feature-row');
                $row.find('.ie-ad-feature-text-input').val('');
                $row.find('.ie-ad-feature-icon-select').val('fa-solid fa-check').trigger('change');
                return;
            }
            $(this).closest('.ie-ad-repeater-row').remove();
        });

        $(document).on('change', '.ie-ad-feature-icon-select', function () {
            updateFeatureIconPreview($(this).closest('.ie-ad-feature-icon-field'), $(this).val());
        });
    }

    function initPayments() {
        $('#ie-test-stripe').on('click', function () {
            var $btn = $(this);
            $btn.prop('disabled', true).text(cfg.strings.stripeTesting);
            ajax('ie_admin_test_stripe').always(function () {
                $btn.prop('disabled', false).text('Test Connection');
            }).done(function (res) {
                if (res.success) {
                    window.alert((res.data && res.data.message) || cfg.strings.actionSuccess);
                    window.location.reload();
                } else {
                    window.alert((res.data && res.data.message) || cfg.strings.actionFailed);
                }
            }).fail(function (xhr) {
                var msg = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message;
                window.alert(msg || cfg.strings.actionFailed);
            });
        });

        $('#ie-copy-webhook').on('click', function () {
            var $input = $('#ie-stripe-webhook-url');
            $input.trigger('select');
            document.execCommand('copy');
        });
    }

    function initReports() {
        $('#ie-ad-date-range').on('change', function () {
            $('.ie-ad-custom-dates').prop('hidden', $(this).val() !== 'custom');
        });
    }

    function initModal() {
        $(document).on('click', '[data-close-modal]', closeModal);
        $(document).on('keydown', function (e) {
            if (e.key === 'Escape') closeModal();
        });
    }

    $(function () {
        initTabs();
        initModal();
        initUsers();
        initReviews();
        initSubscriptions();
        initPayments();
        initReports();
    });
})(jQuery);
