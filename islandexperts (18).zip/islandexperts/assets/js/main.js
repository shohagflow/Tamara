/**
 * Island Experts - Main JavaScript v2.2
 */
(function($) {
    'use strict';

    const Toast = {
        show(message, type = 'info', duration = 3500) {
            const $c = $('#ie-toast-container');
            const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
            const $t = $(`<div class="toast toast-${type}"><span>${icons[type]||''}</span><span>${message}</span></div>`);
            $c.append($t);
            setTimeout(() => { $t.addClass('fading'); setTimeout(() => $t.remove(), 350); }, duration);
        }
    };

    function ieGetRedirectToParam() {
        const params = new URLSearchParams(window.location.search);
        const redirectTo = params.get('redirect_to');
        if (!redirectTo) {
            return null;
        }

        try {
            const url = new URL(decodeURIComponent(redirectTo), window.location.origin);
            if (url.origin !== window.location.origin) {
                return null;
            }
            return url.pathname + url.search + url.hash;
        } catch (e) {
            return null;
        }
    }

    function ieGetProfileRedirectUrl(resData) {
        const redirectTo = ieGetRedirectToParam();
        if (redirectTo) {
            return redirectTo;
        }

        if (resData && resData.redirect_url) {
            return resData.redirect_url;
        }
        const urls = window.IE_AJAX && IE_AJAX.urls;
        if (!urls) {
            return null;
        }
        const type = resData && resData.user_type;
        if (type === 'provider') {
            return urls.providerProfile || urls.account || urls.home;
        }
        return urls.clientProfile || urls.account || urls.home;
    }

    function ieGetHomeUrl() {
        const urls = window.IE_AJAX && IE_AJAX.urls;
        return (urls && urls.home) || '/';
    }

    function ieGetLogoutRedirectUrl($btn) {
        if ($btn && $btn.length) {
            const fromBtn = $btn.data('logoutHome');
            if (fromBtn) {
                return fromBtn;
            }
        }
        return ieGetHomeUrl();
    }

    function iePerformLogout(triggerEl) {
        const $btn = triggerEl ? $(triggerEl) : null;
        const homeUrl = ieGetLogoutRedirectUrl($btn);
        const fallbackUrl = (window.IE_AJAX && IE_AJAX.logoutFallback) || homeUrl;

        if ($btn && $btn.length) {
            $btn.prop('disabled', true);
        }

        if (!window.IE_AJAX || !IE_AJAX.url) {
            window.location.replace(fallbackUrl);
            return;
        }

        $.ajax({
            url: IE_AJAX.url,
            method: 'POST',
            dataType: 'json',
            dataFilter: ieParseAjaxResponse,
            data: {
                action: 'ie_logout',
                nonce: IE_AJAX.nonce,
            },
        }).done(function(res) {
            const dest = (res && res.success && res.data && res.data.redirect_url)
                ? res.data.redirect_url
                : homeUrl;
            window.location.replace(dest);
        }).fail(function() {
            window.location.replace(fallbackUrl);
        });
    }

    function ieParseAjaxResponse(data) {
        if (typeof data !== 'string') {
            return data;
        }

        const trimmed = data.replace(/^\uFEFF+/, '').trim();
        if (trimmed.charAt(0) === '{' || trimmed.charAt(0) === '[') {
            return trimmed;
        }

        const start = trimmed.indexOf('{');
        const end = trimmed.lastIndexOf('}');
        if (start !== -1 && end > start) {
            return trimmed.slice(start, end + 1);
        }

        return trimmed;
    }

    function ieAjax(action, data, btn) {
        if (btn) {
            const $b = $(btn);
            $b.prop('disabled', true).data('orig', $b.html()).html('<span class="ie-btn-spin"></span> Please wait...');
        }
        return $.ajax({
            url: IE_AJAX.url, method: 'POST',
            dataType: 'json',
            dataFilter: ieParseAjaxResponse,
            data: Object.assign({ action, nonce: IE_AJAX.nonce }, data),
        }).always(() => {
            if (btn) { const $b = $(btn); $b.prop('disabled', false).html($b.data('orig')); }
        });
    }

    function esc(str) {
        return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    function formatTime(t) {
        if (!t) return '';
        const [h, m] = t.split(':');
        const hr = parseInt(h);
        return `${hr % 12 || 12}:${m} ${hr >= 12 ? 'PM' : 'AM'}`;
    }

    function formatDate(d) {
        if (!d) return '';
        try { return new Date(d + 'T00:00:00').toLocaleDateString('en-US', { weekday:'short', year:'numeric', month:'short', day:'numeric' }); }
        catch(e) { return d; }
    }

    function isInWishlist(p) {
        if (!window.IE_WISHLIST) return false;
        const id = Number(p.id || 0);
        if (id && IE_WISHLIST.ids && IE_WISHLIST.ids.map(Number).includes(id)) return true;
        const slug = p.slug || '';
        if (slug && IE_WISHLIST.slugs && IE_WISHLIST.slugs.includes(slug)) return true;
        return false;
    }

    function syncWishlistCache(id, slug, added) {
        if (!window.IE_WISHLIST) return;
        IE_WISHLIST.ids = IE_WISHLIST.ids || [];
        IE_WISHLIST.slugs = IE_WISHLIST.slugs || [];
        const numericId = Number(id || 0);
        if (numericId) {
            IE_WISHLIST.ids = added
                ? Array.from(new Set(IE_WISHLIST.ids.concat(numericId)))
                : IE_WISHLIST.ids.filter(function(item) { return Number(item) !== numericId; });
        }
        if (slug) {
            IE_WISHLIST.slugs = added
                ? Array.from(new Set(IE_WISHLIST.slugs.concat(slug)))
                : IE_WISHLIST.slugs.filter(function(item) { return item !== slug; });
        }
    }

    function buildFeaturedWishlistBtn(p) {
        const active = isInWishlist(p);
        const iconClass = active ? 'fa-solid' : 'fa-regular';
        const activeClass = active ? ' active' : '';
        const id = Number(p.id || 0);
        const slug = p.slug || (p.permalink ? p.permalink.replace(/\/$/, '').split('/').pop() : '');
        const idAttr = id ? ` data-id="${id}"` : '';
        const slugAttr = slug ? ` data-slug="${esc(slug)}"` : '';
        const saveLabel = (window.IE_I18N && IE_I18N.saveProvider) || 'Save provider';
        return `<button type="button" class="featured-wishlist-btn wishlist-btn${activeClass}"${idAttr}${slugAttr} onclick="event.preventDefault();event.stopPropagation();IEApp.toggleFeaturedWishlist(this)" aria-label="${esc(saveLabel)}" title="${esc(saveLabel)}"><i class="${iconClass} fa-heart" aria-hidden="true"></i></button>`;
    }

    function formatFeaturedProviderPrice(price) {
        const value = parseFloat(price);
        if (!price || Number.isNaN(value) || value <= 0) {
            return '';
        }
        const fromLabel = (window.IE_I18N && IE_I18N.fromPrice) || 'From';
        const formatted = Number.isInteger(value) ? String(value) : value.toFixed(2).replace(/\.?0+$/, '');
        return `${fromLabel} $${formatted}`;
    }

    function buildFeaturedProviderCard(p) {
        const catSlug = ((p.service_name_slug || p.category_slug || '').toLowerCase().replace(/[^a-z0-9-]/g, ''));
        const serviceLabel = p.service_name || p.category || '';
        const priceLabel = formatFeaturedProviderPrice(p.price);
        const bio     = p.bio ? esc(p.bio) : '';
        const reviewsLabel = (window.IE_I18N && IE_I18N.reviews) || 'reviews';
        const chatLabel    = (window.IE_I18N && IE_I18N.chat) || 'Chat';
        const profileLabel = (window.IE_I18N && IE_I18N.viewProfile) || 'View Profile';
        const hasBanner = !!p.has_service_banner;
        const bannerClass = hasBanner ? '' : ' is-placeholder';
        const bannerAlt = hasBanner ? esc(p.name) : '';
        return `
        <article class="featured-provider-card">
            <div class="featured-provider-service-image${bannerClass}">
                ${buildFeaturedWishlistBtn(p)}
                <img src="${esc(p.service_image)}" alt="${bannerAlt}" loading="lazy">
            </div>
            <div class="featured-provider-profile-wrap">
                <img class="featured-provider-avatar" src="${esc(p.profile_image)}" alt="${esc(p.name)}" loading="lazy">
            </div>
            <div class="featured-provider-body">
                <h3 class="featured-provider-name">${esc(p.name)}</h3>
                <div class="featured-provider-rating">
                    <i class="fa-solid fa-star" aria-hidden="true"></i>
                    <span class="featured-provider-rating-value">${esc(p.rating)}</span>
                    <span class="featured-provider-review-count">(${esc(p.reviews)} ${reviewsLabel})</span>
                </div>
                ${(serviceLabel || priceLabel) ? `
                <div class="featured-provider-service-row">
                    ${serviceLabel ? `<span class="featured-provider-service-name tag tag-${catSlug}">${esc(serviceLabel)}</span>` : ''}
                    ${priceLabel ? `<span class="featured-provider-price">${esc(priceLabel)}</span>` : ''}
                </div>` : ''}
                ${bio ? `<p class="featured-provider-bio">${bio}</p>` : ''}
                <div class="featured-provider-actions">
                    <a href="${esc(p.chat_url)}" class="btn-featured-chat">
                        <i class="fa-regular fa-comment-dots" aria-hidden="true"></i>
                        ${chatLabel}
                    </a>
                    <a href="${esc(p.permalink)}" class="btn-featured-profile">
                        ${profileLabel}
                        <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </article>`;
    }

    function buildProviderCard(p) {
        const availClass = { available_now:'avail-now', available_week:'avail-week', busy:'avail-busy' }[p.availability] || 'avail-now';
        const catSlug    = (p.category_slug || p.category || '').toLowerCase().replace(/[^a-z0-9]/g,'-');
        const imgHtml    = p.thumbnail
            ? `<img src="${esc(p.thumbnail)}" alt="${esc(p.title)}" loading="lazy">`
            : `<div class="no-image">${esc(p.title.charAt(0).toUpperCase())}</div>`;
        return `
        <div class="provider-card" onclick="window.location='${p.permalink}'">
            <div class="provider-card-image">
                ${imgHtml}
                ${p.verified ? '<div class="verified-badge"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg> Verified</div>' : ''}
                <div class="availability-badge ${availClass}">${esc(p.avail_label)}</div>
                <button class="wishlist-btn" data-id="${p.id}" onclick="event.stopPropagation(); IEApp.toggleWishlist(this, ${p.id})" title="Save provider">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                </button>
            </div>
            <div class="provider-card-body">
                <div class="provider-card-title-row">
                    <span class="provider-name">${esc(p.title)}</span>
                    <span class="provider-rating"><span class="star-icon">★</span>${esc(p.rating)}<span class="review-count">(${esc(p.reviews)})</span></span>
                </div>
                ${p.category ? `<div class="provider-tags"><span class="tag tag-${catSlug}">${esc(p.category)}</span></div>` : ''}
                <div class="provider-meta">
                    ${p.location ? `<span class="meta-item"><span>📍</span>${esc(p.location)}</span>` : ''}
                    ${p.experience && p.experience !== '0' ? `<span class="meta-item"><span>⏱</span>${esc(p.experience)} yrs exp</span>` : ''}
                </div>
                ${p.price ? `<div class="provider-price">From <strong>$${esc(p.price)}</strong> / service</div>` : ''}
            </div>
        </div>`;
    }

    function buildBookingCard(b) {
        const canCancel = ['pending','confirmed'].includes(b.status);
        const thumbHtml = b.provider_thumb
            ? `<img src="${esc(b.provider_thumb)}" alt="${esc(b.provider_name)}">`
            : `<div class="thumb-placeholder">${esc((b.provider_name||'?').charAt(0).toUpperCase())}</div>`;
        return `
        <div class="booking-card" id="booking-card-${b.id}">
            <div class="booking-provider-thumb">${thumbHtml}</div>
            <div class="booking-info">
                <h4>${esc(b.provider_name)}</h4>
                <div class="booking-meta-row">
                    ${b.date ? `<span class="booking-meta-item">📅 ${formatDate(b.date)}</span>` : ''}
                    ${b.time ? `<span class="booking-meta-item">⏰ ${formatTime(b.time)}</span>` : ''}
                    ${b.service ? `<span class="booking-meta-item">🛠 ${esc(b.service)}</span>` : ''}
                </div>
                ${b.provider_cat ? `<span class="booking-service-tag">${esc(b.provider_cat)}</span>` : ''}
            </div>
            <div class="booking-actions">
                <span class="booking-status-badge status-${esc(b.status)}">${esc(b.status)}</span>
                ${canCancel ? `<button class="btn-cancel-booking" onclick="IEApp.cancelBooking(this,${b.id})">Cancel</button>` : ''}
            </div>
        </div>`;
    }

    /* MOBILE MENU */
    function setMobileNavOpen(open) {
        const $nav = $('#site-nav');
        const $toggle = $('#mobile-menu-toggle');
        $nav.toggleClass('mobile-open', open);
        $toggle.toggleClass('is-open', open).attr('aria-expanded', open ? 'true' : 'false');
        $('body').toggleClass('mobile-nav-open', open);
    }

    $('#mobile-menu-toggle').on('click', function() {
        setMobileNavOpen(!$('#site-nav').hasClass('mobile-open'));
    });
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#site-header').length) {
            setMobileNavOpen(false);
        }
        if (!$(e.target).closest('.header-user-menu').length) {
            $('.header-user-menu').removeClass('is-open');
            $('.header-user-menu__toggle').attr('aria-expanded', 'false');
        }
    });
    $('#site-nav a').on('click', function() { setMobileNavOpen(false); });
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') {
            setMobileNavOpen(false);
            $('.header-user-menu').removeClass('is-open');
            $('.header-user-menu__toggle').attr('aria-expanded', 'false');
        }
    });

    /* HEADER USER MENU */
    $(document).on('click', '.header-user-menu__toggle', function(e) {
        e.stopPropagation();
        const $menu = $(this).closest('.header-user-menu');
        const isOpen = $menu.hasClass('is-open');

        $('.header-user-menu').removeClass('is-open');
        $('.header-user-menu__toggle').attr('aria-expanded', 'false');

        if (!isOpen) {
            $menu.addClass('is-open');
            $(this).attr('aria-expanded', 'true');
        }
    });

    $(document).on('click', '.header-user-menu__dropdown', function(e) {
        e.stopPropagation();
    });

    $(document).on('click', '.header-user-menu__link:not(.header-user-menu__logout)', function() {
        $('.header-user-menu').removeClass('is-open');
        $('.header-user-menu__toggle').attr('aria-expanded', 'false');
        setMobileNavOpen(false);
    });

    $(document).on('click', '[data-ie-logout], #btn-logout, .header-user-menu__logout', function(e) {
        e.preventDefault();
        e.stopPropagation();

        if (!confirm((window.IE_I18N && IE_I18N.confirmLogout) || 'Are you sure you want to log out?')) {
            return;
        }

        iePerformLogout(this);
    });

    /* HERO CAROUSEL */
    (function() {
        const slides = document.querySelectorAll('.hero-slide');
        if (!slides.length) return;
        let current = 0;
        setInterval(function() {
            slides[current].classList.remove('active');
            current = (current + 1) % slides.length;
            slides[current].classList.add('active');
        }, 5000);
    })();

    /* ==============================================
       BROWSE PAGE
    =============================================== */
    if ($('#providers-grid').length) {
        const defaults = window.IE_BROWSE_DEFAULTS || {};
        let state = {
            category : defaults.category || 'all',
            search   : defaults.search   || '',
            rating   : '',
            price    : '',
            page     : 1,
        };

        if (state.category && state.category !== 'all') {
            $('#browse-category-filter').val(state.category);
        }
        if (state.search) $('#browse-search-input').val(state.search);
        checkResetBtn();

        function checkResetBtn() {
            const isFiltered = state.category !== 'all' || state.rating !== '' || state.price !== '' || state.search !== '';
            $('#reset-all-filters').toggle(isFiltered);
        }

        function getPaginationPages(currentPage, totalPages) {
            if (totalPages <= 7) {
                return Array.from({ length: totalPages }, (_, i) => i + 1);
            }

            const pages = new Set([1, totalPages, currentPage, currentPage - 1, currentPage + 1]);
            const sorted = [...pages].filter((p) => p >= 1 && p <= totalPages).sort((a, b) => a - b);
            const result = [];
            let prev = 0;

            sorted.forEach((page) => {
                if (prev && page - prev > 1) {
                    result.push('ellipsis');
                }
                result.push(page);
                prev = page;
            });

            return result;
        }

        function buildBrowsePagination(data) {
            const { total, total_pages, current_page, showing_from, showing_to } = data;
            const i18n = window.IE_I18N || {};

            if (!total || total_pages <= 1) {
                $('#browse-pagination-wrap').attr('hidden', true);
                $('#browse-pagination').empty();
                $('#browse-pagination-info').empty();
                return;
            }

            const infoTemplate = i18n.paginationShowing || 'Showing %1$d–%2$d of %3$d providers';
            const infoText = infoTemplate
                .replace('%1$d', showing_from)
                .replace('%2$d', showing_to)
                .replace('%3$d', total);

            let html = `<button type="button" class="page-btn page-btn-nav" data-page="${current_page - 1}" ${current_page <= 1 ? 'disabled' : ''} aria-label="${i18n.paginationPrevious || 'Previous'}">
                <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
                <span>${i18n.paginationPrevious || 'Previous'}</span>
            </button>`;

            getPaginationPages(current_page, total_pages).forEach((item) => {
                if (item === 'ellipsis') {
                    html += '<span class="page-ellipsis" aria-hidden="true">…</span>';
                    return;
                }

                const isActive = item === current_page;
                html += `<button type="button" class="page-btn ${isActive ? 'active' : ''}" data-page="${item}" aria-label="Page ${item}" ${isActive ? 'aria-current="page"' : ''}>${item}</button>`;
            });

            html += `<button type="button" class="page-btn page-btn-nav" data-page="${current_page + 1}" ${current_page >= total_pages ? 'disabled' : ''} aria-label="${i18n.paginationNext || 'Next'}">
                <span>${i18n.paginationNext || 'Next'}</span>
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
            </button>`;

            $('#browse-pagination-info').text(infoText);
            $('#browse-pagination').html(html);
            $('#browse-pagination-wrap').removeAttr('hidden');
        }

        function loadBrowse() {
            $('#providers-grid').html('<div class="browse-loading"><div class="spinner"></div><p>' + ((window.IE_I18N && IE_I18N.loadingProviders) || 'Loading providers...') + '</p></div>');
            $('#browse-pagination-wrap').attr('hidden', true);
            $('#browse-pagination').empty();
            $('#browse-pagination-info').empty();
            ieAjax('ie_search_providers', {
                search   : state.search,
                category : state.category,
                rating   : state.rating,
                price    : state.price,
                sort     : 'rating',
                page     : state.page,
            }).done(function(res) {
        if (!res.success) { $('#providers-grid').html('<div class="no-results"><div class="no-results-icon"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></div><h3>' + (window.IE_I18N?.failedLoad || 'Failed to load') + '</h3></div>'); return; }
                const { providers, total, total_pages, current_page } = res.data;
                const i18n = window.IE_I18N || {};
                if (!providers.length) {
                    $('#providers-grid').html('<div class="no-results"><div class="no-results-icon"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i></div><h3>' + (i18n.noProviders || 'No providers found') + '</h3><p>' + (i18n.tryFilters || 'Try different filters or search terms.') + '</p></div>');
                } else {
                    $('#providers-grid').html(providers.map(buildFeaturedProviderCard).join(''));
                }
                buildBrowsePagination(res.data);
            }).fail(function() {
                $('#providers-grid').html('<div class="no-results"><div class="no-results-icon"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></div><h3>Connection error</h3><p>Please refresh the page.</p></div>');
            });
        }

        loadBrowse();

        $(document).on('click', '#reset-all-filters', function() {
            state.category = 'all';
            state.rating   = '';
            state.price    = '';
            state.search   = '';
            state.page     = 1;

            $('#browse-category-filter').val('all');
            $('#browse-rating-filter').val('');
            $('#browse-price-filter').val('');
            $('#browse-search-input').val('');
            $('#reset-all-filters').hide();
            loadBrowse();
        });

        $('#browse-category-filter').on('change', function() {
            state.category = $(this).val();
            state.page = 1;
            loadBrowse();
            checkResetBtn();
        });

        $('#browse-rating-filter').on('change', function() {
            state.rating = $(this).val();
            state.page = 1;
            loadBrowse();
            checkResetBtn();
        });

        $('#browse-price-filter').on('change', function() {
            state.price = $(this).val();
            state.page = 1;
            loadBrowse();
            checkResetBtn();
        });

        let searchTimer;
        $('#browse-search-input').on('input', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => { state.search = $(this).val().trim(); state.page = 1; loadBrowse(); checkResetBtn(); }, 400);
        });

        $(document).on('click', '.browse-pagination .page-btn:not(:disabled)', function() {
            state.page = parseInt($(this).data('page'), 10);
            loadBrowse();
            $('html, body').animate({ scrollTop: $('.browse-page-wrap').offset().top - 90 }, 350);
        });

    } // end browse block

    /* WISHLIST */
    window.IEApp = window.IEApp || {};

    IEApp.toggleFaq = function( btn ) {
        const card   = btn.closest( '.ie-faq-card' );
        const body   = btn.nextElementSibling;
        const isOpen = card.classList.contains( 'open' );

        document.querySelectorAll( '.ie-faq-card.open' ).forEach( function( c ) {
            c.classList.remove( 'open' );
            c.querySelector( '.faq-body' ).style.display = 'none';
        } );

        if ( ! isOpen ) {
            card.classList.add( 'open' );
            body.style.display = 'block';
        }
    };

    IEApp.toggleWishlist = function(btn, providerId) {
        ieAjax('ie_toggle_wishlist', { provider_id: providerId }).done(function(res) {
            if (res.success) {
                const added = res.data.action === 'added';
                const $b = $(btn);
                $b.toggleClass('active', added);
                $b.find('svg').attr('fill', added ? '#d06a1e' : 'none').css('stroke', added ? '#d06a1e' : 'currentColor');
                syncWishlistCache(providerId, '', added);
                Toast.show(res.data.message, added ? 'success' : 'info');
            } else {
                Toast.show(res.data.message || 'Please log in to save providers.', 'error');
                if ((res.data.message || '').includes('log in')) setTimeout(() => { window.location = (IE_AJAX.urls && IE_AJAX.urls.account) || '/account/'; }, 1200);
            }
        });
    };

    IEApp.toggleFeaturedWishlist = function(btn) {
        const $b = $(btn);
        const id = parseInt($b.data('id'), 10) || 0;
        const slug = String($b.data('slug') || '');
        const payload = {};
        if (id) payload.provider_id = id;
        else if (slug) payload.provider_slug = slug;
        else return;

        ieAjax('ie_toggle_wishlist', payload).done(function(res) {
            if (res.success) {
                const added = res.data.action === 'added';
                $b.toggleClass('active', added);
                $b.find('i').toggleClass('fa-regular', !added).toggleClass('fa-solid', added);
                syncWishlistCache(id, slug, added);
                Toast.show(res.data.message, added ? 'success' : 'info');
            } else {
                Toast.show(res.data.message || 'Please log in to save providers.', 'error');
                if ((res.data.message || '').includes('log in')) {
                    setTimeout(function() {
                        window.location = (IE_AJAX.urls && IE_AJAX.urls.account) || '/account/';
                    }, 1200);
                }
            }
        });
    };

    /* BOOKINGS LIST LOADER */
    function loadBookingsList(filter, containerId) {
        const $wrap = $('#' + containerId);
        $wrap.html('<div style="text-align:center;padding:60px;color:var(--color-text-muted)"><div class="spinner" style="margin:0 auto 12px"></div><p>Loading...</p></div>');
        ieAjax('ie_get_bookings', { filter }).done(function(res) {
            if (!res.success) { $wrap.html('<div class="empty-state"><div class="empty-state-icon">⚠️</div><h3>Error loading bookings</h3><p>Please refresh the page.</p></div>'); return; }
            const { bookings } = res.data;
            if (!bookings || !bookings.length) {
                const label = filter !== 'all' ? filter : '';
                $wrap.html(`<div class="empty-state"><div class="empty-state-icon">📅</div><h3>No ${label} bookings found</h3><p>You don't have any ${label} bookings yet.</p><a href="/browse/" class="btn-browse-now">Browse Providers</a></div>`);
            } else {
                $wrap.html('<div class="bookings-list">' + bookings.map(buildBookingCard).join('') + '</div>');
            }
        }).fail(function() { $wrap.html('<div class="empty-state"><div class="empty-state-icon">⚠️</div><h3>Connection error</h3><p>Please refresh and try again.</p></div>'); });
    }

    /* CANCEL BOOKING */
    IEApp.cancelBooking = function(btn, bookingId) {
        if (!confirm('Are you sure you want to cancel this booking?')) return;
        ieAjax('ie_cancel_booking', { booking_id: bookingId }, btn).done(function(res) {
            if (res.success) {
                $(`#booking-card-${bookingId} .booking-status-badge`).removeClass('status-pending status-confirmed').addClass('status-cancelled').text('cancelled');
                $(`#booking-card-${bookingId} .btn-cancel-booking`).remove();
                Toast.show('Booking cancelled.', 'info');
            } else { Toast.show(res.data.message || 'Cannot cancel this booking.', 'error'); }
        });
    };

    /* AUTH TABS */
    $(document).on('click', '.auth-tab-btn', function() {
        const tab = $(this).data('tab');
        $('.auth-tab-btn').removeClass('active');
        $('.auth-tab-btn[data-tab="' + tab + '"]').addClass('active');
        if (tab === 'login') {
            $('#auth-header-login').show();
            $('#auth-header-register').hide();
            $('#auth-panel-login').show();
            $('#auth-panel-register').hide();
        } else {
            $('#auth-header-login').hide();
            $('#auth-header-register').show();
            $('#auth-panel-register').show();
            $('#auth-panel-login').hide();
            syncUserTypeSelection();
        }
    });

    if ($('#auth-panel-login').length) {
        const params = new URLSearchParams(window.location.search);
        if (params.get('type') === 'provider') {
            $('#reg-type-provider').prop('checked', true);
        }
        if (params.get('mode') === 'register' || params.get('type') === 'provider') {
            $('.auth-tab-btn[data-tab="register"]').trigger('click');
        }
    }

    /* LOGIN */
    $('#btn-login').on('click', function() {
        const email = $('#login-email').val().trim(), password = $('#login-password').val();
        $('#login-error, #login-success').removeClass('show');
        if (!email || !password) { $('#login-error').addClass('show').text('Please enter your email and password.'); return; }
        ieAjax('ie_login', { email, password }, this).done(function(res) {
            if (res.success) {
                $('#login-success').addClass('show').text(res.data.message || 'Login successful!');
                const dest = ieGetProfileRedirectUrl(res.data) || window.location.href;
                setTimeout(() => { window.location = dest; }, 800);
            }
            else { $('#login-error').addClass('show').text(res.data.message || 'Login failed.'); }
        }).fail(function() { $('#login-error').addClass('show').text('Connection error. Please try again.'); });
    });
    $('#login-password').on('keypress', function(e) { if (e.which === 13) $('#btn-login').trigger('click'); });

    /* REGISTER */
	$('#btn-register').on('click', function() {
		const firstName = $('#reg-firstname').val().trim(), lastName = $('#reg-lastname').val().trim(), email = $('#reg-email').val().trim(), password = $('#reg-password').val(), confirmPassword = $('#reg-confirm-password').val();
		const userType = $('input[name="reg-user-type"]:checked').val() || 'customer';
		$('#reg-error, #reg-success').removeClass('show');
		if (!firstName || !email || !password || !confirmPassword) { $('#reg-error').addClass('show').text('Please fill in all required fields.'); return; }
		if (password.length < 6) { $('#reg-error').addClass('show').text('Password must be at least 6 characters.'); return; }
		if (password !== confirmPassword) { $('#reg-error').addClass('show').text('Passwords do not match.'); return; }

        const payload = { first_name: firstName, last_name: lastName, email, password, confirm_password: confirmPassword, user_type: userType };
        if (userType === 'provider') {
            payload.service_name = $('#reg-service-name').val().trim();
            payload.experience   = $('#reg-experience').val().trim();
            payload.location     = $('#reg-location').val().trim();
            if (!payload.service_name || !payload.experience || !payload.location) {
                $('#reg-error').addClass('show').text('Please fill in your business name, experience, and location.');
                return;
            }
        }

		ieAjax('ie_register', payload, this).done(function(res) {
			if (res.success) {
                $('#reg-success').addClass('show').text(res.data.message || 'Account created!');
                const dest = ieGetProfileRedirectUrl(res.data) || window.location.href;
                setTimeout(() => { window.location = dest; }, 1000);
            }
			else { $('#reg-error').addClass('show').text(res.data.message || 'Registration failed.'); }
		}).fail(function() { $('#reg-error').addClass('show').text('Connection error. Please try again.'); });
	});

    /* DASHBOARD NAV PANELS */
    $(document).on('click', '#btn-profile-message-notify', function(e) {
        e.preventDefault();
        const $nav = $('.dashboard-nav-item[data-panel="messages"]');
        if ($nav.length) {
            $nav.trigger('click');
        }
    });

    $(document).on('click', '.dashboard-nav-item[data-panel]', function() {
        const panel = $(this).data('panel');
        $('.dashboard-nav-item').removeClass('active'); $(this).addClass('active');
        $('.dashboard-panel').removeClass('active'); $('#panel-' + panel).addClass('active');
        if (panel === 'bookings' && !$(this).data('loaded')) { loadBookingsList('all', 'dashboard-bookings-list'); $(this).data('loaded', true); }
        if (panel === 'saved' && !$(this).data('loaded')) { loadSavedProviders(); $(this).data('loaded', true); }
        if (panel === 'messages' && !$(this).data('loaded') && !$('.provider-profile-page').length) {
            setMessagesMobileView();
            const presetProvider = $('#panel-messages').data('active-provider');
            if (presetProvider && !activeChatProviderId) {
                activeChatProviderId = String(presetProvider);
            }
            if ($('#messages-conversation-list .client-messages-item').length) {
                syncConversationsCache();
                if (activeChatProviderId) {
                    openChat(activeChatProviderId);
                } else {
                    startClientChatPolling();
                }
            } else {
                loadConversations();
            }
            $(this).data('loaded', true);
        } else if (panel === 'messages' && !$('.provider-profile-page').length) {
            startClientChatPolling();
        }
    });
    $(document).on('click', '[data-dash-filter]', function() {
        $(this).addClass('active').siblings().removeClass('active');
        loadBookingsList($(this).data('dash-filter'), 'dashboard-bookings-list');
    });

    /* PROFILE PHOTO PREVIEW + SAVE */
    let profilePhotoPreviewUrl = null;

    function getProfilePhotoAltText() {
        const first = $('#profile-firstname').val().trim();
        const last = $('#profile-lastname').val().trim();
        const full = `${first} ${last}`.trim();
        return full || $('.dashboard-user-name').first().text().trim() || 'Profile photo';
    }

    function revokeProfilePhotoPreview() {
        if (profilePhotoPreviewUrl) {
            URL.revokeObjectURL(profilePhotoPreviewUrl);
            profilePhotoPreviewUrl = null;
        }
    }

    function updateSidebarAvatarPreview(url, alt) {
        $('#sidebar-avatar').addClass('has-image').html(
            `<img src="${esc(url)}" alt="${esc(alt || 'Profile photo')}" id="sidebar-avatar-img">`
        );
    }

    function applySavedSidebarAvatar(avatarUrl, displayName) {
        if (!avatarUrl) {
            return;
        }
        revokeProfilePhotoPreview();
        updateSidebarAvatarPreview(avatarUrl, displayName || getProfilePhotoAltText());
    }

    /* SAVE PROFILE */
    $('#btn-save-profile').on('click', function() {
        $('#profile-error').removeClass('show');

        const formData = new FormData();
        formData.append('action', 'ie_update_profile');
        formData.append('nonce', IE_AJAX.nonce);
        formData.append('first_name', $('#profile-firstname').val().trim());
        formData.append('last_name', $('#profile-lastname').val().trim());

        const photoInput = document.getElementById('profile-photo');
        const photoFile  = photoInput && photoInput.files[0];
        if (photoFile) {
            formData.append('profile_photo', photoFile);
        }

        const $btn = $(this);
        $btn.prop('disabled', true).data('orig', $btn.html()).html('<span class="ie-btn-spin"></span> Please wait...');

        $.ajax({
            url: IE_AJAX.url,
            method: 'POST',
            dataType: 'json',
            dataFilter: ieParseAjaxResponse,
            data: formData,
            processData: false,
            contentType: false,
        }).done(function(res) {
            if (res.success) {
                Toast.show(res.data.message || 'Profile updated!', 'success');

                if (res.data.display_name) {
                    $('.dashboard-user-name').text(res.data.display_name);
                }

                if (res.data.avatar_url) {
                    applySavedSidebarAvatar(res.data.avatar_url, res.data.display_name);
                }

                if (photoInput) {
                    photoInput.value = '';
                }
            } else {
                $('#profile-error').addClass('show').text(res.data.message || 'Failed to update.');
            }
        }).fail(function() {
            $('#profile-error').addClass('show').text('Connection error. Please try again.');
        }).always(function() {
            $btn.prop('disabled', false).html($btn.data('orig'));
        });
    });

    $('#profile-photo').on('change', function() {
        const file = this.files[0];
        $('#profile-error').removeClass('show');
        revokeProfilePhotoPreview();

        if (!file) {
            return;
        }

        const allowed = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowed.includes(file.type)) {
            $('#profile-error').addClass('show').text('Please upload a JPG, PNG, or WEBP image.');
            this.value = '';
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            $('#profile-error').addClass('show').text('Image must be smaller than 5MB.');
            this.value = '';
            return;
        }

        profilePhotoPreviewUrl = URL.createObjectURL(file);
        updateSidebarAvatarPreview(profilePhotoPreviewUrl, getProfilePhotoAltText());
    });

    /* CHANGE PASSWORD */
    $('#btn-change-password').on('click', function() {
        $('#password-error').removeClass('show');
        const current = $('#curr-password').val(), newPass = $('#new-password').val(), confirm = $('#confirm-new-password').val();
        if (!current || !newPass || !confirm) { $('#password-error').addClass('show').text('All fields are required.'); return; }
        if (newPass !== confirm) { $('#password-error').addClass('show').text('New passwords do not match.'); return; }
        if (newPass.length < 6) { $('#password-error').addClass('show').text('Password must be at least 6 characters.'); return; }
        ieAjax('ie_change_password', { current_password: current, new_password: newPass, confirm_password: confirm }, this).done(function(res) {
            if (res.success) { $('#curr-password, #new-password, #confirm-new-password').val(''); Toast.show(res.data.message || 'Password updated!', 'success'); }
            else { $('#password-error').addClass('show').text(res.data.message || 'Failed.'); }
        });
    });

    /* SAVED PROVIDERS */
    const FAVORITES_PER_PAGE = 3;
    let favoritesCache = [];
    let favoritesPage = 1;

    function getFavoritesPaginationPages(currentPage, totalPages) {
        if (totalPages <= 7) {
            return Array.from({ length: totalPages }, function(_, i) { return i + 1; });
        }

        const pages = new Set([1, totalPages, currentPage, currentPage - 1, currentPage + 1]);
        const sorted = Array.from(pages).filter(function(p) { return p >= 1 && p <= totalPages; }).sort(function(a, b) { return a - b; });
        const result = [];
        let prev = 0;

        sorted.forEach(function(page) {
            if (prev && page - prev > 1) {
                result.push('ellipsis');
            }
            result.push(page);
            prev = page;
        });

        return result;
    }

    function buildFavoritesPagination(total, currentPage) {
        const totalPages = Math.ceil(total / FAVORITES_PER_PAGE);
        const i18n = window.IE_I18N || {};

        if (!total || totalPages <= 1) {
            $('#favorites-pagination-wrap').attr('hidden', true);
            $('#favorites-pagination').empty();
            $('#favorites-pagination-info').empty();
            return;
        }

        const showingFrom = ((currentPage - 1) * FAVORITES_PER_PAGE) + 1;
        const showingTo = Math.min(currentPage * FAVORITES_PER_PAGE, total);
        const infoTemplate = i18n.paginationShowingFavorites || i18n.paginationShowing || 'Showing %1$d–%2$d of %3$d saved providers';
        const infoText = infoTemplate
            .replace('%1$d', showingFrom)
            .replace('%2$d', showingTo)
            .replace('%3$d', total);

        let html = `<button type="button" class="page-btn page-btn-nav" data-page="${currentPage - 1}" ${currentPage <= 1 ? 'disabled' : ''} aria-label="${i18n.paginationPrevious || 'Previous'}">
            <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
            <span>${i18n.paginationPrevious || 'Previous'}</span>
        </button>`;

        getFavoritesPaginationPages(currentPage, totalPages).forEach(function(item) {
            if (item === 'ellipsis') {
                html += '<span class="page-ellipsis" aria-hidden="true">…</span>';
                return;
            }

            const isActive = item === currentPage;
            html += `<button type="button" class="page-btn ${isActive ? 'active' : ''}" data-page="${item}" aria-label="Page ${item}" ${isActive ? 'aria-current="page"' : ''}>${item}</button>`;
        });

        html += `<button type="button" class="page-btn page-btn-nav" data-page="${currentPage + 1}" ${currentPage >= totalPages ? 'disabled' : ''} aria-label="${i18n.paginationNext || 'Next'}">
            <span>${i18n.paginationNext || 'Next'}</span>
            <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
        </button>`;

        $('#favorites-pagination-info').text(infoText);
        $('#favorites-pagination').html(html);
        $('#favorites-pagination-wrap').removeAttr('hidden');
    }

    function renderSavedProvidersPage() {
        const $grid = $('#saved-providers-grid');

        if (!favoritesCache.length) {
            $grid.html(`<div class="no-results" style="grid-column:1/-1;text-align:center;padding:60px 20px"><div style="font-size:3rem;margin-bottom:12px">❤️</div><h3 style="font-family:var(--font-body);margin-bottom:8px">No saved providers yet</h3><p style="color:var(--color-text-muted);font-size:0.875rem;margin-bottom:16px">Browse providers and tap the heart icon to save them here.</p><a href="${(IE_AJAX.urls && IE_AJAX.urls.browse) || '/browse/'}" style="color:var(--color-primary);font-weight:600">Browse Providers →</a></div>`);
            buildFavoritesPagination(0, 1);
            return;
        }

        const total = favoritesCache.length;
        const totalPages = Math.ceil(total / FAVORITES_PER_PAGE);
        if (favoritesPage > totalPages) {
            favoritesPage = totalPages;
        }
        if (favoritesPage < 1) {
            favoritesPage = 1;
        }

        const start = (favoritesPage - 1) * FAVORITES_PER_PAGE;
        const pageItems = favoritesCache.slice(start, start + FAVORITES_PER_PAGE);
        $grid.html(pageItems.map(buildFeaturedProviderCard).join(''));
        buildFavoritesPagination(total, favoritesPage);
    }

    function loadSavedProviders() {
        const $grid = $('#saved-providers-grid');
        $grid.html('<div style="text-align:center;padding:60px;grid-column:1/-1;color:var(--color-text-muted)"><div class="spinner" style="margin:0 auto 12px"></div><p>Loading saved providers...</p></div>');
        $('#favorites-pagination-wrap').attr('hidden', true);
        ieAjax('ie_get_wishlist', {}).done(function(res) {
            if (res.success && res.data.providers && res.data.providers.length) {
                favoritesCache = res.data.providers;
                favoritesPage = 1;
                renderSavedProvidersPage();
            } else {
                favoritesCache = [];
                favoritesPage = 1;
                renderSavedProvidersPage();
            }
        }).fail(function() {
            favoritesCache = [];
            $grid.html('<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--color-text-muted)">Failed to load saved providers.</div>');
            buildFavoritesPagination(0, 1);
        });
    }

    $(document).on('click', '#favorites-pagination .page-btn:not(:disabled)', function() {
        favoritesPage = parseInt($(this).data('page'), 10) || 1;
        renderSavedProvidersPage();
        const $panel = $('#panel-saved');
        if ($panel.length) {
            $('html, body').animate({ scrollTop: $panel.offset().top - 90 }, 300);
        }
    });

    if ($('#saved-providers-grid').length && $('#panel-saved').hasClass('active')) {
        loadSavedProviders();
        $('.dashboard-nav-item[data-panel="saved"]').data('loaded', true);
    }

    /* CLIENT MESSAGES */
    let conversationsCache = [];
    let activeChatProviderId = null;
    let activeProviderCustomerId = null;
    let pendingClientAttachment = null;
    let pendingProviderAttachment = null;
    let providerChatPollFn = null;
    let providerChatRefreshFn = null;
    let clientChatPollTimer = null;
    let clientChatLastSignature = '';
    let messageNotifyTimer = null;
    let lastMessageNotifyCount = null;
    const CHAT_POLL_MS = 2000;
    const MESSAGE_NOTIFY_POLL_MS = 2000;

    function formatMessageNotifyCount(count) {
        const n = parseInt(count, 10) || 0;
        return n > 99 ? '99+' : String(n);
    }

    function hasMessageNotifyTargets() {
        return $('#btn-profile-message-notify').length
            || $('#dashboard-nav-message-count').length
            || $('[data-header-notify-badge]').length;
    }

    function isUserDashboardPage() {
        return $('body').hasClass('ie-user-dashboard') || $('.account-page-wrap.client-profile-page').length > 0;
    }

    function updateMessageNotifyBadge(count) {
        const $btn = $('#btn-profile-message-notify');
        const $badge = $('#profile-message-notify-count');
        const $navBadge = $('#dashboard-nav-message-count');
        const $navItem = $('.dashboard-nav-item[data-panel="messages"]');
        const $headerBadges = $('[data-header-notify-badge]');
        const $headerToggles = $('.header-user-menu__toggle');
        const n = parseInt(count, 10) || 0;
        const label = formatMessageNotifyCount(n);

        if ($badge.length) {
            if (n > 0) {
                $badge.text(label).prop('hidden', false);
            } else {
                $badge.prop('hidden', true).text('0');
            }
        }

        if ($btn.length) {
            if (n > 0) {
                $btn.addClass('has-unread');
                $btn.attr(
                    'aria-label',
                    `${(IE_I18N && IE_I18N.newMessages) || 'New messages'} (${n})`
                );
            } else {
                $btn.removeClass('has-unread');
                $btn.attr('aria-label', (IE_I18N && IE_I18N.viewMessages) || 'View messages');
            }

            if (lastMessageNotifyCount !== null && n > lastMessageNotifyCount) {
                $btn.addClass('is-pulse');
                setTimeout(function() {
                    $btn.removeClass('is-pulse');
                }, 1200);
            }
        }

        if ($navBadge.length) {
            if (n > 0) {
                $navBadge.text(label).prop('hidden', false);
                $navItem.addClass('has-unread');
            } else {
                $navBadge.prop('hidden', true).text('0');
                $navItem.removeClass('has-unread');
            }
        }

        if ($headerBadges.length) {
            if (isUserDashboardPage()) {
                $headerBadges.prop('hidden', true);
            } else {
                $headerBadges.each(function() {
                    const $el = $(this);
                    if (n > 0) {
                        $el.text(label).prop('hidden', false);
                    } else {
                        $el.prop('hidden', true).text('0');
                    }
                });
            }
        }

        if ($headerToggles.length) {
            if (isUserDashboardPage()) {
                $headerToggles.removeClass('has-unread');
                $headerToggles.attr('aria-label', (IE_I18N && IE_I18N.accountMenu) || 'Account menu');
            } else {
                $headerToggles.toggleClass('has-unread', n > 0);
                $headerToggles.attr(
                    'aria-label',
                    n > 0
                        ? `${(IE_I18N && IE_I18N.newMessages) || 'New messages'} (${n})`
                        : ((IE_I18N && IE_I18N.accountMenu) || 'Account menu')
                );
            }
        }

        lastMessageNotifyCount = n;
    }

    function pollMessageNotifications() {
        if (!hasMessageNotifyTargets()) {
            return;
        }

        if (document.hidden) {
            return;
        }

        ieAjax('ie_get_unread_message_count', {}).done(function(res) {
            if (res.success && typeof res.data.unread !== 'undefined') {
                updateMessageNotifyBadge(res.data.unread);
            }
        });
    }

    function stopMessageNotifyPolling() {
        if (messageNotifyTimer) {
            clearInterval(messageNotifyTimer);
            messageNotifyTimer = null;
        }
    }

    function startMessageNotifyPolling() {
        stopMessageNotifyPolling();
        if (!hasMessageNotifyTargets()) {
            return;
        }

        pollMessageNotifications();
        messageNotifyTimer = setInterval(pollMessageNotifications, MESSAGE_NOTIFY_POLL_MS);
    }

    function initMessageNotifyWatcher() {
        if (!hasMessageNotifyTargets()) {
            return;
        }

        startMessageNotifyPolling();

        document.addEventListener('visibilitychange', function() {
            if (!document.hidden) {
                pollMessageNotifications();
            }
        });
    }

    function pollClientChatThread() {
        if (!activeChatProviderId || !$('#panel-messages').hasClass('active')) {
            return;
        }

        ieAjax('ie_get_chat_thread', { provider_id: activeChatProviderId }).done(function(res) {
            if (!res.success) {
                return;
            }

            const signature = getChatSignature(res.data.messages || []);
            if (signature !== clientChatLastSignature) {
                renderChatMessages(res.data.messages || [], true);
            }
            pollMessageNotifications();
        });
    }

    function pollClientConversations() {
        if (!$('#panel-messages').hasClass('active')) {
            return;
        }

        refreshConversationList();
    }

    function getChatSignature(messages) {
        return (messages || []).map(function(m) {
            return `${m.id || 0}:${m.time || ''}:${m.body || ''}:${(m.attachment && m.attachment.id) || 0}`;
        }).join('|');
    }

    function stopClientChatPolling() {
        if (clientChatPollTimer) {
            clearInterval(clientChatPollTimer);
            clientChatPollTimer = null;
        }
    }

    function startClientChatPolling() {
        stopClientChatPolling();
        if (!$('#panel-messages').hasClass('active')) {
            return;
        }

        pollClientChatThread();
        pollClientConversations();

        clientChatPollTimer = setInterval(function() {
            pollClientChatThread();
            pollClientConversations();
        }, CHAT_POLL_MS);
    }

    function formatChatTime(value) {
        if (!value) return '';
        try {
            const date = new Date(value.replace(' ', 'T'));
            const now = new Date();
            const sameDay = date.toDateString() === now.toDateString();
            if (sameDay) {
                return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
            }
            return date.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric' });
        } catch (e) {
            return '';
        }
    }

    function buildMessageBubbleMeta(time, isMine) {
        const formatted = formatChatTime(time);
        if (!formatted) {
            return '';
        }

        const checkIcon = isMine
            ? '<i class="fa-solid fa-check client-messages-bubble__status" aria-hidden="true"></i>'
            : '';

        return `<span class="client-messages-bubble__meta"><span class="client-messages-bubble__time">${esc(formatted)}</span>${checkIcon}</span>`;
    }

    function buildChatAttachmentBlock(m) {
        const att = m.attachment;
        if (!att || !att.url) {
            return '';
        }

        const messageId = m.id || 0;
        const downloadUrl = att.download_url || att.url;
        const downloadLabel = (IE_I18N && IE_I18N.download) || 'Download';
        const name = att.name || 'File';
        const sizeLabel = att.size_label || '';
        const icon = att.icon || 'fa-file-lines';

        const downloadBtn = `<a href="${esc(downloadUrl)}" class="client-messages-bubble__doc-download"><i class="fa-solid fa-download" aria-hidden="true"></i><span>${esc(downloadLabel)}</span></a>`;

        if (att.type === 'image') {
            return `<div class="client-messages-bubble__media-wrap">` +
                `<a href="${esc(att.url)}" class="client-messages-bubble__media-link" target="_blank" rel="noopener noreferrer">` +
                `<img src="${esc(att.url)}" alt="${esc(name)}" class="client-messages-bubble__media client-messages-bubble__media--image">` +
                `</a>${downloadBtn}</div>`;
        }

        if (att.type === 'video') {
            return `<div class="client-messages-bubble__media-wrap">` +
                `<video class="client-messages-bubble__media client-messages-bubble__media--video" controls preload="metadata" src="${esc(att.url)}"></video>` +
                `${downloadBtn}</div>`;
        }

        return `<div class="client-messages-bubble__doc">` +
            `<div class="client-messages-bubble__doc-icon"><i class="fa-solid ${esc(icon)}" aria-hidden="true"></i></div>` +
            `<div class="client-messages-bubble__doc-info">` +
            `<strong class="client-messages-bubble__doc-name">${esc(name)}</strong>` +
            (sizeLabel ? `<span class="client-messages-bubble__doc-size">${esc(sizeLabel)}</span>` : '') +
            `</div>${downloadBtn}</div>`;
    }

    function buildChatBubbleContent(m) {
        let html = '';

        if (m.attachment && m.attachment.url) {
            html += buildChatAttachmentBlock(m);
        }

        if (m.body) {
            html += `<div class="client-messages-bubble__text">${esc(m.body)}</div>`;
        }

        if (!html) {
            html = `<div class="client-messages-bubble__text">${esc((IE_I18N && IE_I18N.attachmentSent) || 'Attachment')}</div>`;
        }

        return html;
    }

    function updateChatAttachmentPreview(context) {
        const isClient = context === 'client';
        const file = isClient ? pendingClientAttachment : pendingProviderAttachment;
        const $preview = isClient ? $('#chat-attachment-preview') : $('#provider-chat-attachment-preview');

        if (!$preview.length) {
            return;
        }

        if (!file) {
            $preview.prop('hidden', true).empty();
            return;
        }

        $preview.prop('hidden', false).html(
            `<span class="client-messages-chat__attachment-chip">` +
            `<i class="fa-solid fa-paperclip" aria-hidden="true"></i>` +
            `<span class="client-messages-chat__attachment-name">${esc(file.name)}</span>` +
            `<button type="button" class="client-messages-chat__attachment-remove" data-context="${context}" aria-label="${esc((IE_I18N && IE_I18N.removeAttachment) || 'Remove attachment')}">&times;</button>` +
            `</span>`
        );
    }

    function clearChatAttachment(context) {
        if (context === 'client') {
            pendingClientAttachment = null;
            $('#chat-attachment-input').val('');
        } else {
            pendingProviderAttachment = null;
            $('#provider-chat-attachment-input').val('');
        }
        updateChatAttachmentPreview(context);
    }

    function queueChatAttachment(fileInput, context) {
        const file = fileInput && fileInput.files ? fileInput.files[0] : null;
        if (!file) {
            return;
        }

        if (context === 'client') {
            pendingClientAttachment = file;
        } else {
            pendingProviderAttachment = file;
        }

        updateChatAttachmentPreview(context);
        fileInput.value = '';
    }

    function submitChatPayload(context) {
        const isClient = context === 'client';
        const threadId = isClient ? activeChatProviderId : activeProviderCustomerId;
        const $input = isClient ? $('#chat-message-input') : $('#provider-chat-message-input');
        const $sendBtn = isClient ? $('#btn-send-chat') : $('#btn-provider-send-chat');
        const pendingFile = isClient ? pendingClientAttachment : pendingProviderAttachment;
        const message = $input.val().trim();

        if (!threadId) {
            Toast.show((IE_I18N && IE_I18N.selectConversation) || 'Select a conversation first.', 'error');
            return;
        }

        if (!message && !pendingFile) {
            return;
        }

        $sendBtn.prop('disabled', true);

        function onSendSuccess() {
            $input.val('');
            clearChatAttachment(context);

            if (isClient) {
                pollClientChatThread();
                refreshConversationList();
            } else if (providerChatPollFn) {
                providerChatPollFn();
            }
            if (!isClient && providerChatRefreshFn) {
                providerChatRefreshFn();
            }
        }

        function onSendError(message) {
            Toast.show(message || 'Failed to send.', 'error');
        }

        if (pendingFile) {
            const formData = new FormData();
            formData.append('action', isClient ? 'ie_send_chat_message' : 'ie_send_provider_chat_message');
            formData.append('nonce', IE_AJAX.nonce);
            formData.append('chat_attachment', pendingFile);
            formData.append(isClient ? 'provider_id' : 'customer_id', threadId);
            if (message) {
                formData.append('message', message);
            }

            $.ajax({
                url: IE_AJAX.url,
                method: 'POST',
                dataType: 'json',
                dataFilter: ieParseAjaxResponse,
                data: formData,
                processData: false,
                contentType: false,
            }).done(function(res) {
                if (res.success) {
                    onSendSuccess();
                } else {
                    onSendError((res.data && res.data.message) || 'Failed to send file.');
                }
            }).fail(function(xhr) {
                let message = 'Connection error. Please try again.';
                if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    message = xhr.responseJSON.data.message;
                }
                onSendError(message);
            }).always(function() {
                $sendBtn.prop('disabled', false);
            });

            return;
        }

        ieAjax(isClient ? 'ie_send_chat_message' : 'ie_send_provider_chat_message', {
            [isClient ? 'provider_id' : 'customer_id']: threadId,
            message: message,
        }).done(function(res) {
            if (res.success) {
                onSendSuccess();
            } else {
                onSendError((res.data && res.data.message) || 'Failed to send.');
            }
        }).fail(function() {
            onSendError('Connection error. Please try again.');
        }).always(function() {
            $sendBtn.prop('disabled', false);
        });
    }

    function buildConversationItem(c) {
        return `
        <button type="button" class="client-messages-item${String(activeChatProviderId) === String(c.id) ? ' is-active' : ''}" data-provider-id="${c.id}">
            <img src="${esc(c.avatar)}" alt="${esc(c.name)}" class="client-messages-item__avatar">
            <span class="client-messages-item__content">
                <span class="client-messages-item__top">
                    <strong class="client-messages-item__name">${esc(c.name)}</strong>
                    <span class="client-messages-item__time">${esc(formatChatTime(c.last_time))}</span>
                </span>
                <span class="client-messages-item__preview">${esc(c.last_message)}</span>
            </span>
        </button>`;
    }

    function renderConversationList(list) {
        const $list = $('#messages-conversation-list');
        $('#messages-count').text(list.length);

        if (!list.length) {
            const browse = (IE_AJAX.urls && IE_AJAX.urls.browse) || '/browse/';
            $list.html(`
                <div class="client-messages-list__empty">
                    <p>${esc((IE_I18N && IE_I18N.noConversations) || 'No conversations yet')}</p>
                    <a href="${browse}">${esc((IE_I18N && IE_I18N.browseProviders) || 'Browse Providers')}</a>
                </div>`);
            return;
        }

        $list.html(list.map(buildConversationItem).join(''));
    }

    function initMessageTimes() {
        $('[data-time]').each(function() {
            const $el = $(this);
            const raw = $el.attr('data-time');
            if (!raw) {
                return;
            }
            const isMine = $el.closest('.client-messages-bubble-wrap').hasClass('is-mine');
            $el.replaceWith(buildMessageBubbleMeta(raw, isMine));
        });
    }

    function isMobileMessagesView() {
        return window.matchMedia('(max-width: 767px)').matches;
    }

    function setMessagesMobileView(openChat) {
        const $layout = $('.client-messages-layout');
        if (!$layout.length) {
            return;
        }

        if (!isMobileMessagesView()) {
            $layout.removeClass('is-chat-open');
            return;
        }

        if (openChat) {
            $layout.addClass('is-chat-open');
        } else {
            $layout.removeClass('is-chat-open');
        }
    }

    function scrollToMobileChat(chatAreaId) {
        if (!isMobileMessagesView()) {
            return;
        }

        const chatArea = document.getElementById(chatAreaId || 'messages-chat-area');
        if (chatArea) {
            chatArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    function syncConversationsCache() {
        ieAjax('ie_get_conversations', { target_provider: activeChatProviderId || '' }).done(function(res) {
            if (res.success) {
                conversationsCache = res.data.conversations || [];
                $('#messages-count').text(conversationsCache.length);
                if (typeof res.data.unread !== 'undefined') {
                    updateMessageNotifyBadge(res.data.unread);
                }
            }
        });
    }

    function refreshConversationList() {
        ieAjax('ie_get_conversations', { target_provider: activeChatProviderId || '' }).done(function(res) {
            if (res.success) {
                conversationsCache = res.data.conversations || [];
                renderConversationList(conversationsCache);
                initMessageTimes();
                if (typeof res.data.unread !== 'undefined') {
                    updateMessageNotifyBadge(res.data.unread);
                }
            }
        });
    }

    function loadConversations() {
        const $list = $('#messages-conversation-list');
        const hasItems = $list.find('.client-messages-item').length > 0;

        if (!hasItems) {
            $list.html(`<div class="client-messages-list__loading"><div class="spinner"></div><p>${esc((IE_I18N && IE_I18N.loadingMessages) || 'Loading messages...')}</p></div>`);
        }

        ieAjax('ie_get_conversations', { target_provider: activeChatProviderId || '' }).done(function(res) {
            if (res.success) {
                conversationsCache = res.data.conversations || [];
                if (typeof res.data.unread !== 'undefined') {
                    updateMessageNotifyBadge(res.data.unread);
                }
                if (conversationsCache.length && !activeChatProviderId) {
                    activeChatProviderId = String(conversationsCache[0].id);
                }
                renderConversationList(conversationsCache);
                initMessageTimes();
                if (activeChatProviderId) {
                    openChat(activeChatProviderId);
                } else {
                    startClientChatPolling();
                }
            } else if (!hasItems) {
                $list.html('<div class="client-messages-list__empty"><p>Failed to load conversations.</p></div>');
            }
        }).fail(function() {
            if (!hasItems) {
                $list.html('<div class="client-messages-list__empty"><p>Failed to load conversations.</p></div>');
            }
        });
    }

    function renderChatMessages(messages, forceScroll) {
        const $body = $('#messages-chat-body');
        const signature = getChatSignature(messages);
        if (!forceScroll && signature === clientChatLastSignature) {
            return;
        }
        clientChatLastSignature = signature;

        if (!messages || !messages.length) {
            $body.html(`<div class="client-messages-chat__thread-empty"><p>${esc((IE_I18N && IE_I18N.startChatHint) || 'Send a message to start the conversation.')}</p></div>`);
            return;
        }

        $body.html(messages.map(function(m) {
            const isMine = m.sender === 'customer';
            return `
            <div class="client-messages-bubble-wrap${isMine ? ' is-mine' : ''}">
                <div class="client-messages-bubble">${buildChatBubbleContent(m)}</div>
                ${buildMessageBubbleMeta(m.time, isMine)}
            </div>`;
        }).join(''));

        $body.scrollTop($body[0].scrollHeight);
    }

    function closeChatHeadMenu() {
        const $menu = $('#chat-head-menu');
        if (!$menu.length) {
            return;
        }
        $menu.removeClass('is-open');
        $('#btn-chat-head-menu').attr('aria-expanded', 'false');
        $('#chat-head-dropdown').prop('hidden', true);
    }

    function toggleChatHeadMenu() {
        const $menu = $('#chat-head-menu');
        const $dropdown = $('#chat-head-dropdown');
        if (!$menu.length || !$dropdown.length) {
            return;
        }

        if (!activeChatProviderId) {
            closeChatHeadMenu();
            return;
        }

        const willOpen = !$menu.hasClass('is-open');
        closeChatHeadMenu();
        if (willOpen) {
            $menu.addClass('is-open');
            $('#btn-chat-head-menu').attr('aria-expanded', 'true');
            $dropdown.prop('hidden', false);
        }
    }

    function deleteActiveChatConversation() {
        if (!activeChatProviderId) {
            return;
        }

        const confirmMsg = (IE_I18N && IE_I18N.confirmDeleteChat) || 'Delete this conversation and all messages with this provider?';
        if (!window.confirm(confirmMsg)) {
            return;
        }

        closeChatHeadMenu();
        ieAjax('ie_delete_chat_conversation', { provider_id: activeChatProviderId }).done(function(res) {
            if (res.success) {
                activeChatProviderId = null;
                stopClientChatPolling();
                clearChatAttachment('client');
                setMessagesMobileView(false);
                $('#messages-chat-body').html(`<div class="client-messages-chat__thread-empty"><p>${esc((IE_I18N && IE_I18N.selectConversation) || 'Select a conversation to start chatting.')}</p></div>`);
                $('#chat-head-user-link').attr('href', '#');
                $('#chat-head-name').text('');
                $('#chat-head-role').text('');
                loadConversations();
                pollMessageNotifications();
                Toast.show((res.data && res.data.message) || (IE_I18N && IE_I18N.conversationDeleted) || 'Conversation deleted.', 'success');
            } else {
                Toast.show((res.data && res.data.message) || 'Failed to delete conversation.', 'error');
            }
        }).fail(function() {
            Toast.show('Connection error. Please try again.', 'error');
        });
    }

    function openChat(providerId) {
        activeChatProviderId = String(providerId);
        clientChatLastSignature = '';
        clearChatAttachment('client');
        $('.client-messages-item').removeClass('is-active');
        $(`.client-messages-item[data-provider-id="${activeChatProviderId}"]`).addClass('is-active');

        setMessagesMobileView(true);
        scrollToMobileChat('messages-chat-area');
        $('#messages-chat-body').html(`<div class="client-messages-list__loading"><div class="spinner"></div></div>`);

        ieAjax('ie_get_chat_thread', { provider_id: providerId }).done(function(res) {
            if (!res.success) {
                Toast.show((res.data && res.data.message) || 'Failed to load chat.', 'error');
                $('#messages-chat-body').html(`<div class="client-messages-chat__thread-empty"><p>${esc((IE_I18N && IE_I18N.startChatHint) || 'Send a message to start the conversation.')}</p></div>`);
                stopClientChatPolling();
                return;
            }
            const p = res.data.provider;
            $('#chat-head-avatar').attr({ src: p.avatar, alt: p.name });
            $('#chat-head-name').text(p.name);
            $('#chat-head-role').text(p.category ? `${(IE_I18N && IE_I18N.specialist) || 'Specialist'} — ${p.category}` : '');
            $('#chat-head-user-link').attr('href', p.permalink || '#');
            closeChatHeadMenu();
            renderChatMessages(res.data.messages || [], true);
            startClientChatPolling();
            pollMessageNotifications();
        }).fail(function() {
            Toast.show('Connection error. Please try again.', 'error');
            stopClientChatPolling();
        });
    }

    function sendChatMessage() {
        submitChatPayload('client');
    }

    $(document).on('click', '.client-messages-item', function() {
        openChat(String($(this).attr('data-provider-id')));
    });

    $('#btn-messages-back').on('click', function() {
        setMessagesMobileView(false);
        stopClientChatPolling();
        const listArea = document.getElementById('messages-conversation-list');
        if (listArea) {
            listArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });

    $(window).on('resize', function() {
        if (!isMobileMessagesView()) {
            setMessagesMobileView(false);
        }
    });

    $(document).on('click', '.dashboard-nav-item[data-panel]', function() {
        const panel = $(this).data('panel');
        if (panel !== 'messages') {
            stopClientChatPolling();
        }
    });

    $('#btn-send-chat').on('click', sendChatMessage);
    $('#chat-message-input').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            sendChatMessage();
        }
    });

    $('#btn-chat-attach').on('click', function() {
        $('#chat-attachment-input').trigger('click');
    });

    $('#btn-chat-head-menu').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        toggleChatHeadMenu();
    });

    $('#btn-delete-chat-conversation').on('click', function(e) {
        e.preventDefault();
        deleteActiveChatConversation();
    });

    $(document).on('click', function(e) {
        if (!$(e.target).closest('#chat-head-menu').length) {
            closeChatHeadMenu();
        }
    });

    $('#chat-attachment-input').on('change', function() {
        queueChatAttachment(this, 'client');
    });

    $(document).on('click', '.client-messages-chat__attachment-remove', function() {
        clearChatAttachment(String($(this).data('context') || 'client'));
    });

    $('#messages-search').on('input', function() {
        const q = $(this).val().trim().toLowerCase();
        if (!q) {
            renderConversationList(conversationsCache);
            return;
        }
        renderConversationList(conversationsCache.filter(function(c) {
            return (c.name || '').toLowerCase().includes(q) || (c.last_message || '').toLowerCase().includes(q);
        }));
    });

    if ($('.client-profile-page').length && !$('.provider-profile-page').length && $('#panel-messages').length) {
        const presetProvider = $('#panel-messages').data('active-provider');
        if (presetProvider) {
            activeChatProviderId = String(presetProvider);
        }
        initMessageTimes();
        if ($('#panel-messages').hasClass('active') && activeChatProviderId) {
            setMessagesMobileView(true);
        } else {
            setMessagesMobileView();
        }
        const $chatBody = $('#messages-chat-body');
        if ($chatBody.length) {
            $chatBody.scrollTop($chatBody[0].scrollHeight);
        }
        syncConversationsCache();
        if ($('#panel-messages').hasClass('active')) {
            $('.dashboard-nav-item[data-panel="messages"]').data('loaded', true);
            loadConversations();
        }
    }

    function syncUserTypeSelection() {
        const $checked = $('input[name="reg-user-type"]:checked');
        $('.user-type-option').removeClass('is-selected');
        if ($checked.length) {
            $checked.closest('.user-type-option').addClass('is-selected');
        }
        toggleRegProviderFields();
    }

    function toggleRegProviderFields() {
        const isProvider = $('input[name="reg-user-type"]:checked').val() === 'provider';
        $('#reg-provider-fields').toggleClass('is-visible', isProvider);
    }

    $(document).on('change', 'input[name="reg-user-type"]', syncUserTypeSelection);

    $(document).on('click', '.user-type-option', function() {
        const $radio = $(this).find('input[name="reg-user-type"]');
        $radio.prop('checked', true);
        syncUserTypeSelection();
    });

    if ($('#auth-panel-register').length) {
        syncUserTypeSelection();
    }

    /* PASSWORD TOGGLE */
    $(document).on('click', '.password-toggle', function() {
        const $input = $('#' + $(this).data('target'));
        const isPwd = $input.attr('type') === 'password';
        $input.attr('type', isPwd ? 'text' : 'password');
        $(this).html(isPwd
            ? '<i class="fa-regular fa-eye-slash" aria-hidden="true"></i>'
            : '<i class="fa-regular fa-eye" aria-hidden="true"></i>');
    });

    /* ESC KEY */
    $(document).on('keydown', function(e) { if (e.key === 'Escape') { $('.modal-overlay.open').removeClass('open'); $('body').css('overflow',''); } });

    /* SINGLE PROVIDER — SEND MESSAGE */
    $(document).on('click', '#btn-send-message', function() {
        const name = $('#msg-name').val().trim(), email = $('#msg-email').val().trim(), phone = $('#msg-phone').val().trim(), body = $('#msg-body').val().trim(), pid = $('#msg-provider-id').val();
        $('#msg-error, #msg-success').removeClass('show');
        if (!name || !email || !body) { $('#msg-error').addClass('show').text('Please fill in all required fields.'); return; }
        ieAjax('ie_send_message', { provider_id: pid, name, email, phone, message: body }, this).done(function(res) {
            if (res.success) { $('#msg-success').addClass('show').text('Message sent successfully!'); $('#msg-name, #msg-email, #msg-phone, #msg-body').val(''); }
            else { $('#msg-error').addClass('show').text(res.data.message || 'Failed to send.'); }
        });
    });

    /* STAR RATING PICKER */
    $(document).on('mouseenter', '.star-pick', function() {
        const val = $(this).data('val');
        $('.star-pick').each(function() { $(this).css('color', $(this).data('val') <= val ? '#f59e0b' : '#d1d5db'); });
    }).on('mouseleave', '#star-rating', function() {
        const selected = parseInt($('#review-rating').val()) || 5;
        $('.star-pick').each(function() { $(this).css('color', $(this).data('val') <= selected ? '#f59e0b' : '#d1d5db'); });
    }).on('click', '.star-pick', function() {
        const val = $(this).data('val');
        $('#review-rating').val(val);
        $('.star-pick').each(function() { $(this).css('color', $(this).data('val') <= val ? '#f59e0b' : '#d1d5db'); });
    });
    const initRating = parseInt($('#review-rating').val()) || 5;
    $('.star-pick').each(function() { $(this).css('color', $(this).data('val') <= initRating ? '#f59e0b' : '#d1d5db'); });

    /* SUBMIT REVIEW */
    $(document).on('click', '#btn-submit-review', function() {
        const body = $('#review-body').val().trim(), rating = $('#review-rating').val(), providerId = $('#review-provider-id').val();
        $('#review-error, #review-success').removeClass('show');
        if (!body) { $('#review-error').addClass('show').text('Please write your review.'); return; }
        ieAjax('ie_submit_review', { provider_id: providerId, rating, review: body }, this).done(function(res) {
            if (res.success) { $('#review-success').addClass('show').text(res.data.message || 'Review submitted!'); $('#review-body').val(''); setTimeout(() => location.reload(), 1500); }
            else { $('#review-error').addClass('show').text(res.data.message || 'Failed to submit.'); }
        });
    });

    /* MY BUSINESS SAVE */
    $('#btn-save-business').on('click', function() {
        $('#biz-error').removeClass('show');
        ieAjax('ie_update_provider', {
            provider_id: $('#biz-provider-id').val(), business_name: $('#biz-name').val().trim(),
            about: $('#biz-about').val().trim(), phone: $('#biz-phone').val().trim(),
            service_area: $('#biz-area').val().trim(),
            price_from: $('#biz-price').val().trim(), experience: $('#biz-exp').val().trim(),
            availability: $('#biz-avail').val(), website: $('#biz-website').val().trim(),
        }, this).done(function(res) {
            if (res.success) { Toast.show(res.data.message || 'Business info updated!', 'success'); }
            else { $('#biz-error').addClass('show').text(res.data.message || 'Failed to update.'); }
        });
    });

    /* PROVIDER PROFILE DASHBOARD */
    if ($('.provider-profile-page').length) {
        let profileProgressHideTimer = null;
        let profileProgressDismissed = false;

        function hideProviderProfileProgress() {
            const $wrap = $('#provider-profile-progress');
            if (!$wrap.length || profileProgressDismissed) {
                return;
            }

            profileProgressDismissed = true;

            if (profileProgressHideTimer) {
                clearTimeout(profileProgressHideTimer);
                profileProgressHideTimer = null;
            }

            $wrap.addClass('is-hiding');

            setTimeout(function() {
                $wrap.remove();
            }, 450);

            if (window.IE_AJAX && IE_AJAX.url) {
                $.ajax({
                    url: IE_AJAX.url,
                    method: 'POST',
                    dataType: 'json',
                    dataFilter: ieParseAjaxResponse,
                    data: {
                        action: 'ie_dismiss_profile_progress',
                        nonce: IE_AJAX.nonce,
                    },
                });
            }
        }

        function scheduleProviderProfileProgressHide() {
            const $wrap = $('#provider-profile-progress');
            if (!$wrap.length || profileProgressDismissed || profileProgressHideTimer) {
                return;
            }

            profileProgressHideTimer = setTimeout(function() {
                profileProgressHideTimer = null;
                hideProviderProfileProgress();
            }, 5000);
        }

        function collectProviderSocials() {
            const socials = [];
            $('#provider-social-list .provider-social-row').each(function() {
                const icon = $(this).find('.social-icon').val();
                const url = $(this).find('.social-url').val().trim();
                if (!url) {
                    return;
                }
                socials.push({ icon, url });
            });
            return socials;
        }

        function hasValidSocialLinks() {
            return collectProviderSocials().length >= 1;
        }

        function getWorkGalleryCount() {
            return $('#provider-work-gallery .provider-work-gallery-item').length;
        }

        function hasWorkGalleryImages() {
            return getWorkGalleryCount() >= 1;
        }

        function updateProviderProfileProgress() {
            const $wrap = $('#provider-profile-progress');
            if (!$wrap.length) {
                return;
            }

            const hasPhoto = String($wrap.data('hasPhoto')) === '1'
                || $('.dashboard-avatar').hasClass('has-image');
            const checks = [
                hasPhoto,
                $('#profile-firstname').val().trim() !== '',
                $('#profile-lastname').val().trim() !== '',
                $('#profile-email').val().trim() !== '',
                $('#biz-name').val().trim() !== '',
                $('#biz-about').val().trim() !== '',
                $('#biz-phone').val().trim() !== '',
                $('#biz-area').val().trim() !== '',
                $('#biz-exp').val().trim() !== '',
                hasValidSocialLinks(),
            ];
            const completed = checks.filter(Boolean).length;
            const total = checks.length;
            const percent = total ? Math.round((completed / total) * 100) : 0;
            const i18n = window.IE_I18N || {};

            $wrap.toggleClass('is-complete', percent >= 100);
            $wrap.find('.provider-profile-progress__value').text(`${percent}%`);
            $wrap.find('.provider-profile-progress__bar').css('width', `${percent}%`);
            $wrap.find('.provider-profile-progress__track').attr('aria-valuenow', String(percent));

            const hint = percent >= 100
                ? (i18n.profileComplete || 'Your profile information is 100% complete.')
                : `${completed} of ${total} required fields completed. ${i18n.profileIncomplete || 'Fill in all profile information to reach 100%.'}`;

            $wrap.find('.provider-profile-progress__hint').text(hint);

            if (percent >= 100) {
                scheduleProviderProfileProgressHide();
            } else if (profileProgressHideTimer) {
                clearTimeout(profileProgressHideTimer);
                profileProgressHideTimer = null;
            }
        }

        $('#panel-profile').on(
            'input change',
            '#profile-firstname, #profile-lastname, #biz-name, #biz-about, #biz-phone, #biz-area, #biz-exp, #provider-social-list .social-url',
            updateProviderProfileProgress
        );

        $('#profile-photo').on('change.providerProgress', function() {
            if (this.files && this.files[0]) {
                $('#provider-profile-progress').data('hasPhoto', 1);
            }
            updateProviderProfileProgress();
        });

        updateProviderProfileProgress();

        function getProviderServiceRowTemplate() {
            return $('#provider-service-row-template').html() || '';
        }

        function getServicePlaceholderImage() {
            return $('#provider-services-list').data('placeholder-image') || '';
        }

        function revokeServiceImagePreview($row) {
            const previewUrl = $row.data('preview-url');
            if (previewUrl) {
                URL.revokeObjectURL(previewUrl);
                $row.removeData('preview-url');
            }
        }

        function updateServiceImagePreview($row) {
            const placeholder = getServicePlaceholderImage();
            const imageId = parseInt($row.find('.svc-image-id').val(), 10) || 0;
            const $preview = $row.find('.svc-image-preview');
            const pendingUrl = $row.data('preview-url');

            if (pendingUrl) {
                $preview.attr('src', pendingUrl);
                return;
            }

            if (imageId) {
                return;
            }

            $preview.attr('src', placeholder);
        }

        $('#btn-add-service').on('click', function() {
            const template = getProviderServiceRowTemplate();
            if (!template) {
                return;
            }
            $('#provider-services-list').append(template);
        });

        $(document).on('change', '.svc-image-input', function() {
            const file = this.files[0];
            const $row = $(this).closest('.provider-service-row');
            const $preview = $row.find('.svc-image-preview');
            revokeServiceImagePreview($row);

            if (!file) {
                updateServiceImagePreview($row);
                return;
            }

            const allowed = ['image/jpeg', 'image/png', 'image/webp'];
            if (!allowed.includes(file.type)) {
                $('#services-error').addClass('show').text('Please upload a JPG, PNG, or WEBP image.');
                this.value = '';
                updateServiceImagePreview($row);
                return;
            }

            if (file.size > 5 * 1024 * 1024) {
                $('#services-error').addClass('show').text('Each service image must be smaller than 5MB.');
                this.value = '';
                updateServiceImagePreview($row);
                return;
            }

            $('#services-error').removeClass('show');
            const previewUrl = URL.createObjectURL(file);
            $row.data('preview-url', previewUrl);
            $preview.attr('src', previewUrl);
        });

        $(document).on('click', '.provider-service-remove', function() {
            revokeServiceImagePreview($(this).closest('.provider-service-row'));
            $(this).closest('.provider-service-row').remove();
        });

        function collectProviderServices() {
            const services = [];
            $('#provider-services-list .provider-service-row').each(function(index) {
                const name = $(this).find('.svc-name').val().trim();
                if (!name) {
                    return;
                }
                services.push({
                    index: index,
                    name: name,
                    price: $(this).find('.svc-price').val().trim(),
                    image_id: parseInt($(this).find('.svc-image-id').val(), 10) || 0,
                    show_publicly: $(this).find('.svc-show-publicly').is(':checked') ? 1 : 0,
                });
            });
            return services;
        }

        function buildProviderServicesFormData() {
            const formData = new FormData();
            formData.append('action', 'ie_update_provider_services');
            formData.append('nonce', IE_AJAX.nonce);
            formData.append('provider_id', $('#provider-id').val());
            formData.append('services', JSON.stringify(collectProviderServices()));

            $('#provider-services-list .provider-service-row').each(function(index) {
                const name = $(this).find('.svc-name').val().trim();
                if (!name) {
                    return;
                }
                const fileInput = $(this).find('.svc-image-input')[0];
                if (fileInput && fileInput.files[0]) {
                    formData.append('service_images[' + index + ']', fileInput.files[0]);
                }
            });

            return formData;
        }

        function getProviderSocialRowTemplate() {
            return $('#provider-social-row-template').html() || '';
        }

        $('#btn-add-social-link').on('click', function() {
            const template = getProviderSocialRowTemplate();
            if (!template) {
                return;
            }
            $('#provider-social-list').append(template);
            updateProviderProfileProgress();
        });

        $(document).on('click', '.provider-social-remove', function() {
            const $rows = $('#provider-social-list .provider-social-row');
            if ($rows.length <= 1) {
                $(this).closest('.provider-social-row').find('input, select').val('');
                updateProviderProfileProgress();
                return;
            }
            $(this).closest('.provider-social-row').remove();
            updateProviderProfileProgress();
        });

        const maxWorkGalleryImages = parseInt($('#provider-work-gallery').data('max-images'), 10) || 10;
        let workGalleryPendingKey = 0;
        let workGalleryLimitNotified = false;

        function updateWorkGalleryControls() {
            const atLimit = getWorkGalleryCount() >= maxWorkGalleryImages;
            $('#btn-add-work-images').prop('disabled', atLimit).toggleClass('is-disabled', atLimit);
        }

        function collectWorkGalleryIds() {
            const ids = [];
            $('#provider-work-gallery .provider-work-gallery-item:not(.is-pending)').each(function() {
                const id = parseInt($(this).data('id'), 10);
                if (id) {
                    ids.push(id);
                }
            });
            return ids;
        }

        function appendWorkGalleryPreview(file) {
            workGalleryPendingKey += 1;
            const key = workGalleryPendingKey;
            const previewUrl = URL.createObjectURL(file);
            const $item = $(`
                <div class="provider-work-gallery-item is-pending" data-pending-key="${key}">
                    <img src="${esc(previewUrl)}" alt="">
                    <button type="button" class="provider-work-gallery-remove" aria-label="Remove image">
                        <i class="fa-solid fa-trash-can" aria-hidden="true"></i>
                    </button>
                </div>
            `);
            $item.data('file', file);
            $('#provider-work-gallery').append($item);
        }

        $('#btn-add-work-images').on('click', function() {
            if (getWorkGalleryCount() >= maxWorkGalleryImages) {
                Toast.show((window.IE_I18N && IE_I18N.workGalleryMax) || 'You can upload up to 10 work preview images.', 'warning');
                return;
            }
            $('#work-gallery-input').trigger('click');
        });

        $('#work-gallery-input').on('change', function() {
            const files = Array.from(this.files || []);
            if (!files.length) {
                return;
            }

            let added = 0;
            files.forEach(function(file) {
                if (getWorkGalleryCount() >= maxWorkGalleryImages) {
                    return;
                }
                appendWorkGalleryPreview(file);
                added += 1;
            });

            if (added < files.length && !workGalleryLimitNotified) {
                workGalleryLimitNotified = true;
                Toast.show((window.IE_I18N && IE_I18N.workGalleryMax) || 'You can upload up to 10 work preview images.', 'warning');
                setTimeout(function() { workGalleryLimitNotified = false; }, 1500);
            }

            this.value = '';
            updateWorkGalleryControls();
            updateProviderProfileProgress();
        });

        $(document).on('click', '.provider-work-gallery-remove', function() {
            const $item = $(this).closest('.provider-work-gallery-item');
            if ($item.hasClass('is-pending')) {
                const previewUrl = $item.find('img').attr('src');
                if (previewUrl) {
                    URL.revokeObjectURL(previewUrl);
                }
            }
            $item.remove();
            updateWorkGalleryControls();
            updateProviderProfileProgress();
        });

        function renderProviderWorkGallery(gallery) {
            const $list = $('#provider-work-gallery');
            $list.find('.provider-work-gallery-item.is-pending').each(function() {
                const previewUrl = $(this).find('img').attr('src');
                if (previewUrl) {
                    URL.revokeObjectURL(previewUrl);
                }
            });
            $list.empty();

            (gallery || []).forEach(function(image) {
                if (!image || !image.id || !image.thumb) {
                    return;
                }
                $list.append(`
                    <div class="provider-work-gallery-item" data-id="${esc(String(image.id))}">
                        <img src="${esc(image.thumb)}" alt="">
                        <button type="button" class="provider-work-gallery-remove" aria-label="Remove image">
                            <i class="fa-solid fa-trash-can" aria-hidden="true"></i>
                        </button>
                    </div>
                `);
            });
            updateWorkGalleryControls();
        }

        updateWorkGalleryControls();

        function buildProviderUpdateFormData(providerId) {
            const formData = new FormData();
            formData.append('action', 'ie_update_provider');
            formData.append('nonce', IE_AJAX.nonce);
            formData.append('provider_id', providerId);
            formData.append('business_name', $('#biz-name').val().trim());
            formData.append('about', $('#biz-about').val().trim());
            formData.append('phone', $('#biz-phone').val().trim());
            formData.append('service_area', $('#biz-area').val().trim());
            formData.append('experience', $('#biz-exp').val().trim());
            formData.append('socials', JSON.stringify(collectProviderSocials()));
            formData.append('work_gallery_ids', JSON.stringify(collectWorkGalleryIds()));

            $('#provider-work-gallery .provider-work-gallery-item.is-pending').each(function() {
                const file = $(this).data('file');
                if (file) {
                    formData.append('work_gallery_files[]', file);
                }
            });

            return formData;
        }

        $('#btn-save-provider-profile').on('click', function() {
            $('#profile-error').removeClass('show');
            const $btn = $(this);
            const providerId = $('#provider-id').val();
            const origHtml = $btn.html();
            const profileFormData = new FormData();
            profileFormData.append('action', 'ie_update_profile');
            profileFormData.append('nonce', IE_AJAX.nonce);
            profileFormData.append('first_name', $('#profile-firstname').val().trim());
            profileFormData.append('last_name', $('#profile-lastname').val().trim());
            const photoInput = document.getElementById('profile-photo');
            if (photoInput && photoInput.files[0]) {
                profileFormData.append('profile_photo', photoInput.files[0]);
            }

            $btn.prop('disabled', true).html('<span class="ie-btn-spin"></span> Please wait...');

            $.ajax({
                url: IE_AJAX.url,
                method: 'POST',
                dataType: 'json',
                dataFilter: ieParseAjaxResponse,
                data: profileFormData,
                processData: false,
                contentType: false,
            }).then(function(profileRes) {
                if (!profileRes || !profileRes.success) {
                    return $.Deferred().reject({
                        message: (profileRes && profileRes.data && profileRes.data.message) || 'Failed to update profile.',
                    });
                }

                return $.ajax({
                    url: IE_AJAX.url,
                    method: 'POST',
                    dataType: 'json',
                    dataFilter: ieParseAjaxResponse,
                    data: buildProviderUpdateFormData(providerId),
                    processData: false,
                    contentType: false,
                }).then(function(bizRes) {
                    if (!bizRes || !bizRes.success) {
                        return $.Deferred().reject({
                            message: (bizRes && bizRes.data && bizRes.data.message) || 'Failed to update business info.',
                        });
                    }

                    return { profileRes, bizRes };
                });
            }).done(function(result) {
                Toast.show(result.bizRes.data.message || 'Profile updated!', 'success');

                if (result.profileRes.data.display_name) {
                    $('.dashboard-user-name').text(result.profileRes.data.display_name);
                }

                if (result.profileRes.data.avatar_url) {
                    applySavedSidebarAvatar(result.profileRes.data.avatar_url, result.profileRes.data.display_name);
                    $('#provider-profile-progress').data('hasPhoto', 1);
                }

                if (photoInput) {
                    photoInput.value = '';
                }

                if (Array.isArray(result.bizRes.data.work_gallery)) {
                    renderProviderWorkGallery(result.bizRes.data.work_gallery);
                }

                updateProviderProfileProgress();
            }).fail(function(err) {
                let message = 'Connection error. Please try again.';
                if (err && err.message) {
                    message = err.message;
                } else if (err && err.responseJSON && err.responseJSON.data && err.responseJSON.data.message) {
                    message = err.responseJSON.data.message;
                }
                $('#profile-error').addClass('show').text(message);
            }).always(function() {
                $btn.prop('disabled', false).html(origHtml);
            });
        });

        $('#btn-save-services').on('click', function() {
            $('#services-error').removeClass('show');
            const $btn = $(this);
            const origHtml = $btn.html();

            $btn.prop('disabled', true).html('<span class="ie-btn-spin"></span> Please wait...');

            $.ajax({
                url: IE_AJAX.url,
                method: 'POST',
                dataType: 'json',
                dataFilter: ieParseAjaxResponse,
                data: buildProviderServicesFormData(),
                processData: false,
                contentType: false,
            }).done(function(res) {
                if (res.success) {
                    Toast.show(res.data.message || 'Services updated!', 'success');
                    $('#provider-services-list .svc-image-input').val('');

                    if (Array.isArray(res.data.services)) {
                        res.data.services.forEach(function(service, index) {
                            const $row = $('#provider-services-list .provider-service-row').eq(index);
                            if (!$row.length) {
                                return;
                            }
                            revokeServiceImagePreview($row);
                            $row.find('.svc-image-id').val(service.image_id || 0);
                            $row.find('.svc-image-preview').attr('src', service.image_url || getServicePlaceholderImage());
                            $row.find('.svc-show-publicly').prop('checked', !!service.show_publicly);
                        });
                    }
                } else {
                    $('#services-error').addClass('show').text(res.data.message || 'Failed to update services.');
                }
            }).fail(function(xhr) {
                let message = 'Connection error. Please try again.';
                if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    message = xhr.responseJSON.data.message;
                }
                $('#services-error').addClass('show').text(message);
            }).always(function() {
                $btn.prop('disabled', false).html(origHtml);
            });
        });

        let providerConversationsCache = [];
        let providerChatPollTimer = null;
        let providerChatLastSignature = '';

        function refreshProviderConversationList() {
            ieAjax('ie_get_provider_conversations', {}).done(function(res) {
                if (res.success) {
                    providerConversationsCache = res.data.conversations || [];
                    renderProviderConversationList(providerConversationsCache);
                    if (typeof res.data.unread !== 'undefined') {
                        updateMessageNotifyBadge(res.data.unread);
                    }
                }
            });
        }

        function pollProviderChatThread() {
            if (!activeProviderCustomerId || !$('#panel-messages').hasClass('active')) {
                return;
            }

            ieAjax('ie_get_provider_customer_thread', { customer_id: activeProviderCustomerId }).done(function(res) {
                if (!res.success) {
                    return;
                }

                const signature = getChatSignature(res.data.messages || []);
                if (signature !== providerChatLastSignature) {
                    renderProviderChatMessages(res.data.messages || [], true);
                }
                pollMessageNotifications();
            });
        }

        function pollProviderConversations() {
            if (!$('#panel-messages').hasClass('active')) {
                return;
            }

            refreshProviderConversationList();
        }

        function stopProviderChatPolling() {
            if (providerChatPollTimer) {
                clearInterval(providerChatPollTimer);
                providerChatPollTimer = null;
            }
        }

        function startProviderChatPolling() {
            stopProviderChatPolling();
            if (!$('#panel-messages').hasClass('active')) {
                return;
            }

            pollProviderChatThread();
            pollProviderConversations();

            providerChatPollTimer = setInterval(function() {
                pollProviderChatThread();
                pollProviderConversations();
            }, CHAT_POLL_MS);
        }

        function renderProviderChatMessages(messages, forceScroll) {
            const $body = $('#provider-messages-chat-body');
            const signature = getChatSignature(messages);
            if (!forceScroll && signature === providerChatLastSignature) {
                return;
            }
            providerChatLastSignature = signature;

            if (!messages || !messages.length) {
                $body.html(`<div class="client-messages-chat__thread-empty"><p>${esc((IE_I18N && IE_I18N.replyToCustomers) || 'Reply to customer inquiries here.')}</p></div>`);
                return;
            }

            $body.html(messages.map(function(m) {
                const isMine = m.sender === 'provider';
                return `<div class="client-messages-bubble-wrap${isMine ? ' is-mine' : ''}">
                    <div class="client-messages-bubble">${buildChatBubbleContent(m)}</div>
                    ${buildMessageBubbleMeta(m.time, isMine)}
                </div>`;
            }).join(''));
            $body.scrollTop($body[0].scrollHeight);
        }

        function loadProviderConversations(openChatAfter) {
            const $list = $('#provider-messages-conversation-list');
            const hasItems = $list.find('.client-messages-item').length > 0;

            if (!hasItems) {
                $list.html(`<div class="client-messages-list__loading"><div class="spinner"></div><p>${esc((IE_I18N && IE_I18N.loadingMessages) || 'Loading messages...')}</p></div>`);
            }

            ieAjax('ie_get_provider_conversations', {}).done(function(res) {
                if (!res.success) {
                    if (!hasItems) {
                        $list.html('<div class="client-messages-list__empty"><p>Failed to load conversations.</p></div>');
                    }
                    return;
                }

                providerConversationsCache = res.data.conversations || [];
                renderProviderConversationList(providerConversationsCache);
                if (typeof res.data.unread !== 'undefined') {
                    updateMessageNotifyBadge(res.data.unread);
                }

                if (openChatAfter) {
                    if (!activeProviderCustomerId && providerConversationsCache.length) {
                        activeProviderCustomerId = String(providerConversationsCache[0].id);
                    }
                    if (activeProviderCustomerId) {
                        openProviderChat(activeProviderCustomerId);
                    } else {
                        startProviderChatPolling();
                    }
                }
            }).fail(function() {
                if (!hasItems) {
                    $list.html('<div class="client-messages-list__empty"><p>Failed to load conversations.</p></div>');
                }
            });
        }

        function buildProviderConversationItem(c) {
            return `
            <button type="button" class="client-messages-item${activeProviderCustomerId === String(c.id) ? ' is-active' : ''}" data-customer-id="${esc(c.id)}">
                <img src="${esc(c.avatar)}" alt="${esc(c.name)}" class="client-messages-item__avatar">
                <span class="client-messages-item__content">
                    <span class="client-messages-item__top">
                        <strong class="client-messages-item__name">${esc(c.name)}</strong>
                        <span class="client-messages-item__time" data-time="${esc(c.last_time || '')}"></span>
                    </span>
                    <span class="client-messages-item__preview">${esc(c.last_message)}</span>
                </span>
            </button>`;
        }

        function renderProviderConversationList(list) {
            const $list = $('#provider-messages-conversation-list');
            $('#provider-messages-count').text(list.length);
            if (!list.length) {
                $list.html(`<div class="client-messages-list__empty"><p>${esc((IE_I18N && IE_I18N.noCustomerMessages) || 'No customer messages yet')}</p></div>`);
                return;
            }
            $list.html(list.map(buildProviderConversationItem).join(''));
            $('[data-time]').each(function() {
                const raw = $(this).attr('data-time');
                if (raw) $(this).text(formatChatTime(raw));
            });
        }

        function closeProviderChatHeadMenu() {
            const $menu = $('#provider-chat-head-menu');
            if (!$menu.length) {
                return;
            }
            $menu.removeClass('is-open');
            $('#btn-provider-chat-head-menu').attr('aria-expanded', 'false');
            $('#provider-chat-head-dropdown').prop('hidden', true);
        }

        function toggleProviderChatHeadMenu() {
            const $menu = $('#provider-chat-head-menu');
            const $dropdown = $('#provider-chat-head-dropdown');
            if (!$menu.length || !$dropdown.length) {
                return;
            }

            if (!activeProviderCustomerId) {
                closeProviderChatHeadMenu();
                return;
            }

            const willOpen = !$menu.hasClass('is-open');
            closeProviderChatHeadMenu();
            if (willOpen) {
                $menu.addClass('is-open');
                $('#btn-provider-chat-head-menu').attr('aria-expanded', 'true');
                $dropdown.prop('hidden', false);
            }
        }

        function deleteActiveProviderChatConversation() {
            if (!activeProviderCustomerId) {
                return;
            }

            const confirmMsg = (IE_I18N && IE_I18N.confirmDeleteCustomerChat) || 'Delete this conversation and all messages with this customer?';
            if (!window.confirm(confirmMsg)) {
                return;
            }

            closeProviderChatHeadMenu();
            ieAjax('ie_delete_provider_chat_conversation', { customer_id: activeProviderCustomerId }).done(function(res) {
                if (res.success) {
                    activeProviderCustomerId = null;
                    stopProviderChatPolling();
                    clearChatAttachment('provider');
                    setMessagesMobileView(false);
                    $('#provider-messages-chat-body').html(`<div class="client-messages-chat__thread-empty"><p>${esc((IE_I18N && IE_I18N.replyToCustomers) || 'Reply to customer inquiries here.')}</p></div>`);
                    $('#provider-chat-head-name').text('');
                    $('#provider-chat-head-role').text('');
                    loadProviderConversations(false);
                    pollMessageNotifications();
                    Toast.show((res.data && res.data.message) || (IE_I18N && IE_I18N.conversationDeleted) || 'Conversation deleted.', 'success');
                } else {
                    Toast.show((res.data && res.data.message) || 'Failed to delete conversation.', 'error');
                }
            }).fail(function() {
                Toast.show('Connection error. Please try again.', 'error');
            });
        }

        function openProviderChat(customerId) {
            activeProviderCustomerId = String(customerId);
            providerChatLastSignature = '';
            clearChatAttachment('provider');
            closeProviderChatHeadMenu();
            $('.client-messages-item').removeClass('is-active');
            $(`.client-messages-item[data-customer-id="${customerId}"]`).addClass('is-active');
            setMessagesMobileView(true);
            scrollToMobileChat('provider-messages-chat-area');
            $('#provider-messages-chat-body').html('<div class="client-messages-list__loading"><div class="spinner"></div></div>');

            ieAjax('ie_get_provider_customer_thread', { customer_id: customerId }).done(function(res) {
                if (!res.success) {
                    Toast.show((res.data && res.data.message) || 'Failed to load chat.', 'error');
                    $('#provider-messages-chat-body').html(`<div class="client-messages-chat__thread-empty"><p>${esc((IE_I18N && IE_I18N.replyToCustomers) || 'Reply to customer inquiries here.')}</p></div>`);
                    stopProviderChatPolling();
                    return;
                }
                const c = res.data.customer;
                $('#provider-chat-head-avatar').attr({ src: c.avatar, alt: c.name });
                $('#provider-chat-head-name').text(c.name);
                renderProviderChatMessages(res.data.messages || [], true);
                startProviderChatPolling();
                pollMessageNotifications();
            }).fail(function() {
                Toast.show('Connection error. Please try again.', 'error');
                stopProviderChatPolling();
            });
        }

        function sendProviderChatMessage() {
            submitChatPayload('provider');
        }

        $(document).on('click', '#provider-messages-conversation-list .client-messages-item', function() {
            openProviderChat(String($(this).attr('data-customer-id')));
        });

        $('#btn-provider-messages-back').on('click', function() {
            setMessagesMobileView(false);
            stopProviderChatPolling();
            const listArea = document.getElementById('provider-messages-conversation-list');
            if (listArea) {
                listArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });

        $(document).on('click', '.provider-profile-page .dashboard-nav-item[data-panel]', function() {
            const panel = $(this).data('panel');
            if (panel !== 'messages') {
                stopProviderChatPolling();
            }
        });

        $('#btn-provider-send-chat').on('click', sendProviderChatMessage);
        $('#provider-chat-message-input').on('keypress', function(e) {
            if (e.which === 13) {
                e.preventDefault();
                sendProviderChatMessage();
            }
        });

        $('#btn-provider-chat-attach').on('click', function() {
            $('#provider-chat-attachment-input').trigger('click');
        });

        $('#provider-chat-attachment-input').on('change', function() {
            queueChatAttachment(this, 'provider');
        });

        $('#btn-provider-chat-head-menu').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleProviderChatHeadMenu();
        });

        $('#btn-delete-provider-chat-conversation').on('click', function(e) {
            e.preventDefault();
            deleteActiveProviderChatConversation();
        });

        $(document).on('click', function(e) {
            if (!$(e.target).closest('#provider-chat-head-menu').length) {
                closeProviderChatHeadMenu();
            }
        });

        providerChatPollFn = pollProviderChatThread;
        providerChatRefreshFn = refreshProviderConversationList;

        $('#provider-messages-search').on('input', function() {
            const q = $(this).val().trim().toLowerCase();
            if (!q) {
                renderProviderConversationList(providerConversationsCache);
                return;
            }
            renderProviderConversationList(providerConversationsCache.filter(function(c) {
                return (c.name || '').toLowerCase().includes(q) || (c.last_message || '').toLowerCase().includes(q);
            }));
        });

        const presetCustomer = $('#panel-messages').data('active-customer');
        if (presetCustomer) {
            activeProviderCustomerId = String(presetCustomer);
        }
        initMessageTimes();
        if ($('#panel-messages').hasClass('active') && activeProviderCustomerId) {
            setMessagesMobileView(true);
        } else {
            setMessagesMobileView();
        }

        if ($('#panel-messages').hasClass('active')) {
            $('.provider-profile-page .dashboard-nav-item[data-panel="messages"]').data('loaded', true);
            loadProviderConversations(true);
            startProviderChatPolling();
        }

        $(document).on('click', '.provider-profile-page .dashboard-nav-item[data-panel="messages"]', function() {
            if (!$(this).data('loaded')) {
                loadProviderConversations(!!activeProviderCustomerId);
                $(this).data('loaded', true);
            }
            startProviderChatPolling();
        });

    }

    initMessageNotifyWatcher();

    /* CONTACT FORM */
    if ($('#btn-contact-submit').length) {
        $('#btn-contact-submit').on('click', function() {
            const name    = $('#contact-name').val().trim();
            const email   = $('#contact-email').val().trim();
            const subject = $('#contact-subject').val().trim();
            const message = $('#contact-message').val().trim();
            const i18n    = window.IE_I18N || {};

            $('#contact-error, #contact-success').removeClass('show');

            if (!name || !email || !subject || !message) {
                $('#contact-error').addClass('show').text(i18n.fillRequired || 'Please fill in all required fields.');
                return;
            }

            const $btn = $(this);
            $btn.prop('disabled', true).text(i18n.sending || 'Sending...');

            ieAjax('ie_contact_form', {
                name,
                email,
                phone: $('#contact-phone').val().trim(),
                subject,
                message,
            }).done(function(res) {
                if (res.success) {
                    $('#contact-success').addClass('show').text(i18n.contactSuccess || 'Message sent!');
                    $('#contact-name, #contact-email, #contact-phone, #contact-message').val('');
                    $('#contact-subject').val('');
                } else {
                    $('#contact-error').addClass('show').text((res.data && res.data.message) || i18n.contactFailed || 'Failed to send.');
                }
            }).fail(function() {
                $('#contact-error').addClass('show').text(i18n.connectionError || 'Connection error. Please try again.');
            }).always(function() {
                $btn.prop('disabled', false).html((i18n.sendMessage || 'Send Message') + ' <i class="fa-solid fa-paper-plane" aria-hidden="true"></i>');
            });
        });
    }

})(jQuery);