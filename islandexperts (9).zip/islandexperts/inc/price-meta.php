<?php
/**
 * Price page meta fields (intro section).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_price_default_intro() {
    return [
        'badge'    => ie__( 'Subscription Plans' ),
        'title'    => ie__( 'Simple, Transparent Pricing' ),
        'subtitle' => ie__( 'Choose the plan that fits your business. Switch between monthly and yearly billing anytime.' ),
    ];
}

function ie_get_price_page_data( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_price_default_intro();

    return [
        'intro' => [
            'badge'    => get_post_meta( $post_id, '_ie_price_page_badge', true ) ?: $defaults['badge'],
            'title'    => get_post_meta( $post_id, '_ie_price_page_title', true ) ?: $defaults['title'],
            'subtitle' => get_post_meta( $post_id, '_ie_price_page_subtitle', true ) ?: $defaults['subtitle'],
        ],
    ];
}

function ie_seed_price_page_defaults( $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id || get_post_type( $post_id ) !== 'page' ) {
        return;
    }

    $defaults = ie_get_price_default_intro();

    if ( ! get_post_meta( $post_id, '_ie_price_page_badge', true ) ) {
        update_post_meta( $post_id, '_ie_price_page_badge', $defaults['badge'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_price_page_title', true ) ) {
        update_post_meta( $post_id, '_ie_price_page_title', $defaults['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_price_page_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_price_page_subtitle', $defaults['subtitle'] );
    }
}

function ie_add_price_page_meta_box( $post_type, $post ) {
    if ( $post_type !== 'page' || ! $post instanceof WP_Post ) {
        return;
    }

    if ( ! ie_page_uses_template( $post->ID, 'price.php' ) ) {
        return;
    }

    add_meta_box(
        'ie_price_page_settings',
        ie__( 'Price Page Settings' ),
        'ie_price_page_meta_box_cb',
        'page',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'ie_add_price_page_meta_box', 10, 2 );

function ie_price_page_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_price_page', 'ie_price_page_nonce' );

    $intro = ie_get_price_page_data( $post->ID )['intro'];
    ?>
    <style>
        .ie-price-meta-field { margin-bottom: 14px; }
        .ie-price-meta-field label { display: block; font-weight: 600; margin-bottom: 6px; }
        .ie-price-meta-field input[type="text"],
        .ie-price-meta-field textarea { width: 100%; }
    </style>

    <div class="ie-price-meta-field">
        <label for="ie_price_page_badge"><?php echo esc_html( ie__( 'Badge Text' ) ); ?></label>
        <input type="text" id="ie_price_page_badge" name="_ie_price_page_badge" value="<?php echo esc_attr( $intro['badge'] ); ?>">
    </div>

    <div class="ie-price-meta-field">
        <label for="ie_price_page_title"><?php echo esc_html( ie__( 'Page Title' ) ); ?></label>
        <input type="text" id="ie_price_page_title" name="_ie_price_page_title" value="<?php echo esc_attr( $intro['title'] ); ?>">
    </div>

    <div class="ie-price-meta-field">
        <label for="ie_price_page_subtitle"><?php echo esc_html( ie__( 'Page Subtitle' ) ); ?></label>
        <textarea id="ie_price_page_subtitle" name="_ie_price_page_subtitle" rows="2"><?php echo esc_textarea( $intro['subtitle'] ); ?></textarea>
    </div>
    <?php
}

function ie_save_price_page_meta( $post_id ) {
    if ( ! isset( $_POST['ie_price_page_nonce'] ) || ! wp_verify_nonce( $_POST['ie_price_page_nonce'], 'ie_save_price_page' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( get_post_type( $post_id ) !== 'page' ) {
        return;
    }
    if ( ! ie_page_uses_template( $post_id, 'price.php' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['_ie_price_page_badge'] ) ) {
        update_post_meta( $post_id, '_ie_price_page_badge', sanitize_text_field( wp_unslash( $_POST['_ie_price_page_badge'] ) ) );
    }
    if ( isset( $_POST['_ie_price_page_title'] ) ) {
        update_post_meta( $post_id, '_ie_price_page_title', sanitize_text_field( wp_unslash( $_POST['_ie_price_page_title'] ) ) );
    }
    if ( isset( $_POST['_ie_price_page_subtitle'] ) ) {
        update_post_meta( $post_id, '_ie_price_page_subtitle', sanitize_textarea_field( wp_unslash( $_POST['_ie_price_page_subtitle'] ) ) );
    }
}
add_action( 'save_post_page', 'ie_save_price_page_meta' );

function ie_get_price_content_post_id() {
    if ( is_page() ) {
        return get_queried_object_id();
    }

    $page = get_page_by_path( 'price' );

    return $page ? (int) $page->ID : 0;
}
