<?php
/**
 * Price page template helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_render_price_intro( $intro ) {
    if ( empty( $intro['badge'] ) && empty( $intro['title'] ) && empty( $intro['subtitle'] ) ) {
        return;
    }
    ?>
    <div class="pricing-intro">
        <?php if ( ! empty( $intro['badge'] ) ) : ?>
            <span class="pricing-badge"><?php echo esc_html( $intro['badge'] ); ?></span>
        <?php endif; ?>
        <?php if ( ! empty( $intro['title'] ) ) : ?>
            <h1><?php echo esc_html( $intro['title'] ); ?></h1>
        <?php endif; ?>
        <?php if ( ! empty( $intro['subtitle'] ) ) : ?>
            <p><?php echo esc_html( $intro['subtitle'] ); ?></p>
        <?php endif; ?>
    </div>
    <?php
}

function ie_render_subscription_pricing_cards() {
    $plans = ie_get_active_subscription_plans();

    if ( ! $plans ) {
        echo '<p>' . esc_html( ie__( 'No subscription plans are available right now.' ) ) . '</p>';
        return;
    }

    $total = count( $plans );

    foreach ( $plans as $index => $plan ) {
        $slug           = ie_get_subscription_plan_slug( $plan['id'] ?? '' );
        $billing        = ie_admin_get_plan_billing( $plan );
        $monthly        = $billing['period'] === 'monthly'
            ? ie_format_subscription_price( $billing['price'] )
            : ie_format_subscription_price( '0' );
        $yearly         = $billing['period'] === 'yearly'
            ? ie_format_subscription_price( $billing['price'] )
            : ie_format_subscription_price( '0' );
        $features       = ie_admin_get_plan_editor_features( $plan );
        $is_featured    = $total > 1 && $index === ( $total - 1 );
        $icon_class     = $is_featured ? 'subscription-plan-icon-premium' : 'subscription-plan-icon-basic';
        $icon           = $is_featured ? 'fa-solid fa-crown' : 'fa-solid fa-layer-group';
        $card_class     = 'pricing-card subscription-card' . ( $is_featured ? ' featured' : '' );
        $button_class   = $is_featured ? 'btn-pricing-filled' : 'btn-pricing-outline';
        $plan_name      = $plan['name'] ?? ie__( 'Plan' );
        $description    = $plan['description'] ?? '';
        $monthly_label  = sprintf( ie__( '%s (Monthly)' ), $plan_name );
        $yearly_label   = sprintf( ie__( '%s (Yearly)' ), $plan_name );
        $subscribe_text = sprintf( ie__( 'Subscribe to %s' ), preg_replace( '/\s+Plan$/i', '', $plan_name ) );
        ?>
        <article class="<?php echo esc_attr( $card_class ); ?>" data-plan="<?php echo esc_attr( $slug ); ?>">
            <?php if ( $is_featured ) : ?>
                <span class="pricing-card-badge badge-popular"><?php echo esc_html( ie__( 'Most Popular' ) ); ?></span>
            <?php endif; ?>

            <div class="subscription-card-head">
                <div class="subscription-plan-icon <?php echo esc_attr( $icon_class ); ?>">
                    <i class="<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></i>
                </div>
                <h3><?php echo esc_html( $plan_name ); ?></h3>
                <?php if ( $description !== '' ) : ?>
                    <p class="pricing-desc"><?php echo esc_html( $description ); ?></p>
                <?php endif; ?>
            </div>

            <div class="pricing-price">
                <span class="amount" data-monthly="<?php echo esc_attr( $monthly ); ?>" data-yearly="<?php echo esc_attr( $yearly ); ?>"><?php echo esc_html( $monthly ); ?></span>
                <span class="period" data-monthly="<?php echo esc_attr( ie__( '/ month' ) ); ?>" data-yearly="<?php echo esc_attr( ie__( '/ year' ) ); ?>"><?php echo esc_html( ie__( '/ month' ) ); ?></span>
            </div>

            <ul class="pricing-features">
                <?php foreach ( $features as $feature ) : ?>
                    <?php if ( ( $feature['text'] ?? '' ) === '' ) : ?>
                        <?php continue; ?>
                    <?php endif; ?>
                    <?php
                    $icon_slug = ie_admin_get_plan_feature_icon_modifier( $feature['icon'] ?? 'fa-solid fa-check' );
                    $icon_cls  = ie_admin_resolve_plan_feature_icon( $feature['icon'] ?? 'fa-solid fa-check' );
                    ?>
                    <li>
                        <span class="feat-check feat-check--<?php echo esc_attr( str_replace( 'is-', '', $icon_slug ) ); ?>">
                            <i class="<?php echo esc_attr( $icon_cls ); ?>" aria-hidden="true"></i>
                        </span>
                        <?php echo esc_html( $feature['text'] ); ?>
                    </li>
                <?php endforeach; ?>
            </ul>

            <button type="button"
                    class="<?php echo esc_attr( $button_class ); ?> ie-choose-plan"
                    data-plan-monthly="<?php echo esc_attr( $monthly_label ); ?>"
                    data-plan-yearly="<?php echo esc_attr( $yearly_label ); ?>"
                    data-price-monthly="<?php echo esc_attr( $monthly . ' / ' . ie__( 'month' ) ); ?>"
                    data-price-yearly="<?php echo esc_attr( $yearly . ' / ' . ie__( 'year' ) ); ?>"
                    data-plan-id-monthly="<?php echo esc_attr( $slug . '-monthly' ); ?>"
                    data-plan-id-yearly="<?php echo esc_attr( $slug . '-annual' ); ?>"
                    data-paypal="#">
                <?php echo esc_html( $subscribe_text ); ?>
            </button>
        </article>
        <?php
    }
}
