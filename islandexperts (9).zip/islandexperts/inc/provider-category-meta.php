<?php
/**
 * Provider Categories CPT meta box, seeding, and admin UI.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_add_provider_category_meta_box() {
    add_meta_box(
        'ie_provider_category_details',
        ie__( 'Category Details' ),
        'ie_provider_category_meta_box_cb',
        'ie_provider_category',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'ie_add_provider_category_meta_box' );

function ie_provider_category_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_provider_category', 'ie_provider_category_nonce' );

    $short_desc  = get_post_meta( $post->ID, '_ie_cat_short_description', true );
    $browse_slug = get_post_meta( $post->ID, '_ie_cat_browse_slug', true );
    $icon_type   = get_post_meta( $post->ID, '_ie_cat_icon_type', true ) ?: 'fontawesome';
    $icon_class  = get_post_meta( $post->ID, '_ie_cat_icon_class', true ) ?: 'fa-solid fa-screwdriver-wrench';
    $icon_image  = get_post_meta( $post->ID, '_ie_cat_icon_image', true );
    $presets     = ie_get_provider_category_fa_presets();
    ?>
    <table class="form-table ie-provider-category-meta">
        <tr>
            <th scope="row"><label for="ie_cat_short_description"><?php echo esc_html( ie__( 'Short Description' ) ); ?></label></th>
            <td>
                <textarea id="ie_cat_short_description" name="ie_cat_short_description" rows="3" class="large-text"><?php echo esc_textarea( $short_desc ); ?></textarea>
                <p class="description"><?php echo esc_html( ie__( 'Shown on the home page category card.' ) ); ?></p>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="ie_cat_browse_slug"><?php echo esc_html( ie__( 'Browse Filter Slug' ) ); ?></label></th>
            <td>
                <input type="text" id="ie_cat_browse_slug" name="ie_cat_browse_slug" value="<?php echo esc_attr( $browse_slug ); ?>" class="regular-text">
                <p class="description"><?php echo esc_html( ie__( 'Links to the provider browse page (matches the provider category taxonomy slug).' ) ); ?></p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php echo esc_html( ie__( 'Icon Type' ) ); ?></th>
            <td>
                <label style="margin-right:16px;">
                    <input type="radio" name="ie_cat_icon_type" value="fontawesome" <?php checked( $icon_type, 'fontawesome' ); ?>>
                    <?php echo esc_html( ie__( 'Font Awesome Icon' ) ); ?>
                </label>
                <label>
                    <input type="radio" name="ie_cat_icon_type" value="image" <?php checked( $icon_type, 'image' ); ?>>
                    <?php echo esc_html( ie__( 'Upload Image' ) ); ?>
                </label>
            </td>
        </tr>
        <tr class="ie-cat-icon-fontawesome-row">
            <th scope="row"><label for="ie_cat_icon_preset"><?php echo esc_html( ie__( 'Font Awesome Icon' ) ); ?></label></th>
            <td>
                <select id="ie_cat_icon_preset" class="regular-text" style="max-width:320px;margin-bottom:8px;">
                    <option value=""><?php echo esc_html( ie__( '— Select a preset —' ) ); ?></option>
                    <?php foreach ( $presets as $class => $label ) : ?>
                        <option value="<?php echo esc_attr( $class ); ?>" <?php selected( $icon_class, $class ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="text" id="ie_cat_icon_class" name="ie_cat_icon_class" value="<?php echo esc_attr( $icon_class ); ?>" class="regular-text" placeholder="fa-solid fa-wrench" style="max-width:320px;">
                <p class="description"><?php echo esc_html( ie__( 'Choose a preset or enter any Font Awesome class (e.g. fa-solid fa-wrench).' ) ); ?></p>
                <div class="ie-cat-icon-preview" style="margin-top:10px;">
                    <span style="display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;border-radius:12px;background:#f0f4f8;">
                        <i id="ie-cat-fa-preview" class="<?php echo esc_attr( $icon_class ); ?>" aria-hidden="true" style="font-size:20px;color:<?php echo esc_attr( ie_get_theme_primary_color() ); ?>;"></i>
                    </span>
                </div>
            </td>
        </tr>
        <tr class="ie-cat-icon-image-row">
            <th scope="row"><?php echo esc_html( ie__( 'Icon Image' ) ); ?></th>
            <td>
                <div class="ie-cat-icon-image-field">
                    <div class="ie-cat-icon-image-preview<?php echo $icon_image ? '' : ' is-empty'; ?>">
                        <?php if ( $icon_image ) : ?>
                            <img src="<?php echo esc_url( $icon_image ); ?>" alt="">
                        <?php else : ?>
                            <?php echo esc_html( ie__( 'No image' ) ); ?>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" id="ie_cat_icon_image" name="ie_cat_icon_image" value="<?php echo esc_url( $icon_image ); ?>">
                    <p>
                        <button type="button" class="button" id="ie-cat-upload-icon"><?php echo esc_html( ie__( 'Upload Icon' ) ); ?></button>
                        <button type="button" class="button" id="ie-cat-remove-icon"<?php echo $icon_image ? '' : ' style="display:none;"'; ?>><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
                    </p>
                </div>
            </td>
        </tr>
    </table>
    <?php
}

function ie_save_provider_category_meta( $post_id ) {
    if ( ! isset( $_POST['ie_provider_category_nonce'] ) || ! wp_verify_nonce( $_POST['ie_provider_category_nonce'], 'ie_save_provider_category' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( get_post_type( $post_id ) !== 'ie_provider_category' ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['ie_cat_short_description'] ) ) {
        update_post_meta( $post_id, '_ie_cat_short_description', sanitize_textarea_field( wp_unslash( $_POST['ie_cat_short_description'] ) ) );
    }

    if ( isset( $_POST['ie_cat_browse_slug'] ) ) {
        update_post_meta( $post_id, '_ie_cat_browse_slug', sanitize_title( wp_unslash( $_POST['ie_cat_browse_slug'] ) ) );
    }

    $icon_type = isset( $_POST['ie_cat_icon_type'] ) ? sanitize_key( wp_unslash( $_POST['ie_cat_icon_type'] ) ) : 'fontawesome';
    if ( ! in_array( $icon_type, [ 'fontawesome', 'image' ], true ) ) {
        $icon_type = 'fontawesome';
    }
    update_post_meta( $post_id, '_ie_cat_icon_type', $icon_type );

    if ( isset( $_POST['ie_cat_icon_class'] ) ) {
        update_post_meta( $post_id, '_ie_cat_icon_class', sanitize_text_field( wp_unslash( $_POST['ie_cat_icon_class'] ) ) );
    }

    if ( isset( $_POST['ie_cat_icon_image'] ) ) {
        update_post_meta( $post_id, '_ie_cat_icon_image', esc_url_raw( wp_unslash( $_POST['ie_cat_icon_image'] ) ) );
    }
}
add_action( 'save_post_ie_provider_category', 'ie_save_provider_category_meta' );

function ie_provider_category_columns( $cols ) {
    return array_merge(
        array_slice( $cols, 0, 2 ),
        [
            'ie_cat_icon'  => ie__( 'Icon' ),
            'ie_cat_slug'  => ie__( 'Browse Slug' ),
            'ie_cat_order' => ie__( 'Order' ),
        ],
        array_slice( $cols, 2 )
    );
}
add_filter( 'manage_ie_provider_category_posts_columns', 'ie_provider_category_columns' );

function ie_provider_category_column_data( $col, $post_id ) {
    switch ( $col ) {
        case 'ie_cat_icon':
            $data = ie_get_provider_category_data( $post_id );
            echo '<span style="display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;background:#f0f4f8;">';
            if ( $data['icon_type'] === 'image' && $data['icon_image'] ) {
                echo '<img src="' . esc_url( $data['icon_image'] ) . '" alt="" width="20" height="20" style="object-fit:contain;">';
            } else {
                echo '<i class="' . esc_attr( $data['icon_class'] ) . '" aria-hidden="true" style="color:' . esc_attr( ie_get_theme_primary_color() ) . ';"></i>';
            }
            echo '</span>';
            break;
        case 'ie_cat_slug':
            echo esc_html( get_post_meta( $post_id, '_ie_cat_browse_slug', true ) ?: '—' );
            break;
        case 'ie_cat_order':
            echo esc_html( (string) get_post( $post_id )->menu_order );
            break;
    }
}
add_action( 'manage_ie_provider_category_posts_custom_column', 'ie_provider_category_column_data', 10, 2 );

function ie_seed_provider_categories() {
    foreach ( ie_get_default_provider_categories() as $index => $cat ) {
        $existing = get_posts( [
            'post_type'      => 'ie_provider_category',
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_key'       => '_ie_cat_browse_slug',
            'meta_value'     => $cat['slug'],
        ] );

        if ( $existing ) {
            continue;
        }

        $post_id = wp_insert_post( [
            'post_title'  => $cat['title'],
            'post_name'   => $cat['slug'],
            'post_type'   => 'ie_provider_category',
            'post_status' => 'publish',
            'menu_order'  => $cat['menu_order'] ?? ( $index + 1 ),
        ] );

        if ( is_wp_error( $post_id ) || ! $post_id ) {
            continue;
        }

        update_post_meta( $post_id, '_ie_cat_icon_type', $cat['icon_type'] );
        update_post_meta( $post_id, '_ie_cat_icon_class', $cat['icon_class'] );
        update_post_meta( $post_id, '_ie_cat_short_description', $cat['short_description'] );
        update_post_meta( $post_id, '_ie_cat_browse_slug', $cat['slug'] );

        if ( ! term_exists( $cat['slug'], 'ie_category' ) ) {
            wp_insert_term( $cat['title'], 'ie_category', [ 'slug' => $cat['slug'] ] );
        }
    }
}

function ie_enqueue_provider_category_admin_assets( $hook ) {
    if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
        return;
    }

    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'ie_provider_category' ) {
        return;
    }

    wp_enqueue_media();

    wp_enqueue_script(
        'ie-admin-provider-category',
        ie_asset_uri( 'js/admin-provider-category.js' ),
        [ 'jquery', 'media-editor' ],
        IE_THEME_VERSION,
        true
    );

    wp_localize_script(
        'ie-admin-provider-category',
        'IE_PROVIDER_CAT_ADMIN',
        [
            'selectImage' => ie__( 'Select Category Icon' ),
            'useImage'    => ie__( 'Use this icon' ),
            'noImage'     => ie__( 'No image' ),
        ]
    );
}
add_action( 'admin_enqueue_scripts', 'ie_enqueue_provider_category_admin_assets' );
