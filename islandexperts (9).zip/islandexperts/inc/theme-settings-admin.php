<?php
/**
 * Theme Settings admin page.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_register_theme_settings_page() {
    add_menu_page(
        ie__( 'Theme Settings' ),
        ie__( 'Theme Settings' ),
        'manage_options',
        'ie-theme-settings',
        'ie_render_theme_settings_page',
        'dashicons-admin-generic',
        59
    );

    add_submenu_page(
        'ie-theme-settings',
        ie__( 'Global' ),
        ie__( 'Global' ),
        'manage_options',
        'ie-theme-settings',
        'ie_render_theme_settings_page'
    );

    add_submenu_page(
        'ie-theme-settings',
        ie__( 'Header' ),
        ie__( 'Header' ),
        'manage_options',
        'ie-theme-settings-header',
        'ie_render_theme_settings_page'
    );

    add_submenu_page(
        'ie-theme-settings',
        ie__( 'Footer' ),
        ie__( 'Footer' ),
        'manage_options',
        'ie-theme-settings-footer',
        'ie_render_theme_settings_page'
    );
}
add_action( 'admin_menu', 'ie_register_theme_settings_page' );

function ie_get_theme_settings_admin_pages() {
    return [
        'ie-theme-settings'        => [
            'section' => 'global',
            'label'   => ie__( 'Global' ),
            'title'   => ie__( 'Global Settings' ),
            'desc'    => ie__( 'Overview and general theme configuration.' ),
        ],
        'ie-theme-settings-header' => [
            'section' => 'header',
            'label'   => ie__( 'Header' ),
            'title'   => ie__( 'Header Settings' ),
            'desc'    => ie__( 'Manage the site header logo and related options.' ),
        ],
        'ie-theme-settings-footer' => [
            'section' => 'footer',
            'label'   => ie__( 'Footer' ),
            'title'   => ie__( 'Footer Settings' ),
            'desc'    => ie__( 'Manage footer brand, columns, and bottom bar content.' ),
        ],
    ];
}

function ie_get_current_theme_settings_page() {
    $page  = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'ie-theme-settings';
    $pages = ie_get_theme_settings_admin_pages();

    return isset( $pages[ $page ] ) ? $page : 'ie-theme-settings';
}

function ie_get_current_theme_settings_section() {
    $page  = ie_get_current_theme_settings_page();
    $pages = ie_get_theme_settings_admin_pages();

    return $pages[ $page ]['section'];
}

function ie_handle_theme_settings_save() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html( ie__( 'You do not have permission to access this page.' ) ) );
    }

    check_admin_referer( 'ie_save_theme_settings', 'ie_theme_settings_nonce' );

    $existing = ie_get_theme_settings();
    $input    = isset( $_POST['ie_theme_settings'] ) ? wp_unslash( $_POST['ie_theme_settings'] ) : [];

    if ( ! is_array( $input ) ) {
        $input = [];
    }

    if ( ! isset( $input['global'] ) || ! is_array( $input['global'] ) ) {
        $input['global'] = $existing['global'];
    }

    if ( ! isset( $input['header'] ) || ! is_array( $input['header'] ) ) {
        $input['header'] = $existing['header'];
    }

    if ( ! isset( $input['footer'] ) || ! is_array( $input['footer'] ) ) {
        $input['footer'] = $existing['footer'];
    }

    $settings = ie_sanitize_theme_settings( $input );

    update_option( IE_THEME_SETTINGS_OPTION, $settings );

    $redirect_page = isset( $_POST['ie_theme_settings_page'] )
        ? sanitize_key( wp_unslash( $_POST['ie_theme_settings_page'] ) )
        : 'ie-theme-settings';

    if ( ! isset( ie_get_theme_settings_admin_pages()[ $redirect_page ] ) ) {
        $redirect_page = 'ie-theme-settings';
    }

    wp_safe_redirect(
        add_query_arg(
            [ 'page' => $redirect_page, 'settings-updated' => 'true' ],
            admin_url( 'admin.php' )
        )
    );
    exit;
}
add_action( 'admin_post_ie_save_theme_settings', 'ie_handle_theme_settings_save' );

function ie_enqueue_theme_settings_admin_assets( $hook ) {
    $allowed_hooks = [
        'toplevel_page_ie-theme-settings',
        'theme-settings_page_ie-theme-settings-header',
        'theme-settings_page_ie-theme-settings-footer',
    ];

    if ( ! in_array( $hook, $allowed_hooks, true ) ) {
        return;
    }

    wp_enqueue_media();
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_style( 'google-fonts', ie_get_theme_google_fonts_url(), [], ie_get_theme_google_fonts_version() );

    wp_enqueue_script(
        'ie-admin-theme-settings',
        ie_asset_uri( 'js/admin-theme-settings.js' ),
        [ 'jquery', 'media-editor', 'wp-color-picker' ],
        IE_THEME_VERSION,
        true
    );

    wp_localize_script(
        'ie-admin-theme-settings',
        'IE_THEME_SETTINGS_ADMIN',
        [
            'selectImage' => ie__( 'Select Logo' ),
            'useImage'    => ie__( 'Use this logo' ),
            'noImage'     => ie__( 'No logo selected' ),
        ]
    );
}
add_action( 'admin_enqueue_scripts', 'ie_enqueue_theme_settings_admin_assets' );

function ie_render_theme_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $current_page   = ie_get_current_theme_settings_page();
    $pages          = ie_get_theme_settings_admin_pages();
    $current        = $pages[ $current_page ];
    $section        = $current['section'];
    $settings       = ie_get_theme_settings();
    $header         = $settings['header'];
    $footer         = $settings['footer'];
    $brand          = $footer['brand'];
    $columns        = $footer['columns'];
    $socials        = $brand['socials'] ?? [];
    $social_presets = ie_get_theme_social_icon_presets();

    if ( isset( $_GET['settings-updated'] ) ) {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( ie__( 'Theme settings saved successfully.' ) ) . '</p></div>';
    }
    ?>
    <div class="wrap ie-theme-settings">
        <div class="ie-ts-header">
            <div class="ie-ts-header-icon" aria-hidden="true">
                <span class="dashicons dashicons-admin-generic"></span>
            </div>
            <div>
                <h1><?php echo esc_html( ie__( 'Theme Settings' ) ); ?></h1>
                <p><?php echo esc_html( ie__( 'Configure your site header, footer, and global theme options.' ) ); ?></p>
            </div>
        </div>

        <div class="ie-ts-layout">
            <aside class="ie-ts-sidebar" aria-label="<?php echo esc_attr( ie__( 'Theme settings sections' ) ); ?>">
                <nav class="ie-ts-nav">
                    <?php foreach ( $pages as $page_slug => $page ) : ?>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=' . $page_slug ) ); ?>"
                           class="ie-ts-nav-item<?php echo $current_page === $page_slug ? ' is-active' : ''; ?>">
                            <span class="ie-ts-nav-icon dashicons <?php echo esc_attr( ie_get_theme_settings_nav_icon( $page['section'] ) ); ?>" aria-hidden="true"></span>
                            <span class="ie-ts-nav-label"><?php echo esc_html( $page['label'] ); ?></span>
                        </a>
                    <?php endforeach; ?>
                </nav>
            </aside>

            <div class="ie-ts-main">
                <div class="ie-ts-section-head">
                    <h2><?php echo esc_html( $current['title'] ); ?></h2>
                    <p><?php echo esc_html( $current['desc'] ); ?></p>
                </div>

                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ie-ts-form">
                    <input type="hidden" name="action" value="ie_save_theme_settings">
                    <input type="hidden" name="ie_theme_settings_page" value="<?php echo esc_attr( $current_page ); ?>">
                    <?php wp_nonce_field( 'ie_save_theme_settings', 'ie_theme_settings_nonce' ); ?>

                    <div class="ie-ts-panels">
                        <?php if ( $section === 'global' ) : ?>
                            <?php ie_render_theme_settings_global_panel( $settings ); ?>
                        <?php elseif ( $section === 'header' ) : ?>
                            <?php ie_render_theme_settings_header_panel( $header ); ?>
                        <?php else : ?>
                            <?php ie_render_theme_settings_footer_panel( $footer, $brand, $columns, $socials, $social_presets ); ?>
                        <?php endif; ?>
                    </div>

                    <div class="ie-ts-footer-bar">
                        <button type="submit" class="button button-primary button-hero"><?php echo esc_html( ie__( 'Save Settings' ) ); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php ie_render_theme_settings_templates( $social_presets ); ?>
    <?php
}

function ie_get_theme_settings_nav_icon( $section ) {
    $icons = [
        'global' => 'dashicons-admin-site-alt3',
        'header' => 'dashicons-arrow-up-alt',
        'footer' => 'dashicons-arrow-down-alt',
    ];

    return $icons[ $section ] ?? 'dashicons-admin-generic';
}

function ie_render_theme_settings_global_panel( $settings ) {
    $global       = $settings['global'] ?? ie_get_theme_global_defaults();
    $font_choices = ie_get_theme_font_choices();
    ?>
    <section class="ie-ts-panel is-active" data-panel="global">
        <div class="ie-ts-card">
            <div class="ie-ts-card-head">
                <h3><?php echo esc_html( ie__( 'Layout' ) ); ?></h3>
                <p><?php echo esc_html( ie__( 'Control the main content container width across the website.' ) ); ?></p>
            </div>
            <div class="ie-ts-card-body">
                <table class="form-table ie-ts-form-table">
                    <tr>
                        <th scope="row"><label for="ie-global-container-max"><?php echo esc_html( ie__( 'Container Max Width' ) ); ?></label></th>
                        <td>
                            <input type="number" id="ie-global-container-max" name="ie_theme_settings[global][container_max]" value="<?php echo esc_attr( $global['container_max'] ); ?>" min="960" max="1600" step="10" class="small-text"> px
                            <p class="description"><?php echo esc_html( ie__( 'Recommended range: 960px to 1600px. Default is 1300px.' ) ); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ie-ts-card">
            <div class="ie-ts-card-head">
                <h3><?php echo esc_html( ie__( 'Global Colors' ) ); ?></h3>
                <p><?php echo esc_html( ie__( 'Primary brand, accent, body text, and heading colors.' ) ); ?></p>
            </div>
            <div class="ie-ts-card-body">
                <table class="form-table ie-ts-form-table ie-ts-color-table">
                    <tr>
                        <th scope="row"><label for="ie-global-color-primary"><?php echo esc_html( ie__( 'Primary Color' ) ); ?></label></th>
                        <td><input type="text" id="ie-global-color-primary" class="ie-ts-color-picker" name="ie_theme_settings[global][color_primary]" value="<?php echo esc_attr( $global['color_primary'] ); ?>" data-default-color="<?php echo esc_attr( ie_get_theme_global_defaults()['color_primary'] ); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ie-global-color-accent"><?php echo esc_html( ie__( 'Accent Color' ) ); ?></label></th>
                        <td><input type="text" id="ie-global-color-accent" class="ie-ts-color-picker" name="ie_theme_settings[global][color_accent]" value="<?php echo esc_attr( $global['color_accent'] ); ?>" data-default-color="<?php echo esc_attr( ie_get_theme_global_defaults()['color_accent'] ); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ie-global-color-text"><?php echo esc_html( ie__( 'Body Text Color' ) ); ?></label></th>
                        <td><input type="text" id="ie-global-color-text" class="ie-ts-color-picker" name="ie_theme_settings[global][color_text]" value="<?php echo esc_attr( $global['color_text'] ); ?>" data-default-color="<?php echo esc_attr( ie_get_theme_global_defaults()['color_text'] ); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ie-global-color-heading"><?php echo esc_html( ie__( 'Heading Color' ) ); ?></label></th>
                        <td><input type="text" id="ie-global-color-heading" class="ie-ts-color-picker" name="ie_theme_settings[global][color_heading]" value="<?php echo esc_attr( $global['color_heading'] ); ?>" data-default-color="<?php echo esc_attr( ie_get_theme_global_defaults()['color_heading'] ); ?>"></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="ie-ts-card">
            <div class="ie-ts-card-head">
                <h3><?php echo esc_html( ie__( 'Typography' ) ); ?></h3>
                <p><?php echo esc_html( ie__( 'Choose Google Fonts for headings and body text.' ) ); ?></p>
            </div>
            <div class="ie-ts-card-body">
                <table class="form-table ie-ts-form-table">
                    <tr>
                        <th scope="row"><label for="ie-global-font-heading"><?php echo esc_html( ie__( 'Heading Font' ) ); ?></label></th>
                        <td>
                            <select id="ie-global-font-heading" name="ie_theme_settings[global][font_heading]" class="regular-text">
                                <?php foreach ( $font_choices as $value => $label ) : ?>
                                    <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $global['font_heading'], $value ); ?>><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ie-global-font-body"><?php echo esc_html( ie__( 'Body Font' ) ); ?></label></th>
                        <td>
                            <select id="ie-global-font-body" name="ie_theme_settings[global][font_body]" class="regular-text">
                                <?php foreach ( $font_choices as $value => $label ) : ?>
                                    <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $global['font_body'], $value ); ?>><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </table>
                <div class="ie-ts-font-preview">
                    <p class="ie-ts-font-preview-label"><?php echo esc_html( ie__( 'Preview' ) ); ?></p>
                    <p id="ie-ts-font-preview-heading" class="ie-ts-font-preview-heading" style="font-family: <?php echo esc_attr( ie_get_theme_font_stack( $global['font_heading'] ) ); ?>;"><?php echo esc_html( ie__( 'Heading Font Preview' ) ); ?></p>
                    <p id="ie-ts-font-preview-body" class="ie-ts-font-preview-body" style="font-family: <?php echo esc_attr( ie_get_theme_font_stack( $global['font_body'] ) ); ?>;"><?php echo esc_html( ie__( 'Body font preview text. The quick brown fox jumps over the lazy dog.' ) ); ?></p>
                </div>
            </div>
        </div>
    </section>
    <?php
}

function ie_render_theme_settings_header_panel( $header ) {
    ?>
    <section class="ie-ts-panel is-active" data-panel="header">
        <div class="ie-ts-card">
            <div class="ie-ts-card-head">
                <h3><?php echo esc_html( ie__( 'Header Logo' ) ); ?></h3>
                <p><?php echo esc_html( ie__( 'Upload the logo shown in the site header navigation.' ) ); ?></p>
            </div>
            <div class="ie-ts-card-body">
                <div class="ie-ts-logo-field">
                    <div class="ie-ts-logo-preview<?php echo empty( $header['logo_url'] ) ? ' is-empty' : ''; ?>">
                        <?php if ( ! empty( $header['logo_url'] ) ) : ?>
                            <img src="<?php echo esc_url( $header['logo_url'] ); ?>" alt="">
                        <?php else : ?>
                            <?php echo esc_html( ie__( 'No logo selected' ) ); ?>
                        <?php endif; ?>
                    </div>
                    <div class="ie-ts-logo-actions">
                        <input type="hidden" name="ie_theme_settings[header][logo_url]" id="ie-header-logo-url" value="<?php echo esc_url( $header['logo_url'] ); ?>">
                        <button type="button" class="button button-primary ie-ts-upload-logo" data-target="ie-header-logo-url" data-preview=".ie-ts-logo-preview"><?php echo esc_html( ie__( 'Upload Logo' ) ); ?></button>
                        <button type="button" class="button ie-ts-remove-logo" data-target="ie-header-logo-url" data-preview=".ie-ts-logo-preview"><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
                    </div>
                </div>
                <table class="form-table ie-ts-form-table">
                    <tr>
                        <th scope="row"><label for="ie-header-logo-alt"><?php echo esc_html( ie__( 'Logo Alt Text' ) ); ?></label></th>
                        <td>
                            <input type="text" id="ie-header-logo-alt" name="ie_theme_settings[header][logo_alt]" value="<?php echo esc_attr( $header['logo_alt'] ); ?>" class="regular-text">
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </section>
    <?php
}

function ie_render_theme_settings_footer_panel( $footer, $brand, $columns, $socials, $social_presets ) {
    ?>
    <section class="ie-ts-panel is-active" data-panel="footer">
        <div class="ie-ts-card">
            <div class="ie-ts-card-head">
                <h3><?php echo esc_html( ie__( 'Footer Brand' ) ); ?></h3>
                <p><?php echo esc_html( ie__( 'Logo, tagline, and social links in the first footer column.' ) ); ?></p>
            </div>
            <div class="ie-ts-card-body">
                <div class="ie-ts-logo-field">
                    <label class="ie-ts-field-label"><?php echo esc_html( ie__( 'Footer Logo' ) ); ?></label>
                    <p class="description"><?php echo esc_html( ie__( 'Leave empty to use the header logo.' ) ); ?></p>
                    <div class="ie-ts-logo-preview ie-ts-footer-logo-preview<?php echo empty( $brand['logo_url'] ) ? ' is-empty' : ''; ?>">
                        <?php if ( ! empty( $brand['logo_url'] ) ) : ?>
                            <img src="<?php echo esc_url( $brand['logo_url'] ); ?>" alt="">
                        <?php else : ?>
                            <?php echo esc_html( ie__( 'Uses header logo' ) ); ?>
                        <?php endif; ?>
                    </div>
                    <div class="ie-ts-logo-actions">
                        <input type="hidden" name="ie_theme_settings[footer][brand][logo_url]" id="ie-footer-logo-url" value="<?php echo esc_url( $brand['logo_url'] ); ?>">
                        <button type="button" class="button button-primary ie-ts-upload-logo" data-target="ie-footer-logo-url" data-preview=".ie-ts-footer-logo-preview"><?php echo esc_html( ie__( 'Upload Footer Logo' ) ); ?></button>
                        <button type="button" class="button ie-ts-remove-logo" data-target="ie-footer-logo-url" data-preview=".ie-ts-footer-logo-preview"><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
                    </div>
                </div>

                <table class="form-table ie-ts-form-table">
                    <tr>
                        <th scope="row"><label for="ie-footer-tagline"><?php echo esc_html( ie__( 'Tagline' ) ); ?></label></th>
                        <td>
                            <textarea id="ie-footer-tagline" name="ie_theme_settings[footer][brand][tagline]" rows="3" class="large-text"><?php echo esc_textarea( $brand['tagline'] ); ?></textarea>
                        </td>
                    </tr>
                </table>

                <div class="ie-ts-repeater-section">
                    <div class="ie-ts-repeater-head">
                        <h4><?php echo esc_html( ie__( 'Social Links' ) ); ?></h4>
                        <button type="button" class="button" id="ie-ts-add-social"><?php echo esc_html( ie__( 'Add Social Link' ) ); ?></button>
                    </div>
                    <div id="ie-ts-social-repeater" class="ie-ts-repeater">
                        <?php
                        if ( ! $socials ) {
                            $socials = [ [ 'icon' => '', 'url' => '', 'label' => '' ] ];
                        }
                        foreach ( $socials as $index => $social ) :
                            ie_render_theme_settings_social_row( $index, $social, $social_presets );
                        endforeach;
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="ie-ts-card">
            <div class="ie-ts-card-head">
                <h3><?php echo esc_html( ie__( 'Footer Columns' ) ); ?></h3>
                <p><?php echo esc_html( ie__( 'Add navigation or contact columns beside the brand section.' ) ); ?></p>
            </div>
            <div class="ie-ts-card-body">
                <div class="ie-ts-repeater-head">
                    <span></span>
                    <button type="button" class="button button-primary" id="ie-ts-add-column"><?php echo esc_html( ie__( 'Add Column' ) ); ?></button>
                </div>
                <div id="ie-ts-columns-repeater" class="ie-ts-columns-repeater">
                    <?php
                    if ( ! $columns ) {
                        $columns = [ [ 'title' => '', 'type' => 'links', 'links' => [] ] ];
                    }
                    foreach ( $columns as $col_index => $column ) {
                        ie_render_theme_settings_column_row( $col_index, $column );
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="ie-ts-card">
            <div class="ie-ts-card-head">
                <h3><?php echo esc_html( ie__( 'Footer Bottom Bar' ) ); ?></h3>
                <p><?php echo esc_html( ie__( 'Customize the copyright line. Leave empty for the default text.' ) ); ?></p>
            </div>
            <div class="ie-ts-card-body">
                <table class="form-table ie-ts-form-table">
                    <tr>
                        <th scope="row"><label for="ie-footer-copyright"><?php echo esc_html( ie__( 'Copyright Text' ) ); ?></label></th>
                        <td>
                            <input type="text" id="ie-footer-copyright" name="ie_theme_settings[footer][copyright]" value="<?php echo esc_attr( $footer['copyright'] ); ?>" class="large-text" placeholder="<?php echo esc_attr( ie__( '© {year} {site_name}. All rights reserved.' ) ); ?>">
                            <p class="description"><?php echo esc_html( ie__( 'Use {year} and {site_name} as placeholders.' ) ); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </section>
    <?php
}

function ie_theme_settings_row_number( $index, $fallback = 1 ) {
    return is_numeric( $index ) ? ( (int) $index + 1 ) : (int) $fallback;
}

function ie_render_theme_settings_social_row( $index, $social, $presets ) {
    $row_num = ie_theme_settings_row_number( $index );
    ?>
    <div class="ie-ts-repeater-item ie-ts-social-item">
        <div class="ie-ts-repeater-item-head">
            <strong><?php echo esc_html( ie__( 'Social Link' ) ); ?> <span class="ie-ts-item-num"><?php echo esc_html( (string) $row_num ); ?></span></strong>
            <button type="button" class="button-link-delete ie-ts-remove-social"><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
        </div>
        <div class="ie-ts-fields-grid">
            <div>
                <label><?php echo esc_html( ie__( 'Icon' ) ); ?></label>
                <select name="ie_theme_settings[footer][brand][socials][<?php echo esc_attr( (string) $index ); ?>][icon]" class="ie-ts-social-icon-select">
                    <option value=""><?php echo esc_html( ie__( '— Select —' ) ); ?></option>
                    <?php foreach ( $presets as $class => $label ) : ?>
                        <option value="<?php echo esc_attr( $class ); ?>" <?php selected( $social['icon'] ?? '', $class ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label><?php echo esc_html( ie__( 'URL' ) ); ?></label>
                <input type="url" name="ie_theme_settings[footer][brand][socials][<?php echo esc_attr( (string) $index ); ?>][url]" value="<?php echo esc_url( $social['url'] ?? '' ); ?>" class="regular-text">
            </div>
            <div>
                <label><?php echo esc_html( ie__( 'Aria Label' ) ); ?></label>
                <input type="text" name="ie_theme_settings[footer][brand][socials][<?php echo esc_attr( (string) $index ); ?>][label]" value="<?php echo esc_attr( $social['label'] ?? '' ); ?>" class="regular-text">
            </div>
        </div>
    </div>
    <?php
}

function ie_render_theme_settings_column_row( $col_index, $column ) {
    $type       = $column['type'] ?? 'links';
    $links      = $column['links'] ?? [];
    $items      = $column['items'] ?? [];
    $column_num = ie_theme_settings_row_number( $col_index );
    ?>
    <div class="ie-ts-repeater-item ie-ts-column-item" data-column-index="<?php echo esc_attr( (string) $col_index ); ?>">
        <div class="ie-ts-repeater-item-head">
            <strong><?php echo esc_html( ie__( 'Column' ) ); ?> <span class="ie-ts-column-num"><?php echo esc_html( (string) $column_num ); ?></span></strong>
            <button type="button" class="button-link-delete ie-ts-remove-column"><?php echo esc_html( ie__( 'Remove Column' ) ); ?></button>
        </div>
        <div class="ie-ts-fields-grid ie-ts-fields-grid-2">
            <div>
                <label><?php echo esc_html( ie__( 'Column Title' ) ); ?></label>
                <input type="text" name="ie_theme_settings[footer][columns][<?php echo esc_attr( (string) $col_index ); ?>][title]" value="<?php echo esc_attr( $column['title'] ?? '' ); ?>" class="regular-text">
            </div>
            <div>
                <label><?php echo esc_html( ie__( 'Column Type' ) ); ?></label>
                <select name="ie_theme_settings[footer][columns][<?php echo esc_attr( (string) $col_index ); ?>][type]" class="ie-ts-column-type">
                    <option value="links" <?php selected( $type, 'links' ); ?>><?php echo esc_html( ie__( 'Navigation Links' ) ); ?></option>
                    <option value="contact" <?php selected( $type, 'contact' ); ?>><?php echo esc_html( ie__( 'Contact Info' ) ); ?></option>
                </select>
            </div>
        </div>

        <div class="ie-ts-column-links<?php echo $type === 'contact' ? ' is-hidden' : ''; ?>">
            <div class="ie-ts-subrepeater-head">
                <h4><?php echo esc_html( ie__( 'Links' ) ); ?></h4>
                <button type="button" class="button ie-ts-add-link"><?php echo esc_html( ie__( 'Add Link' ) ); ?></button>
            </div>
            <div class="ie-ts-link-list">
                <?php
                if ( ! $links ) {
                    $links = [ [ 'label' => '', 'url' => '' ] ];
                }
                foreach ( $links as $link_index => $link ) {
                    ie_render_theme_settings_link_row( $col_index, $link_index, $link );
                }
                ?>
            </div>
        </div>

        <div class="ie-ts-column-contact<?php echo $type === 'links' ? ' is-hidden' : ''; ?>">
            <div class="ie-ts-subrepeater-head">
                <h4><?php echo esc_html( ie__( 'Contact Items' ) ); ?></h4>
                <button type="button" class="button ie-ts-add-contact"><?php echo esc_html( ie__( 'Add Item' ) ); ?></button>
            </div>
            <div class="ie-ts-contact-list">
                <?php
                if ( ! $items ) {
                    $items = [ [ 'icon' => '', 'label' => '', 'value' => '', 'link' => '' ] ];
                }
                foreach ( $items as $item_index => $item ) {
                    ie_render_theme_settings_contact_row( $col_index, $item_index, $item );
                }
                ?>
            </div>
        </div>
    </div>
    <?php
}

function ie_render_theme_settings_link_row( $col_index, $link_index, $link ) {
    ?>
    <div class="ie-ts-sub-item ie-ts-link-item">
        <input type="text" name="ie_theme_settings[footer][columns][<?php echo esc_attr( (string) $col_index ); ?>][links][<?php echo esc_attr( (string) $link_index ); ?>][label]" value="<?php echo esc_attr( $link['label'] ?? '' ); ?>" placeholder="<?php echo esc_attr( ie__( 'Link label' ) ); ?>">
        <input type="url" name="ie_theme_settings[footer][columns][<?php echo esc_attr( (string) $col_index ); ?>][links][<?php echo esc_attr( (string) $link_index ); ?>][url]" value="<?php echo esc_url( $link['url'] ?? '' ); ?>" placeholder="<?php echo esc_attr( ie__( 'URL' ) ); ?>">
        <button type="button" class="button ie-ts-remove-link" aria-label="<?php echo esc_attr( ie__( 'Remove link' ) ); ?>">&times;</button>
    </div>
    <?php
}

function ie_render_theme_settings_contact_row( $col_index, $item_index, $item ) {
    ?>
    <div class="ie-ts-sub-item ie-ts-contact-item">
        <input type="text" name="ie_theme_settings[footer][columns][<?php echo esc_attr( (string) $col_index ); ?>][items][<?php echo esc_attr( (string) $item_index ); ?>][icon]" value="<?php echo esc_attr( $item['icon'] ?? '' ); ?>" placeholder="<?php echo esc_attr( ie__( 'Icon class' ) ); ?>">
        <input type="text" name="ie_theme_settings[footer][columns][<?php echo esc_attr( (string) $col_index ); ?>][items][<?php echo esc_attr( (string) $item_index ); ?>][label]" value="<?php echo esc_attr( $item['label'] ?? '' ); ?>" placeholder="<?php echo esc_attr( ie__( 'Label' ) ); ?>">
        <input type="text" name="ie_theme_settings[footer][columns][<?php echo esc_attr( (string) $col_index ); ?>][items][<?php echo esc_attr( (string) $item_index ); ?>][value]" value="<?php echo esc_attr( $item['value'] ?? '' ); ?>" placeholder="<?php echo esc_attr( ie__( 'Value' ) ); ?>">
        <input type="url" name="ie_theme_settings[footer][columns][<?php echo esc_attr( (string) $col_index ); ?>][items][<?php echo esc_attr( (string) $item_index ); ?>][link]" value="<?php echo esc_url( $item['link'] ?? '' ); ?>" placeholder="<?php echo esc_attr( ie__( 'Link (optional)' ) ); ?>">
        <button type="button" class="button ie-ts-remove-contact" aria-label="<?php echo esc_attr( ie__( 'Remove item' ) ); ?>">&times;</button>
    </div>
    <?php
}

function ie_render_theme_settings_templates( $social_presets ) {
    ob_start();
    ie_render_theme_settings_social_row( '__INDEX__', [ 'icon' => '', 'url' => '', 'label' => '' ], $social_presets );
    $social_template = ob_get_clean();

    ob_start();
    ie_render_theme_settings_column_row( '__COL__', [ 'title' => '', 'type' => 'links', 'links' => [ [ 'label' => '', 'url' => '' ] ] ] );
    $column_template = ob_get_clean();

    ob_start();
    ie_render_theme_settings_link_row( '__COL__', '__LINK__', [ 'label' => '', 'url' => '' ] );
    $link_template = ob_get_clean();

    ob_start();
    ie_render_theme_settings_contact_row( '__COL__', '__ITEM__', [ 'icon' => '', 'label' => '', 'value' => '', 'link' => '' ] );
    $contact_template = ob_get_clean();
    ?>
    <script type="text/html" id="ie-ts-social-template"><?php echo $social_template; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
    <script type="text/html" id="ie-ts-column-template"><?php echo $column_template; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
    <script type="text/html" id="ie-ts-link-template"><?php echo $link_template; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
    <script type="text/html" id="ie-ts-contact-template"><?php echo $contact_template; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
    <?php
}
