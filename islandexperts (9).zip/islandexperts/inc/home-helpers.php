<?php
/**
 * Home page template helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_render_home_hero( $hero ) {
    $slides = $hero['slides'] ?? [];
    if ( ! $slides ) {
        return;
    }
    ?>
    <section class="hero-section">
        <div class="hero-slides">
            <?php foreach ( $slides as $index => $slide_url ) : ?>
                <div class="hero-slide<?php echo $index === 0 ? ' active' : ''; ?>" style="background-image:url('<?php echo esc_url( $slide_url ); ?>')"></div>
            <?php endforeach; ?>
        </div>
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <?php if ( ! empty( $hero['title'] ) ) : ?>
                <h1><?php echo esc_html( $hero['title'] ); ?></h1>
            <?php endif; ?>
            <?php if ( ! empty( $hero['subtitle'] ) ) : ?>
                <p><?php echo esc_html( $hero['subtitle'] ); ?></p>
            <?php endif; ?>
            <div class="hero-actions">
                <?php if ( ! empty( $hero['primary_text'] ) && ! empty( $hero['primary_url'] ) ) : ?>
                    <a href="<?php echo esc_url( $hero['primary_url'] ); ?>" class="btn-hero-primary">
                        <?php echo esc_html( $hero['primary_text'] ); ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </a>
                <?php endif; ?>
                <?php if ( ! empty( $hero['secondary_text'] ) && ! empty( $hero['secondary_url'] ) ) : ?>
                    <a href="<?php echo esc_url( $hero['secondary_url'] ); ?>" class="btn-hero-secondary"><?php echo esc_html( $hero['secondary_text'] ); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php
}

function ie_render_home_why( $why ) {
    $items = $why['items'] ?? [];
    if ( ! $items && empty( $why['title'] ) ) {
        return;
    }
    ?>
    <section class="why-section">
        <div class="container">
            <div class="why-section-header">
                <?php if ( ! empty( $why['title'] ) ) : ?>
                    <h2><?php echo esc_html( $why['title'] ); ?></h2>
                <?php endif; ?>
                <?php if ( ! empty( $why['subtitle'] ) ) : ?>
                    <p><?php echo esc_html( $why['subtitle'] ); ?></p>
                <?php endif; ?>
            </div>
            <?php if ( $items ) : ?>
                <div class="why-grid">
                    <?php foreach ( $items as $item ) : ?>
                        <div class="why-item">
                            <div class="why-icon">
                                <i class="<?php echo esc_attr( $item['icon'] ?? 'fa-solid fa-star' ); ?>" aria-hidden="true"></i>
                            </div>
                            <?php if ( ! empty( $item['title'] ) ) : ?>
                                <h3><?php echo esc_html( $item['title'] ); ?></h3>
                            <?php endif; ?>
                            <?php if ( ! empty( $item['text'] ) ) : ?>
                                <p><?php echo esc_html( $item['text'] ); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <?php
}

function ie_render_home_cta( $cta ) {
    if ( empty( $cta['title'] ) && empty( $cta['text'] ) ) {
        return;
    }
    ?>
    <section class="cta-section">
        <div class="container">
            <div class="cta-inner">
                <div class="cta-content">
                    <?php if ( ! empty( $cta['title'] ) ) : ?>
                        <h2><?php echo esc_html( $cta['title'] ); ?></h2>
                    <?php endif; ?>
                    <?php if ( ! empty( $cta['text'] ) ) : ?>
                        <p><?php echo esc_html( $cta['text'] ); ?></p>
                    <?php endif; ?>
                </div>
                <div class="cta-actions">
                    <?php if ( ! empty( $cta['primary_text'] ) && ! empty( $cta['primary_url'] ) ) : ?>
                        <a href="<?php echo esc_url( $cta['primary_url'] ); ?>" class="btn-cta-primary"><?php echo esc_html( $cta['primary_text'] ); ?></a>
                    <?php endif; ?>
                    <?php if ( ! empty( $cta['secondary_text'] ) && ! empty( $cta['secondary_url'] ) ) : ?>
                        <a href="<?php echo esc_url( $cta['secondary_url'] ); ?>" class="btn-cta-outline"><?php echo esc_html( $cta['secondary_text'] ); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <?php
}

function ie_render_home_featured_providers( $section, $browse_url = '' ) {
    if ( ! $browse_url ) {
        $browse_url = ie_get_theme_page_url( 'browse' );
    }

    $featured_providers = [];
    $top_providers      = new WP_Query( [
        'post_type'      => 'ie_provider',
        'post_status'    => 'publish',
        'posts_per_page' => 8,
        'meta_key'       => '_ie_rating',
        'orderby'        => 'meta_value_num',
        'order'          => 'DESC',
    ] );

    if ( $top_providers->have_posts() ) {
        while ( $top_providers->have_posts() ) {
            $top_providers->the_post();
            $featured_providers[] = ie_format_featured_provider( ie_get_provider_data( get_the_ID() ) );
        }
        wp_reset_postdata();
    }

    if ( count( $featured_providers ) < 8 ) {
        $existing_names = array_column( $featured_providers, 'name' );
        foreach ( ie_get_dummy_featured_providers() as $dummy ) {
            if ( count( $featured_providers ) >= 8 ) {
                break;
            }
            if ( ! in_array( $dummy['name'], $existing_names, true ) ) {
                $featured_providers[] = $dummy;
            }
        }
    }

    $featured_providers = array_slice( $featured_providers, 0, 8 );
    ?>
    <section id="top-providers" class="featured-providers-section">
        <div class="container">
            <div class="featured-providers-header">
                <?php if ( ! empty( $section['title'] ) ) : ?>
                    <h2><?php echo esc_html( $section['title'] ); ?></h2>
                <?php endif; ?>
                <?php if ( ! empty( $section['subtitle'] ) ) : ?>
                    <p><?php echo esc_html( $section['subtitle'] ); ?></p>
                <?php endif; ?>
            </div>
            <div class="featured-providers-grid">
                <?php foreach ( $featured_providers as $provider ) {
                    ie_render_featured_provider_card( $provider );
                } ?>
            </div>
            <div class="featured-providers-footer">
                <a href="<?php echo esc_url( $browse_url ); ?>" class="view-all-link view-all-link-branded"><?php echo esc_html( ie__( 'View all categories' ) ); ?> <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>
            </div>
        </div>
    </section>
    <?php
}
