<?php
/**
 * Island Experts – Sample Provider Data Installer
 *
 * Run this ONCE by visiting: yourdomain.com/?ie_install_providers=1
 * Make sure to delete or disable this file afterwards.
 *
 * Usage: Upload to /wp-content/themes/island-experts/inc/install-sample-data.php
 * Then visit your site with ?ie_install_providers=1
 */

// This file is included via functions.php only if requested
function ie_install_providers() {
    if ( ! isset( $_GET['ie_install_providers'] ) || ! current_user_can( 'manage_options' ) ) return;
    if ( get_option( 'ie_providers_installed' ) ) {
        echo '<p style="font-family:sans-serif;padding:40px;color:green;">✅ Sample providers already installed.</p>';
        die;
    }

    $providers = [
        [
            'title'        => 'BrightSpark Electrical',
            'category'     => 'electrical',
            'location'     => 'Castries',
            'rating'       => '4.9',
            'reviews'      => '62',
            'price'        => '65',
            'exp'          => '10',
            'avail'        => 'available_now',
            'verified'     => '1',
            'premium'      => '1',
            'phone'        => '+1 (758) 456-7890',
            'email'        => 'info@brightspark.lc',
            'profile_image'=> 'https://i.pravatar.cc/150?u=brightspark-electrical',
            'description'  => 'Professional electrical services for residential and commercial properties across St. Lucia. Licensed and insured with over 10 years of experience.',
        ],
        [
            'title'        => 'ColorWorks Painting',
            'category'     => 'painting',
            'location'     => 'Gros Islet',
            'rating'       => '4.9',
            'reviews'      => '55',
            'price'        => '75',
            'exp'          => '20',
            'avail'        => 'busy',
            'verified'     => '1',
            'profile_image'=> 'https://i.pravatar.cc/150?u=colorworks-painting',
            'description'  => 'Expert interior and exterior painting services. We use premium paints and guarantee a flawless finish on every project.',
        ],
        [
            'title'        => 'Precision Carpentry',
            'category'     => 'carpentry',
            'location'     => 'Soufrière',
            'rating'       => '4.8',
            'reviews'      => '41',
            'price'        => '25',
            'exp'          => '18',
            'avail'        => 'available_week',
            'verified'     => '1',
            'profile_image'=> 'https://i.pravatar.cc/150?u=precision-carpentry',
            'description'  => 'Custom carpentry and woodworking for kitchens, furniture, and structural work throughout southern St. Lucia.',
        ],
        [
            'title'        => 'Fix-It Plumbing Co.',
            'category'     => 'plumbing',
            'location'     => 'Vieux Fort',
            'rating'       => '4.8',
            'reviews'      => '47',
            'price'        => '75',
            'exp'          => '15',
            'avail'        => 'available_now',
            'verified'     => '1',
            'profile_image'=> 'https://i.pravatar.cc/150?u=fixit-plumbing',
            'description'  => 'Fast, reliable plumbing services. Emergency callouts available 24/7 in Vieux Fort and surrounding areas.',
        ],
        [
            'title'        => 'Sparkle Clean Services',
            'category'     => 'cleaning',
            'location'     => 'Castries & Surrounding',
            'rating'       => '4.7',
            'reviews'      => '89',
            'price'        => '45',
            'exp'          => '7',
            'avail'        => 'available_week',
            'verified'     => '1',
            'profile_image'=> 'https://i.pravatar.cc/150?u=sparkle-clean',
            'description'  => 'Residential and commercial cleaning services. Regular, deep clean, and move-in/move-out packages available.',
        ],
        [
            'title'        => 'Greenscapes Landscaping',
            'category'     => 'landscaping',
            'location'     => 'Dennery',
            'rating'       => '4.6',
            'reviews'      => '34',
            'price'        => '45',
            'exp'          => '12',
            'avail'        => 'available_now',
            'profile_image'=> 'https://i.pravatar.cc/150?u=greenscapes-landscaping',
            'description'  => 'Full-service landscaping, garden maintenance, and lawn care across St. Lucia. Transform your outdoor space.',
        ],
        [
            'title'        => 'CoolBreeze HVAC',
            'category'     => 'hvac',
            'location'     => 'Countywide',
            'rating'       => '4.5',
            'reviews'      => '28',
            'price'        => '99',
            'exp'          => '8',
            'avail'        => 'available_now',
            'verified'     => '1',
            'description'  => 'Air conditioning installation, repair, and maintenance. All major brands serviced island-wide.',
        ],
        [
            'title'        => 'SwiftMove Relocations',
            'category'     => 'moving',
            'location'     => 'Metro Area',
            'rating'       => '4.4',
            'reviews'      => '19',
            'price'        => '40',
            'exp'          => '5',
            'avail'        => 'available_now',
            'description'  => 'Affordable and professional moving services for homes and offices. Careful handling of all your belongings.',
        ],
        [
            'title'        => 'Island Pest Solutions',
            'category'     => 'pest-control',
            'location'     => 'Castries',
            'rating'       => '4.3',
            'reviews'      => '22',
            'price'        => '60',
            'exp'          => '9',
            'avail'        => 'available_week',
            'verified'     => '1',
            'description'  => 'Environmentally responsible pest control for homes and businesses. Termites, ants, roaches, and more.',
        ],
        [
            'title'        => 'TopShield Roofing',
            'category'     => 'roofing',
            'location'     => 'Island-wide',
            'rating'       => '4.5',
            'reviews'      => '16',
            'price'        => '150',
            'exp'          => '14',
            'avail'        => 'available_week',
            'description'  => 'Expert roofing installation and repair services. Hurricane-resistant materials and workmanship guarantee.',
        ],
        [
            'title'        => 'Oasis Landscaping',
            'category'     => 'landscaping',
            'location'     => 'Gros Islet',
            'rating'       => '0',
            'reviews'      => '0',
            'price'        => '50',
            'exp'          => '3',
            'avail'        => 'available_now',
            'description'  => 'Landscaping and lawn care services in the north of the island. New business, competitive pricing.',
        ],
    ];

    echo '<div style="font-family:sans-serif;padding:40px;max-width:600px;">';
    echo '<h2>Installing Sample Providers…</h2>';

    foreach ( $providers as $prov ) {
        // Check if already exists
        $existing = get_posts([
            'post_type'   => 'ie_provider',
            'post_status' => 'any',
            'title'       => $prov['title'],
            'numberposts' => 1,
        ]);

        if ( $existing ) {
            echo '<p>⏭ Skipped: ' . esc_html( $prov['title'] ) . ' (already exists)</p>';
            continue;
        }

        $pid = wp_insert_post([
            'post_type'    => 'ie_provider',
            'post_title'   => $prov['title'],
            'post_content' => $prov['description'] ?? '',
            'post_status'  => 'publish',
        ]);

        if ( is_wp_error( $pid ) ) {
            echo '<p style="color:red;">✕ Error: ' . esc_html( $pid->get_error_message() ) . '</p>';
            continue;
        }

        // Assign category
        if ( ! empty( $prov['category'] ) ) {
            $term = get_term_by( 'slug', $prov['category'], 'ie_category' );
            if ( $term ) wp_set_post_terms( $pid, [ $term->term_id ], 'ie_category' );
        }

        $service_image = ! empty( $prov['image'] )
            ? $prov['image']
            : ie_get_category_service_image( $prov['category'] ?? '' );

        // Assign location
        if ( ! empty( $prov['location'] ) ) {
            $loc_term = get_term_by( 'name', $prov['location'], 'ie_location' );
            if ( ! $loc_term ) {
                $new_loc = wp_insert_term( $prov['location'], 'ie_location' );
                if ( ! is_wp_error( $new_loc ) ) {
                    wp_set_post_terms( $pid, [ $new_loc['term_id'] ], 'ie_location' );
                }
            } else {
                wp_set_post_terms( $pid, [ $loc_term->term_id ], 'ie_location' );
            }
        }

        // Meta
        update_post_meta( $pid, '_ie_rating',           $prov['rating'] ?? '' );
        update_post_meta( $pid, '_ie_review_count',     $prov['reviews'] ?? '' );
        update_post_meta( $pid, '_ie_price_from',       $prov['price'] ?? '' );
        update_post_meta( $pid, '_ie_experience_years', $prov['exp'] ?? '' );
        update_post_meta( $pid, '_ie_service_area',     $prov['location'] ?? '' );
        update_post_meta( $pid, '_ie_availability',     $prov['avail'] ?? '' );
        update_post_meta( $pid, '_ie_verified',         $prov['verified'] ?? '' );
        update_post_meta( $pid, '_ie_premium',          $prov['premium'] ?? '' );
        update_post_meta( $pid, '_ie_phone',            $prov['phone'] ?? '' );
        update_post_meta( $pid, '_ie_email',            $prov['email'] ?? '' );
        update_post_meta( $pid, '_ie_about',            $prov['description'] ?? '' );
        update_post_meta( $pid, '_ie_profile_image',    $prov['profile_image'] ?? '' );

        if ( ! empty( $service_image ) ) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attachment_id = media_sideload_image( $service_image, $pid, $prov['title'], 'id' );
            if ( ! is_wp_error( $attachment_id ) ) {
                set_post_thumbnail( $pid, $attachment_id );
            }
        }

        echo '<p style="color:green;">✅ Created: ' . esc_html( $prov['title'] ) . '</p>';
    }

    update_option( 'ie_providers_installed', '1' );
    echo '<p style="margin-top:20px;font-weight:bold;">Done! <a href="' . esc_url( home_url('/') ) . '">Visit your site →</a></p>';
    echo '<p style="color:red;margin-top:8px;font-size:12px;">⚠️ IMPORTANT: Remove or disable this file for security.</p>';
    echo '</div>';
    die;
}
add_action( 'init', 'ie_install_providers' );
