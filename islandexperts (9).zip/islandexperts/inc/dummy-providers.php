<?php
/**
 * Dummy service provider profiles for demo / home featured section.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_dummy_providers() {
    return [
        'brightspark-electrical' => [
            'name'          => 'BrightSpark Electrical',
            'rating'        => '4.9',
            'reviews'       => '62',
            'category'      => ie__( 'Electrical' ),
            'category_slug' => 'electrical',
            'bio'           => ie__( 'Licensed electricians for residential and commercial work across St. Lucia. Fast response, safe installations, and fair pricing.' ),
            'about'         => ie__( 'BrightSpark Electrical delivers safe, code-compliant electrical work for homes and businesses across St. Lucia. From panel upgrades to full rewiring, our licensed team responds quickly and stands behind every job.' ),
            'profile_image' => 'https://i.pravatar.cc/150?u=brightspark-electrical',
            'location'      => ie__( 'Castries' ),
            'experience'    => '10',
            'price'         => '65',
            'phone'         => '+1 (758) 456-7890',
            'email'         => 'info@brightspark.lc',
            'verified'      => true,
            'availability'  => 'available_now',
            'services'      => [
                [ 'name' => ie__( 'Electrical Inspection' ), 'price' => '65', 'unit' => 'job' ],
                [ 'name' => ie__( 'Outlet & Switch Repair' ), 'price' => '45', 'unit' => 'job' ],
            ],
        ],
        'fixit-plumbing' => [
            'name'          => 'Fix-It Plumbing Co.',
            'rating'        => '4.8',
            'reviews'       => '47',
            'category'      => ie__( 'Plumbing' ),
            'category_slug' => 'plumbing',
            'bio'           => ie__( 'Reliable plumbing repairs, installations, and 24/7 emergency callouts in Vieux Fort and surrounding areas.' ),
            'about'         => ie__( 'Fix-It Plumbing Co. handles everything from leaky faucets to full bathroom installations. Our emergency team is available around the clock for urgent plumbing issues in Vieux Fort and nearby communities.' ),
            'profile_image' => 'https://i.pravatar.cc/150?u=fixit-plumbing',
            'location'      => ie__( 'Vieux Fort' ),
            'experience'    => '15',
            'price'         => '75',
            'phone'         => '+1 (758) 555-0142',
            'email'         => 'help@fixitplumbing.lc',
            'verified'      => true,
            'availability'  => 'available_now',
            'services'      => [
                [ 'name' => ie__( 'Pipe Repair' ), 'price' => '75', 'unit' => 'job' ],
                [ 'name' => ie__( 'Drain Cleaning' ), 'price' => '55', 'unit' => 'job' ],
            ],
        ],
        'sparkle-clean' => [
            'name'          => 'Sparkle Clean Services',
            'rating'        => '4.7',
            'reviews'       => '89',
            'category'      => ie__( 'Cleaning' ),
            'category_slug' => 'cleaning',
            'bio'           => ie__( 'Professional home and office cleaning with deep-clean, move-in, and recurring service packages available island-wide.' ),
            'about'         => ie__( 'Sparkle Clean Services offers reliable residential and commercial cleaning with eco-friendly products. Choose one-time deep cleans, move-in packages, or recurring weekly service tailored to your schedule.' ),
            'profile_image' => 'https://i.pravatar.cc/150?u=sparkle-clean',
            'location'      => ie__( 'Castries & Surrounding' ),
            'experience'    => '7',
            'price'         => '45',
            'phone'         => '+1 (758) 555-0198',
            'email'         => 'book@sparkleclean.lc',
            'verified'      => true,
            'availability'  => 'available_week',
            'services'      => [
                [ 'name' => ie__( 'Standard Home Clean' ), 'price' => '45', 'unit' => 'job' ],
                [ 'name' => ie__( 'Deep Clean' ), 'price' => '85', 'unit' => 'job' ],
            ],
        ],
        'colorworks-painting' => [
            'name'          => 'ColorWorks Painting',
            'rating'        => '4.9',
            'reviews'       => '55',
            'category'      => ie__( 'Painting' ),
            'category_slug' => 'painting',
            'bio'           => ie__( 'Interior and exterior painting specialists using premium materials for a flawless, long-lasting finish on every project.' ),
            'about'         => ie__( 'ColorWorks Painting transforms interiors and exteriors with meticulous prep work and premium paints. We deliver clean lines, even coverage, and finishes built to withstand St. Lucia\'s climate.' ),
            'profile_image' => 'https://i.pravatar.cc/150?u=colorworks-painting',
            'location'      => ie__( 'Gros Islet' ),
            'experience'    => '20',
            'price'         => '75',
            'phone'         => '+1 (758) 555-0231',
            'email'         => 'hello@colorworks.lc',
            'verified'      => true,
            'availability'  => 'busy',
            'services'      => [
                [ 'name' => ie__( 'Interior Room Paint' ), 'price' => '75', 'unit' => 'room' ],
                [ 'name' => ie__( 'Exterior Wall Paint' ), 'price' => '120', 'unit' => 'job' ],
            ],
        ],
        'precision-carpentry' => [
            'name'          => 'Precision Carpentry',
            'rating'        => '4.8',
            'reviews'       => '41',
            'category'      => ie__( 'Carpentry' ),
            'category_slug' => 'carpentry',
            'bio'           => ie__( 'Custom kitchens, built-ins, furniture, and structural carpentry crafted with precision for homes across southern St. Lucia.' ),
            'about'         => ie__( 'Precision Carpentry builds custom cabinetry, wardrobes, and structural woodwork with attention to detail. We work closely with homeowners to design durable solutions that fit your space and budget.' ),
            'profile_image' => 'https://i.pravatar.cc/150?u=precision-carpentry',
            'location'      => ie__( 'Soufrière' ),
            'experience'    => '18',
            'price'         => '25',
            'phone'         => '+1 (758) 555-0267',
            'email'         => 'projects@precisioncarpentry.lc',
            'verified'      => true,
            'availability'  => 'available_week',
            'services'      => [
                [ 'name' => ie__( 'Custom Shelving' ), 'price' => '25', 'unit' => 'hr' ],
                [ 'name' => ie__( 'Kitchen Cabinet Install' ), 'price' => '350', 'unit' => 'job' ],
            ],
        ],
        'greenscapes-landscaping' => [
            'name'          => 'Greenscapes Landscaping',
            'rating'        => '4.6',
            'reviews'       => '34',
            'category'      => ie__( 'Landscaping' ),
            'category_slug' => 'landscaping',
            'bio'           => ie__( 'Garden design, lawn care, and outdoor maintenance to transform and maintain beautiful spaces across the island.' ),
            'about'         => ie__( 'Greenscapes Landscaping designs and maintains outdoor spaces with native plants, lawn care, and seasonal upkeep. Let us help you create a beautiful, low-maintenance garden you\'ll enjoy year-round.' ),
            'profile_image' => 'https://i.pravatar.cc/150?u=greenscapes-landscaping',
            'location'      => ie__( 'Dennery' ),
            'experience'    => '12',
            'price'         => '45',
            'phone'         => '+1 (758) 555-0310',
            'email'         => 'care@greenscapes.lc',
            'verified'      => false,
            'availability'  => 'available_now',
            'services'      => [
                [ 'name' => ie__( 'Lawn Maintenance' ), 'price' => '45', 'unit' => 'visit' ],
                [ 'name' => ie__( 'Garden Design Consult' ), 'price' => '90', 'unit' => 'job' ],
            ],
        ],
        'coolbreeze-hvac' => [
            'name'          => 'CoolBreeze HVAC',
            'rating'        => '4.5',
            'reviews'       => '28',
            'category'      => ie__( 'HVAC' ),
            'category_slug' => 'hvac',
            'bio'           => ie__( 'Air conditioning installation, repair, and maintenance for homes and businesses island-wide.' ),
            'about'         => ie__( 'CoolBreeze HVAC installs, services, and repairs air conditioning systems for residential and commercial clients. We work with all major brands and offer maintenance plans to keep you cool year-round.' ),
            'profile_image' => 'https://i.pravatar.cc/150?u=coolbreeze-hvac',
            'location'      => ie__( 'Island-wide' ),
            'experience'    => '8',
            'price'         => '99',
            'phone'         => '+1 (758) 555-0344',
            'email'         => 'service@coolbreeze.lc',
            'verified'      => true,
            'availability'  => 'available_now',
            'services'      => [
                [ 'name' => ie__( 'AC Service & Tune-up' ), 'price' => '99', 'unit' => 'job' ],
                [ 'name' => ie__( 'Unit Installation' ), 'price' => '250', 'unit' => 'job' ],
            ],
        ],
        'swiftmove-relocations' => [
            'name'          => 'SwiftMove Relocations',
            'rating'        => '4.4',
            'reviews'       => '19',
            'category'      => ie__( 'Moving' ),
            'category_slug' => 'moving',
            'bio'           => ie__( 'Professional home and office moving services with careful handling and affordable island-wide rates.' ),
            'about'         => ie__( 'SwiftMove Relocations provides careful, efficient moving for homes and offices across St. Lucia. Our trained team handles packing, transport, and setup so your move is stress-free from start to finish.' ),
            'profile_image' => 'https://i.pravatar.cc/150?u=swiftmove-relocations',
            'location'      => ie__( 'Metro Area' ),
            'experience'    => '5',
            'price'         => '40',
            'phone'         => '+1 (758) 555-0378',
            'email'         => 'move@swiftmove.lc',
            'verified'      => false,
            'availability'  => 'available_now',
            'services'      => [
                [ 'name' => ie__( 'Local Home Move' ), 'price' => '40', 'unit' => 'hr' ],
                [ 'name' => ie__( 'Office Relocation' ), 'price' => '180', 'unit' => 'job' ],
            ],
        ],
    ];
}

function ie_get_dummy_provider_by_slug( $slug ) {
    $providers = ie_get_dummy_providers();
    $slug      = sanitize_title( $slug );

    return $providers[ $slug ] ?? null;
}

function ie_get_dummy_featured_providers() {
    $slugs    = [
        'brightspark-electrical',
        'fixit-plumbing',
        'sparkle-clean',
        'colorworks-painting',
        'precision-carpentry',
        'greenscapes-landscaping',
        'coolbreeze-hvac',
        'swiftmove-relocations',
    ];
    $all      = ie_get_dummy_providers();
    $featured = [];

    foreach ( $slugs as $slug ) {
        if ( empty( $all[ $slug ] ) ) {
            continue;
        }

        $p          = $all[ $slug ];
        $featured[] = [
            'id'            => 0,
            'slug'          => $slug,
            'name'          => $p['name'],
            'rating'        => $p['rating'],
            'reviews'       => $p['reviews'],
            'category'      => $p['category'],
            'category_slug' => $p['category_slug'],
            'bio'           => $p['bio'],
            'service_image' => ie_get_featured_service_image( $p['category_slug'], '' ),
            'profile_image' => $p['profile_image'],
            'permalink'     => ie_get_provider_single_url( $slug ),
            'chat_url'      => ie_get_provider_single_url( $slug ) . '#sp-contact',
            'price'         => $p['price'] ?? '',
        ];
    }

    return $featured;
}

function ie_get_dummy_provider_reviews( $slug ) {
    $reviews = [
        'brightspark-electrical' => [
            [ 'author' => 'Marcus T.', 'rating' => 5, 'date' => 'Mar 8, 2026', 'text' => ie__( 'Fixed our office wiring quickly and professionally. Very knowledgeable team and fair pricing.' ) ],
            [ 'author' => 'Denise F.', 'rating' => 5, 'date' => 'Feb 19, 2026', 'text' => ie__( 'Responded same day for an emergency outlet issue. Clean work and explained everything clearly.' ) ],
            [ 'author' => 'Kevin B.', 'rating' => 4, 'date' => 'Jan 30, 2026', 'text' => ie__( 'Great panel upgrade service. Arrived on time and left the workspace tidy.' ) ],
        ],
        'fixit-plumbing' => [
            [ 'author' => 'Alana P.', 'rating' => 5, 'date' => 'Mar 5, 2026', 'text' => ie__( 'Came out late at night for a burst pipe. Fast, calm, and got everything under control.' ) ],
            [ 'author' => 'Jerome L.', 'rating' => 5, 'date' => 'Feb 11, 2026', 'text' => ie__( 'Installed a new bathroom fixture perfectly. Honest quote and no hidden fees.' ) ],
            [ 'author' => 'Sandra M.', 'rating' => 4, 'date' => 'Jan 22, 2026', 'text' => ie__( 'Reliable drain cleaning service. Would definitely call them again.' ) ],
        ],
        'sparkle-clean' => [
            [ 'author' => 'Rachel G.', 'rating' => 5, 'date' => 'Mar 10, 2026', 'text' => ie__( 'Our home has never looked this clean. Attention to detail was outstanding.' ) ],
            [ 'author' => 'Philip H.', 'rating' => 5, 'date' => 'Feb 24, 2026', 'text' => ie__( 'Office deep clean was thorough and well organised. Team was friendly and efficient.' ) ],
            [ 'author' => 'Nadia C.', 'rating' => 4, 'date' => 'Feb 2, 2026', 'text' => ie__( 'Great move-in cleaning package. Every corner was spotless when we arrived.' ) ],
        ],
        'colorworks-painting' => [
            [ 'author' => 'Andre W.', 'rating' => 5, 'date' => 'Mar 3, 2026', 'text' => ie__( 'Beautiful exterior paint job that still looks fresh after heavy rain. Highly recommend.' ) ],
            [ 'author' => 'Claire D.', 'rating' => 5, 'date' => 'Feb 15, 2026', 'text' => ie__( 'Interior rooms finished with crisp lines and zero mess. Very professional crew.' ) ],
            [ 'author' => 'Owen S.', 'rating' => 5, 'date' => 'Jan 18, 2026', 'text' => ie__( 'Helped us pick the right colours and completed the job ahead of schedule.' ) ],
        ],
        'precision-carpentry' => [
            [ 'author' => 'Helena R.', 'rating' => 5, 'date' => 'Mar 1, 2026', 'text' => ie__( 'Custom kitchen shelves fit perfectly. Excellent craftsmanship and communication.' ) ],
            [ 'author' => 'David K.', 'rating' => 5, 'date' => 'Feb 8, 2026', 'text' => ie__( 'Built a wardrobe exactly to our specifications. Solid work and fair price.' ) ],
            [ 'author' => 'Monique J.', 'rating' => 4, 'date' => 'Jan 25, 2026', 'text' => ie__( 'Reliable carpentry for door repairs. Neat finish and respectful of our home.' ) ],
        ],
        'greenscapes-landscaping' => [
            [ 'author' => 'Thomas E.', 'rating' => 5, 'date' => 'Feb 28, 2026', 'text' => ie__( 'Transformed our backyard with smart planting choices. Garden looks amazing now.' ) ],
            [ 'author' => 'Lisa A.', 'rating' => 4, 'date' => 'Feb 12, 2026', 'text' => ie__( 'Consistent lawn care and trimming. Yard always looks well maintained.' ) ],
            [ 'author' => 'Gregory N.', 'rating' => 5, 'date' => 'Jan 20, 2026', 'text' => ie__( 'Professional landscaping consultation with practical ideas for our budget.' ) ],
        ],
        'coolbreeze-hvac' => [
            [ 'author' => 'Patricia V.', 'rating' => 5, 'date' => 'Mar 6, 2026', 'text' => ie__( 'AC installation was smooth and the unit cools our shop perfectly.' ) ],
            [ 'author' => 'Sean M.', 'rating' => 4, 'date' => 'Feb 17, 2026', 'text' => ie__( 'Quick service call for a noisy unit. Problem solved the same visit.' ) ],
            [ 'author' => 'Vanessa T.', 'rating' => 5, 'date' => 'Jan 29, 2026', 'text' => ie__( 'Annual maintenance plan keeps our home comfortable year-round. Great value.' ) ],
        ],
        'swiftmove-relocations' => [
            [ 'author' => 'Carlos B.', 'rating' => 5, 'date' => 'Feb 22, 2026', 'text' => ie__( 'Careful with our furniture and finished the move faster than expected.' ) ],
            [ 'author' => 'Emily R.', 'rating' => 4, 'date' => 'Feb 5, 2026', 'text' => ie__( 'Friendly team and no damage to any items. Stress-free moving experience.' ) ],
            [ 'author' => 'Ian P.', 'rating' => 5, 'date' => 'Jan 15, 2026', 'text' => ie__( 'Office relocation handled professionally from packing to setup.' ) ],
        ],
    ];

    $slug = sanitize_title( $slug );

    return $reviews[ $slug ] ?? [
        [ 'author' => 'Guest User', 'rating' => 5, 'date' => 'Feb 1, 2026', 'text' => ie__( 'Excellent service and very professional. Would hire again.' ) ],
        [ 'author' => 'Local Customer', 'rating' => 4, 'date' => 'Jan 10, 2026', 'text' => ie__( 'Good communication and quality work from start to finish.' ) ],
    ];
}

function ie_get_provider_reviews_list( $provider_id, $slug ) {
    if ( $provider_id ) {
        $comments = get_comments( [
            'post_id' => $provider_id,
            'status'  => 'approve',
            'number'  => 5,
            'orderby' => 'comment_date',
            'order'   => 'DESC',
        ] );

        if ( $comments ) {
            $list = [];
            foreach ( $comments as $comment ) {
                $list[] = [
                    'author' => $comment->comment_author,
                    'rating' => (int) ( get_comment_meta( $comment->comment_ID, '_ie_review_rating', true ) ?: 5 ),
                    'date'   => date_i18n( 'M j, Y', strtotime( $comment->comment_date ) ),
                    'text'   => $comment->comment_content,
                ];
            }
            return $list;
        }
    }

    return ie_get_dummy_provider_reviews( $slug );
}

function ie_is_dummy_message_provider_id( $id ) {
    return is_string( $id ) && strpos( $id, 'dummy-' ) === 0;
}

function ie_get_dummy_message_slug( $id ) {
    return ie_is_dummy_message_provider_id( $id ) ? substr( $id, 6 ) : '';
}

function ie_get_dummy_message_conversations() {
    $items = [
        [
            'slug'         => 'brightspark-electrical',
            'last_message' => ie__( 'Yes, I can come by tomorrow morning to take a look.' ),
            'last_time'    => gmdate( 'Y-m-d H:i:s', strtotime( 'today 04:26' ) ),
        ],
        [
            'slug'         => 'fixit-plumbing',
            'last_message' => ie__( 'The pipe repair quote I sent still works for you?' ),
            'last_time'    => gmdate( 'Y-m-d H:i:s', strtotime( '-3 days 14:10' ) ),
        ],
        [
            'slug'         => 'colorworks-painting',
            'last_message' => ie__( 'We can start the exterior painting next week.' ),
            'last_time'    => gmdate( 'Y-m-d H:i:s', strtotime( '-5 days 11:40' ) ),
        ],
        [
            'slug'         => 'sparkle-clean',
            'last_message' => ie__( 'Deep clean package is available this Saturday.' ),
            'last_time'    => gmdate( 'Y-m-d H:i:s', strtotime( '-8 days 09:15' ) ),
        ],
    ];

    $conversations = [];
    foreach ( $items as $item ) {
        $provider = ie_get_dummy_provider_by_slug( $item['slug'] );
        if ( ! $provider ) {
            continue;
        }

        $conversations[] = [
            'id'           => 'dummy-' . $item['slug'],
            'slug'         => $item['slug'],
            'name'         => $provider['name'],
            'category'     => $provider['category'],
            'avatar'       => ie_get_provider_avatar_url( $provider['name'], $provider['profile_image'] ?? '' ),
            'permalink'    => ie_get_provider_single_url( $item['slug'] ),
            'last_message' => $item['last_message'],
            'last_time'    => $item['last_time'],
            'has_messages' => true,
            'is_dummy'     => true,
        ];
    }

    return $conversations;
}

function ie_get_dummy_chat_messages( $slug ) {
    $slug = sanitize_title( $slug );
    $threads = [
        'brightspark-electrical' => [
            [
                'sender' => 'provider',
                'body'   => ie__( 'Hello! Thanks for reaching out to BrightSpark Electrical. How can I help you today?' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( 'today 04:20' ) ),
            ],
            [
                'sender' => 'customer',
                'body'   => ie__( 'Hi, I need someone to check a few outlets that stopped working in my kitchen.' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( 'today 04:22' ) ),
            ],
            [
                'sender' => 'provider',
                'body'   => ie__( 'No problem. Can you tell me if the whole kitchen lost power or just a few sockets?' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( 'today 04:24' ) ),
            ],
            [
                'sender' => 'customer',
                'body'   => ie__( 'Just two outlets near the counter. The lights still work fine.' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( 'today 04:25' ) ),
            ],
            [
                'sender' => 'provider',
                'body'   => ie__( 'Yes, I can come by tomorrow morning to take a look.' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( 'today 04:26' ) ),
            ],
        ],
        'fixit-plumbing' => [
            [
                'sender' => 'customer',
                'body'   => ie__( 'Hi, I have a leaking pipe under the bathroom sink.' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( '-3 days 13:50' ) ),
            ],
            [
                'sender' => 'provider',
                'body'   => ie__( 'Thanks for the message. I can stop by this afternoon if that works for you.' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( '-3 days 14:00' ) ),
            ],
            [
                'sender' => 'provider',
                'body'   => ie__( 'The pipe repair quote I sent still works for you?' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( '-3 days 14:10' ) ),
            ],
        ],
        'colorworks-painting' => [
            [
                'sender' => 'customer',
                'body'   => ie__( 'Can you repaint the exterior of a small guest house in Gros Islet?' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( '-5 days 10:55' ) ),
            ],
            [
                'sender' => 'provider',
                'body'   => ie__( 'Absolutely. I would need photos or a quick site visit for an accurate quote.' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( '-5 days 11:15' ) ),
            ],
            [
                'sender' => 'provider',
                'body'   => ie__( 'We can start the exterior painting next week.' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( '-5 days 11:40' ) ),
            ],
        ],
        'sparkle-clean' => [
            [
                'sender' => 'customer',
                'body'   => ie__( 'Do you offer a one-time deep clean before guests arrive?' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( '-8 days 08:50' ) ),
            ],
            [
                'sender' => 'provider',
                'body'   => ie__( 'Yes we do. Our deep clean package includes kitchen, bathrooms, and all living areas.' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( '-8 days 09:05' ) ),
            ],
            [
                'sender' => 'provider',
                'body'   => ie__( 'Deep clean package is available this Saturday.' ),
                'time'   => gmdate( 'Y-m-d H:i:s', strtotime( '-8 days 09:15' ) ),
            ],
        ],
    ];

    if ( ! empty( $threads[ $slug ] ) ) {
        return $threads[ $slug ];
    }

    return [
        [
            'sender' => 'provider',
            'body'   => ie__( 'Hello! Send us a message and we will get back to you shortly.' ),
            'time'   => current_time( 'mysql' ),
        ],
    ];
}

function ie_get_dummy_message_provider_meta( $slug ) {
    $provider = ie_get_dummy_provider_by_slug( $slug );
    if ( ! $provider ) {
        return null;
    }

    return [
        'id'        => 'dummy-' . sanitize_title( $slug ),
        'slug'      => sanitize_title( $slug ),
        'name'      => $provider['name'],
        'category'  => $provider['category'],
        'avatar'    => ie_get_provider_avatar_url( $provider['name'], $provider['profile_image'] ?? '' ),
        'permalink' => ie_get_provider_single_url( $slug ),
        'is_dummy'  => true,
    ];
}

function ie_get_dummy_provider_inbox_conversations() {
    return [
        [
            'id'           => 'dummy-customer-marcus',
            'name'         => 'Marcus T.',
            'avatar'       => 'https://i.pravatar.cc/150?u=marcus-customer',
            'last_message' => ie__( 'Can you come by tomorrow morning for the outlet issue?' ),
            'last_time'    => '2026-03-10 09:15:00',
            'is_dummy'     => true,
        ],
        [
            'id'           => 'dummy-customer-alana',
            'name'         => 'Alana P.',
            'avatar'       => 'https://i.pravatar.cc/150?u=alana-customer',
            'last_message' => ie__( 'Thanks for the quick response yesterday!' ),
            'last_time'    => '2026-03-09 16:40:00',
            'is_dummy'     => true,
        ],
        [
            'id'           => 'dummy-customer-denise',
            'name'         => 'Denise F.',
            'avatar'       => 'https://i.pravatar.cc/150?u=denise-customer',
            'last_message' => ie__( 'What is your availability this weekend?' ),
            'last_time'    => '2026-03-08 11:20:00',
            'is_dummy'     => true,
        ],
    ];
}

function ie_is_dummy_provider_inbox_customer_id( $customer_id ) {
    return is_string( $customer_id ) && strpos( $customer_id, 'dummy-customer-' ) === 0;
}

function ie_get_dummy_provider_inbox_messages( $customer_id ) {
    $threads = [
        'dummy-customer-marcus' => [
            [ 'sender' => 'customer', 'body' => ie__( 'Hi, I need help with a faulty outlet in my kitchen.' ), 'time' => '2026-03-10 08:30:00' ],
            [ 'sender' => 'provider', 'body' => ie__( 'Hello Marcus! I can take a look tomorrow morning.' ), 'time' => '2026-03-10 08:45:00' ],
            [ 'sender' => 'customer', 'body' => ie__( 'Can you come by tomorrow morning for the outlet issue?' ), 'time' => '2026-03-10 09:15:00' ],
        ],
        'dummy-customer-alana' => [
            [ 'sender' => 'customer', 'body' => ie__( 'The repair looks great, thank you!' ), 'time' => '2026-03-09 16:10:00' ],
            [ 'sender' => 'provider', 'body' => ie__( 'Happy to help anytime, Alana.' ), 'time' => '2026-03-09 16:25:00' ],
            [ 'sender' => 'customer', 'body' => ie__( 'Thanks for the quick response yesterday!' ), 'time' => '2026-03-09 16:40:00' ],
        ],
        'dummy-customer-denise' => [
            [ 'sender' => 'customer', 'body' => ie__( 'What is your availability this weekend?' ), 'time' => '2026-03-08 11:20:00' ],
        ],
    ];

    return $threads[ $customer_id ] ?? [];
}
