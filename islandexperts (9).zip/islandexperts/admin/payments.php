<?php
/**
 * Island Experts Admin — payments module.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'IE_PAYMENT_SETTINGS_OPTION', 'ie_payment_settings' );
define( 'IE_PAYMENT_LOGS_OPTION', 'ie_payment_logs' );

function ie_admin_get_default_payment_settings() {
    return [
        'stripe_enabled'     => '0',
        'stripe_publishable' => '',
        'stripe_secret'      => '',
    ];
}

function ie_admin_get_payment_settings() {
    $settings = get_option( IE_PAYMENT_SETTINGS_OPTION, [] );
    if ( ! is_array( $settings ) ) {
        $settings = [];
    }

    return wp_parse_args( $settings, ie_admin_get_default_payment_settings() );
}

function ie_admin_sanitize_payment_settings( $input ) {
    if ( ! is_array( $input ) ) {
        return ie_admin_get_default_payment_settings();
    }

    return [
        'stripe_enabled'     => ! empty( $input['stripe_enabled'] ) ? '1' : '0',
        'stripe_publishable' => sanitize_text_field( $input['stripe_publishable'] ?? '' ),
        'stripe_secret'      => sanitize_text_field( $input['stripe_secret'] ?? '' ),
    ];
}

function ie_admin_get_stripe_webhook_url() {
    return add_query_arg( 'ie_stripe_webhook', '1', home_url( '/' ) );
}

function ie_admin_get_payment_logs( $limit = 50 ) {
    $logs = get_option( IE_PAYMENT_LOGS_OPTION, [] );
    if ( ! is_array( $logs ) ) {
        return [];
    }

    usort( $logs, function ( $a, $b ) {
        return strcmp( $b['date'] ?? '', $a['date'] ?? '' );
    } );

    return array_slice( $logs, 0, $limit );
}

function ie_admin_add_payment_log( $entry ) {
    $logs   = ie_admin_get_payment_logs( 200 );
    $logs[] = wp_parse_args( $entry, [
        'id'      => uniqid( 'log_', true ),
        'date'    => current_time( 'mysql' ),
        'amount'  => '0.00',
        'status'  => 'info',
        'user_id' => 0,
        'message' => '',
    ] );

    update_option( IE_PAYMENT_LOGS_OPTION, array_slice( $logs, -200 ), false );
}

function ie_admin_test_stripe_connection() {
    $settings = ie_admin_get_payment_settings();
    $secret   = $settings['stripe_secret'] ?? '';

    if ( $secret === '' ) {
        return new WP_Error( 'missing_secret', ie__( 'Stripe secret key is required.' ) );
    }

    $response = wp_remote_get(
        'https://api.stripe.com/v1/balance',
        [
            'headers' => [
                'Authorization' => 'Bearer ' . $secret,
            ],
            'timeout' => 15,
        ]
    );

    if ( is_wp_error( $response ) ) {
        return $response;
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( $code >= 200 && $code < 300 ) {
        ie_admin_add_payment_log( [
            'status'  => 'success',
            'message' => ie__( 'Stripe connection test successful.' ),
        ] );

        return [
            'message' => ie__( 'Stripe connection successful.' ),
            'livemode'=> ! empty( $body['livemode'] ),
        ];
    }

    $error = $body['error']['message'] ?? ie__( 'Stripe connection failed.' );

    ie_admin_add_payment_log( [
        'status'  => 'failed',
        'message' => $error,
    ] );

    return new WP_Error( 'stripe_failed', $error );
}

function ie_admin_handle_stripe_webhook() {
    if ( empty( $_GET['ie_stripe_webhook'] ) ) {
        return;
    }

    $payload = file_get_contents( 'php://input' );
    ie_admin_add_payment_log( [
        'status'  => 'info',
        'message' => ie__( 'Stripe webhook received.' ) . ' (' . strlen( (string) $payload ) . ' bytes)',
    ] );

    status_header( 200 );
    echo wp_json_encode( [ 'received' => true ] );
    exit;
}
add_action( 'init', 'ie_admin_handle_stripe_webhook' );

function ie_admin_render_payments_page() {
    if ( ! ie_admin_user_can() ) {
        return;
    }

    $current_page = ie_admin_get_current_page();
    $settings     = ie_admin_get_payment_settings();
    $logs         = ie_admin_get_payment_logs();
    $webhook_url  = ie_admin_get_stripe_webhook_url();

    ie_admin_render_shell_open( $current_page );

    if ( isset( $_GET['payments-updated'] ) ) {
        ie_admin_notice( ie__( 'Payment settings saved successfully.' ) );
    }
    ?>
    <div class="ie-ad-payments" data-section="payments">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ie-ad-form">
            <?php wp_nonce_field( 'ie_save_payment_settings', 'ie_payment_settings_nonce' ); ?>
            <input type="hidden" name="action" value="ie_save_payment_settings">

            <div class="ie-ad-card">
                <h3><?php echo esc_html( ie__( 'Stripe Integration' ) ); ?></h3>

                <label class="ie-ad-checkbox">
                    <input type="checkbox" name="payment_settings[stripe_enabled]" value="1" <?php checked( $settings['stripe_enabled'], '1' ); ?>>
                    <?php echo esc_html( ie__( 'Enable Stripe' ) ); ?>
                </label>

                <div class="ie-ad-field">
                    <label for="stripe_publishable"><?php echo esc_html( ie__( 'Stripe Publishable Key' ) ); ?></label>
                    <input type="text" id="stripe_publishable" name="payment_settings[stripe_publishable]" value="<?php echo esc_attr( $settings['stripe_publishable'] ); ?>" class="regular-text">
                </div>

                <div class="ie-ad-field">
                    <label for="stripe_secret"><?php echo esc_html( ie__( 'Stripe Secret Key' ) ); ?></label>
                    <input type="password" id="stripe_secret" name="payment_settings[stripe_secret]" value="<?php echo esc_attr( $settings['stripe_secret'] ); ?>" class="regular-text" autocomplete="new-password">
                </div>

                <div class="ie-ad-field">
                    <label><?php echo esc_html( ie__( 'Webhook URL' ) ); ?></label>
                    <div class="ie-ad-copy-field">
                        <input type="text" readonly value="<?php echo esc_attr( $webhook_url ); ?>" class="regular-text" id="ie-stripe-webhook-url">
                        <button type="button" class="button" id="ie-copy-webhook"><?php echo esc_html( ie__( 'Copy' ) ); ?></button>
                    </div>
                    <p class="description"><?php echo esc_html( ie__( 'Add this URL to your Stripe dashboard webhook settings.' ) ); ?></p>
                </div>

                <div class="ie-ad-actions-bar">
                    <button type="button" class="button" id="ie-test-stripe"><?php echo esc_html( ie__( 'Test Connection' ) ); ?></button>
                    <?php submit_button( ie__( 'Save Settings' ), 'primary', 'submit', false ); ?>
                </div>
            </div>
        </form>

        <div class="ie-ad-card ie-ad-card--logs">
            <h3><?php echo esc_html( ie__( 'Payment Logs' ) ); ?></h3>
            <div class="ie-ad-table-wrap">
                <table class="ie-ad-table">
                    <thead>
                        <tr>
                            <th><?php echo esc_html( ie__( 'Date' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Status' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Message' ) ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ( ! $logs ) : ?>
                            <tr><td colspan="3"><?php echo esc_html( ie__( 'No payment logs yet.' ) ); ?></td></tr>
                        <?php else : ?>
                            <?php foreach ( $logs as $log ) : ?>
                                <tr>
                                    <td><?php echo esc_html( $log['date'] ?? '' ); ?></td>
                                    <td><?php ie_admin_status_badge( $log['status'] ?? 'info' ); ?></td>
                                    <td><?php echo esc_html( $log['message'] ?? '' ); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php

    ie_admin_render_shell_close();
}

function ie_handle_save_payment_settings() {
    ie_admin_verify_post( 'ie_save_payment_settings', 'ie_payment_settings_nonce' );

    $input    = isset( $_POST['payment_settings'] ) ? wp_unslash( $_POST['payment_settings'] ) : [];
    $settings = ie_admin_sanitize_payment_settings( $input );

    update_option( IE_PAYMENT_SETTINGS_OPTION, $settings, false );

    wp_safe_redirect( add_query_arg( 'payments-updated', '1', admin_url( 'admin.php?page=ie-admin-payments' ) ) );
    exit;
}
add_action( 'admin_post_ie_save_payment_settings', 'ie_handle_save_payment_settings' );

function ie_ajax_admin_test_stripe() {
    ie_admin_verify_request( 'ie_admin_dashboard', 'nonce' );

    $result = ie_admin_test_stripe_connection();

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( [ 'message' => $result->get_error_message() ] );
    }

    wp_send_json_success( $result );
}
add_action( 'wp_ajax_ie_admin_test_stripe', 'ie_ajax_admin_test_stripe' );

