(function ($) {
    'use strict';

    const i18n = window.IE_PROVIDER_CAT_ADMIN || {};

    function toggleIconFields() {
        const type = $('input[name="ie_cat_icon_type"]:checked').val() || 'fontawesome';
        $('.ie-cat-icon-fontawesome-row').toggle(type === 'fontawesome');
        $('.ie-cat-icon-image-row').toggle(type === 'image');
    }

    function updateFaPreview() {
        const iconClass = $('#ie_cat_icon_class').val() || 'fa-solid fa-screwdriver-wrench';
        $('#ie-cat-fa-preview').attr('class', iconClass);
    }

    function setIconImagePreview(url) {
        const $preview = $('.ie-cat-icon-image-preview');
        const noImageText = i18n.noImage || 'No image';

        if (url) {
            $preview.removeClass('is-empty').html('<img src="' + url + '" alt="">');
            $('#ie-cat-remove-icon').show();
        } else {
            $preview.addClass('is-empty').text(noImageText);
            $('#ie-cat-remove-icon').hide();
        }

        $('#ie_cat_icon_image').val(url);
    }

    function openIconMediaFrame() {
        const frame = wp.media({
            title: i18n.selectImage || 'Select Category Icon',
            button: { text: i18n.useImage || 'Use this icon' },
            library: { type: 'image' },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            setIconImagePreview(attachment.url || '');
        });

        frame.open();
    }

    $(document).on('change', 'input[name="ie_cat_icon_type"]', toggleIconFields);
    $(document).on('input change', '#ie_cat_icon_class', updateFaPreview);
    $(document).on('change', '#ie_cat_icon_preset', function () {
        const value = $(this).val();
        if (!value) {
            return;
        }
        $('#ie_cat_icon_class').val(value).trigger('input');
    });
    $(document).on('click', '#ie-cat-upload-icon', function (event) {
        event.preventDefault();
        openIconMediaFrame();
    });
    $(document).on('click', '#ie-cat-remove-icon', function (event) {
        event.preventDefault();
        setIconImagePreview('');
    });

    $(function () {
        toggleIconFields();
        updateFaPreview();
    });
}(jQuery));
