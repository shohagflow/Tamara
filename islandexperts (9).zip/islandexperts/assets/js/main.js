/**
 * Island Experts - Main JavaScript v2.2
 */
(function($) {
    'use strict';

    const Toast = {
        show(message, type = 'info', duration = 3500) {
            const $c = $('#ie-toast-container');
            const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
            const $t = $(`<div class="toast toast-${type}"><span>${icons[type]||''}</span><span>${message}</span></div>`);
            $c.append($t);
            setTimeout(() => { $t.addClass('fading'); setTimeout(() => $t.remove(), 350); }, duration);
        }
    };

    function ieGetProfileRedirectUrl(resData) {
        if (resData && resData.redirect_url) {
            return resData.redirect_url;
        }
        const urls = window.IE_AJAX && IE_AJAX.urls;
        if (!urls) {
            return null;
        }
        const type = resData && resData.user_type;
        if (type === 'provider') {
            return urls.providerProfile || urls.account || urls.home;
        }
        return urls.clientProfile || urls.account || urls.home;
    }

    function ieGetHomeUrl() {
        const urls = window.IE_AJAX && IE_AJAX.urls;
        return (urls && urls.home) || '/';
    }

    function ieGetLogoutRedirectUrl($btn) {
        if ($btn && $btn.length) {
            const fromBtn = $btn.data('logoutHome');
            if (fromBtn) {
                return fromBtn;
            }
        }
        return ieGetHomeUrl();
    }

    function iePerformLogout(triggerEl) {
        const $btn = triggerEl ? $(triggerEl) : null;
        const homeUrl = ieGetLogoutRedirectUrl($btn);
        const fallbackUrl = (window.IE_AJAX && IE_AJAX.logoutFallback) || homeUrl;

        if ($btn && $btn.length) {
            $btn.prop('disabled', true);
        }

        if (!window.IE_AJAX || !IE_AJAX.url) {
            window.location.replace(fallbackUrl);
            return;
        }

        $.ajax({
            url: IE_AJAX.url,
            method: 'POST',
            dataType: 'json',
            dataFilter: ieParseAjaxResponse,
            data: {
                action: 'ie_logout',
                nonce: IE_AJAX.nonce,
            },
        }).done(function(res) {
            const dest = (res && res.success && res.data && res.data.redirect_url)
                ? res.data.redirect_url
                : homeUrl;
            window.location.replace(dest);
        }).fail(function() {
            window.location.replace(fallbackUrl);
        });
    }

    function ieParseAjaxResponse(data) {
        if (typeof data !== 'string') {
            return data;
        }

        const trimmed = data.replace(/^\uFEFF+/, '').trim();
        if (trimmed.charAt(0) === '{' || trimmed.charAt(0) === '[') {
            return trimmed;
        }

        const start = trimmed.indexOf('{');
        const end = trimmed.lastIndexOf('}');
        if (start !== -1 && end > start) {
            return trimmed.slice(start, end + 1);
        }

        return trimmed;
    }

    function ieAjax(action, data, btn) {
        if (btn) {
            const $b = $(btn);
            $b.prop('disabled', true).data('orig', $b.html()).html('<span class="ie-btn-spin"></span> Please wait...');
        }
        return $.ajax({
            url: IE_AJAX.url, method: 'POST',
            dataType: 'json',
            dataFilter: ieParseAjaxResponse,
            data: Object.assign({ action, nonce: IE_AJAX.nonce }, data),
        }).always(() => {
            if (btn) { const $b = $(btn); $b.prop('disabled', false).html($b.data('orig')); }
        });
    }

    function esc(str) {
        return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    function formatTime(t) {
        if (!t) return '';
        const [h, m] = t.split(':');
        const hr = parseInt(h);
        return `${hr % 12 || 12}:${m} ${hr >= 12 ? 'PM' : 'AM'}`;
    }

    function formatDate(d) {
        if (!d) return '';
        try { return new Date(d + 'T00:00:00').toLocaleDateString('en-US', { weekday:'short', year:'numeric', month:'short', day:'numeric' }); }
        catch(e) { return d; }
    }

    function isInWishlist(p) {
        if (!window.IE_WISHLIST) return false;
        const id = Number(p.id || 0);
        if (id && IE_WISHLIST.ids && IE_WISHLIST.ids.map(Number).includes(id)) return true;
        const slug = p.slug || '';
        if (slug && IE_WISHLIST.slugs && IE_WISHLIST.slugs.includes(slug)) return true;
        return false;
    }

    function syncWishlistCache(id, slug, added) {
        if (!window.IE_WISHLIST) return;
        IE_WISHLIST.ids = IE_WISHLIST.ids || [];
        IE_WISHLIST.slugs = IE_WISHLIST.slugs || [];
        const numericId = Number(id || 0);
        if (numericId) {
            IE_WISHLIST.ids = added
                ? Array.from(new Set(IE_WISHLIST.ids.concat(numericId)))
                : IE_WISHLIST.ids.filter(function(item) { return Number(item) !== numericId; });
        }
        if (slug) {
            IE_WISHLIST.slugs = added
                ? Array.from(new Set(IE_WISHLIST.slugs.concat(slug)))
                : IE_WISHLIST.slugs.filter(function(item) { return item !== slug; });
        }
    }

    function buildFeaturedWishlistBtn(p) {
        const active = isInWishlist(p);
        const iconClass = active ? 'fa-solid' : 'fa-regular';
        const activeClass = active ? ' active' : '';
        const id = Number(p.id || 0);
        const slug = p.slug || (p.permalink ? p.permalink.replace(/\/$/, '').split('/').pop() : '');
        const idAttr = id ? ` data-id="${id}"` : '';
        const slugAttr = slug ? ` data-slug="${esc(slug)}"` : '';
        const saveLabel = (window.IE_I18N && IE_I18N.saveProvider) || 'Save provider';
        return `<button type="button" class="featured-wishlist-btn wishlist-btn${activeClass}"${idAttr}${slugAttr} onclick="event.preventDefault();event.stopPropagation();IEApp.toggleFeaturedWishlist(this)" aria-label="${esc(saveLabel)}" title="${esc(saveLabel)}"><i class="${iconClass} fa-heart" aria-hidden="true"></i></button>`;
    }

    function buildFeaturedProviderCard(p) {
        const catSlug = (p.category_slug || '').toLowerCase().replace(/[^a-z0-9-]/g, '');
        const bio     = p.bio ? esc(p.bio.split(/\s+/).slice(0, 6).join(' ') + (p.bio.split(/\s+/).length > 6 ? '…' : '')) : '';
        const reviewsLabel = (window.IE_I18N && IE_I18N.reviews) || 'reviews';
        const chatLabel    = (window.IE_I18N && IE_I18N.chat) || 'Chat';
        const profileLabel = (window.IE_I18N && IE_I18N.viewProfile) || 'View Profile';
        return `
        <article class="featured-provider-card">
            <div class="featured-provider-service-image">
                ${buildFeaturedWishlistBtn(p)}
                <img src="${esc(p.service_image)}" alt="${esc(p.name)}" loading="lazy">
            </div>
            <div class="featured-provider-profile-wrap">
                <img class="featured-provider-avatar" src="${esc(p.profile_image)}" alt="${esc(p.name)}" loading="lazy">
            </div>
            <div class="featured-provider-body">
                <h3 class="featured-provider-name">${esc(p.name)}</h3>
                <div class="featured-provider-rating">
                    <i class="fa-solid fa-star" aria-hidden="true"></i>
                    <span>${esc(p.rating)}</span>
                    <span class="featured-provider-review-count">(${esc(p.reviews)} ${reviewsLabel})</span>
                </div>
                ${p.category ? `<span class="featured-provider-category tag tag-${catSlug}">${esc(p.category)}</span>` : ''}
                ${bio ? `<p class="featured-provider-bio">${bio}</p>` : ''}
                <div class="featured-provider-actions">
                    <a href="${esc(p.chat_url)}" class="btn-featured-chat">
                        <i class="fa-regular fa-comment-dots" aria-hidden="true"></i>
                        ${chatLabel}
                    </a>
                    <a href="${esc(p.permalink)}" class="btn-featured-profile">
                        ${profileLabel}
                        <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </article>`;
    }

    function buildProviderCard(p) {
        const availClass = { available_now:'avail-now', available_week:'avail-week', busy:'avail-busy' }[p.availability] || 'avail-now';
        const catSlug    = (p.category_slug || p.category || '').toLowerCase().replace(/[^a-z0-9]/g,'-');
        const imgHtml    = p.thumbnail
            ? `<img src="${esc(p.thumbnail)}" alt="${esc(p.title)}" loading="lazy">`
            : `<div class="no-image">${esc(p.title.charAt(0).toUpperCase())}</div>`;
        return `
        <div class="provider-card" onclick="window.location='${p.permalink}'">
            <div class="provider-card-image">
                ${imgHtml}
                ${p.verified ? '<div class="verified-badge"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg> Verified</div>' : ''}
                <div class="availability-badge ${availClass}">${esc(p.avail_label)}</div>
                <button class="wishlist-btn" data-id="${p.id}" onclick="event.stopPropagation(); IEApp.toggleWishlist(this, ${p.id})" title="Save provider">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                </button>
            </div>
            <div class="provider-card-body">
                <div class="provider-card-title-row">
                    <span class="provider-name">${esc(p.title)}</span>
                    <span class="provider-rating"><span class="star-icon">★</span>${esc(p.rating)}<span class="review-count">(${esc(p.reviews)})</span></span>
                </div>
                ${p.category ? `<div class="provider-tags"><span class="tag tag-${catSlug}">${esc(p.category)}</span></div>` : ''}
                <div class="provider-meta">
                    ${p.location ? `<span class="meta-item"><span>📍</span>${esc(p.location)}</span>` : ''}
                    ${p.experience && p.experience !== '0' ? `<span class="meta-item"><span>⏱</span>${esc(p.experience)} yrs exp</span>` : ''}
                </div>
                ${p.price ? `<div class="provider-price">From <strong>$${esc(p.price)}</strong> / service</div>` : ''}
            </div>
        </div>`;
    }

    function buildBookingCard(b) {
        const canCancel = ['pending','confirmed'].includes(b.status);
        const thumbHtml = b.provider_thumb
            ? `<img src="${esc(b.provider_thumb)}" alt="${esc(b.provider_name)}">`
            : `<div class="thumb-placeholder">${esc((b.provider_name||'?').charAt(0).toUpperCase())}</div>`;
        return `
        <div class="booking-card" id="booking-card-${b.id}">
            <div class="booking-provider-thumb">${thumbHtml}</div>
            <div class="booking-info">
                <h4>${esc(b.provider_name)}</h4>
                <div class="booking-meta-row">
                    ${b.date ? `<span class="booking-meta-item">📅 ${formatDate(b.date)}</span>` : ''}
                    ${b.time ? `<span class="booking-meta-item">⏰ ${formatTime(b.time)}</span>` : ''}
                    ${b.service ? `<span class="booking-meta-item">🛠 ${esc(b.service)}</span>` : ''}
                </div>
                ${b.provider_cat ? `<span class="booking-service-tag">${esc(b.provider_cat)}</span>` : ''}
            </div>
            <div class="booking-actions">
                <span class="booking-status-badge status-${esc(b.status)}">${esc(b.status)}</span>
                ${canCancel ? `<button class="btn-cancel-booking" onclick="IEApp.cancelBooking(this,${b.id})">Cancel</button>` : ''}
            </div>
        </div>`;
    }

    /* MOBILE MENU */
    function setMobileNavOpen(open) {
        const $nav = $('#site-nav');
        const $toggle = $('#mobile-menu-toggle');
        $nav.toggleClass('mobile-open', open);
        $toggle.toggleClass('is-open', open).attr('aria-expanded', open ? 'true' : 'false');
        $('body').toggleClass('mobile-nav-open', open);
    }

    $('#mobile-menu-toggle').on('click', function() {
        setMobileNavOpen(!$('#site-nav').hasClass('mobile-open'));
    });
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#site-header').length) {
            setMobileNavOpen(false);
        }
        if (!$(e.target).closest('.header-user-menu').length) {
            $('.header-user-menu').removeClass('is-open');
            $('.header-user-menu__toggle').attr('aria-expanded', 'false');
        }
    });
    $('#site-nav a').on('click', function() { setMobileNavOpen(false); });
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') {
            setMobileNavOpen(false);
            $('.header-user-menu').removeClass('is-open');
            $('.header-user-menu__toggle').attr('aria-expanded', 'false');
        }
    });

    /* HEADER USER MENU */
    $(document).on('click', '.header-user-menu__toggle', function(e) {
        e.stopPropagation();
        const $menu = $(this).closest('.header-user-menu');
        const isOpen = $menu.hasClass('is-open');

        $('.header-user-menu').removeClass('is-open');
        $('.header-user-menu__toggle').attr('aria-expanded', 'false');

        if (!isOpen) {
            $menu.addClass('is-open');
            $(this).attr('aria-expanded', 'true');
        }
    });

    $(document).on('click', '.header-user-menu__dropdown', function(e) {
        e.stopPropagation();
    });

    $(document).on('click', '.header-user-menu__link:not(.header-user-menu__logout)', function() {
        $('.header-user-menu').removeClass('is-open');
        $('.header-user-menu__toggle').attr('aria-expanded', 'false');
        setMobileNavOpen(false);
    });

    $(document).on('click', '[data-ie-logout], #btn-logout, .header-user-menu__logout', function(e) {
        e.preventDefault();
        e.stopPropagation();

        if (!confirm((window.IE_I18N && IE_I18N.confirmLogout) || 'Are you sure you want to log out?')) {
            return;
        }

        iePerformLogout(this);
    });

    /* HERO CAROUSEL */
    (function() {
        const slides = document.querySelectorAll('.hero-slide');
        if (!slides.length) return;
        let current = 0;
        setInterval(function() {
            slides[current].classList.remove('active');
            current = (current + 1) % slides.length;
            slides[current].classList.add('active');
        }, 5000);
    })();

    /* ==============================================
       BROWSE PAGE
    =============================================== */
    if ($('#providers-grid').length) {
        const defaults = window.IE_BROWSE_DEFAULTS || {};
        let state = {
            category : defaults.category || 'all',
            search   : defaults.search   || '',
            rating   : '',
            price    : '',
            page     : 1,
        };

        if (state.category && state.category !== 'all') {
            $('#browse-category-filter').val(state.category);
        }
        if (state.search) $('#browse-search-input').val(state.search);

        function checkResetBtn() {
            const isFiltered = state.category !== 'all' || state.rating !== '' || state.price !== '' || state.search !== '';
            $('#reset-all-filters').toggle(isFiltered);
        }

        function getPaginationPages(currentPage, totalPages) {
            if (totalPages <= 7) {
                return Array.from({ length: totalPages }, (_, i) => i + 1);
            }

            const pages = new Set([1, totalPages, currentPage, currentPage - 1, currentPage + 1]);
            const sorted = [...pages].filter((p) => p >= 1 && p <= totalPages).sort((a, b) => a - b);
            const result = [];
            let prev = 0;

            sorted.forEach((page) => {
                if (prev && page - prev > 1) {
                    result.push('ellipsis');
                }
                result.push(page);
                prev = page;
            });

            return result;
        }

        function buildBrowsePagination(data) {
            const { total, total_pages, current_page, showing_from, showing_to } = data;
            const i18n = window.IE_I18N || {};

            if (!total || total_pages <= 1) {
                $('#browse-pagination-wrap').attr('hidden', true);
                $('#browse-pagination').empty();
                $('#browse-pagination-info').empty();
                return;
            }

            const infoTemplate = i18n.paginationShowing || 'Showing %1$d–%2$d of %3$d providers';
            const infoText = infoTemplate
                .replace('%1$d', showing_from)
                .replace('%2$d', showing_to)
                .replace('%3$d', total);

            let html = `<button type="button" class="page-btn page-btn-nav" data-page="${current_page - 1}" ${current_page <= 1 ? 'disabled' : ''} aria-label="${i18n.paginationPrevious || 'Previous'}">
                <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
                <span>${i18n.paginationPrevious || 'Previous'}</span>
            </button>`;

            getPaginationPages(current_page, total_pages).forEach((item) => {
                if (item === 'ellipsis') {
                    html += '<span class="page-ellipsis" aria-hidden="true">…</span>';
                    return;
                }

                const isActive = item === current_page;
                html += `<button type="button" class="page-btn ${isActive ? 'active' : ''}" data-page="${item}" aria-label="Page ${item}" ${isActive ? 'aria-current="page"' : ''}>${item}</button>`;
            });

            html += `<button type="button" class="page-btn page-btn-nav" data-page="${current_page + 1}" ${current_page >= total_pages ? 'disabled' : ''} aria-label="${i18n.paginationNext || 'Next'}">
                <span>${i18n.paginationNext || 'Next'}</span>
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
            </button>`;

            $('#browse-pagination-info').text(infoText);
            $('#browse-pagination').html(html);
            $('#browse-pagination-wrap').removeAttr('hidden');
        }

        function loadBrowse() {
            $('#providers-grid').html('<div class="browse-loading"><div class="spinner"></div><p>' + ((window.IE_I18N && IE_I18N.loadingProviders) || 'Loading providers...') + '</p></div>');
            $('#browse-pagination-wrap').attr('hidden', true);
            $('#browse-pagination').empty();
            $('#browse-pagination-info').empty();
            ieAjax('ie_search_providers', {
                search   : state.search,
                category : state.category,
                rating   : state.rating,
                price    : state.price,
                sort     : 'rating',
                page     : state.page,
            }).done(function(res) {
        if (!res.success) { $('#providers-grid').html('<div class="no-results"><div class="no-results-icon">⚠️</div><h3>' + (window.IE_I18N?.failedLoad || 'Failed to load') + '</h3></div>'); return; }
                const { providers, total, total_pages, current_page } = res.data;
                const i18n = window.IE_I18N || {};
                const countText = total === 1
                    ? (i18n.providerFound || '1 provider found')
                    : (i18n.providersFound || '%d providers found').replace('%d', total);
                $('#results-count').text(countText);
                if (!providers.length) {
                    $('#providers-grid').html('<div class="no-results"><div class="no-results-icon">🔍</div><h3>' + (i18n.noProviders || 'No providers found') + '</h3><p>' + (i18n.tryFilters || 'Try different filters or search terms.') + '</p></div>');
                } else {
                    $('#providers-grid').html(providers.map(buildFeaturedProviderCard).join(''));
                }
                buildBrowsePagination(res.data);
            }).fail(function() {
                $('#providers-grid').html('<div class="no-results"><div class="no-results-icon">⚠️</div><h3>Connection error</h3><p>Please refresh the page.</p></div>');
            });
        }

        loadBrowse();

        $(document).on('click', '#reset-all-filters', function() {
            state.category = 'all';
            state.rating   = '';
            state.price    = '';
            state.search   = '';
            state.page     = 1;

            $('#browse-category-filter').val('all');
            $('#browse-rating-filter').val('');
            $('#browse-price-filter').val('');
            $('#browse-search-input').val('');
            $('#reset-all-filters').hide();
            loadBrowse();
        });

        $('#browse-category-filter').on('change', function() {
            state.category = $(this).val();
            state.page = 1;
            loadBrowse();
            checkResetBtn();
        });

        $('#browse-rating-filter').on('change', function() {
            state.rating = $(this).val();
            state.page = 1;
            loadBrowse();
            checkResetBtn();
        });

        $('#browse-price-filter').on('change', function() {
            state.price = $(this).val();
            state.page = 1;
            loadBrowse();
            checkResetBtn();
        });

        let searchTimer;
        $('#browse-search-input').on('input', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => { state.search = $(this).val().trim(); state.page = 1; loadBrowse(); checkResetBtn(); }, 400);
        });

        $(document).on('click', '.browse-pagination .page-btn:not(:disabled)', function() {
            state.page = parseInt($(this).data('page'), 10);
            loadBrowse();
            $('html, body').animate({ scrollTop: $('.browse-page-wrap').offset().top - 90 }, 350);
        });

    } // end browse block

    /* WISHLIST */
    window.IEApp = window.IEApp || {};

    IEApp.toggleFaq = function( btn ) {
        const card   = btn.closest( '.ie-faq-card' );
        const body   = btn.nextElementSibling;
        const isOpen = card.classList.contains( 'open' );

        document.querySelectorAll( '.ie-faq-card.open' ).forEach( function( c ) {
            c.classList.remove( 'open' );
            c.querySelector( '.faq-body' ).style.display = 'none';
        } );

        if ( ! isOpen ) {
            card.classList.add( 'open' );
            body.style.display = 'block';
        }
    };

    IEApp.toggleWishlist = function(btn, providerId) {
        ieAjax('ie_toggle_wishlist', { provider_id: providerId }).done(function(res) {
            if (res.success) {
                const added = res.data.action === 'added';
                const $b = $(btn);
                $b.toggleClass('active', added);
                $b.find('svg').attr('fill', added ? '#d06a1e' : 'none').css('stroke', added ? '#d06a1e' : 'currentColor');
                syncWishlistCache(providerId, '', added);
                Toast.show(res.data.message, added ? 'success' : 'info');
            } else {
                Toast.show(res.data.message || 'Please log in to save providers.', 'error');
                if ((res.data.message || '').includes('log in')) setTimeout(() => { window.location = (IE_AJAX.urls && IE_AJAX.urls.account) || '/account/'; }, 1200);
            }
        });
    };

    IEApp.toggleFeaturedWishlist = function(btn) {
        const $b = $(btn);
        const id = parseInt($b.data('id'), 10) || 0;
        const slug = String($b.data('slug') || '');
        const payload = {};
        if (id) payload.provider_id = id;
        else if (slug) payload.provider_slug = slug;
        else return;

        ieAjax('ie_toggle_wishlist', payload).done(function(res) {
            if (res.success) {
                const added = res.data.action === 'added';
                $b.toggleClass('active', added);
                $b.find('i').toggleClass('fa-regular', !added).toggleClass('fa-solid', added);
                syncWishlistCache(id, slug, added);
                Toast.show(res.data.message, added ? 'success' : 'info');
            } else {
                Toast.show(res.data.message || 'Please log in to save providers.', 'error');
                if ((res.data.message || '').includes('log in')) {
                    setTimeout(function() {
                        window.location = (IE_AJAX.urls && IE_AJAX.urls.account) || '/account/';
                    }, 1200);
                }
            }
        });
    };

    /* BOOKINGS LIST LOADER */
    function loadBookingsList(filter, containerId) {
        const $wrap = $('#' + containerId);
        $wrap.html('<div style="text-align:center;padding:60px;color:var(--color-text-muted)"><div class="spinner" style="margin:0 auto 12px"></div><p>Loading...</p></div>');
        ieAjax('ie_get_bookings', { filter }).done(function(res) {
            if (!res.success) { $wrap.html('<div class="empty-state"><div class="empty-state-icon">⚠️</div><h3>Error loading bookings</h3><p>Please refresh the page.</p></div>'); return; }
            const { bookings } = res.data;
            if (!bookings || !bookings.length) {
                const label = filter !== 'all' ? filter : '';
                $wrap.html(`<div class="empty-state"><div class="empty-state-icon">📅</div><h3>No ${label} bookings found</h3><p>You don't have any ${label} bookings yet.</p><a href="/browse/" class="btn-browse-now">Browse Providers</a></div>`);
            } else {
                $wrap.html('<div class="bookings-list">' + bookings.map(buildBookingCard).join('') + '</div>');
            }
        }).fail(function() { $wrap.html('<div class="empty-state"><div class="empty-state-icon">⚠️</div><h3>Connection error</h3><p>Please refresh and try again.</p></div>'); });
    }

    /* CANCEL BOOKING */
    IEApp.cancelBooking = function(btn, bookingId) {
        if (!confirm('Are you sure you want to cancel this booking?')) return;
        ieAjax('ie_cancel_booking', { booking_id: bookingId }, btn).done(function(res) {
            if (res.success) {
                $(`#booking-card-${bookingId} .booking-status-badge`).removeClass('status-pending status-confirmed').addClass('status-cancelled').text('cancelled');
                $(`#booking-card-${bookingId} .btn-cancel-booking`).remove();
                Toast.show('Booking cancelled.', 'info');
            } else { Toast.show(res.data.message || 'Cannot cancel this booking.', 'error'); }
        });
    };

    /* AUTH TABS */
    $(document).on('click', '.auth-tab-btn', function() {
        const tab = $(this).data('tab');
        $('.auth-tab-btn').removeClass('active');
        $('.auth-tab-btn[data-tab="' + tab + '"]').addClass('active');
        if (tab === 'login') {
            $('#auth-header-login').show();
            $('#auth-header-register').hide();
            $('#auth-panel-login').show();
            $('#auth-panel-register').hide();
        } else {
            $('#auth-header-login').hide();
            $('#auth-header-register').show();
            $('#auth-panel-register').show();
            $('#auth-panel-login').hide();
            syncUserTypeSelection();
        }
    });

    if ($('#auth-panel-login').length) {
        const params = new URLSearchParams(window.location.search);
        if (params.get('type') === 'provider') {
            $('#reg-type-provider').prop('checked', true);
        }
        if (params.get('mode') === 'register' || params.get('type') === 'provider') {
            $('.auth-tab-btn[data-tab="register"]').trigger('click');
        }
    }

    /* LOGIN */
    $('#btn-login').on('click', function() {
        const email = $('#login-email').val().trim(), password = $('#login-password').val();
        $('#login-error, #login-success').removeClass('show');
        if (!email || !password) { $('#login-error').addClass('show').text('Please enter your email and password.'); return; }
        ieAjax('ie_login', { email, password }, this).done(function(res) {
            if (res.success) {
                $('#login-success').addClass('show').text(res.data.message || 'Login successful!');
                const dest = ieGetProfileRedirectUrl(res.data) || window.location.href;
                setTimeout(() => { window.location = dest; }, 800);
            }
            else { $('#login-error').addClass('show').text(res.data.message || 'Login failed.'); }
        }).fail(function() { $('#login-error').addClass('show').text('Connection error. Please try again.'); });
    });
    $('#login-password').on('keypress', function(e) { if (e.which === 13) $('#btn-login').trigger('click'); });

    /* REGISTER */
	$('#btn-register').on('click', function() {
		const firstName = $('#reg-firstname').val().trim(), lastName = $('#reg-lastname').val().trim(), email = $('#reg-email').val().trim(), password = $('#reg-password').val(), confirmPassword = $('#reg-confirm-password').val();
		const userType = $('input[name="reg-user-type"]:checked').val() || 'customer';
		$('#reg-error, #reg-success').removeClass('show');
		if (!firstName || !email || !password || !confirmPassword) { $('#reg-error').addClass('show').text('Please fill in all required fields.'); return; }
		if (password.length < 6) { $('#reg-error').addClass('show').text('Password must be at least 6 characters.'); return; }
		if (password !== confirmPassword) { $('#reg-error').addClass('show').text('Passwords do not match.'); return; }

        const payload = { first_name: firstName, last_name: lastName, email, password, confirm_password: confirmPassword, user_type: userType };
        if (userType === 'provider') {
            payload.service_name = $('#reg-service-name').val().trim();
            payload.experience   = $('#reg-experience').val().trim();
            payload.location     = $('#reg-location').val().trim();
            if (!payload.service_name || !payload.experience || !payload.location) {
                $('#reg-error').addClass('show').text('Please fill in your business name, experience, and location.');
                return;
            }
        }

		ieAjax('ie_register', payload, this).done(function(res) {
			if (res.success) {
                $('#reg-success').addClass('show').text(res.data.message || 'Account created!');
                const dest = ieGetProfileRedirectUrl(res.data) || window.location.href;
                setTimeout(() => { window.location = dest; }, 1000);
            }
			else { $('#reg-error').addClass('show').text(res.data.message || 'Registration failed.'); }
		}).fail(function() { $('#reg-error').addClass('show').text('Connection error. Please try again.'); });
	});

    /* DASHBOARD NAV PANELS */
    $(document).on('click', '.dashboard-nav-item[data-panel]', function() {
        const panel = $(this).data('panel');
        $('.dashboard-nav-item').removeClass('active'); $(this).addClass('active');
        $('.dashboard-panel').removeClass('active'); $('#panel-' + panel).addClass('active');
        if (panel === 'bookings' && !$(this).data('loaded')) { loadBookingsList('all', 'dashboard-bookings-list'); $(this).data('loaded', true); }
        if (panel === 'saved' && !$(this).data('loaded')) { loadSavedProviders(); $(this).data('loaded', true); }
        if (panel === 'messages' && !$(this).data('loaded') && !$('.provider-profile-page').length) {
            setMessagesMobileView();
            if ($('#messages-conversation-list .client-messages-item').length) {
                syncConversationsCache();
            } else {
                loadConversations();
            }
            $(this).data('loaded', true);
        }
    });
    $(document).on('click', '[data-dash-filter]', function() {
        $(this).addClass('active').siblings().removeClass('active');
        loadBookingsList($(this).data('dash-filter'), 'dashboard-bookings-list');
    });

    /* SAVE PROFILE */
    $('#btn-save-profile').on('click', function() {
        $('#profile-error, #profile-success').removeClass('show');

        const formData = new FormData();
        formData.append('action', 'ie_update_profile');
        formData.append('nonce', IE_AJAX.nonce);
        formData.append('first_name', $('#profile-firstname').val().trim());
        formData.append('last_name', $('#profile-lastname').val().trim());

        const photoInput = document.getElementById('profile-photo');
        const photoFile  = photoInput && photoInput.files[0];
        if (photoFile) {
            formData.append('profile_photo', photoFile);
        }

        const $btn = $(this);
        $btn.prop('disabled', true).data('orig', $btn.html()).html('<span class="ie-btn-spin"></span> Please wait...');

        $.ajax({
            url: IE_AJAX.url,
            method: 'POST',
            dataType: 'json',
            dataFilter: ieParseAjaxResponse,
            data: formData,
            processData: false,
            contentType: false,
        }).done(function(res) {
            if (res.success) {
                $('#profile-success').addClass('show').text(res.data.message || 'Profile updated!');
                Toast.show('Profile updated!', 'success');

                if (res.data.display_name) {
                    $('.dashboard-user-name').text(res.data.display_name);
                }

                if (res.data.avatar_url) {
                    const alt = res.data.display_name || 'Profile photo';
                    $('#sidebar-avatar').addClass('has-image').html(`<img src="${res.data.avatar_url}" alt="${esc(alt)}" id="sidebar-avatar-img">`);
                }

                if (photoInput) {
                    photoInput.value = '';
                }
            } else {
                $('#profile-error').addClass('show').text(res.data.message || 'Failed to update.');
            }
        }).fail(function() {
            $('#profile-error').addClass('show').text('Connection error. Please try again.');
        }).always(function() {
            $btn.prop('disabled', false).html($btn.data('orig'));
        });
    });

    $('#profile-photo').on('change', function() {
        const file = this.files[0];
        $('#profile-error').removeClass('show');

        if (!file) return;

        const allowed = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowed.includes(file.type)) {
            $('#profile-error').addClass('show').text('Please upload a JPG, PNG, or WEBP image.');
            this.value = '';
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            $('#profile-error').addClass('show').text('Image must be smaller than 5MB.');
            this.value = '';
        }
    });

    /* CHANGE PASSWORD */
    $('#btn-change-password').on('click', function() {
        $('#password-error, #password-success').removeClass('show');
        const current = $('#curr-password').val(), newPass = $('#new-password').val(), confirm = $('#confirm-new-password').val();
        if (!current || !newPass || !confirm) { $('#password-error').addClass('show').text('All fields are required.'); return; }
        if (newPass !== confirm) { $('#password-error').addClass('show').text('New passwords do not match.'); return; }
        if (newPass.length < 6) { $('#password-error').addClass('show').text('Password must be at least 6 characters.'); return; }
        ieAjax('ie_change_password', { current_password: current, new_password: newPass, confirm_password: confirm }, this).done(function(res) {
            if (res.success) { $('#password-success').addClass('show').text(res.data.message || 'Password updated!'); $('#curr-password, #new-password, #confirm-new-password').val(''); Toast.show('Password updated!', 'success'); }
            else { $('#password-error').addClass('show').text(res.data.message || 'Failed.'); }
        });
    });

    /* SAVED PROVIDERS */
    const FAVORITES_PER_PAGE = 3;
    let favoritesCache = [];
    let favoritesPage = 1;

    function getFavoritesPaginationPages(currentPage, totalPages) {
        if (totalPages <= 7) {
            return Array.from({ length: totalPages }, function(_, i) { return i + 1; });
        }

        const pages = new Set([1, totalPages, currentPage, currentPage - 1, currentPage + 1]);
        const sorted = Array.from(pages).filter(function(p) { return p >= 1 && p <= totalPages; }).sort(function(a, b) { return a - b; });
        const result = [];
        let prev = 0;

        sorted.forEach(function(page) {
            if (prev && page - prev > 1) {
                result.push('ellipsis');
            }
            result.push(page);
            prev = page;
        });

        return result;
    }

    function buildFavoritesPagination(total, currentPage) {
        const totalPages = Math.ceil(total / FAVORITES_PER_PAGE);
        const i18n = window.IE_I18N || {};

        if (!total || totalPages <= 1) {
            $('#favorites-pagination-wrap').attr('hidden', true);
            $('#favorites-pagination').empty();
            $('#favorites-pagination-info').empty();
            return;
        }

        const showingFrom = ((currentPage - 1) * FAVORITES_PER_PAGE) + 1;
        const showingTo = Math.min(currentPage * FAVORITES_PER_PAGE, total);
        const infoTemplate = i18n.paginationShowingFavorites || i18n.paginationShowing || 'Showing %1$d–%2$d of %3$d saved providers';
        const infoText = infoTemplate
            .replace('%1$d', showingFrom)
            .replace('%2$d', showingTo)
            .replace('%3$d', total);

        let html = `<button type="button" class="page-btn page-btn-nav" data-page="${currentPage - 1}" ${currentPage <= 1 ? 'disabled' : ''} aria-label="${i18n.paginationPrevious || 'Previous'}">
            <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
            <span>${i18n.paginationPrevious || 'Previous'}</span>
        </button>`;

        getFavoritesPaginationPages(currentPage, totalPages).forEach(function(item) {
            if (item === 'ellipsis') {
                html += '<span class="page-ellipsis" aria-hidden="true">…</span>';
                return;
            }

            const isActive = item === currentPage;
            html += `<button type="button" class="page-btn ${isActive ? 'active' : ''}" data-page="${item}" aria-label="Page ${item}" ${isActive ? 'aria-current="page"' : ''}>${item}</button>`;
        });

        html += `<button type="button" class="page-btn page-btn-nav" data-page="${currentPage + 1}" ${currentPage >= totalPages ? 'disabled' : ''} aria-label="${i18n.paginationNext || 'Next'}">
            <span>${i18n.paginationNext || 'Next'}</span>
            <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
        </button>`;

        $('#favorites-pagination-info').text(infoText);
        $('#favorites-pagination').html(html);
        $('#favorites-pagination-wrap').removeAttr('hidden');
    }

    function renderSavedProvidersPage() {
        const $grid = $('#saved-providers-grid');

        if (!favoritesCache.length) {
            $grid.html(`<div class="no-results" style="grid-column:1/-1;text-align:center;padding:60px 20px"><div style="font-size:3rem;margin-bottom:12px">❤️</div><h3 style="font-family:var(--font-body);margin-bottom:8px">No saved providers yet</h3><p style="color:var(--color-text-muted);font-size:0.875rem;margin-bottom:16px">Browse providers and tap the heart icon to save them here.</p><a href="${(IE_AJAX.urls && IE_AJAX.urls.browse) || '/browse/'}" style="color:var(--color-primary);font-weight:600">Browse Providers →</a></div>`);
            buildFavoritesPagination(0, 1);
            return;
        }

        const total = favoritesCache.length;
        const totalPages = Math.ceil(total / FAVORITES_PER_PAGE);
        if (favoritesPage > totalPages) {
            favoritesPage = totalPages;
        }
        if (favoritesPage < 1) {
            favoritesPage = 1;
        }

        const start = (favoritesPage - 1) * FAVORITES_PER_PAGE;
        const pageItems = favoritesCache.slice(start, start + FAVORITES_PER_PAGE);
        $grid.html(pageItems.map(buildFeaturedProviderCard).join(''));
        buildFavoritesPagination(total, favoritesPage);
    }

    function loadSavedProviders() {
        const $grid = $('#saved-providers-grid');
        $grid.html('<div style="text-align:center;padding:60px;grid-column:1/-1;color:var(--color-text-muted)"><div class="spinner" style="margin:0 auto 12px"></div><p>Loading saved providers...</p></div>');
        $('#favorites-pagination-wrap').attr('hidden', true);
        ieAjax('ie_get_wishlist', {}).done(function(res) {
            if (res.success && res.data.providers && res.data.providers.length) {
                favoritesCache = res.data.providers;
                favoritesPage = 1;
                renderSavedProvidersPage();
            } else {
                favoritesCache = [];
                favoritesPage = 1;
                renderSavedProvidersPage();
            }
        }).fail(function() {
            favoritesCache = [];
            $grid.html('<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--color-text-muted)">Failed to load saved providers.</div>');
            buildFavoritesPagination(0, 1);
        });
    }

    $(document).on('click', '#favorites-pagination .page-btn:not(:disabled)', function() {
        favoritesPage = parseInt($(this).data('page'), 10) || 1;
        renderSavedProvidersPage();
        const $panel = $('#panel-saved');
        if ($panel.length) {
            $('html, body').animate({ scrollTop: $panel.offset().top - 90 }, 300);
        }
    });

    if ($('#saved-providers-grid').length && $('#panel-saved').hasClass('active')) {
        loadSavedProviders();
        $('.dashboard-nav-item[data-panel="saved"]').data('loaded', true);
    }

    /* CLIENT MESSAGES */
    let conversationsCache = [];
    let activeChatProviderId = null;

    function formatChatTime(value) {
        if (!value) return '';
        try {
            const date = new Date(value.replace(' ', 'T'));
            const now = new Date();
            const sameDay = date.toDateString() === now.toDateString();
            if (sameDay) {
                return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
            }
            return date.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric' });
        } catch (e) {
            return '';
        }
    }

    function buildConversationItem(c) {
        return `
        <button type="button" class="client-messages-item${activeChatProviderId === c.id ? ' is-active' : ''}" data-provider-id="${c.id}">
            <img src="${esc(c.avatar)}" alt="${esc(c.name)}" class="client-messages-item__avatar">
            <span class="client-messages-item__content">
                <span class="client-messages-item__top">
                    <strong class="client-messages-item__name">${esc(c.name)}</strong>
                    <span class="client-messages-item__time">${esc(formatChatTime(c.last_time))}</span>
                </span>
                <span class="client-messages-item__preview">${esc(c.last_message)}</span>
            </span>
        </button>`;
    }

    function renderConversationList(list) {
        const $list = $('#messages-conversation-list');
        $('#messages-count').text(list.length);

        if (!list.length) {
            const browse = (IE_AJAX.urls && IE_AJAX.urls.browse) || '/browse/';
            $list.html(`
                <div class="client-messages-list__empty">
                    <p>${esc((IE_I18N && IE_I18N.noConversations) || 'No conversations yet')}</p>
                    <a href="${browse}">${esc((IE_I18N && IE_I18N.browseProviders) || 'Browse Providers')}</a>
                </div>`);
            return;
        }

        $list.html(list.map(buildConversationItem).join(''));
    }

    function initMessageTimes() {
        $('[data-time]').each(function() {
            const raw = $(this).attr('data-time');
            if (raw) {
                $(this).text(formatChatTime(raw));
            }
        });
    }

    function isMobileMessagesView() {
        return window.matchMedia('(max-width: 767px)').matches;
    }

    function setMessagesMobileView() {
        $('.client-messages-layout').removeClass('is-chat-open');
    }

    function scrollToMobileChat() {
        if (!isMobileMessagesView()) return;
        const chatArea = document.getElementById('messages-chat-area');
        if (chatArea) {
            chatArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    function syncConversationsCache() {
        ieAjax('ie_get_conversations', {}).done(function(res) {
            if (res.success) {
                conversationsCache = res.data.conversations || [];
                $('#messages-count').text(conversationsCache.length);
            }
        });
    }

    function loadConversations() {
        const $list = $('#messages-conversation-list');
        const hasItems = $list.find('.client-messages-item').length > 0;

        if (!hasItems) {
            $list.html(`<div class="client-messages-list__loading"><div class="spinner"></div><p>${esc((IE_I18N && IE_I18N.loadingMessages) || 'Loading messages...')}</p></div>`);
        }

        ieAjax('ie_get_conversations', {}).done(function(res) {
            if (res.success) {
                conversationsCache = res.data.conversations || [];
                if (conversationsCache.length && !activeChatProviderId) {
                    activeChatProviderId = String(conversationsCache[0].id);
                }
                renderConversationList(conversationsCache);
                initMessageTimes();
                if (conversationsCache.length && activeChatProviderId) {
                    openChat(activeChatProviderId);
                }
            } else if (!hasItems) {
                $list.html('<div class="client-messages-list__empty"><p>Failed to load conversations.</p></div>');
            }
        }).fail(function() {
            if (!hasItems) {
                $list.html('<div class="client-messages-list__empty"><p>Failed to load conversations.</p></div>');
            }
        });
    }

    function renderChatMessages(messages) {
        const $body = $('#messages-chat-body');
        if (!messages || !messages.length) {
            $body.html(`<div class="client-messages-chat__thread-empty"><p>${esc((IE_I18N && IE_I18N.startChatHint) || 'Send a message to start the conversation.')}</p></div>`);
            return;
        }

        $body.html(messages.map(function(m) {
            const isMine = m.sender === 'customer';
            return `
            <div class="client-messages-bubble-wrap${isMine ? ' is-mine' : ''}">
                <div class="client-messages-bubble">${esc(m.body)}</div>
                <span class="client-messages-bubble__time">${esc(formatChatTime(m.time))}</span>
            </div>`;
        }).join(''));

        $body.scrollTop($body[0].scrollHeight);
    }

    function openChat(providerId) {
        activeChatProviderId = providerId;
        $('.client-messages-item').removeClass('is-active');
        $(`.client-messages-item[data-provider-id="${providerId}"]`).addClass('is-active');

        setMessagesMobileView();
        scrollToMobileChat();
        $('#messages-chat-body').html(`<div class="client-messages-list__loading"><div class="spinner"></div></div>`);

        ieAjax('ie_get_chat_thread', { provider_id: providerId }).done(function(res) {
            if (!res.success) return;
            const p = res.data.provider;
            $('#chat-head-avatar').attr({ src: p.avatar, alt: p.name });
            $('#chat-head-name').text(p.name);
            $('#chat-head-role').text(p.category ? `${(IE_I18N && IE_I18N.specialist) || 'Specialist'} — ${p.category}` : '');
            $('#chat-head-profile').attr('href', p.permalink);
            renderChatMessages(res.data.messages || []);
        });
    }

    function sendChatMessage() {
        const message = $('#chat-message-input').val().trim();
        if (!activeChatProviderId || !message) return;

        $('#btn-send-chat').prop('disabled', true);
        ieAjax('ie_send_chat_message', { provider_id: activeChatProviderId, message }).done(function(res) {
            if (res.success) {
                $('#chat-message-input').val('');
                const $body = $('#messages-chat-body');
                $body.find('.client-messages-chat__thread-empty').remove();
                $body.append(`
                    <div class="client-messages-bubble-wrap is-mine">
                        <div class="client-messages-bubble">${esc(res.data.chat.body)}</div>
                        <span class="client-messages-bubble__time">${esc(formatChatTime(res.data.chat.time))}</span>
                    </div>`);
                $body.scrollTop($body[0].scrollHeight);
                if (!res.data.is_dummy) {
                    loadConversations();
                }
                Toast.show((IE_I18N && IE_I18N.messageSent) || 'Message sent!', 'success');
            } else {
                Toast.show(res.data.message || 'Failed to send.', 'error');
            }
        }).fail(function() {
            Toast.show('Connection error. Please try again.', 'error');
        }).always(function() {
            $('#btn-send-chat').prop('disabled', false);
        });
    }

    $(document).on('click', '.client-messages-item', function() {
        openChat(String($(this).attr('data-provider-id')));
    });

    $('#btn-messages-back').on('click', function() {
        const listArea = document.getElementById('messages-conversation-list');
        if (listArea) {
            listArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });

    $(window).on('resize', function() {
        setMessagesMobileView();
    });

    $('#btn-send-chat').on('click', sendChatMessage);
    $('#chat-message-input').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            sendChatMessage();
        }
    });

    $('#messages-search').on('input', function() {
        const q = $(this).val().trim().toLowerCase();
        if (!q) {
            renderConversationList(conversationsCache);
            return;
        }
        renderConversationList(conversationsCache.filter(function(c) {
            return (c.name || '').toLowerCase().includes(q) || (c.last_message || '').toLowerCase().includes(q);
        }));
    });

    if ($('.client-profile-page').length && !$('.provider-profile-page').length && $('#panel-messages').length) {
        const presetProvider = $('#panel-messages').data('active-provider');
        if (presetProvider) {
            activeChatProviderId = String(presetProvider);
        }
        initMessageTimes();
        setMessagesMobileView();
        const $chatBody = $('#messages-chat-body');
        if ($chatBody.length) {
            $chatBody.scrollTop($chatBody[0].scrollHeight);
        }
        syncConversationsCache();
        if ($('#panel-messages').hasClass('active')) {
            $('.dashboard-nav-item[data-panel="messages"]').data('loaded', true);
        }
    }

    function syncUserTypeSelection() {
        const $checked = $('input[name="reg-user-type"]:checked');
        $('.user-type-option').removeClass('is-selected');
        if ($checked.length) {
            $checked.closest('.user-type-option').addClass('is-selected');
        }
        toggleRegProviderFields();
    }

    function toggleRegProviderFields() {
        const isProvider = $('input[name="reg-user-type"]:checked').val() === 'provider';
        $('#reg-provider-fields').toggleClass('is-visible', isProvider);
    }

    $(document).on('change', 'input[name="reg-user-type"]', syncUserTypeSelection);

    $(document).on('click', '.user-type-option', function() {
        const $radio = $(this).find('input[name="reg-user-type"]');
        $radio.prop('checked', true);
        syncUserTypeSelection();
    });

    if ($('#auth-panel-register').length) {
        syncUserTypeSelection();
    }

    /* PASSWORD TOGGLE */
    $(document).on('click', '.password-toggle', function() {
        const $input = $('#' + $(this).data('target'));
        const isPwd = $input.attr('type') === 'password';
        $input.attr('type', isPwd ? 'text' : 'password');
        $(this).html(isPwd
            ? '<i class="fa-regular fa-eye-slash" aria-hidden="true"></i>'
            : '<i class="fa-regular fa-eye" aria-hidden="true"></i>');
    });

    /* ESC KEY */
    $(document).on('keydown', function(e) { if (e.key === 'Escape') { $('.modal-overlay.open').removeClass('open'); $('body').css('overflow',''); } });

    /* SINGLE PROVIDER — SEND MESSAGE */
    $(document).on('click', '#btn-send-message', function() {
        const name = $('#msg-name').val().trim(), email = $('#msg-email').val().trim(), phone = $('#msg-phone').val().trim(), body = $('#msg-body').val().trim(), pid = $('#msg-provider-id').val();
        $('#msg-error, #msg-success').removeClass('show');
        if (!name || !email || !body) { $('#msg-error').addClass('show').text('Please fill in all required fields.'); return; }
        ieAjax('ie_send_message', { provider_id: pid, name, email, phone, message: body }, this).done(function(res) {
            if (res.success) { $('#msg-success').addClass('show').text('Message sent successfully!'); $('#msg-name, #msg-email, #msg-phone, #msg-body').val(''); }
            else { $('#msg-error').addClass('show').text(res.data.message || 'Failed to send.'); }
        });
    });

    /* STAR RATING PICKER */
    $(document).on('mouseenter', '.star-pick', function() {
        const val = $(this).data('val');
        $('.star-pick').each(function() { $(this).css('color', $(this).data('val') <= val ? '#f59e0b' : '#d1d5db'); });
    }).on('mouseleave', '#star-rating', function() {
        const selected = parseInt($('#review-rating').val()) || 5;
        $('.star-pick').each(function() { $(this).css('color', $(this).data('val') <= selected ? '#f59e0b' : '#d1d5db'); });
    }).on('click', '.star-pick', function() {
        const val = $(this).data('val');
        $('#review-rating').val(val);
        $('.star-pick').each(function() { $(this).css('color', $(this).data('val') <= val ? '#f59e0b' : '#d1d5db'); });
    });
    const initRating = parseInt($('#review-rating').val()) || 5;
    $('.star-pick').each(function() { $(this).css('color', $(this).data('val') <= initRating ? '#f59e0b' : '#d1d5db'); });

    /* SUBMIT REVIEW */
    $(document).on('click', '#btn-submit-review', function() {
        const body = $('#review-body').val().trim(), rating = $('#review-rating').val(), providerId = $('#review-provider-id').val();
        $('#review-error, #review-success').removeClass('show');
        if (!body) { $('#review-error').addClass('show').text('Please write your review.'); return; }
        ieAjax('ie_submit_review', { provider_id: providerId, rating, review: body }, this).done(function(res) {
            if (res.success) { $('#review-success').addClass('show').text(res.data.message || 'Review submitted!'); $('#review-body').val(''); setTimeout(() => location.reload(), 1500); }
            else { $('#review-error').addClass('show').text(res.data.message || 'Failed to submit.'); }
        });
    });

    /* MY BUSINESS SAVE */
    $('#btn-save-business').on('click', function() {
        $('#biz-error, #biz-success').removeClass('show');
        ieAjax('ie_update_provider', {
            provider_id: $('#biz-provider-id').val(), business_name: $('#biz-name').val().trim(),
            about: $('#biz-about').val().trim(), phone: $('#biz-phone').val().trim(),
            email: $('#biz-email').val().trim(), service_area: $('#biz-area').val().trim(),
            price_from: $('#biz-price').val().trim(), experience: $('#biz-exp').val().trim(),
            availability: $('#biz-avail').val(), website: $('#biz-website').val().trim(),
        }, this).done(function(res) {
            if (res.success) { $('#biz-success').addClass('show').text(res.data.message); Toast.show('Business info updated!', 'success'); }
            else { $('#biz-error').addClass('show').text(res.data.message || 'Failed to update.'); }
        });
    });

    /* PROVIDER PROFILE DASHBOARD */
    if ($('.provider-profile-page').length) {
        const serviceRowTemplate = `
            <div class="provider-service-row">
                <div class="form-group">
                    <label class="form-label">${esc((IE_I18N && IE_I18N.serviceName) || 'Service Name')}</label>
                    <input type="text" class="form-control svc-name" value="">
                </div>
                <div class="form-group">
                    <label class="form-label">${esc((IE_I18N && IE_I18N.price) || 'Price')}</label>
                    <input type="text" class="form-control svc-price" value="">
                </div>
                <div class="form-group">
                    <label class="form-label">${esc((IE_I18N && IE_I18N.unit) || 'Unit')}</label>
                    <input type="text" class="form-control svc-unit" value="" placeholder="hr, job, visit">
                </div>
                <button type="button" class="provider-service-remove" aria-label="Remove service">
                    <i class="fa-solid fa-trash-can" aria-hidden="true"></i>
                </button>
            </div>`;

        $('#btn-add-service').on('click', function() {
            $('#provider-services-list').append(serviceRowTemplate);
        });

        $(document).on('click', '.provider-service-remove', function() {
            $(this).closest('.provider-service-row').remove();
        });

        $('#btn-save-provider-profile').on('click', function() {
            $('#profile-error, #profile-success').removeClass('show');
            const $btn = $(this);
            const providerId = $('#provider-id').val();
            const formData = new FormData();
            formData.append('action', 'ie_update_profile');
            formData.append('nonce', IE_AJAX.nonce);
            formData.append('first_name', $('#profile-firstname').val().trim());
            formData.append('last_name', $('#profile-lastname').val().trim());
            const photoInput = document.getElementById('profile-photo');
            if (photoInput && photoInput.files[0]) {
                formData.append('profile_photo', photoInput.files[0]);
            }

            $btn.prop('disabled', true);

            $.ajax({
                url: IE_AJAX.url,
                method: 'POST',
                dataType: 'json',
                dataFilter: ieParseAjaxResponse,
                data: formData,
                processData: false,
                contentType: false,
            }).done(function(profileRes) {
                if (!profileRes.success) {
                    $('#profile-error').addClass('show').text(profileRes.data.message || 'Failed to update profile.');
                    return;
                }

                return ieAjax('ie_update_provider', {
                    provider_id: providerId,
                    business_name: $('#biz-name').val().trim(),
                    about: $('#biz-about').val().trim(),
                    phone: $('#biz-phone').val().trim(),
                    email: $('#biz-email').val().trim(),
                    service_area: $('#biz-area').val().trim(),
                    price_from: $('#biz-price').val().trim(),
                    experience: $('#biz-exp').val().trim(),
                    availability: $('#biz-avail').val(),
                    website: $('#biz-website').val().trim(),
                });
            }).then(function(bizRes) {
                if (!bizRes || !bizRes.success) {
                    $('#profile-error').addClass('show').text((bizRes && bizRes.data && bizRes.data.message) || 'Failed to update business info.');
                    return;
                }
                $('#profile-success').addClass('show').text(bizRes.data.message || 'Profile updated successfully!');
                Toast.show(bizRes.data.message || 'Profile updated!', 'success');
            }).fail(function() {
                $('#profile-error').addClass('show').text('Connection error. Please try again.');
            }).always(function() {
                $btn.prop('disabled', false);
            });
        });

        $('#btn-save-services').on('click', function() {
            $('#services-error, #services-success').removeClass('show');
            const services = [];
            $('#provider-services-list .provider-service-row').each(function() {
                const name = $(this).find('.svc-name').val().trim();
                if (!name) return;
                services.push({
                    name,
                    price: $(this).find('.svc-price').val().trim(),
                    unit: $(this).find('.svc-unit').val().trim(),
                });
            });

            const $btn = $(this);
            $btn.prop('disabled', true);
            ieAjax('ie_update_provider_services', {
                provider_id: $('#provider-id').val(),
                services: JSON.stringify(services),
            }).done(function(res) {
                if (res.success) {
                    $('#services-success').addClass('show').text(res.data.message);
                    Toast.show(res.data.message || 'Services updated!', 'success');
                } else {
                    $('#services-error').addClass('show').text(res.data.message || 'Failed to update services.');
                }
            }).fail(function() {
                $('#services-error').addClass('show').text('Connection error. Please try again.');
            }).always(function() {
                $btn.prop('disabled', false);
            });
        });

        let providerConversationsCache = [];
        let activeProviderCustomerId = null;

        function buildProviderConversationItem(c) {
            return `
            <button type="button" class="client-messages-item${activeProviderCustomerId === String(c.id) ? ' is-active' : ''}" data-customer-id="${esc(c.id)}">
                <img src="${esc(c.avatar)}" alt="${esc(c.name)}" class="client-messages-item__avatar">
                <span class="client-messages-item__content">
                    <span class="client-messages-item__top">
                        <strong class="client-messages-item__name">${esc(c.name)}</strong>
                        <span class="client-messages-item__time" data-time="${esc(c.last_time || '')}"></span>
                    </span>
                    <span class="client-messages-item__preview">${esc(c.last_message)}</span>
                </span>
            </button>`;
        }

        function renderProviderConversationList(list) {
            const $list = $('#provider-messages-conversation-list');
            $('#provider-messages-count').text(list.length);
            if (!list.length) {
                $list.html(`<div class="client-messages-list__empty"><p>${esc((IE_I18N && IE_I18N.noCustomerMessages) || 'No customer messages yet')}</p></div>`);
                return;
            }
            $list.html(list.map(buildProviderConversationItem).join(''));
            $('[data-time]').each(function() {
                const raw = $(this).attr('data-time');
                if (raw) $(this).text(formatChatTime(raw));
            });
        }

        function openProviderChat(customerId) {
            activeProviderCustomerId = String(customerId);
            $('.client-messages-item').removeClass('is-active');
            $(`.client-messages-item[data-customer-id="${customerId}"]`).addClass('is-active');
            $('#provider-messages-chat-body').html('<div class="client-messages-list__loading"><div class="spinner"></div></div>');

            ieAjax('ie_get_provider_customer_thread', { customer_id: customerId }).done(function(res) {
                if (!res.success) return;
                const c = res.data.customer;
                $('#provider-chat-head-avatar').attr({ src: c.avatar, alt: c.name });
                $('#provider-chat-head-name').text(c.name);
                const messages = res.data.messages || [];
                const $body = $('#provider-messages-chat-body');
                if (!messages.length) {
                    $body.html(`<div class="client-messages-chat__thread-empty"><p>${esc((IE_I18N && IE_I18N.replyToCustomers) || 'Reply to customer inquiries here.')}</p></div>`);
                } else {
                    $body.html(messages.map(function(m) {
                        const isMine = m.sender === 'provider';
                        return `<div class="client-messages-bubble-wrap${isMine ? ' is-mine' : ''}">
                            <div class="client-messages-bubble">${esc(m.body)}</div>
                            <span class="client-messages-bubble__time">${esc(formatChatTime(m.time))}</span>
                        </div>`;
                    }).join(''));
                    $body.scrollTop($body[0].scrollHeight);
                }
            });
        }

        function sendProviderChatMessage() {
            const message = $('#provider-chat-message-input').val().trim();
            if (!activeProviderCustomerId || !message) return;
            $('#btn-provider-send-chat').prop('disabled', true);
            ieAjax('ie_send_provider_chat_message', { customer_id: activeProviderCustomerId, message }).done(function(res) {
                if (res.success) {
                    $('#provider-chat-message-input').val('');
                    const $body = $('#provider-messages-chat-body');
                    $body.find('.client-messages-chat__thread-empty').remove();
                    $body.append(`<div class="client-messages-bubble-wrap is-mine">
                        <div class="client-messages-bubble">${esc(res.data.chat.body)}</div>
                        <span class="client-messages-bubble__time">${esc(formatChatTime(res.data.chat.time))}</span>
                    </div>`);
                    $body.scrollTop($body[0].scrollHeight);
                    Toast.show(res.data.message || 'Message sent!', 'success');
                } else {
                    Toast.show(res.data.message || 'Failed to send.', 'error');
                }
            }).always(function() {
                $('#btn-provider-send-chat').prop('disabled', false);
            });
        }

        $(document).on('click', '#provider-messages-conversation-list .client-messages-item', function() {
            openProviderChat(String($(this).attr('data-customer-id')));
        });

        $('#btn-provider-send-chat').on('click', sendProviderChatMessage);
        $('#provider-chat-message-input').on('keypress', function(e) {
            if (e.which === 13) {
                e.preventDefault();
                sendProviderChatMessage();
            }
        });

        $('#provider-messages-search').on('input', function() {
            const q = $(this).val().trim().toLowerCase();
            if (!q) {
                renderProviderConversationList(providerConversationsCache);
                return;
            }
            renderProviderConversationList(providerConversationsCache.filter(function(c) {
                return (c.name || '').toLowerCase().includes(q) || (c.last_message || '').toLowerCase().includes(q);
            }));
        });

        const presetCustomer = $('#panel-messages').data('active-customer');
        if (presetCustomer) activeProviderCustomerId = String(presetCustomer);
        $('[data-time]').each(function() {
            const raw = $(this).attr('data-time');
            if (raw) $(this).text(formatChatTime(raw));
        });

        ieAjax('ie_get_provider_conversations', {}).done(function(res) {
            if (res.success) {
                providerConversationsCache = res.data.conversations || [];
                $('#provider-messages-count').text(providerConversationsCache.length);
            }
        });

        $(document).on('click', '.provider-profile-page .dashboard-nav-item[data-panel="messages"]', function() {
            if (!$(this).data('loaded')) {
                ieAjax('ie_get_provider_conversations', {}).done(function(res) {
                    if (res.success) {
                        providerConversationsCache = res.data.conversations || [];
                        renderProviderConversationList(providerConversationsCache);
                    }
                });
                $(this).data('loaded', true);
            }
        });
    }

    /* CONTACT FORM */
    if ($('#btn-contact-submit').length) {
        $('#btn-contact-submit').on('click', function() {
            const name    = $('#contact-name').val().trim();
            const email   = $('#contact-email').val().trim();
            const subject = $('#contact-subject').val().trim();
            const message = $('#contact-message').val().trim();
            const i18n    = window.IE_I18N || {};

            $('#contact-error, #contact-success').removeClass('show');

            if (!name || !email || !subject || !message) {
                $('#contact-error').addClass('show').text(i18n.fillRequired || 'Please fill in all required fields.');
                return;
            }

            const $btn = $(this);
            $btn.prop('disabled', true).text(i18n.sending || 'Sending...');

            ieAjax('ie_contact_form', {
                name,
                email,
                phone: $('#contact-phone').val().trim(),
                subject,
                message,
            }).done(function(res) {
                if (res.success) {
                    $('#contact-success').addClass('show').text(i18n.contactSuccess || 'Message sent!');
                    $('#contact-name, #contact-email, #contact-phone, #contact-message').val('');
                    $('#contact-subject').val('');
                } else {
                    $('#contact-error').addClass('show').text((res.data && res.data.message) || i18n.contactFailed || 'Failed to send.');
                }
            }).fail(function() {
                $('#contact-error').addClass('show').text(i18n.connectionError || 'Connection error. Please try again.');
            }).always(function() {
                $btn.prop('disabled', false).html((i18n.sendMessage || 'Send Message') + ' <i class="fa-solid fa-paper-plane" aria-hidden="true"></i>');
            });
        });
    }

})(jQuery);