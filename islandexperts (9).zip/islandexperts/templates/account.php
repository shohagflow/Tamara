<?php
/**
 * Template Name: Account
 */
get_header();

if ( is_user_logged_in() ) {
    wp_safe_redirect( ie_get_user_profile_url() );
    exit;
}
?>

<div class="account-page-wrap">
    <div class="container">

    <div class="auth-container">
        <div class="auth-card">
            <?php
            $msg = sanitize_text_field( $_GET['msg'] ?? '' );
            if ( $msg === 'provider_only' ) : ?>
                <div class="form-error show auth-alert"><?php echo esc_html( ie__( 'This page is for Service Providers only. Please log in as a Service Provider.' ) ); ?></div>
            <?php elseif ( $msg === 'customer_only' ) : ?>
                <div class="form-error show auth-alert"><?php echo esc_html( ie__( 'This page is for Customers only. Please log in as a Customer.' ) ); ?></div>
            <?php endif; ?>

            <div class="auth-form-wrap auth-form-intro">
                <div id="auth-header-login" class="auth-header">
                    <h2 class="auth-form-title"><?php echo esc_html( ie__( 'Welcome back' ) ); ?></h2>
                    <p class="auth-form-sub"><?php echo esc_html( ie__( 'Sign in to manage your bookings and saved providers.' ) ); ?></p>
                </div>
                <div id="auth-header-register" class="auth-header" style="display:none">
                    <h2 class="auth-form-title"><?php echo esc_html( ie__( 'Create your account' ) ); ?></h2>
                    <p class="auth-form-sub"><?php echo esc_html( ie__( 'Join Island Experts to book trusted local professionals.' ) ); ?></p>
                </div>

                <div class="auth-tabs">
                    <button class="auth-tab-btn active" data-tab="login"><?php echo esc_html( ie__( 'Sign In' ) ); ?></button>
                    <button class="auth-tab-btn" data-tab="register"><?php echo esc_html( ie__( 'Create Account' ) ); ?></button>
                </div>
            </div>

            <!-- Sign In Form -->
            <div id="auth-panel-login" class="auth-form-wrap auth-form-body">
                <div class="form-group">
                    <label class="form-label" for="login-email"><?php echo esc_html( ie__( 'Email Address' ) ); ?></label>
                    <input type="email" id="login-email" class="form-control" placeholder="<?php echo esc_attr( ie__( 'you@example.com' ) ); ?>" autocomplete="email">
                </div>
                <div class="form-group">
                    <label class="form-label" for="login-password"><?php echo esc_html( ie__( 'Password' ) ); ?></label>
                    <div class="input-with-toggle">
                        <input type="password" id="login-password" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Your password' ) ); ?>" autocomplete="current-password">
                        <button class="password-toggle" type="button" data-target="login-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>

                <div class="form-error" id="login-error"></div>
                <div class="form-success" id="login-success"></div>

                <button class="btn-auth" id="btn-login"><?php echo esc_html( ie__( 'Sign In' ) ); ?></button>
            </div>
            <!-- /Sign In Form -->

            <!-- Registration Form -->
            <div id="auth-panel-register" class="auth-form-wrap auth-form-body" style="display:none">
                <div class="auth-form-grid">
                    <div class="form-group">
                        <label class="form-label" for="reg-firstname"><?php echo esc_html( ie__( 'First Name' ) ); ?> <span class="form-required">*</span></label>
                        <input type="text" id="reg-firstname" class="form-control" placeholder="<?php echo esc_attr( ie__( 'John' ) ); ?>" autocomplete="given-name">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="reg-lastname"><?php echo esc_html( ie__( 'Last Name' ) ); ?></label>
                        <input type="text" id="reg-lastname" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Doe' ) ); ?>" autocomplete="family-name">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="reg-email"><?php echo esc_html( ie__( 'Email Address' ) ); ?> <span class="form-required">*</span></label>
                    <input type="email" id="reg-email" class="form-control" placeholder="<?php echo esc_attr( ie__( 'you@example.com' ) ); ?>" autocomplete="email">
                </div>

                <div class="form-group auth-user-type-group">
                    <div class="user-type-options">
                        <label class="user-type-option is-selected" id="type-customer-label">
                            <input type="radio" name="reg-user-type" id="reg-type-customer" value="customer" checked>
                            <span class="user-type-option__text"><?php echo esc_html( ie__( 'Customer' ) ); ?></span>
                        </label>
                        <label class="user-type-option" id="type-provider-label">
                            <input type="radio" name="reg-user-type" id="reg-type-provider" value="provider">
                            <span class="user-type-option__text"><?php echo esc_html( ie__( 'Service Provider' ) ); ?></span>
                        </label>
                    </div>
                </div>

                <div id="reg-provider-fields" class="reg-provider-fields">
                    <div class="reg-provider-fields__title">
                        <i class="fa-solid fa-briefcase" aria-hidden="true"></i>
                        <?php echo esc_html( ie__( 'Business Details' ) ); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="reg-service-name"><?php echo esc_html( ie__( 'Service / Business Name' ) ); ?> <span class="form-required">*</span></label>
                        <input type="text" id="reg-service-name" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. BrightSpark Electrical' ) ); ?>">
                    </div>
                    <div class="auth-form-grid">
                        <div class="form-group">
                            <label class="form-label" for="reg-experience"><?php echo esc_html( ie__( 'Experience (years)' ) ); ?> <span class="form-required">*</span></label>
                            <input type="number" id="reg-experience" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. 5' ) ); ?>" min="0" max="60">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="reg-location"><?php echo esc_html( ie__( 'Location' ) ); ?> <span class="form-required">*</span></label>
                            <input type="text" id="reg-location" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. Castries, Gros Islet' ) ); ?>">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="reg-password"><?php echo esc_html( ie__( 'Password' ) ); ?> <span class="form-required">*</span></label>
                    <div class="input-with-toggle">
                        <input type="password" id="reg-password" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Min 6 characters' ) ); ?>" autocomplete="new-password">
                        <button class="password-toggle" type="button" data-target="reg-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="reg-confirm-password"><?php echo esc_html( ie__( 'Confirm Password' ) ); ?> <span class="form-required">*</span></label>
                    <div class="input-with-toggle">
                        <input type="password" id="reg-confirm-password" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Repeat your password' ) ); ?>" autocomplete="new-password">
                        <button class="password-toggle" type="button" data-target="reg-confirm-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>

                <div class="form-error" id="reg-error"></div>
                <div class="form-success" id="reg-success"></div>

                <button class="btn-auth" id="btn-register"><?php echo esc_html( ie__( 'Create Account' ) ); ?></button>
            </div>
            <!-- /Registration Form -->
        </div>
    </div>

    </div>
</div>

<?php get_footer(); ?>
