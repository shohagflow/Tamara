<?php
/**
 * Template Name: Register as Provider
 */
get_header();

$from_payment  = isset( $_GET['from_payment'] );
$selected_plan = '';
if ( $from_payment && isset( $_COOKIE['ie_plan'] ) ) {
    $selected_plan = sanitize_text_field( $_COOKIE['ie_plan'] );
}

$is_logged_in = is_user_logged_in();
$current_user = $is_logged_in ? wp_get_current_user() : null;

$existing_provider = null;
if ( $is_logged_in ) {
    $existing = get_posts( [
        'post_type'   => 'ie_provider',
        'author'      => $current_user->ID,
        'post_status' => [ 'publish', 'pending' ],
        'numberposts' => 1,
    ] );
    if ( $existing ) {
        $existing_provider = $existing[0];
    }
}

$categories = get_terms( [ 'taxonomy' => 'ie_category', 'hide_empty' => false ] );
?>

<div class="provider-register-page">
    <div class="container">

        <?php if ( ! $is_logged_in ) : ?>
            <div class="provider-state-card">
                <div class="provider-state-icon">
                    <i class="fa-solid fa-lock" aria-hidden="true"></i>
                </div>
                <h2><?php echo esc_html( ie__( 'Sign in to list your business' ) ); ?></h2>
                <p style="color:var(--color-text-muted);margin:12px 0 24px;"><?php echo esc_html( ie__( 'You need an account to register as a service provider.' ) ); ?></p>
                <a href="<?php echo esc_url( home_url( '/account/' ) ); ?>" class="btn-auth" style="display:inline-block;width:auto;padding:12px 32px;text-decoration:none;">
                    <?php echo esc_html( ie__( 'Sign In / Register' ) ); ?>
                </a>
            </div>

        <?php elseif ( $existing_provider ) : ?>
            <div class="provider-state-card">
                <div class="provider-state-icon <?php echo $existing_provider->post_status === 'pending' ? 'is-warning' : 'is-success'; ?>">
                    <i class="fa-solid <?php echo $existing_provider->post_status === 'pending' ? 'fa-clock' : 'fa-circle-check'; ?>" aria-hidden="true"></i>
                </div>
                <h2>
                    <?php echo esc_html( $existing_provider->post_status === 'pending' ? ie__( 'Your listing is under review' ) : ie__( 'You are already listed!' ) ); ?>
                </h2>
                <p style="color:var(--color-text-muted);margin:12px 0 24px;">
                    <?php echo esc_html( $existing_provider->post_status === 'pending'
                        ? ie__( 'Our team will review your application and approve it within 24 hours. You will be notified by email.' )
                        : ie__( 'Your business is live on Island Experts.' ) ); ?>
                </p>
                <?php if ( $existing_provider->post_status === 'publish' ) : ?>
                    <a href="<?php echo esc_url( get_permalink( $existing_provider->ID ) ); ?>" class="btn-auth" style="display:inline-block;width:auto;padding:12px 32px;text-decoration:none;">
                        <?php echo esc_html( ie__( 'View My Listing' ) ); ?>
                    </a>
                <?php endif; ?>
            </div>

        <?php else : ?>
            <div class="provider-register-wrap">

                <?php if ( $from_payment ) : ?>
                    <div class="provider-alert provider-alert--success">
                        <span class="provider-alert__icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></span>
                        <div>
                            <div class="provider-alert__title"><?php echo esc_html( ie__( 'Payment Successful!' ) ); ?></div>
                            <div class="provider-alert__text">
                                <?php if ( $selected_plan ) : ?>
                                    <?php echo esc_html( ie__( 'Plan:' ) ); ?> <strong><?php echo esc_html( $selected_plan ); ?></strong> —
                                <?php endif; ?>
                                <?php echo esc_html( ie__( 'Now complete your profile below to go live.' ) ); ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="provider-register-header">
                    <span class="provider-register-badge">
                        <i class="fa-solid fa-briefcase" aria-hidden="true"></i>
                        <?php echo esc_html( ie__( 'For Service Providers' ) ); ?>
                    </span>
                    <h1><?php echo esc_html( ie__( 'List Your Business' ) ); ?></h1>
                    <p><?php echo esc_html( ie__( 'Fill in your details below. Our team will review and approve your listing within 24 hours.' ) ); ?></p>
                </div>

                <div class="provider-form-card" id="provider-form-card">

                    <div class="provider-form-section">
                        <h3 class="provider-section-title">
                            <i class="fa-solid fa-clipboard-list" aria-hidden="true"></i>
                            <?php echo esc_html( ie__( 'Basic Information' ) ); ?>
                        </h3>
                        <div class="form-group">
                            <label class="form-label" for="reg-business-name"><?php echo esc_html( ie__( 'Business Name' ) ); ?> <span class="form-required">*</span></label>
                            <input type="text" id="reg-business-name" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. BrightSpark Electrical' ) ); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="reg-category"><?php echo esc_html( ie__( 'Service Category' ) ); ?> <span class="form-required">*</span></label>
                            <select id="reg-category" class="form-control">
                                <option value=""><?php echo esc_html( ie__( 'Select a category...' ) ); ?></option>
                                <?php foreach ( $categories as $cat ) : ?>
                                    <option value="<?php echo esc_attr( $cat->slug ); ?>" data-id="<?php echo esc_attr( $cat->term_id ); ?>">
                                        <?php echo esc_html( $cat->name ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="reg-about"><?php echo esc_html( ie__( 'About Your Business' ) ); ?> <span class="form-required">*</span></label>
                            <textarea id="reg-about" class="form-control" rows="4" placeholder="<?php echo esc_attr( ie__( 'Describe your services, experience, and what makes you stand out...' ) ); ?>"></textarea>
                        </div>
                    </div>

                    <div class="provider-form-section">
                        <h3 class="provider-section-title">
                            <i class="fa-solid fa-phone" aria-hidden="true"></i>
                            <?php echo esc_html( ie__( 'Contact Information' ) ); ?>
                        </h3>
                        <div class="provider-form-grid">
                            <div class="form-group">
                                <label class="form-label" for="reg-phone"><?php echo esc_html( ie__( 'Phone Number' ) ); ?> <span class="form-required">*</span></label>
                                <input type="tel" id="reg-phone" class="form-control" placeholder="<?php echo esc_attr( ie__( '+1 (758) 000-0000' ) ); ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="reg-email"><?php echo esc_html( ie__( 'Business Email' ) ); ?> <span class="form-required">*</span></label>
                                <input type="email" id="reg-email" class="form-control" placeholder="<?php echo esc_attr( ie__( 'you@yourbusiness.com' ) ); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="reg-website"><?php echo esc_html( ie__( 'Website (optional)' ) ); ?></label>
                            <input type="url" id="reg-website" class="form-control" placeholder="<?php echo esc_attr( ie__( 'https://yourbusiness.com' ) ); ?>">
                        </div>
                    </div>

                    <div class="provider-form-section">
                        <h3 class="provider-section-title">
                            <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                            <?php echo esc_html( ie__( 'Location & Experience' ) ); ?>
                        </h3>
                        <div class="provider-form-grid">
                            <div class="form-group">
                                <label class="form-label" for="reg-area"><?php echo esc_html( ie__( 'Service Area' ) ); ?> <span class="form-required">*</span></label>
                                <input type="text" id="reg-area" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. Castries, Gros Islet' ) ); ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="reg-experience"><?php echo esc_html( ie__( 'Years of Experience' ) ); ?> <span class="form-required">*</span></label>
                                <input type="number" id="reg-experience" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. 5' ) ); ?>" min="0" max="60">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="reg-price"><?php echo esc_html( ie__( 'Starting Price ($)' ) ); ?> <span class="form-required">*</span></label>
                            <input type="number" id="reg-price" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. 50' ) ); ?>" min="0">
                            <span class="provider-form-hint"><?php echo esc_html( ie__( 'Minimum price per service/job' ) ); ?></span>
                        </div>
                    </div>

                    <div class="provider-form-section">
                        <h3 class="provider-section-title">
                            <i class="fa-solid fa-tags" aria-hidden="true"></i>
                            <?php echo esc_html( ie__( 'Services & Pricing' ) ); ?>
                        </h3>
                        <p class="provider-form-note"><?php echo esc_html( ie__( 'Add each service you offer with its price.' ) ); ?></p>
                        <div class="services-grid-labels">
                            <span><?php echo esc_html( ie__( 'Service Name' ) ); ?></span>
                            <span><?php echo esc_html( ie__( 'Price' ) ); ?></span>
                            <span><?php echo esc_html( ie__( 'Per (job/hr/sqft)' ) ); ?></span>
                            <span></span>
                        </div>
                        <div id="services-repeater" class="services-repeater">
                            <div class="service-row">
                                <input type="text" class="form-control svc-name" placeholder="<?php echo esc_attr( ie__( 'e.g. Interior Painting' ) ); ?>">
                                <input type="text" class="form-control svc-price" placeholder="<?php echo esc_attr( ie__( '$250' ) ); ?>">
                                <input type="text" class="form-control svc-unit" placeholder="<?php echo esc_attr( ie__( 'job' ) ); ?>">
                                <button type="button" class="btn-remove-service remove-service-row" aria-label="<?php echo esc_attr( ie__( 'Remove service' ) ); ?>">
                                    <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                                </button>
                            </div>
                        </div>
                        <button type="button" id="add-service-row" class="btn-add-service">
                            <i class="fa-solid fa-plus" aria-hidden="true"></i>
                            <?php echo esc_html( ie__( 'Add Another Service' ) ); ?>
                        </button>
                    </div>

                    <div class="provider-form-section">
                        <h3 class="provider-section-title">
                            <i class="fa-solid fa-camera" aria-hidden="true"></i>
                            <?php echo esc_html( ie__( 'Profile Photo' ) ); ?>
                        </h3>
                        <p class="provider-form-note"><?php echo esc_html( ie__( 'Upload a photo of you, your team, or your work. (JPG, PNG — max 5MB)' ) ); ?></p>
                        <div id="photo-upload-area" class="photo-upload-area" onclick="document.getElementById('reg-photo').click()">
                            <div id="photo-preview" class="photo-preview" style="display:none;">
                                <img id="photo-preview-img" alt="">
                            </div>
                            <div id="photo-placeholder">
                                <div class="photo-upload-icon">
                                    <i class="fa-solid fa-cloud-arrow-up" aria-hidden="true"></i>
                                </div>
                                <p class="photo-upload-text"><?php echo esc_html( ie__( 'Click to upload photo' ) ); ?></p>
                            </div>
                            <input type="file" id="reg-photo" accept="image/jpeg,image/png,image/webp" style="display:none">
                        </div>
                    </div>

                    <div class="form-error" id="reg-provider-error"></div>
                    <div class="form-success" id="reg-provider-success"></div>

                    <button class="btn-auth" id="btn-submit-provider" style="font-size:1rem;padding:14px;">
                        <i class="fa-solid fa-paper-plane" aria-hidden="true"></i>
                        <?php echo esc_html( ie__( 'Submit for Review' ) ); ?>
                    </button>
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>

<script>
(function($) {
    const serviceRowHtml = `
        <div class="service-row">
            <input type="text" class="form-control svc-name" placeholder="<?php echo esc_attr( ie__( 'e.g. Interior Painting' ) ); ?>">
            <input type="text" class="form-control svc-price" placeholder="<?php echo esc_attr( ie__( '$250' ) ); ?>">
            <input type="text" class="form-control svc-unit" placeholder="<?php echo esc_attr( ie__( 'job' ) ); ?>">
            <button type="button" class="btn-remove-service remove-service-row" aria-label="<?php echo esc_attr( ie__( 'Remove service' ) ); ?>">
                <i class="fa-solid fa-xmark" aria-hidden="true"></i>
            </button>
        </div>`;

    $('#add-service-row').on('click', function() {
        $('#services-repeater').append(serviceRowHtml);
    });

    $(document).on('click', '.remove-service-row', function() {
        if ($('.service-row').length > 1) {
            $(this).closest('.service-row').remove();
        }
    });

    $('#reg-photo').on('change', function() {
        const file = this.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function(e) {
            $('#photo-preview-img').attr('src', e.target.result);
            $('#photo-preview').show();
            $('#photo-placeholder').hide();
        };
        reader.readAsDataURL(file);
    });

    $('#btn-submit-provider').on('click', function() {
        $('#reg-provider-error, #reg-provider-success').removeClass('show');

        const name     = $('#reg-business-name').val().trim();
        const category = $('#reg-category').val();
        const catId    = $('#reg-category option:selected').data('id');
        const about    = $('#reg-about').val().trim();
        const phone    = $('#reg-phone').val().trim();
        const email    = $('#reg-email').val().trim();
        const website  = $('#reg-website').val().trim();
        const area     = $('#reg-area').val().trim();
        const exp      = $('#reg-experience').val().trim();
        const price    = $('#reg-price').val().trim();

        if (!name || !category || !about || !phone || !email || !area || !exp || !price) {
            $('#reg-provider-error').addClass('show').text(IE_I18N.fillRequired);
            $('html,body').animate({ scrollTop: $('#reg-provider-error').offset().top - 100 }, 300);
            return;
        }

        const services = [];
        $('.service-row').each(function() {
            const svcName  = $(this).find('.svc-name').val().trim();
            const svcPrice = $(this).find('.svc-price').val().trim();
            const svcUnit  = $(this).find('.svc-unit').val().trim();
            if (svcName && svcPrice) {
                services.push({ name: svcName, price: svcPrice, unit: svcUnit || 'job' });
            }
        });

        const formData = new FormData();
        formData.append('action', 'ie_register_provider');
        formData.append('nonce', IE_AJAX.nonce);
        formData.append('business_name', name);
        formData.append('category_id', catId);
        formData.append('category_slug', category);
        formData.append('about', about);
        formData.append('phone', phone);
        formData.append('email', email);
        formData.append('website', website);
        formData.append('service_area', area);
        formData.append('experience', exp);
        formData.append('price_from', price);
        formData.append('services', JSON.stringify(services));

        const photoFile = $('#reg-photo')[0].files[0];
        if (photoFile) formData.append('photo', photoFile);

        const $btn = $(this);
        $btn.prop('disabled', true).html('<span class="ie-btn-spin"></span> <?php echo esc_js( ie__( 'Submitting...' ) ); ?>');

        $.ajax({
            url: IE_AJAX.url,
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
        }).done(function(res) {
            if (res.success) {
                const profileUrl = '<?php echo esc_url( ie_get_theme_page_url( 'provider-profile' ) ); ?>';
                const dest = (res.data && res.data.redirect_url) || (IE_AJAX.urls && IE_AJAX.urls.providerProfile) || profileUrl;
                const successHtml = `
                    <div class="provider-success-card">
                        <div class="provider-success-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
                        <h2><?php echo esc_js( ie__( 'Application Submitted!' ) ); ?></h2>
                        <p style="color:var(--color-text-light);font-size:0.95rem;margin:12px 0 8px;">
                            <?php echo esc_js( ie__( 'Your business profile has been submitted for review.' ) ); ?>
                        </p>
                        <p style="color:var(--color-text-muted);font-size:0.9rem;margin-bottom:24px;">
                            <?php echo esc_js( ie__( 'Redirecting to your profile...' ) ); ?>
                        </p>
                    </div>`;
                $('#provider-form-card').html(successHtml);
                $('html,body').animate({ scrollTop: 0 }, 400);
                setTimeout(function() { window.location = dest; }, 1200);
            } else {
                $('#reg-provider-error').addClass('show').text(res.data.message || '<?php echo esc_js( ie__( 'Submission failed. Please try again.' ) ); ?>');
                $btn.prop('disabled', false).html('<i class="fa-solid fa-paper-plane" aria-hidden="true"></i> <?php echo esc_js( ie__( 'Submit for Review' ) ); ?>');
                $('html,body').animate({ scrollTop: $('#reg-provider-error').offset().top - 100 }, 300);
            }
        }).fail(function() {
            $('#reg-provider-error').addClass('show').text(IE_I18N.connectionError);
            $btn.prop('disabled', false).html('<i class="fa-solid fa-paper-plane" aria-hidden="true"></i> <?php echo esc_js( ie__( 'Submit for Review' ) ); ?>');
        });
    });
})(jQuery);
</script>

<?php get_footer(); ?>
