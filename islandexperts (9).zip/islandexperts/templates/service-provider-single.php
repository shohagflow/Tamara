<?php
/**
 * Template Name: Service Provider Single
 */
get_header();

$slug     = get_query_var( 'ie_provider_slug' );
$provider = ie_resolve_provider_for_single( $slug );

if ( ! $provider ) {
    ?>
    <section class="sp-single-page">
        <div class="container sp-single-wrap">
            <div class="sp-not-found">
                <h1><?php echo esc_html( ie__( 'Provider not found' ) ); ?></h1>
                <p><?php echo esc_html( ie__( 'This service provider profile could not be found.' ) ); ?></p>
                <a href="<?php echo esc_url( ie_get_theme_page_url( 'browse' ) ); ?>" class="btn-featured-profile"><?php echo esc_html( ie__( 'Browse Providers' ) ); ?></a>
            </div>
        </div>
    </section>
    <?php
    get_footer();
    return;
}

$cat_slug  = preg_replace( '/[^a-z0-9-]/', '', strtolower( $provider['category_slug'] ?? '' ) );
$avail_map = [
    'available_now'  => 'avail-now',
    'available_week' => 'avail-week',
    'busy'           => 'avail-busy',
];
$avail_cls = $avail_map[ $provider['availability'] ?? '' ] ?? 'avail-now';
$fallback  = ie_get_category_service_image( $cat_slug );
?>

<section class="sp-single-page">
    <div class="container sp-single-wrap">
        <a href="<?php echo esc_url( home_url( '/#top-providers' ) ); ?>" class="sp-back-link">
            <i class="fa-solid fa-arrow-left" aria-hidden="true"></i>
            <?php echo esc_html( ie__( 'Back' ) ); ?>
        </a>

        <div class="sp-hero-card">
            <div class="sp-hero-image">
                <img src="<?php echo esc_url( $provider['service_image'] ); ?>"
                     alt="<?php echo esc_attr( $provider['title'] ); ?>"
                     onerror="this.onerror=null;this.src='<?php echo esc_url( $fallback ); ?>';">
            </div>

            <div class="sp-hero-body">
                <div class="sp-profile-row">
                    <img class="sp-avatar"
                         src="<?php echo esc_url( $provider['profile_image'] ); ?>"
                         alt="<?php echo esc_attr( $provider['title'] ); ?>"
                         onerror="this.onerror=null;this.src='<?php echo esc_url( ie_get_provider_avatar_url( $provider['title'] ) ); ?>';">
                    <div class="sp-title-block">
                        <div class="sp-title-row">
                            <h1><?php echo esc_html( $provider['title'] ); ?></h1>
                            <?php if ( ! empty( $provider['verified'] ) ) : ?>
                                <span class="sp-verified"><i class="fa-solid fa-circle-check" aria-hidden="true"></i> <?php echo esc_html( ie__( 'Verified' ) ); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="sp-rating">
                            <i class="fa-solid fa-star" aria-hidden="true"></i>
                            <strong><?php echo esc_html( $provider['rating'] ); ?></strong>
                            <span>(<?php echo esc_html( $provider['reviews'] ); ?> <?php echo esc_html( ie__( 'reviews' ) ); ?>)</span>
                        </div>
                        <div class="sp-tags">
                            <?php if ( ! empty( $provider['category'] ) ) : ?>
                                <span class="tag tag-<?php echo esc_attr( $cat_slug ); ?>"><?php echo esc_html( $provider['category'] ); ?></span>
                            <?php endif; ?>
                            <span class="availability-badge <?php echo esc_attr( $avail_cls ); ?> sp-availability">
                                <?php echo esc_html( $provider['avail_label'] ); ?>
                            </span>
                        </div>
                    </div>
                </div>

                <div class="sp-meta-grid">
                    <?php if ( ! empty( $provider['location'] ) ) : ?>
                        <div class="sp-meta-item">
                            <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                            <?php echo esc_html( $provider['location'] ); ?>
                        </div>
                    <?php endif; ?>
                    <?php if ( ! empty( $provider['experience'] ) && $provider['experience'] !== '0' ) : ?>
                        <div class="sp-meta-item">
                            <i class="fa-solid fa-clock" aria-hidden="true"></i>
                            <?php echo esc_html( $provider['experience'] ); ?> <?php echo esc_html( ie__( 'years experience' ) ); ?>
                        </div>
                    <?php endif; ?>
                    <?php if ( ! empty( $provider['price'] ) && $provider['price'] !== '0' ) : ?>
                        <div class="sp-meta-item sp-price">
                            <i class="fa-solid fa-tag" aria-hidden="true"></i>
                            <?php echo esc_html( ie__( 'From' ) ); ?> <strong>$<?php echo esc_html( $provider['price'] ); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="sp-contact-inline" id="sp-contact">
                    <a href="<?php echo esc_url( ie_get_provider_single_url( $provider['slug'] ) . '#sp-contact' ); ?>" class="btn-featured-chat sp-contact-chat">
                        <i class="fa-regular fa-comment-dots" aria-hidden="true"></i>
                        <?php echo esc_html( ie__( 'Chat' ) ); ?>
                    </a>

                    <?php if ( ! empty( $provider['phone'] ) ) : ?>
                        <a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $provider['phone'] ) ); ?>" class="sp-contact-link">
                            <i class="fa-solid fa-phone" aria-hidden="true"></i>
                            <?php echo esc_html( $provider['phone'] ); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ( ! empty( $provider['email'] ) ) : ?>
                        <a href="mailto:<?php echo esc_attr( $provider['email'] ); ?>" class="sp-contact-link">
                            <i class="fa-solid fa-envelope" aria-hidden="true"></i>
                            <?php echo esc_html( $provider['email'] ); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ( ! empty( $provider['social'] ) ) : ?>
                        <div class="sp-social-links">
                            <?php if ( ! empty( $provider['social']['facebook'] ) ) : ?>
                                <a href="<?php echo esc_url( $provider['social']['facebook'] ); ?>" class="sp-social-btn sp-social-fb" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( ie__( 'Facebook' ) ); ?>">
                                    <i class="fa-brands fa-facebook-f" aria-hidden="true"></i>
                                </a>
                            <?php endif; ?>
                            <?php if ( ! empty( $provider['social']['instagram'] ) ) : ?>
                                <a href="<?php echo esc_url( $provider['social']['instagram'] ); ?>" class="sp-social-btn sp-social-in" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( ie__( 'Instagram' ) ); ?>">
                                    <i class="fa-brands fa-instagram" aria-hidden="true"></i>
                                </a>
                            <?php endif; ?>
                            <?php if ( ! empty( $provider['social']['youtube'] ) ) : ?>
                                <a href="<?php echo esc_url( $provider['social']['youtube'] ); ?>" class="sp-social-btn sp-social-yt" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( ie__( 'YouTube' ) ); ?>">
                                    <i class="fa-brands fa-youtube" aria-hidden="true"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="sp-content-grid">
            <div class="sp-main">
                <?php if ( ! empty( $provider['about'] ) ) : ?>
                    <div class="sp-panel">
                        <h2><?php echo esc_html( ie__( 'About' ) ); ?></h2>
                        <p><?php echo esc_html( $provider['about'] ); ?></p>
                    </div>
                <?php endif; ?>

                <?php if ( ! empty( $provider['services'] ) ) : ?>
                    <div class="sp-panel">
                        <h2><?php echo esc_html( ie__( 'Services & Pricing' ) ); ?></h2>
                        <ul class="sp-services-list">
                            <?php foreach ( $provider['services'] as $svc ) : ?>
                                <li>
                                    <span><?php echo esc_html( $svc['name'] ); ?></span>
                                    <strong>$<?php echo esc_html( $svc['price'] ); ?> / <?php echo esc_html( $svc['unit'] ?? 'job' ); ?></strong>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ( ! empty( $provider['reviews_list'] ) ) : ?>
                    <div class="sp-panel sp-reviews-panel">
                        <div class="sp-reviews-header">
                            <h2><?php echo esc_html( ie__( 'Reviews' ) ); ?></h2>
                            <span class="sp-reviews-count"><?php echo esc_html( $provider['reviews'] ); ?> <?php echo esc_html( ie__( 'total' ) ); ?></span>
                        </div>
                        <div class="sp-reviews-list">
                            <?php foreach ( $provider['reviews_list'] as $review ) :
                                $stars = str_repeat( '★', (int) $review['rating'] ) . str_repeat( '☆', 5 - (int) $review['rating'] );
                                $initial = strtoupper( substr( $review['author'], 0, 1 ) );
                            ?>
                                <article class="sp-review-item">
                                    <div class="sp-review-top">
                                        <div class="sp-review-avatar"><?php echo esc_html( $initial ); ?></div>
                                        <div class="sp-review-meta">
                                            <strong><?php echo esc_html( $review['author'] ); ?></strong>
                                            <div class="sp-review-stars">
                                                <span class="sp-stars" aria-hidden="true"><?php echo esc_html( $stars ); ?></span>
                                                <span class="sp-review-date"><?php echo esc_html( $review['date'] ); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <p><?php echo esc_html( $review['text'] ); ?></p>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
