<?php ie_render_site_footer(); ?>

<?php wp_footer(); ?>
</body>
</html>
