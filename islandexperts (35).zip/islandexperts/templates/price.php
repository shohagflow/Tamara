<?php
/**
 * Template Name: Price
 */
get_header();

$price_data           = ie_get_price_page_data( ie_get_price_content_post_id() );
$yearly_discount_text = ie_get_subscription_yearly_discount_text();
$payment_cancelled    = isset( $_GET['payment'] ) && $_GET['payment'] === 'cancelled';
$payment_success      = isset( $_GET['payment'] ) && $_GET['payment'] === 'success' && empty( $_GET['session_id'] );
$success_plan         = '';

if ( $payment_success ) {
    $success_plan = sanitize_text_field( wp_unslash( $_GET['plan'] ?? '' ) );

    if ( $success_plan === '' && isset( $_COOKIE['ie_plan'] ) ) {
        $success_plan = sanitize_text_field( wp_unslash( $_COOKIE['ie_plan'] ) );
    }
}
?>

<div class="pricing-page-wrap">
    <div class="container">

        <?php ie_render_price_intro( $price_data['intro'] ); ?>

        <div class="pricing-billing-toggle" role="tablist" aria-label="<?php echo esc_attr( ie__( 'Billing period' ) ); ?>">
            <button type="button" class="pricing-billing-option is-active" data-billing="monthly" role="tab" aria-selected="true">
                <?php echo esc_html( ie__( 'Monthly' ) ); ?>
            </button>
            <button type="button" class="pricing-billing-option" data-billing="yearly" role="tab" aria-selected="false">
                <?php echo esc_html( ie__( 'Yearly' ) ); ?>
                <?php if ( $yearly_discount_text !== '' ) : ?>
                    <span class="pricing-save-badge"><?php echo esc_html( $yearly_discount_text ); ?></span>
                <?php endif; ?>
            </button>
        </div>

        <div class="pricing-grid subscription-cards">
            <?php if ( $payment_success ) : ?>
                <div class="provider-alert provider-alert--success" style="grid-column:1/-1;margin-bottom:8px;">
                    <span class="provider-alert__icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></span>
                    <div>
                        <div class="provider-alert__title"><?php echo esc_html( ie__( 'Payment Successful!' ) ); ?></div>
                        <div class="provider-alert__text">
                            <?php if ( $success_plan !== '' ) : ?>
                                <?php echo esc_html( ie__( 'Plan:' ) ); ?> <strong><?php echo esc_html( $success_plan ); ?></strong> —
                            <?php endif; ?>
                            <?php echo esc_html( ie__( 'Your subscription is now active.' ) ); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ( $payment_cancelled ) : ?>
                <div class="provider-alert provider-alert--warning" style="grid-column:1/-1;margin-bottom:8px;">
                    <span class="provider-alert__icon"><i class="fa-solid fa-circle-info" aria-hidden="true"></i></span>
                    <div>
                        <div class="provider-alert__title"><?php echo esc_html( ie__( 'Payment cancelled' ) ); ?></div>
                        <div class="provider-alert__text"><?php echo esc_html( ie__( 'No charge was made. Choose a plan below when you are ready.' ) ); ?></div>
                    </div>
                </div>
            <?php endif; ?>

            <?php ie_render_subscription_pricing_cards(); ?>
        </div>

    </div>
</div>

<script>
(function($) {
    function setBillingPeriod(period) {
        $('.pricing-billing-option').each(function() {
            var isActive = $(this).data('billing') === period;
            $(this).toggleClass('is-active', isActive).attr('aria-selected', isActive ? 'true' : 'false');
        });

        $('.subscription-card').each(function() {
            var cardPeriod = $(this).data('billingPeriod');
            $(this).toggleClass('is-billing-active', cardPeriod === period);
        });

        $('.pricing-empty-message--monthly').prop('hidden', period !== 'monthly' || $('.subscription-card[data-billing-period="monthly"]').length > 0);
        $('.pricing-empty-message--yearly').prop('hidden', period !== 'yearly' || $('.subscription-card[data-billing-period="yearly"]').length > 0);
    }

    $('.pricing-billing-option').on('click', function() {
        setBillingPeriod($(this).data('billing'));
    });

    $(document).on('click', '.ie-choose-plan', function(e) {
        e.preventDefault();

        var $btn         = $(this);
        var planId       = $btn.data('planId') || $btn.attr('data-plan-id');
        var originalText = $.trim($btn.text());
        var ajaxConfig   = window.IE_AJAX || {};
        var i18n         = window.IE_I18N || {};

        if (!planId) {
            alert(i18n.checkoutFailed || 'Unable to start checkout.');
            return;
        }

        if (!ajaxConfig.stripeEnabled) {
            alert(i18n.stripeNotConfigured || 'Stripe is not configured. Please contact support.');
            return;
        }

        $btn.prop('disabled', true).addClass('is-loading').text(i18n.redirectingCheckout || 'Redirecting...');

        $.post(ajaxConfig.url, {
            action: 'ie_create_stripe_checkout',
            nonce: ajaxConfig.nonce,
            plan_id: planId
        }).done(function(res) {
            if (res.success && res.data && res.data.url) {
                window.location.href = res.data.url;
                return;
            }

            alert((res.data && res.data.message) ? res.data.message : (i18n.checkoutFailed || 'Unable to start checkout.'));
            $btn.prop('disabled', false).removeClass('is-loading').text(originalText);
        }).fail(function() {
            alert(i18n.checkoutFailed || 'Unable to start checkout.');
            $btn.prop('disabled', false).removeClass('is-loading').text(originalText);
        });
    });
})(jQuery);
</script>

<?php get_footer(); ?>
