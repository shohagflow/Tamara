<?php
/**
 * Template Name: Client Profile
 */

if ( ! is_user_logged_in() ) {
    wp_safe_redirect( ie_get_theme_page_url( 'account' ) );
    exit;
}

if ( ie_get_user_type() === 'provider' ) {
    wp_safe_redirect( ie_get_theme_page_url( 'provider-profile' ) );
    exit;
}

$user              = wp_get_current_user();
$avatar            = strtoupper( substr( $user->display_name ?: $user->user_email, 0, 1 ) );
$profile_image_url = ie_get_user_profile_image_url( $user->ID, 'medium' );
$has_profile_image = ie_get_user_profile_image_id( $user->ID ) > 0;

$active_tab = sanitize_key( $_GET['tab'] ?? 'profile' );
$valid_tabs = [ 'profile', 'messages', 'saved', 'settings' ];
if ( ! in_array( $active_tab, $valid_tabs, true ) ) {
    $active_tab = 'profile';
}

$chat_provider_id = 0;
if ( isset( $_GET['provider'] ) ) {
    $chat_provider_id = (int) $_GET['provider'];
} elseif ( ! empty( $_GET['provider_slug'] ) ) {
    $chat_provider_id = ie_resolve_provider_id_by_slug( sanitize_title( wp_unslash( (string) $_GET['provider_slug'] ) ) );
}

if ( $chat_provider_id ) {
    $active_tab = 'messages';
}

$conversations       = ie_get_user_conversations( $user->ID, $chat_provider_id );
$active_conversation = null;

if ( $chat_provider_id ) {
    foreach ( $conversations as $conversation ) {
        if ( (int) ( $conversation['id'] ?? 0 ) === $chat_provider_id ) {
            $active_conversation = $conversation;
            break;
        }
    }
}

if ( ! $active_conversation ) {
    $active_conversation = $conversations[0] ?? null;
}
$active_messages = [];
if ( $active_conversation ) {
    $active_messages = ie_get_chat_thread_messages( $user->ID, (int) $active_conversation['id'] );
}

if ( $active_tab === 'messages' && $active_conversation ) {
    ie_mark_client_chat_read( $user->ID, (int) $active_conversation['id'] );
}

$unread_message_count = ie_get_client_unread_message_count( $user->ID );

get_header();
?>

<div class="account-page-wrap client-profile-page">
    <div class="container">

        <header class="client-profile-header">
            <div class="client-profile-header__text">
                <h1 class="client-profile-title"><?php echo esc_html( sprintf( ie__( 'Welcome back, %s' ), $user->first_name ?: $user->display_name ) ); ?></h1>
                <p class="client-profile-subtitle"><?php echo esc_html( ie__( 'Manage your profile, messages, favorites, and account settings in one place.' ) ); ?></p>
            </div>
        </header>

        <?php ie_render_project_progress_section( $user->ID, 'customer' ); ?>

        <div class="dashboard-layout client-dashboard-layout">
            <aside class="dashboard-sidebar">
                <div class="dashboard-user-info">
                    <div class="dashboard-avatar<?php echo $has_profile_image ? ' has-image' : ''; ?>" id="sidebar-avatar">
                        <?php if ( $has_profile_image ) : ?>
                            <img src="<?php echo esc_url( $profile_image_url ); ?>" alt="<?php echo esc_attr( $user->display_name ); ?>" id="sidebar-avatar-img">
                        <?php else : ?>
                            <span id="sidebar-avatar-letter"><?php echo esc_html( $avatar ); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="dashboard-user-name"><?php echo esc_html( $user->display_name ); ?></div>
                    <div class="dashboard-user-email"><?php echo esc_html( $user->user_email ); ?></div>
                    <span class="client-profile-badge"><?php echo esc_html( ie__( 'Customer' ) ); ?></span>
                </div>

                <nav class="dashboard-nav" aria-label="<?php echo esc_attr( ie__( 'Account navigation' ) ); ?>">
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'profile' ? ' active' : ''; ?>" data-panel="profile">
                        <span class="nav-icon"><i class="fa-regular fa-user" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Edit Profile' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'messages' ? ' active' : ''; ?><?php echo $unread_message_count > 0 ? ' has-unread' : ''; ?>" data-panel="messages">
                        <span class="nav-icon"><i class="fa-regular fa-envelope" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Messages' ) ); ?>
                        <span class="dashboard-nav-badge" id="dashboard-nav-message-count"<?php echo $unread_message_count > 0 ? '' : ' hidden'; ?>><?php echo esc_html( $unread_message_count > 99 ? '99+' : (string) $unread_message_count ); ?></span>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'saved' ? ' active' : ''; ?>" data-panel="saved">
                        <span class="nav-icon"><i class="fa-regular fa-heart" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Favorites List' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'settings' ? ' active' : ''; ?>" data-panel="settings">
                        <span class="nav-icon"><i class="fa-solid fa-gear" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Account Settings' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item logout-btn" id="btn-logout" data-ie-logout data-logout-home="<?php echo esc_url( ie_get_theme_page_url( 'home' ) ); ?>">
                        <span class="nav-icon"><i class="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Log Out' ) ); ?>
                    </button>
                </nav>
            </aside>

            <div class="dashboard-content client-dashboard-content">
                <!-- Edit Profile -->
                <div class="dashboard-panel<?php echo $active_tab === 'profile' ? ' active' : ''; ?>" id="panel-profile">
                    <div class="dashboard-panel-head dashboard-panel-head--with-notify">
                        <div class="dashboard-panel-head__text">
                            <h2 class="panel-title"><?php echo esc_html( ie__( 'Edit Profile' ) ); ?></h2>
                            <p class="panel-desc"><?php echo esc_html( ie__( 'Update your personal information so providers can reach you easily.' ) ); ?></p>
                        </div>
                        <button
                            type="button"
                            class="profile-message-notify<?php echo $unread_message_count > 0 ? ' has-unread' : ''; ?>"
                            id="btn-profile-message-notify"
                            aria-label="<?php echo esc_attr( ie__( 'View messages' ) ); ?>"
                            title="<?php echo esc_attr( ie__( 'View messages' ) ); ?>"
                        >
                            <i class="fa-regular fa-envelope" aria-hidden="true"></i>
                            <span class="profile-message-notify__badge" id="profile-message-notify-count"<?php echo $unread_message_count > 0 ? '' : ' hidden'; ?>><?php echo esc_html( $unread_message_count > 99 ? '99+' : (string) $unread_message_count ); ?></span>
                        </button>
                    </div>

                    <div class="dashboard-panel-body">
                        <div class="profile-form-grid">
                            <div class="form-group full-width">
                                <label class="form-label" for="profile-photo"><?php echo esc_html( ie__( 'Profile Photo' ) ); ?></label>
                                <input type="file" id="profile-photo" class="form-control form-control-file" accept="image/jpeg,image/png,image/webp">
                                <p class="form-hint"><?php echo esc_html( ie__( 'JPG, PNG or WEBP — max 5MB' ) ); ?></p>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="profile-firstname"><?php echo esc_html( ie__( 'First Name' ) ); ?></label>
                                <input type="text" id="profile-firstname" class="form-control" value="<?php echo esc_attr( $user->first_name ); ?>" autocomplete="given-name">
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="profile-lastname"><?php echo esc_html( ie__( 'Last Name' ) ); ?></label>
                                <input type="text" id="profile-lastname" class="form-control" value="<?php echo esc_attr( $user->last_name ); ?>" autocomplete="family-name">
                            </div>
                            <div class="form-group full-width">
                                <label class="form-label" for="profile-email"><?php echo esc_html( ie__( 'Email Address' ) ); ?></label>
                                <input type="email" id="profile-email" class="form-control is-readonly" value="<?php echo esc_attr( $user->user_email ); ?>" disabled>
                                <p class="form-hint"><?php echo esc_html( ie__( 'Email cannot be changed here. Contact support if you need to update it.' ) ); ?></p>
                            </div>
                        </div>

                        <div class="form-error" id="profile-error"></div>
                    </div>

                    <div class="dashboard-panel-actions">
                        <button type="button" class="btn-save-profile" id="btn-save-profile"><?php echo esc_html( ie__( 'Save Changes' ) ); ?></button>
                    </div>
                </div>

                <!-- Messages -->
                <div class="dashboard-panel dashboard-panel--messages<?php echo $active_tab === 'messages' ? ' active' : ''; ?>" id="panel-messages"<?php echo $active_conversation ? ' data-active-provider="' . esc_attr( $active_conversation['id'] ) . '"' : ''; ?>>
                    <div class="client-messages-layout">
                        <aside class="client-messages-sidebar">
                            <div class="client-messages-sidebar__head">
                                <h3 class="client-messages-sidebar__title"><?php echo esc_html( ie__( 'Conversations' ) ); ?></h3>
                                <span class="client-messages-count" id="messages-count"><?php echo esc_html( count( $conversations ) ); ?></span>
                            </div>
                            <div class="client-messages-search">
                                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                                <input type="search" id="messages-search" class="client-messages-search__input" placeholder="<?php echo esc_attr( ie__( 'Search chat...' ) ); ?>" autocomplete="off">
                            </div>
                            <div class="client-messages-list" id="messages-conversation-list">
                                <?php if ( $conversations ) : ?>
                                    <?php foreach ( $conversations as $conversation ) : ?>
                                        <?php
                                        $is_active = $active_conversation
                                            && (string) ( $conversation['id'] ?? '' ) === (string) ( $active_conversation['id'] ?? '' );
                                        ?>
                                        <button
                                            type="button"
                                            class="client-messages-item<?php echo $is_active ? ' is-active' : ''; ?>"
                                            data-provider-id="<?php echo esc_attr( $conversation['id'] ); ?>"
                                        >
                                            <img src="<?php echo esc_url( $conversation['avatar'] ); ?>" alt="<?php echo esc_attr( $conversation['name'] ); ?>" class="client-messages-item__avatar">
                                            <span class="client-messages-item__content">
                                                <span class="client-messages-item__top">
                                                    <strong class="client-messages-item__name"><?php echo esc_html( $conversation['name'] ); ?></strong>
                                                    <span class="client-messages-item__time" data-time="<?php echo esc_attr( $conversation['last_time'] ); ?>"></span>
                                                </span>
                                                <span class="client-messages-item__preview"><?php echo esc_html( $conversation['last_message'] ); ?></span>
                                            </span>
                                        </button>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <div class="client-messages-list__empty">
                                        <p><?php echo esc_html( ie__( 'No conversations yet' ) ); ?></p>
                                        <a href="<?php echo esc_url( ie_get_theme_page_url( 'browse' ) ); ?>"><?php echo esc_html( ie__( 'Browse Providers' ) ); ?></a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </aside>

                        <div class="client-messages-chat" id="messages-chat-area">
                            <div class="client-messages-chat__active" id="messages-chat-active">
                                <header class="client-messages-chat__head">
                                    <button type="button" class="client-messages-chat__back" id="btn-messages-back" aria-label="<?php echo esc_attr( ie__( 'Back to conversations' ) ); ?>">
                                        <i class="fa-solid fa-arrow-left" aria-hidden="true"></i>
                                    </button>
                                    <a href="<?php echo $active_conversation ? esc_url( $active_conversation['permalink'] ) : '#'; ?>" class="client-messages-chat__head-user" id="chat-head-user-link"<?php echo $active_conversation ? '' : ' aria-disabled="true" tabindex="-1"'; ?>>
                                        <?php if ( $active_conversation ) : ?>
                                            <img src="<?php echo esc_url( $active_conversation['avatar'] ); ?>" alt="<?php echo esc_attr( $active_conversation['name'] ); ?>" class="client-messages-chat__head-avatar" id="chat-head-avatar">
                                            <div class="client-messages-chat__head-user-text">
                                                <strong class="client-messages-chat__head-name" id="chat-head-name"><?php echo esc_html( $active_conversation['name'] ); ?></strong>
                                                <span class="client-messages-chat__head-role" id="chat-head-role">
                                                    <?php
                                                    if ( ! empty( $active_conversation['category'] ) ) {
                                                        echo esc_html( ie__( 'Specialist' ) . ' — ' . $active_conversation['category'] );
                                                    }
                                                    ?>
                                                </span>
                                            </div>
                                        <?php endif; ?>
                                    </a>
                                    <div class="client-messages-chat__head-menu" id="chat-head-menu">
                                        <button type="button" class="client-messages-chat__head-link" id="btn-chat-head-menu" aria-label="<?php echo esc_attr( ie__( 'Chat options' ) ); ?>" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa-solid fa-ellipsis-vertical" aria-hidden="true"></i>
                                        </button>
                                        <div class="client-messages-chat__head-dropdown" id="chat-head-dropdown" hidden>
                                            <button type="button" class="client-messages-chat__head-dropdown-item client-messages-chat__head-dropdown-item--danger" id="btn-delete-chat-conversation">
                                                <i class="fa-solid fa-trash" aria-hidden="true"></i>
                                                <span><?php echo esc_html( ie__( 'Delete user' ) ); ?></span>
                                            </button>
                                        </div>
                                    </div>
                                </header>

                                <div class="client-messages-chat__body" id="messages-chat-body">
                                    <?php if ( $active_messages ) : ?>
                                        <?php foreach ( $active_messages as $message ) : ?>
                                            <div class="client-messages-bubble-wrap<?php echo ( $message['sender'] === 'customer' ) ? ' is-mine' : ''; ?>">
                                                <div class="client-messages-bubble"><?php echo ie_render_chat_message_bubble_inner( $message ); ?></div>
                                                <span class="client-messages-bubble__time" data-time="<?php echo esc_attr( $message['time'] ); ?>"></span>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else : ?>
                                        <div class="client-messages-chat__thread-empty">
                                            <p><?php echo esc_html( ie__( 'Send a message to start the conversation.' ) ); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <footer class="client-messages-chat__composer">
                                    <div class="client-messages-chat__attachment-preview" id="chat-attachment-preview" hidden></div>
                                    <button type="button" class="client-messages-chat__attach" id="btn-chat-attach" aria-label="<?php echo esc_attr( ie__( 'Attach file' ) ); ?>">
                                        <i class="fa-solid fa-paperclip" aria-hidden="true"></i>
                                    </button>
                                    <input type="file" id="chat-attachment-input" class="client-messages-chat__file-input" hidden accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.txt,.csv,.rtf">
                                    <div class="client-messages-chat__input-wrap">
                                        <input type="text" id="chat-message-input" class="client-messages-chat__input" placeholder="<?php echo esc_attr( ie__( 'Write a message...' ) ); ?>" autocomplete="off">
                                        <button type="button" class="client-messages-chat__send" id="btn-send-chat" aria-label="<?php echo esc_attr( ie__( 'Send message' ) ); ?>">
                                            <i class="fa-solid fa-paper-plane" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </footer>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Favorites -->
                <div class="dashboard-panel<?php echo $active_tab === 'saved' ? ' active' : ''; ?>" id="panel-saved">
                    <div class="dashboard-panel-head">
                        <h2 class="panel-title"><?php echo esc_html( ie__( 'Favorites List' ) ); ?></h2>
                        <p class="panel-desc"><?php echo esc_html( ie__( 'Providers you have saved for quick access.' ) ); ?></p>
                    </div>

                    <div class="dashboard-panel-body dashboard-panel-body--flush">
                        <div id="saved-providers-grid" class="featured-providers-grid client-favorites-grid"></div>
                        <div class="browse-pagination-wrap client-favorites-pagination-wrap" id="favorites-pagination-wrap" hidden>
                            <p class="browse-pagination-info" id="favorites-pagination-info" aria-live="polite"></p>
                            <nav class="browse-pagination" id="favorites-pagination" aria-label="<?php echo esc_attr( ie__( 'Favorites pagination' ) ); ?>"></nav>
                        </div>
                    </div>
                </div>

                <!-- Account Settings -->
                <div class="dashboard-panel<?php echo $active_tab === 'settings' ? ' active' : ''; ?>" id="panel-settings">
                    <div class="dashboard-panel-head">
                        <h2 class="panel-title"><?php echo esc_html( ie__( 'Account Settings' ) ); ?></h2>
                        <p class="panel-desc"><?php echo esc_html( ie__( 'Keep your account secure by updating your password regularly.' ) ); ?></p>
                    </div>

                    <div class="dashboard-panel-body">
                        <div class="client-settings-section">
                            <h3 class="client-settings-heading"><?php echo esc_html( ie__( 'Change Password' ) ); ?></h3>
                            <div class="form-group">
                                <label class="form-label" for="curr-password"><?php echo esc_html( ie__( 'Current Password' ) ); ?></label>
                                <div class="input-with-toggle">
                                    <input type="password" id="curr-password" class="form-control" autocomplete="current-password">
                                    <button class="password-toggle" type="button" data-target="curr-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                        <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="profile-form-grid">
                                <div class="form-group">
                                    <label class="form-label" for="new-password"><?php echo esc_html( ie__( 'New Password' ) ); ?></label>
                                    <div class="input-with-toggle">
                                        <input type="password" id="new-password" class="form-control" autocomplete="new-password">
                                        <button class="password-toggle" type="button" data-target="new-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="confirm-new-password"><?php echo esc_html( ie__( 'Confirm New Password' ) ); ?></label>
                                    <div class="input-with-toggle">
                                        <input type="password" id="confirm-new-password" class="form-control" autocomplete="new-password">
                                        <button class="password-toggle" type="button" data-target="confirm-new-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="form-error" id="password-error"></div>
                        </div>
                    </div>

                    <div class="dashboard-panel-actions">
                        <button type="button" class="btn-save-profile" id="btn-change-password"><?php echo esc_html( ie__( 'Update Password' ) ); ?></button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php ie_render_offer_modals(); ?>

<?php get_footer(); ?>
