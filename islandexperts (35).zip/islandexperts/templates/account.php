<?php
/**
 * Template Name: Account
 */
get_header();

$reset_user  = ie_get_password_reset_user_from_request();
$is_reset    = $reset_user instanceof WP_User;
$reset_error = is_wp_error( $reset_user ) ? $reset_user->get_error_message() : '';
$reset_key   = $is_reset ? sanitize_text_field( wp_unslash( $_GET['key'] ?? '' ) ) : '';
$reset_login = $is_reset ? sanitize_text_field( wp_unslash( $_GET['login'] ?? '' ) ) : '';

if ( is_user_logged_in() && ! $is_reset && ! $reset_error ) {
    $redirect_to = '';
    if ( ! empty( $_GET['redirect_to'] ) ) {
        $redirect_to = wp_validate_redirect( wp_unslash( (string) $_GET['redirect_to'] ), '' );
    }
    wp_safe_redirect( $redirect_to ?: ie_get_user_profile_url() );
    exit;
}
?>

<div class="account-page-wrap">
    <div class="container">

    <div class="auth-container">
        <div class="auth-card">
            <?php
            $msg = sanitize_text_field( $_GET['msg'] ?? '' );
            if ( $msg === 'provider_only' ) : ?>
                <div class="form-error show auth-alert"><?php echo esc_html( ie__( 'This page is for Service Providers only. Please log in as a Service Provider.' ) ); ?></div>
            <?php elseif ( $msg === 'customer_only' ) : ?>
                <div class="form-error show auth-alert"><?php echo esc_html( ie__( 'This page is for Customers only. Please log in as a Customer.' ) ); ?></div>
            <?php endif; ?>

            <?php if ( $is_reset ) : ?>
                <div class="auth-form-wrap auth-form-intro">
                    <div class="auth-header">
                        <h2 class="auth-form-title"><?php echo esc_html( ie__( 'Create a new password' ) ); ?></h2>
                        <p class="auth-form-sub"><?php echo esc_html( ie__( 'Enter your new password below.' ) ); ?></p>
                    </div>
                </div>

                <div class="auth-form-wrap auth-form-body">
                    <input type="hidden" id="reset-key" value="<?php echo esc_attr( $reset_key ); ?>">
                    <input type="hidden" id="reset-login" value="<?php echo esc_attr( $reset_login ); ?>">

                    <div class="form-group">
                        <label class="form-label" for="reset-password"><?php echo esc_html( ie__( 'New Password' ) ); ?></label>
                        <div class="input-with-toggle">
                            <input type="password" id="reset-password" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Min 6 characters' ) ); ?>" autocomplete="new-password">
                            <button class="password-toggle" type="button" data-target="reset-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                <i class="fa-regular fa-eye" aria-hidden="true"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="reset-confirm-password"><?php echo esc_html( ie__( 'Confirm New Password' ) ); ?></label>
                        <div class="input-with-toggle">
                            <input type="password" id="reset-confirm-password" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Repeat your password' ) ); ?>" autocomplete="new-password">
                            <button class="password-toggle" type="button" data-target="reset-confirm-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                <i class="fa-regular fa-eye" aria-hidden="true"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-error" id="reset-error"></div>
                    <div class="form-success" id="reset-success"></div>

                    <button class="btn-auth" id="btn-reset-password"><?php echo esc_html( ie__( 'Reset Password' ) ); ?></button>
                    <p class="auth-back-wrap">
                        <a class="auth-back-link" href="<?php echo esc_url( ie_get_theme_page_url( 'account' ) ); ?>"><?php echo esc_html( ie__( 'Back to Sign In' ) ); ?></a>
                    </p>
                </div>
            <?php elseif ( $reset_error ) : ?>
                <div class="auth-form-wrap auth-form-intro">
                    <div class="auth-header">
                        <h2 class="auth-form-title"><?php echo esc_html( ie__( 'Reset your password' ) ); ?></h2>
                        <p class="auth-form-sub"><?php echo esc_html( ie__( 'Enter your account email and we will send you a reset link.' ) ); ?></p>
                    </div>
                </div>
                <div class="auth-form-wrap auth-form-body">
                    <div class="form-error show" id="reset-link-error"><?php echo esc_html( $reset_error ); ?></div>
                    <p class="auth-back-wrap">
                        <a class="auth-back-link" href="<?php echo esc_url( ie_get_theme_page_url( 'account' ) ); ?>"><?php echo esc_html( ie__( 'Back to Sign In' ) ); ?></a>
                    </p>
                </div>
            <?php else : ?>
            <div class="auth-form-wrap auth-form-intro" id="auth-intro-default">
                <div id="auth-header-login" class="auth-header">
                    <h2 class="auth-form-title"><?php echo esc_html( ie__( 'Welcome back' ) ); ?></h2>
                    <p class="auth-form-sub"><?php echo esc_html( ie__( 'Sign in to manage your bookings and saved providers.' ) ); ?></p>
                </div>
                <div id="auth-header-register" class="auth-header" style="display:none">
                    <h2 class="auth-form-title"><?php echo esc_html( ie__( 'Create your account' ) ); ?></h2>
                    <p class="auth-form-sub"><?php echo esc_html( ie__( 'Join Island Experts to book trusted local professionals.' ) ); ?></p>
                </div>

                <div class="auth-tabs" id="auth-tabs-default">
                    <button class="auth-tab-btn active" data-tab="login"><?php echo esc_html( ie__( 'Sign In' ) ); ?></button>
                    <button class="auth-tab-btn" data-tab="register"><?php echo esc_html( ie__( 'Create Account' ) ); ?></button>
                </div>
            </div>

            <!-- Sign In Form -->
            <div id="auth-panel-login" class="auth-form-wrap auth-form-body">
                <div class="form-group">
                    <label class="form-label" for="login-email"><?php echo esc_html( ie__( 'Email Address' ) ); ?></label>
                    <input type="email" id="login-email" class="form-control" placeholder="<?php echo esc_attr( ie__( 'you@example.com' ) ); ?>" autocomplete="email">
                </div>
                <div class="form-group">
                    <div class="auth-label-row">
                        <label class="form-label" for="login-password"><?php echo esc_html( ie__( 'Password' ) ); ?></label>
                        <button type="button" class="auth-forgot-link" id="btn-show-forgot-password"><?php echo esc_html( ie__( 'Forgot password?' ) ); ?></button>
                    </div>
                    <div class="input-with-toggle">
                        <input type="password" id="login-password" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Your password' ) ); ?>" autocomplete="current-password">
                        <button class="password-toggle" type="button" data-target="login-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>

                <div class="form-error" id="login-error"></div>
                <div class="form-success" id="login-success"></div>

                <button class="btn-auth" id="btn-login"><?php echo esc_html( ie__( 'Sign In' ) ); ?></button>
            </div>
            <!-- /Sign In Form -->

            <!-- Registration Form -->
            <div id="auth-panel-register" class="auth-form-wrap auth-form-body" style="display:none">
                <div class="auth-form-grid">
                    <div class="form-group">
                        <label class="form-label" for="reg-firstname"><?php echo esc_html( ie__( 'First Name' ) ); ?> <span class="form-required">*</span></label>
                        <input type="text" id="reg-firstname" class="form-control" placeholder="<?php echo esc_attr( ie__( 'John' ) ); ?>" autocomplete="given-name">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="reg-lastname"><?php echo esc_html( ie__( 'Last Name' ) ); ?></label>
                        <input type="text" id="reg-lastname" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Doe' ) ); ?>" autocomplete="family-name">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="reg-email"><?php echo esc_html( ie__( 'Email Address' ) ); ?> <span class="form-required">*</span></label>
                    <input type="email" id="reg-email" class="form-control" placeholder="<?php echo esc_attr( ie__( 'you@example.com' ) ); ?>" autocomplete="email">
                </div>

                <div class="form-group auth-user-type-group">
                    <div class="user-type-options">
                        <label class="user-type-option is-selected" id="type-customer-label">
                            <input type="radio" name="reg-user-type" id="reg-type-customer" value="customer" checked>
                            <span class="user-type-option__text"><?php echo esc_html( ie__( 'Customer' ) ); ?></span>
                        </label>
                        <label class="user-type-option" id="type-provider-label">
                            <input type="radio" name="reg-user-type" id="reg-type-provider" value="provider">
                            <span class="user-type-option__text"><?php echo esc_html( ie__( 'Service Provider' ) ); ?></span>
                        </label>
                    </div>
                </div>

                <div id="reg-provider-fields" class="reg-provider-fields">
                    <div class="reg-provider-fields__title">
                        <i class="fa-solid fa-briefcase" aria-hidden="true"></i>
                        <?php echo esc_html( ie__( 'Business Details' ) ); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="reg-service-name"><?php echo esc_html( ie__( 'Service Name' ) ); ?> <span class="form-required">*</span></label>
                        <input type="text" id="reg-service-name" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. BrightSpark Electrical' ) ); ?>">
                    </div>
                    <div class="auth-form-grid">
                        <div class="form-group">
                            <label class="form-label" for="reg-experience"><?php echo esc_html( ie__( 'Experience (years)' ) ); ?> <span class="form-required">*</span></label>
                            <input type="number" id="reg-experience" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. 5' ) ); ?>" min="0" max="60">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="reg-location"><?php echo esc_html( ie__( 'Location' ) ); ?> <span class="form-required">*</span></label>
                            <input type="text" id="reg-location" class="form-control" placeholder="<?php echo esc_attr( ie__( 'e.g. Castries, Gros Islet' ) ); ?>">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="reg-password"><?php echo esc_html( ie__( 'Password' ) ); ?> <span class="form-required">*</span></label>
                    <div class="input-with-toggle">
                        <input type="password" id="reg-password" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Min 6 characters' ) ); ?>" autocomplete="new-password">
                        <button class="password-toggle" type="button" data-target="reg-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="reg-confirm-password"><?php echo esc_html( ie__( 'Confirm Password' ) ); ?> <span class="form-required">*</span></label>
                    <div class="input-with-toggle">
                        <input type="password" id="reg-confirm-password" class="form-control" placeholder="<?php echo esc_attr( ie__( 'Repeat your password' ) ); ?>" autocomplete="new-password">
                        <button class="password-toggle" type="button" data-target="reg-confirm-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>

                <div class="form-error" id="reg-error"></div>
                <div class="form-success" id="reg-success"></div>

                <button class="btn-auth" id="btn-register"><?php echo esc_html( ie__( 'Create Account' ) ); ?></button>
            </div>
            <!-- /Registration Form -->
            <?php endif; ?>
        </div>
    </div>

    </div>
</div>

<?php get_footer(); ?>
