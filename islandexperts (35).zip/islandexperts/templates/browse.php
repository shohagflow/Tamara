<?php
/**
 * Template Name: Browse
 */
get_header();

$url_category   = sanitize_text_field( $_GET['category'] ?? '' );
$url_search     = sanitize_text_field( $_GET['search'] ?? '' );
$all_categories = get_terms( [ 'taxonomy' => 'ie_category', 'hide_empty' => false, 'orderby' => 'name' ] );
$browse_data    = ie_get_browse_page_data( ie_get_browse_content_post_id() );

wp_add_inline_script(
    'island-experts-main',
    'window.IE_BROWSE_DEFAULTS = ' . wp_json_encode( [
        'category'   => $url_category,
        'search'     => $url_search,
        'browse_url' => ie_get_theme_page_url( 'browse' ),
    ] ) . ';',
    'before'
);
?>

<div class="browse-page-wrap">
    <div class="container">
        <?php ie_render_browse_hero( $browse_data['header'] ); ?>

        <div class="browse-toolbar">
            <div class="browse-search-bar">
                <svg class="search-icon" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="text" id="browse-search-input"
                       placeholder="<?php echo esc_attr( ie__( 'Search by name or service...' ) ); ?>"
                       value="<?php echo esc_attr( $url_search ); ?>">
            </div>

            <div class="browse-toolbar-filters">
                <select class="browse-filter-select" id="browse-category-filter" aria-label="<?php esc_attr_e( 'Category', IE_TEXT_DOMAIN ); ?>">
                    <option value="all"><?php echo esc_html( ie__( 'All Categories' ) ); ?></option>
                    <?php if ( ! empty( $all_categories ) && ! is_wp_error( $all_categories ) ) : ?>
                        <?php foreach ( $all_categories as $term ) : ?>
                            <option value="<?php echo esc_attr( $term->slug ); ?>" <?php selected( $url_category, $term->slug ); ?>>
                                <?php echo esc_html( $term->name ); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>

                <select class="browse-filter-select" id="browse-price-filter" aria-label="<?php esc_attr_e( 'Starting price', IE_TEXT_DOMAIN ); ?>">
                    <?php foreach ( ie_get_browse_price_ranges() as $value => $label ) : ?>
                        <option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>

                <select class="browse-filter-select" id="browse-rating-filter" aria-label="<?php esc_attr_e( 'Minimum rating', IE_TEXT_DOMAIN ); ?>">
                    <option value=""><?php echo esc_html( ie__( 'Any Rating' ) ); ?></option>
                    <option value="4"><?php echo esc_html( ie__( '4+ Stars' ) ); ?></option>
                    <option value="4.5"><?php echo esc_html( ie__( '4.5+ Stars' ) ); ?></option>
                    <option value="5"><?php echo esc_html( ie__( '5 Stars' ) ); ?></option>
                </select>

                <button type="button" id="reset-all-filters" class="browse-reset-btn" style="display:none;">
                    <?php echo esc_html( ie__( 'Reset' ) ); ?>
                </button>
            </div>
        </div>

        <div class="featured-providers-grid browse-providers-grid" id="providers-grid">
            <div class="browse-loading">
                <div class="spinner"></div>
                <p><?php echo esc_html( ie__( 'Loading providers...' ) ); ?></p>
            </div>
        </div>

        <div class="browse-pagination-wrap" id="browse-pagination-wrap" hidden>
            <p class="browse-pagination-info" id="browse-pagination-info" aria-live="polite"></p>
            <nav class="browse-pagination" id="browse-pagination" aria-label="<?php echo esc_attr( ie__( 'Providers pagination' ) ); ?>"></nav>
        </div>
    </div>
</div>

<?php get_footer(); ?>
