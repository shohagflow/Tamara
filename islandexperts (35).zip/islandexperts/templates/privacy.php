<?php
/**
 * Template Name: Privacy Policy
 */
get_header();

$privacy_data = ie_get_privacy_page_data();
$banner       = $privacy_data['banner'];
$notice       = $privacy_data['notice'];
$sections     = $privacy_data['sections'];
?>

<div class="ie-static-page ie-privacy-page">
    <div class="ie-page-hero">
        <div class="ie-page-hero__icon" aria-hidden="true">
            <i class="<?php echo esc_attr( $banner['icon'] ); ?>"></i>
        </div>
        <h1 class="ie-page-hero__title"><?php echo esc_html( $banner['title'] ); ?></h1>
        <?php if ( ! empty( $banner['subtitle'] ) ) : ?>
            <p class="ie-page-hero__subtitle"><?php echo esc_html( $banner['subtitle'] ); ?></p>
        <?php endif; ?>
        <?php if ( ! empty( $banner['last_updated'] ) ) : ?>
            <p class="ie-page-hero__meta"><?php echo esc_html( $banner['last_updated'] ); ?></p>
        <?php endif; ?>
    </div>

    <div class="container ie-page-content">
        <?php ie_render_terms_notice( $notice ); ?>
        <?php ie_render_privacy_sections( $sections ); ?>
    </div>
</div>

<?php get_footer(); ?>
