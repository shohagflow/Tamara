<?php
/**
 * Template Name: Provider Profile
 */

if ( ! is_user_logged_in() ) {
    wp_safe_redirect( ie_get_theme_page_url( 'account' ) );
    exit;
}

if ( ie_get_user_type() !== 'provider' ) {
    wp_safe_redirect( ie_get_theme_page_url( 'client-profile' ) );
    exit;
}

$user              = wp_get_current_user();
$avatar            = strtoupper( substr( $user->display_name ?: $user->user_email, 0, 1 ) );
$profile_image_url = ie_get_user_profile_image_url( $user->ID, 'medium' );
$has_profile_image = ie_get_user_profile_image_id( $user->ID ) > 0;
$provider_post     = ie_get_provider_post_by_user( $user->ID );
$provider_id       = $provider_post ? $provider_post->ID : 0;
$provider_data     = $provider_id ? ie_get_provider_data( $provider_id ) : null;
$subscription      = ie_get_user_subscription_management( $user->ID );
$messaging_quota   = ie_get_provider_messaging_quota( $user->ID );
$can_social_links  = ie_provider_can_use_feature( $user->ID, 'social_links' );
$can_work_gallery  = ie_provider_can_use_feature( $user->ID, 'work_gallery' );
$can_chat_attach   = ie_provider_can_use_feature( $user->ID, 'chat_attachments' );
$gallery_max       = ie_get_provider_work_gallery_limit( $user->ID );
$services_max      = ie_get_provider_services_limit( $user->ID );
$price_page_url    = ie_get_theme_page_url( 'price' );
$social_presets    = ie_get_theme_social_icon_presets();
$socials           = $provider_id ? ie_get_provider_socials( $provider_id ) : [];
if ( ! $socials ) {
    $socials = [ [ 'icon' => '', 'url' => '' ] ];
}
$work_gallery = $provider_id ? ie_get_provider_work_gallery( $provider_id, 'medium' ) : [];

$active_tab = sanitize_key( $_GET['tab'] ?? 'profile' );
$valid_tabs = [ 'profile', 'services', 'messages', 'subscription', 'settings' ];
if ( ! in_array( $active_tab, $valid_tabs, true ) ) {
    $active_tab = 'profile';
}

$conversations         = $provider_id ? ie_get_provider_inbox_conversations( $provider_id ) : [];
$active_conversation   = $conversations[0] ?? null;
$active_messages = [];
if ( $active_conversation && $provider_id ) {
    $active_messages = ie_get_provider_customer_thread_messages( $provider_id, (int) $active_conversation['id'] );
}

if ( $active_tab === 'messages' && $active_conversation && $provider_id ) {
    ie_mark_provider_inbox_read( $provider_id, (int) $active_conversation['id'] );
}

$unread_message_count = $provider_id ? ie_get_provider_unread_message_count( $provider_id ) : 0;

$services_raw = $provider_id ? get_post_meta( $provider_id, '_ie_services', true ) : '';
$services     = $services_raw ? json_decode( $services_raw, true ) : [];
if ( ! is_array( $services ) ) {
    $services = [];
}

$provider_cat_terms          = $provider_id ? get_the_terms( $provider_id, 'ie_category' ) : false;
$provider_category_slug      = ( $provider_cat_terms && ! is_wp_error( $provider_cat_terms ) ) ? $provider_cat_terms[0]->slug : '';
$service_placeholder_image   = ie_get_provider_service_placeholder_image( $provider_id );

$categories = get_terms( [
    'taxonomy'   => 'ie_category',
    'hide_empty' => false,
] );
if ( is_wp_error( $categories ) ) {
    $categories = [];
}

get_header();
?>

<div class="account-page-wrap client-profile-page provider-profile-page">
    <div class="container">

        <header class="client-profile-header">
            <div class="client-profile-header__text">
                <h1 class="client-profile-title"><?php echo esc_html( sprintf( ie__( 'Welcome back, %s' ), $user->first_name ?: $user->display_name ) ); ?></h1>
                <p class="client-profile-subtitle"><?php echo esc_html( ie__( 'Manage your business profile, services, messages, and subscription from one dashboard.' ) ); ?></p>
            </div>
        </header>

        <?php ie_render_project_progress_section( $user->ID, 'provider' ); ?>

        <div class="dashboard-layout client-dashboard-layout">
            <aside class="dashboard-sidebar">
                <div class="dashboard-user-info">
                    <div class="dashboard-avatar<?php echo $has_profile_image ? ' has-image' : ''; ?>" id="sidebar-avatar">
                        <?php if ( $has_profile_image ) : ?>
                            <img src="<?php echo esc_url( $profile_image_url ); ?>" alt="<?php echo esc_attr( $user->display_name ); ?>" id="sidebar-avatar-img">
                        <?php else : ?>
                            <span id="sidebar-avatar-letter"><?php echo esc_html( $avatar ); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="dashboard-user-name"><?php echo esc_html( $user->display_name ); ?></div>
                    <div class="dashboard-user-email"><?php echo esc_html( $user->user_email ); ?></div>
                    <span class="client-profile-badge provider-profile-badge"><?php echo esc_html( ie__( 'Service Provider' ) ); ?></span>
                </div>

                <nav class="dashboard-nav" aria-label="<?php echo esc_attr( ie__( 'Provider navigation' ) ); ?>">
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'profile' ? ' active' : ''; ?>" data-panel="profile">
                        <span class="nav-icon"><i class="fa-regular fa-user" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Edit Profile' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'services' ? ' active' : ''; ?>" data-panel="services">
                        <span class="nav-icon"><i class="fa-solid fa-briefcase" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Service & Complete Job' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'messages' ? ' active' : ''; ?><?php echo $unread_message_count > 0 ? ' has-unread' : ''; ?>" data-panel="messages">
                        <span class="nav-icon"><i class="fa-regular fa-envelope" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Messages' ) ); ?>
                        <span class="dashboard-nav-badge" id="dashboard-nav-message-count"<?php echo $unread_message_count > 0 ? '' : ' hidden'; ?>><?php echo esc_html( $unread_message_count > 99 ? '99+' : (string) $unread_message_count ); ?></span>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'subscription' ? ' active' : ''; ?>" data-panel="subscription">
                        <span class="nav-icon"><i class="fa-solid fa-credit-card" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Subscription Management' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item<?php echo $active_tab === 'settings' ? ' active' : ''; ?>" data-panel="settings">
                        <span class="nav-icon"><i class="fa-solid fa-gear" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Account Settings' ) ); ?>
                    </button>
                    <button type="button" class="dashboard-nav-item logout-btn" id="btn-logout" data-ie-logout data-logout-home="<?php echo esc_url( ie_get_theme_page_url( 'home' ) ); ?>">
                        <span class="nav-icon"><i class="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i></span>
                        <?php echo esc_html( ie__( 'Log Out' ) ); ?>
                    </button>
                </nav>
            </aside>

            <div class="dashboard-content client-dashboard-content">
                <!-- Edit Profile -->
                <div class="dashboard-panel<?php echo $active_tab === 'profile' ? ' active' : ''; ?>" id="panel-profile">
                    <div class="dashboard-panel-head dashboard-panel-head--with-notify">
                        <div class="dashboard-panel-head__text">
                            <h2 class="panel-title"><?php echo esc_html( ie__( 'Edit Profile' ) ); ?></h2>
                            <p class="panel-desc"><?php echo esc_html( ie__( 'Keep your personal and business profile information up to date.' ) ); ?></p>
                        </div>
                        <button
                            type="button"
                            class="profile-message-notify<?php echo $unread_message_count > 0 ? ' has-unread' : ''; ?>"
                            id="btn-profile-message-notify"
                            aria-label="<?php echo esc_attr( ie__( 'View messages' ) ); ?>"
                            title="<?php echo esc_attr( ie__( 'View messages' ) ); ?>"
                        >
                            <i class="fa-regular fa-envelope" aria-hidden="true"></i>
                            <span class="profile-message-notify__badge" id="profile-message-notify-count"<?php echo $unread_message_count > 0 ? '' : ' hidden'; ?>><?php echo esc_html( $unread_message_count > 99 ? '99+' : (string) $unread_message_count ); ?></span>
                        </button>
                    </div>

                    <?php if ( ! $provider_id ) : ?>
                        <div class="dashboard-panel-body">
                            <div class="provider-profile-notice">
                                <p><?php echo esc_html( ie__( 'Your business listing has not been created yet. Please contact support or complete provider registration.' ) ); ?></p>
                            </div>
                        </div>
                    <?php else : ?>
                        <?php ie_render_provider_profile_progress( $provider_id, $user->ID ); ?>
                        <div class="dashboard-panel-body">
                            <input type="hidden" id="provider-id" value="<?php echo esc_attr( $provider_id ); ?>">
                            <div class="profile-form-grid">
                                <div class="form-group full-width">
                                    <label class="form-label" for="profile-photo"><?php echo esc_html( ie__( 'Profile Photo' ) ); ?></label>
                                    <input type="file" id="profile-photo" class="form-control form-control-file" accept="image/jpeg,image/png,image/webp">
                                    <p class="form-hint"><?php echo esc_html( ie__( 'JPG, PNG or WEBP — max 5MB' ) ); ?></p>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="profile-firstname"><?php echo esc_html( ie__( 'First Name' ) ); ?></label>
                                    <input type="text" id="profile-firstname" class="form-control" value="<?php echo esc_attr( $user->first_name ); ?>" autocomplete="given-name">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="profile-lastname"><?php echo esc_html( ie__( 'Last Name' ) ); ?></label>
                                    <input type="text" id="profile-lastname" class="form-control" value="<?php echo esc_attr( $user->last_name ); ?>" autocomplete="family-name">
                                </div>
                                <div class="form-group full-width">
                                    <label class="form-label" for="profile-email"><?php echo esc_html( ie__( 'Email Address' ) ); ?></label>
                                    <input type="email" id="profile-email" class="form-control is-readonly" value="<?php echo esc_attr( $user->user_email ); ?>" disabled>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="biz-name"><?php echo esc_html( ie__( 'Service Name' ) ); ?></label>
                                    <input type="text" id="biz-name" class="form-control" value="<?php echo esc_attr( $provider_data['title'] ?? '' ); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="biz-exp"><?php echo esc_html( ie__( 'Years of Experience' ) ); ?></label>
                                    <input type="number" id="biz-exp" class="form-control" min="0" max="60" value="<?php echo esc_attr( get_post_meta( $provider_id, '_ie_experience_years', true ) ); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="biz-phone"><?php echo esc_html( ie__( 'Phone' ) ); ?></label>
                                    <input type="text" id="biz-phone" class="form-control" value="<?php echo esc_attr( get_post_meta( $provider_id, '_ie_phone', true ) ); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="biz-area"><?php echo esc_html( ie__( 'Service Area' ) ); ?></label>
                                    <input type="text" id="biz-area" class="form-control" value="<?php echo esc_attr( get_post_meta( $provider_id, '_ie_service_area', true ) ); ?>">
                                </div>
                                <div class="form-group full-width">
                                    <label class="form-label" for="biz-about"><?php echo esc_html( ie__( 'About Your Business' ) ); ?></label>
                                    <textarea id="biz-about" class="form-control" rows="4"><?php echo esc_textarea( get_post_meta( $provider_id, '_ie_about', true ) ?: ( $provider_post->post_content ?? '' ) ); ?></textarea>
                                </div>
                                <div class="form-group full-width provider-social-section<?php echo $can_social_links ? '' : ' is-plan-locked'; ?>">
                                    <div class="provider-social-head">
                                        <label class="form-label"><?php echo esc_html( ie__( 'Social Media Links' ) ); ?></label>
                                        <button type="button" class="btn-provider-add-service" id="btn-add-social-link"<?php echo $can_social_links ? '' : ' disabled'; ?>>
                                            <i class="fa-solid fa-plus" aria-hidden="true"></i>
                                            <?php echo esc_html( ie__( 'Add Social Link' ) ); ?>
                                        </button>
                                    </div>
                                    <?php if ( ! $can_social_links ) : ?>
                                        <p class="provider-plan-lock-note">
                                            <?php echo esc_html( ie__( 'Social links are not included in your current plan.' ) ); ?>
                                            <a href="<?php echo esc_url( $price_page_url ); ?>"><?php echo esc_html( ie__( 'Upgrade plan' ) ); ?></a>
                                        </p>
                                    <?php endif; ?>
                                    <div class="provider-social-list" id="provider-social-list">
                                        <?php foreach ( $socials as $social ) : ?>
                                            <?php ie_render_provider_social_row( $social, $social_presets ); ?>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="form-group full-width provider-work-gallery-section<?php echo $can_work_gallery ? '' : ' is-plan-locked'; ?>">
                                    <div class="provider-social-head">
                                        <label class="form-label"><?php echo esc_html( ie__( 'Work Preview Images' ) ); ?></label>
                                        <button type="button" class="btn-provider-add-service" id="btn-add-work-images"<?php echo $can_work_gallery ? '' : ' disabled'; ?>>
                                            <i class="fa-solid fa-plus" aria-hidden="true"></i>
                                            <?php echo esc_html( ie__( 'Add Images' ) ); ?>
                                        </button>
                                    </div>
                                    <?php if ( ! $can_work_gallery ) : ?>
                                        <p class="provider-plan-lock-note">
                                            <?php echo esc_html( ie__( 'Work gallery uploads are not included in your current plan.' ) ); ?>
                                            <a href="<?php echo esc_url( $price_page_url ); ?>"><?php echo esc_html( ie__( 'Upgrade plan' ) ); ?></a>
                                        </p>
                                    <?php endif; ?>
                                    <input type="file" id="work-gallery-input" class="provider-work-gallery-input" accept="image/jpeg,image/png,image/webp" multiple hidden>
                                    <div class="provider-work-gallery" id="provider-work-gallery" data-max-images="<?php echo esc_attr( (string) ( $gallery_max ?: ie_get_provider_work_gallery_max() ) ); ?>">
                                        <?php foreach ( $work_gallery as $image ) : ?>
                                            <div class="provider-work-gallery-item" data-id="<?php echo esc_attr( (string) $image['id'] ); ?>">
                                                <img src="<?php echo esc_url( $image['thumb'] ); ?>" alt="">
                                                <button type="button" class="provider-work-gallery-remove" aria-label="<?php echo esc_attr( ie__( 'Remove image' ) ); ?>">
                                                    <i class="fa-solid fa-trash-can" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <p class="form-hint">
                                        <?php if ( $can_work_gallery ) : ?>
                                            <?php echo esc_html( sprintf( ie__( 'Optional. Upload up to %d images for the Previous Work section on your public profile page.' ), $gallery_max ) ); ?>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>

                            <div class="form-error" id="profile-error"></div>
                        </div>

                        <div class="dashboard-panel-actions">
                            <button type="button" class="btn-save-profile" id="btn-save-provider-profile"><?php echo esc_html( ie__( 'Save Changes' ) ); ?></button>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Service & Complete Job -->
                <div class="dashboard-panel<?php echo $active_tab === 'services' ? ' active' : ''; ?>" id="panel-services">
                    <div class="dashboard-panel-head">
                        <h2 class="panel-title"><?php echo esc_html( ie__( 'Service & Complete Job' ) ); ?></h2>
                        <p class="panel-desc"><?php echo esc_html( ie__( 'Manage your services and view completed projects with client reviews.' ) ); ?></p>
                    </div>

                    <div class="dashboard-panel-tabs" role="tablist" aria-label="<?php echo esc_attr( ie__( 'Services sections' ) ); ?>">
                        <button type="button" class="dashboard-panel-tab-btn active" role="tab" aria-selected="true" aria-controls="provider-services-tab-manage" id="provider-services-tab-btn-manage" data-services-tab="manage">
                            <?php echo esc_html( ie__( 'Services' ) ); ?>
                        </button>
                        <button type="button" class="dashboard-panel-tab-btn" role="tab" aria-selected="false" aria-controls="provider-services-tab-completed" id="provider-services-tab-btn-completed" data-services-tab="completed">
                            <?php echo esc_html( ie__( 'Completed Jobs' ) ); ?>
                        </button>
                    </div>

                    <?php if ( ! $provider_id ) : ?>
                        <div class="dashboard-panel-body">
                            <div class="provider-profile-notice">
                                <p><?php echo esc_html( ie__( 'Create your business profile first to manage services.' ) ); ?></p>
                            </div>
                        </div>
                    <?php else : ?>
                        <div class="dashboard-panel-tab-panel is-active" id="provider-services-tab-manage" role="tabpanel" aria-labelledby="provider-services-tab-btn-manage">
                            <div class="dashboard-panel-body">
                                <?php if ( $services_max > 0 ) : ?>
                                    <p class="provider-plan-limit-note" id="provider-services-limit-note" data-max="<?php echo esc_attr( (string) $services_max ); ?>">
                                        <?php echo esc_html( sprintf( ie__( 'Your plan includes up to %d services.' ), $services_max ) ); ?>
                                    </p>
                                <?php endif; ?>

                                <div class="provider-services-list" id="provider-services-list" data-placeholder-image="<?php echo esc_url( $service_placeholder_image ); ?>" data-max-services="<?php echo esc_attr( $services_max > 0 ? (string) $services_max : '0' ); ?>">
                                    <?php if ( $services ) : ?>
                                        <?php foreach ( $services as $service ) : ?>
                                            <?php ie_render_provider_service_row( $service, $service_placeholder_image ); ?>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>

                                <button type="button" class="btn-provider-add-service" id="btn-add-service">
                                    <i class="fa-solid fa-plus" aria-hidden="true"></i>
                                    <?php echo esc_html( ie__( 'Add Service' ) ); ?>
                                </button>

                                <div class="form-error" id="services-error"></div>
                            </div>

                            <div class="dashboard-panel-actions">
                                <button type="button" class="btn-save-profile" id="btn-save-services"><?php echo esc_html( ie__( 'Save Services' ) ); ?></button>
                            </div>
                        </div>

                        <div class="dashboard-panel-tab-panel" id="provider-services-tab-completed" role="tabpanel" aria-labelledby="provider-services-tab-btn-completed" hidden>
                            <?php ie_render_provider_completed_jobs_list( $user->ID ); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Messages -->
                <div class="dashboard-panel dashboard-panel--messages<?php echo $active_tab === 'messages' ? ' active' : ''; ?>" id="panel-messages"<?php echo $active_conversation ? ' data-active-customer="' . esc_attr( $active_conversation['id'] ) . '"' : ''; ?>>
                    <?php if ( ! $messaging_quota['can_send'] && ! empty( $subscription['on_free_trial'] ) ) : ?>
                        <div class="provider-alert provider-alert--warning provider-sub-alert provider-messages-alert">
                            <span class="provider-alert__icon"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></span>
                            <div>
                                <div class="provider-alert__title"><?php echo esc_html( ie__( 'Messaging limit reached' ) ); ?></div>
                                <div class="provider-alert__text">
                                    <?php echo esc_html( ie__( 'You have used all messages included in your free trial for this period.' ) ); ?>
                                    <a href="<?php echo esc_url( $price_page_url ); ?>"><?php echo esc_html( ie__( 'Subscribe to continue' ) ); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php elseif ( ! $messaging_quota['can_send'] && ! empty( $subscription['trial_expired'] ) ) : ?>
                        <div class="provider-alert provider-alert--warning provider-sub-alert provider-messages-alert">
                            <span class="provider-alert__icon"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></span>
                            <div>
                                <div class="provider-alert__title"><?php echo esc_html( ie__( 'Your free trial has finished' ) ); ?></div>
                                <div class="provider-alert__text">
                                    <?php echo esc_html( ie__( 'Messaging is locked until you subscribe to a plan.' ) ); ?>
                                    <a href="<?php echo esc_url( $price_page_url ); ?>"><?php echo esc_html( ie__( 'View Plans' ) ); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php elseif ( ! $messaging_quota['can_send'] && ! $subscription['has_benefits'] ) : ?>
                        <div class="provider-alert provider-alert--warning provider-sub-alert provider-messages-alert">
                            <span class="provider-alert__icon"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></span>
                            <div>
                                <div class="provider-alert__title"><?php echo esc_html( ie__( 'Messaging unavailable' ) ); ?></div>
                                <div class="provider-alert__text">
                                    <?php echo esc_html( ie__( 'Subscribe to a plan to message customers.' ) ); ?>
                                    <a href="<?php echo esc_url( $price_page_url ); ?>"><?php echo esc_html( ie__( 'View Plans' ) ); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php elseif ( ! $messaging_quota['can_send'] && $subscription['has_plan'] ) : ?>
                        <div class="provider-alert provider-alert--warning provider-sub-alert provider-messages-alert">
                            <span class="provider-alert__icon"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></span>
                            <div>
                                <div class="provider-alert__title"><?php echo esc_html( ie__( 'Messaging limit reached' ) ); ?></div>
                                <div class="provider-alert__text">
                                    <?php echo esc_html( ie__( 'You have used all messages included in your plan for this billing period.' ) ); ?>
                                    <a href="<?php echo esc_url( $price_page_url ); ?>"><?php echo esc_html( ie__( 'Upgrade plan' ) ); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php elseif ( ! $messaging_quota['unlimited'] && $messaging_quota['can_send'] && $messaging_quota['limit'] > 0 && empty( $subscription['on_free_trial'] ) ) : ?>
                        <p class="provider-plan-limit-note provider-messages-alert" id="provider-messaging-quota-note">
                            <?php echo esc_html( sprintf( ie__( 'Messaging: %1$d of %2$d messages used this billing period.' ), $messaging_quota['used'], $messaging_quota['limit'] ) ); ?>
                        </p>
                    <?php endif; ?>

                    <div class="client-messages-layout">
                        <aside class="client-messages-sidebar">
                            <div class="client-messages-sidebar__head">
                                <h3 class="client-messages-sidebar__title"><?php echo esc_html( ie__( 'Customer Inquiries' ) ); ?></h3>
                                <span class="client-messages-count" id="provider-messages-count"><?php echo esc_html( count( $conversations ) ); ?></span>
                            </div>
                            <div class="client-messages-search">
                                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                                <input type="search" id="provider-messages-search" class="client-messages-search__input" placeholder="<?php echo esc_attr( ie__( 'Search chat...' ) ); ?>" autocomplete="off">
                            </div>
                            <div class="client-messages-list" id="provider-messages-conversation-list">
                                <?php if ( $conversations ) : ?>
                                    <?php foreach ( $conversations as $index => $conversation ) : ?>
                                        <button
                                            type="button"
                                            class="client-messages-item<?php echo ( $index === 0 ) ? ' is-active' : ''; ?>"
                                            data-customer-id="<?php echo esc_attr( $conversation['id'] ); ?>"
                                        >
                                            <img src="<?php echo esc_url( $conversation['avatar'] ); ?>" alt="<?php echo esc_attr( $conversation['name'] ); ?>" class="client-messages-item__avatar">
                                            <span class="client-messages-item__content">
                                                <span class="client-messages-item__top">
                                                    <strong class="client-messages-item__name"><?php echo esc_html( $conversation['name'] ); ?></strong>
                                                    <span class="client-messages-item__time" data-time="<?php echo esc_attr( $conversation['last_time'] ); ?>"></span>
                                                </span>
                                                <span class="client-messages-item__preview"><?php echo esc_html( $conversation['last_message'] ); ?></span>
                                            </span>
                                        </button>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <div class="client-messages-list__empty">
                                        <p><?php echo esc_html( ie__( 'No customer messages yet' ) ); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </aside>

                        <div class="client-messages-chat" id="provider-messages-chat-area">
                            <div class="client-messages-chat__active" id="provider-messages-chat-active">
                                <header class="client-messages-chat__head">
                                    <button type="button" class="client-messages-chat__back" id="btn-provider-messages-back" aria-label="<?php echo esc_attr( ie__( 'Back to conversations' ) ); ?>">
                                        <i class="fa-solid fa-arrow-left" aria-hidden="true"></i>
                                    </button>
                                    <div class="client-messages-chat__head-user">
                                        <?php if ( $active_conversation ) : ?>
                                            <img src="<?php echo esc_url( $active_conversation['avatar'] ); ?>" alt="<?php echo esc_attr( $active_conversation['name'] ); ?>" class="client-messages-chat__head-avatar" id="provider-chat-head-avatar">
                                            <div class="client-messages-chat__head-user-text">
                                                <strong class="client-messages-chat__head-name" id="provider-chat-head-name"><?php echo esc_html( $active_conversation['name'] ); ?></strong>
                                                <span class="client-messages-chat__head-role" id="provider-chat-head-role"><?php echo esc_html( ie__( 'Customer' ) ); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="client-messages-chat__head-menu" id="provider-chat-head-menu">
                                        <button type="button" class="client-messages-chat__head-link" id="btn-provider-chat-head-menu" aria-label="<?php echo esc_attr( ie__( 'Chat options' ) ); ?>" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa-solid fa-ellipsis-vertical" aria-hidden="true"></i>
                                        </button>
                                        <div class="client-messages-chat__head-dropdown" id="provider-chat-head-dropdown" hidden>
                                            <button type="button" class="client-messages-chat__head-dropdown-item client-messages-chat__head-dropdown-item--danger" id="btn-delete-provider-chat-conversation">
                                                <i class="fa-solid fa-trash" aria-hidden="true"></i>
                                                <span><?php echo esc_html( ie__( 'Delete user' ) ); ?></span>
                                            </button>
                                        </div>
                                    </div>
                                </header>

                                <div class="client-messages-chat__body" id="provider-messages-chat-body">
                                    <?php if ( $active_messages ) : ?>
                                        <?php foreach ( $active_messages as $message ) : ?>
                                            <div class="client-messages-bubble-wrap<?php echo ( $message['sender'] === 'provider' ) ? ' is-mine' : ''; ?>">
                                                <div class="client-messages-bubble"><?php echo ie_render_chat_message_bubble_inner( $message ); ?></div>
                                                <span class="client-messages-bubble__time" data-time="<?php echo esc_attr( $message['time'] ); ?>"></span>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else : ?>
                                        <div class="client-messages-chat__thread-empty">
                                            <p><?php echo esc_html( ie__( 'Reply to customer inquiries here.' ) ); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <footer class="client-messages-chat__composer">
                                    <div class="client-messages-chat__attachment-preview" id="provider-chat-attachment-preview" hidden></div>
                                    <button type="button" class="client-messages-chat__offer" id="btn-provider-send-offer" aria-label="<?php echo esc_attr( ie__( 'Send Offer' ) ); ?>" title="<?php echo esc_attr( ie__( 'Send Offer' ) ); ?>">
                                        <?php echo esc_html( ie__( 'Offer' ) ); ?>
                                    </button>
                                    <button type="button" class="client-messages-chat__attach" id="btn-provider-chat-attach" aria-label="<?php echo esc_attr( ie__( 'Attach file' ) ); ?>"<?php echo $can_chat_attach ? '' : ' disabled'; ?>>
                                        <i class="fa-solid fa-paperclip" aria-hidden="true"></i>
                                    </button>
                                    <input type="file" id="provider-chat-attachment-input" class="client-messages-chat__file-input" hidden accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.txt,.csv,.rtf">
                                    <div class="client-messages-chat__input-wrap">
                                        <input type="text" id="provider-chat-message-input" class="client-messages-chat__input" placeholder="<?php echo esc_attr( ie__( 'Write a message...' ) ); ?>" autocomplete="off">
                                        <button type="button" class="client-messages-chat__send" id="btn-provider-send-chat" aria-label="<?php echo esc_attr( ie__( 'Send message' ) ); ?>">
                                            <i class="fa-solid fa-paper-plane" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </footer>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Subscription -->
                <div class="dashboard-panel<?php echo $active_tab === 'subscription' ? ' active' : ''; ?>" id="panel-subscription">
                    <div class="dashboard-panel-head">
                        <h2 class="panel-title"><?php echo esc_html( ie__( 'Subscription Management' ) ); ?></h2>
                        <p class="panel-desc"><?php echo esc_html( ie__( 'View your plan details, billing history, and download invoices.' ) ); ?></p>
                    </div>

                    <div class="dashboard-panel-body">
                        <?php if ( $subscription['has_plan'] ) : ?>
                            <div class="provider-sub-overview<?php echo $subscription['is_active'] ? ' is-active' : ''; ?><?php echo $subscription['is_expired'] ? ' is-expired' : ''; ?>">
                                <div class="provider-sub-overview__head">
                                    <div class="provider-sub-overview__title-wrap">
                                        <span class="provider-sub-overview__eyebrow"><?php echo esc_html( ie__( 'Current Plan' ) ); ?></span>
                                        <h3 class="provider-sub-overview__plan"><?php echo esc_html( $subscription['plan_label'] ); ?></h3>
                                        <?php if ( $subscription['price_label'] !== '' ) : ?>
                                            <p class="provider-sub-overview__price">
                                                <?php echo esc_html( $subscription['price_label'] ); ?>
                                                <span>/ <?php echo esc_html( strtolower( $subscription['billing_label'] ) ); ?></span>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                    <?php ie_render_provider_subscription_status_badge( $subscription ); ?>
                                </div>

                                <div class="provider-sub-details-grid">
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Billing Cycle' ) ); ?></span>
                                        <strong class="provider-sub-detail__value"><?php echo esc_html( $subscription['billing_label'] ); ?></strong>
                                    </div>
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Active Date' ) ); ?></span>
                                        <strong class="provider-sub-detail__value"><?php echo esc_html( $subscription['started_label'] ); ?></strong>
                                    </div>
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Expiry Date' ) ); ?></span>
                                        <strong class="provider-sub-detail__value"><?php echo esc_html( $subscription['expires_label'] ); ?></strong>
                                    </div>
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Subscription ID' ) ); ?></span>
                                        <strong class="provider-sub-detail__value provider-sub-detail__value--mono">
                                            <?php echo esc_html( $subscription['stripe_subscription_id'] ?: '—' ); ?>
                                        </strong>
                                    </div>
                                </div>

                                <?php if ( $subscription['can_remove'] || ! $subscription['is_active'] ) : ?>
                                    <div class="provider-sub-overview__actions">
                                        <?php if ( $subscription['can_remove'] ) : ?>
                                            <button type="button" class="btn-save-profile btn-save-profile--danger" id="btn-remove-expired-subscription">
                                                <?php echo esc_html( ie__( 'Remove Expired Subscription' ) ); ?>
                                            </button>
                                            <a href="<?php echo esc_url( ie_get_theme_page_url( 'price' ) ); ?>" class="btn-save-profile">
                                                <?php echo esc_html( ie__( 'Subscribe Again' ) ); ?>
                                            </a>
                                        <?php else : ?>
                                            <a href="<?php echo esc_url( ie_get_theme_page_url( 'price' ) ); ?>" class="btn-save-profile">
                                                <?php echo esc_html( ie__( 'View Plans' ) ); ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if ( $subscription['is_expired'] ) : ?>
                                <div class="provider-alert provider-alert--warning provider-sub-alert">
                                    <span class="provider-alert__icon"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></span>
                                    <div>
                                        <div class="provider-alert__title"><?php echo esc_html( ie__( 'Subscription expired' ) ); ?></div>
                                        <div class="provider-alert__text"><?php echo esc_html( ie__( 'Your plan has ended. Remove the expired subscription or choose a new plan to continue.' ) ); ?></div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="provider-sub-invoices">
                                <div class="provider-sub-invoices__head">
                                    <div class="provider-sub-invoices__head-text">
                                        <h3><?php echo esc_html( ie__( 'Billing History' ) ); ?></h3>
                                        <p><?php echo esc_html( ie__( 'View and download official PDF receipts for your subscription payments.' ) ); ?></p>
                                    </div>
                                    <?php if ( ! empty( $subscription['invoices'] ) ) : ?>
                                        <span class="provider-sub-invoices__count">
                                            <?php echo esc_html( sprintf( _n( '%d invoice', '%d invoices', count( $subscription['invoices'] ), IE_TEXT_DOMAIN ), count( $subscription['invoices'] ) ) ); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <?php if ( ! empty( $subscription['invoices'] ) ) : ?>
                                    <?php
                                    $invoice_brand_logo = ie_get_header_logo_url();
                                    $invoice_brand_name = get_bloginfo( 'name' );
                                    ?>
                                    <div class="provider-sub-invoices__list">
                                        <?php foreach ( $subscription['invoices'] as $invoice ) : ?>
                                            <?php
                                            $invoice_status = sanitize_key( $invoice['status'] ?? '' );
                                            $invoice_number = ie_format_invoice_display_number( $invoice['number'] ?? '', $invoice['id'] ?? '' );
                                            ?>
                                            <article class="provider-sub-invoice-card">
                                                <div class="provider-sub-invoice-card__details">
                                                    <div class="provider-sub-invoice-card__icon" aria-hidden="true">
                                                        <?php if ( $invoice_brand_logo ) : ?>
                                                            <img src="<?php echo esc_url( $invoice_brand_logo ); ?>"
                                                                 alt="<?php echo esc_attr( $invoice_brand_name ); ?>"
                                                                 class="provider-sub-invoice-card__logo">
                                                        <?php else : ?>
                                                            <span class="provider-sub-invoice-card__logo-fallback"><?php echo esc_html( mb_strtoupper( mb_substr( $invoice_brand_name, 0, 1 ) ) ); ?></span>
                                                        <?php endif; ?>
                                                    </div>

                                                    <div class="provider-sub-invoice-card__body">
                                                        <strong class="provider-sub-invoice-card__number"><?php echo esc_html( $invoice_number ); ?></strong>
                                                        <div class="provider-sub-invoice-card__meta">
                                                            <span class="provider-sub-invoice-card__date">
                                                                <i class="fa-regular fa-calendar" aria-hidden="true"></i>
                                                                <?php echo esc_html( ie_format_subscription_date( $invoice['date'] ) ); ?>
                                                            </span>
                                                            <span class="provider-sub-invoice-card__amount">
                                                                <?php echo esc_html( $invoice['amount'] ); ?>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="provider-sub-invoice-card__status">
                                                    <span class="provider-sub-invoice-status is-<?php echo esc_attr( $invoice_status ); ?>">
                                                        <?php echo esc_html( ie_get_invoice_status_label( $invoice_status ) ); ?>
                                                    </span>
                                                </div>

                                                <div class="provider-sub-invoice-card__action">
                                                    <?php if ( ! empty( $invoice['has_pdf'] ) ) : ?>
                                                        <button type="button"
                                                                class="provider-sub-invoice-download"
                                                                data-invoice-id="<?php echo esc_attr( $invoice['id'] ); ?>"
                                                                data-download-url="<?php echo esc_url( $invoice['download_url'] ?? '' ); ?>"
                                                                data-filename="<?php echo esc_attr( $invoice['pdf_filename'] ?? 'invoice.pdf' ); ?>"
                                                                aria-label="<?php echo esc_attr( sprintf( ie__( 'Download PDF for invoice %s' ), $invoice_number ) ); ?>">
                                                            <span class="provider-sub-invoice-download__icon" aria-hidden="true">
                                                                <i class="fa-solid fa-file-pdf"></i>
                                                            </span>
                                                            <span class="provider-sub-invoice-download__text"><?php echo esc_html( ie__( 'Download PDF' ) ); ?></span>
                                                            <span class="provider-sub-invoice-download__loader" aria-hidden="true">
                                                                <i class="fa-solid fa-spinner fa-spin"></i>
                                                            </span>
                                                        </button>
                                                    <?php else : ?>
                                                        <span class="provider-sub-invoice-card__unavailable"><?php echo esc_html( ie__( 'PDF unavailable' ) ); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </article>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else : ?>
                                    <div class="provider-sub-invoices__empty">
                                        <div class="provider-sub-invoices__empty-icon" aria-hidden="true">
                                            <i class="fa-regular fa-file-lines"></i>
                                        </div>
                                        <h4><?php echo esc_html( ie__( 'No invoices yet' ) ); ?></h4>
                                        <p><?php echo esc_html( ie__( 'Your payment receipts will appear here after your first successful subscription charge.' ) ); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php elseif ( ! empty( $subscription['on_free_trial'] ) ) : ?>
                            <div class="provider-sub-overview is-active is-trial">
                                <div class="provider-sub-overview__head">
                                    <div class="provider-sub-overview__title-wrap">
                                        <span class="provider-sub-overview__eyebrow"><?php echo esc_html( ie__( 'Current Plan' ) ); ?></span>
                                        <h3 class="provider-sub-overview__plan"><?php echo esc_html( $subscription['plan_label'] ); ?></h3>
                                        <p class="provider-sub-overview__price provider-sub-overview__price--trial">
                                            <?php
                                            echo esc_html(
                                                sprintf(
                                                    ie__( '%d days remaining' ),
                                                    (int) ( $subscription['free_trial']['days_remaining'] ?? 0 )
                                                )
                                            );
                                            ?>
                                        </p>
                                    </div>
                                    <?php ie_render_provider_subscription_status_badge( $subscription ); ?>
                                </div>

                                <div class="provider-sub-details-grid">
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Free Trial Active' ) ); ?></span>
                                        <strong class="provider-sub-detail__value"><?php echo esc_html( ie__( 'Yes' ) ); ?></strong>
                                    </div>
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Trial Start Date' ) ); ?></span>
                                        <strong class="provider-sub-detail__value"><?php echo esc_html( $subscription['started_label'] ); ?></strong>
                                    </div>
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Trial Expiry Date' ) ); ?></span>
                                        <strong class="provider-sub-detail__value"><?php echo esc_html( $subscription['expires_label'] ); ?></strong>
                                    </div>
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Trial Duration' ) ); ?></span>
                                        <strong class="provider-sub-detail__value">
                                            <?php
                                            echo esc_html(
                                                sprintf(
                                                    ie__( '%d Days' ),
                                                    (int) ( $subscription['free_trial']['configured_days'] ?? 0 )
                                                )
                                            );
                                            ?>
                                        </strong>
                                    </div>
                                </div>

                                <div class="provider-sub-overview__actions">
                                    <a href="<?php echo esc_url( ie_get_theme_page_url( 'price' ) ); ?>" class="btn-save-profile">
                                        <?php echo esc_html( ie__( 'View Plans' ) ); ?>
                                    </a>
                                </div>
                            </div>

                            <div class="provider-alert provider-alert--info provider-sub-alert">
                                <span class="provider-alert__icon"><i class="fa-solid fa-circle-info" aria-hidden="true"></i></span>
                                <div>
                                    <div class="provider-alert__title"><?php echo esc_html( ie__( 'Free trial in progress' ) ); ?></div>
                                    <div class="provider-alert__text"><?php echo esc_html( ie__( 'You currently have Basic Plan benefits during your free trial. Subscribe before your trial ends to keep full access.' ) ); ?></div>
                                </div>
                            </div>
                        <?php elseif ( ! empty( $subscription['trial_expired'] ) ) : ?>
                            <div class="provider-sub-overview is-expired">
                                <div class="provider-sub-overview__head">
                                    <div class="provider-sub-overview__title-wrap">
                                        <span class="provider-sub-overview__eyebrow"><?php echo esc_html( ie__( 'Current Plan' ) ); ?></span>
                                        <h3 class="provider-sub-overview__plan"><?php echo esc_html( $subscription['plan_label'] ); ?></h3>
                                    </div>
                                    <?php ie_render_provider_subscription_status_badge( $subscription ); ?>
                                </div>

                                <div class="provider-sub-details-grid">
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Free Trial Active' ) ); ?></span>
                                        <strong class="provider-sub-detail__value"><?php echo esc_html( ie__( 'No' ) ); ?></strong>
                                    </div>
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Trial Start Date' ) ); ?></span>
                                        <strong class="provider-sub-detail__value"><?php echo esc_html( $subscription['started_label'] ); ?></strong>
                                    </div>
                                    <div class="provider-sub-detail">
                                        <span class="provider-sub-detail__label"><?php echo esc_html( ie__( 'Trial Expiry Date' ) ); ?></span>
                                        <strong class="provider-sub-detail__value"><?php echo esc_html( $subscription['expires_label'] ); ?></strong>
                                    </div>
                                </div>

                                <div class="provider-sub-overview__actions">
                                    <a href="<?php echo esc_url( ie_get_theme_page_url( 'price' ) ); ?>" class="btn-save-profile">
                                        <?php echo esc_html( ie__( 'Subscribe Now' ) ); ?>
                                    </a>
                                </div>
                            </div>

                            <div class="provider-alert provider-alert--warning provider-sub-alert">
                                <span class="provider-alert__icon"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></span>
                                <div>
                                    <div class="provider-alert__title"><?php echo esc_html( ie__( 'Your free trial is finished' ) ); ?></div>
                                    <div class="provider-alert__text"><?php echo esc_html( ie__( 'Your account is now on the free plan. Premium and Basic features are locked until you purchase a subscription.' ) ); ?></div>
                                </div>
                            </div>
                        <?php else : ?>
                            <div class="provider-sub-empty">
                                <div class="provider-sub-empty__icon">
                                    <i class="fa-regular fa-credit-card" aria-hidden="true"></i>
                                </div>
                                <h3><?php echo esc_html( ie__( 'No subscription yet' ) ); ?></h3>
                                <p><?php echo esc_html( ie__( 'Choose a plan to unlock your full provider dashboard and grow your business on Island Experts.' ) ); ?></p>
                                <a href="<?php echo esc_url( ie_get_theme_page_url( 'price' ) ); ?>" class="btn-save-profile">
                                    <?php echo esc_html( ie__( 'View Plans' ) ); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Account Settings -->
                <div class="dashboard-panel<?php echo $active_tab === 'settings' ? ' active' : ''; ?>" id="panel-settings">
                    <div class="dashboard-panel-head">
                        <h2 class="panel-title"><?php echo esc_html( ie__( 'Account Settings' ) ); ?></h2>
                        <p class="panel-desc"><?php echo esc_html( ie__( 'Keep your account secure by updating your password regularly.' ) ); ?></p>
                    </div>

                    <div class="dashboard-panel-body">
                        <div class="client-settings-section">
                            <h3 class="client-settings-heading"><?php echo esc_html( ie__( 'Change Password' ) ); ?></h3>
                            <div class="form-group">
                                <label class="form-label" for="curr-password"><?php echo esc_html( ie__( 'Current Password' ) ); ?></label>
                                <div class="input-with-toggle">
                                    <input type="password" id="curr-password" class="form-control" autocomplete="current-password">
                                    <button class="password-toggle" type="button" data-target="curr-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                        <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="profile-form-grid">
                                <div class="form-group">
                                    <label class="form-label" for="new-password"><?php echo esc_html( ie__( 'New Password' ) ); ?></label>
                                    <div class="input-with-toggle">
                                        <input type="password" id="new-password" class="form-control" autocomplete="new-password">
                                        <button class="password-toggle" type="button" data-target="new-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="confirm-new-password"><?php echo esc_html( ie__( 'Confirm New Password' ) ); ?></label>
                                    <div class="input-with-toggle">
                                        <input type="password" id="confirm-new-password" class="form-control" autocomplete="new-password">
                                        <button class="password-toggle" type="button" data-target="confirm-new-password" aria-label="<?php echo esc_attr( ie__( 'Show password' ) ); ?>">
                                            <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="form-error" id="password-error"></div>
                        </div>
                    </div>

                    <div class="dashboard-panel-actions">
                        <button type="button" class="btn-save-profile" id="btn-change-password"><?php echo esc_html( ie__( 'Update Password' ) ); ?></button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php if ( $provider_id ) : ?>
    <script type="text/html" id="provider-social-row-template"><?php ob_start(); ie_render_provider_social_row( [ 'icon' => '', 'url' => '' ], $social_presets ); echo trim( ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
    <script type="text/html" id="provider-service-row-template"><?php ob_start(); ie_render_provider_service_row( [ 'name' => '', 'price' => '', 'image_id' => 0, 'show_publicly' => false ], $service_placeholder_image ); echo trim( ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
<?php endif; ?>

<?php ie_render_offer_modals(); ?>

<?php get_footer(); ?>
