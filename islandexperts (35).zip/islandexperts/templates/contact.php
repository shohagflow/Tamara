<?php
/**
 * Template Name: Contact
 */
get_header();

$contact_data = ie_get_contact_page_data();
$banner       = $contact_data['banner'];
$sidebar      = $contact_data['sidebar'];
?>

<div class="ie-static-page ie-contact-page">
    <div class="ie-page-hero">
        <div class="ie-page-hero__icon" aria-hidden="true">
            <i class="<?php echo esc_attr( $banner['icon'] ); ?>"></i>
        </div>
        <h1 class="ie-page-hero__title"><?php echo esc_html( $banner['title'] ); ?></h1>
        <?php if ( ! empty( $banner['subtitle'] ) ) : ?>
            <p class="ie-page-hero__subtitle"><?php echo esc_html( $banner['subtitle'] ); ?></p>
        <?php endif; ?>
    </div>

    <div class="container ie-page-content">
        <div class="ie-contact-layout">
            <?php ie_render_contact_sidebar( $sidebar ); ?>

            <div class="ie-contact-form-panel">
                <h2><?php echo esc_html( ie__( 'Send us a Message' ) ); ?></h2>
                <p class="ie-contact-form-panel__desc"><?php echo esc_html( ie__( "Fill in the form below and we'll get back to you within 24 hours." ) ); ?></p>

                <div class="profile-form-grid">
                    <div class="form-group">
                        <label class="form-label" for="contact-name"><?php echo esc_html( ie__( 'Full Name' ) ); ?> <span class="form-required">*</span></label>
                        <input type="text" id="contact-name" class="form-control" placeholder="<?php echo esc_attr( ie__( 'John Doe' ) ); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="contact-email"><?php echo esc_html( ie__( 'Email Address' ) ); ?> <span class="form-required">*</span></label>
                        <input type="email" id="contact-email" class="form-control" placeholder="<?php echo esc_attr( ie__( 'you@example.com' ) ); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="contact-phone"><?php echo esc_html( ie__( 'Phone Number' ) ); ?></label>
                        <input type="tel" id="contact-phone" class="form-control" placeholder="<?php echo esc_attr( ie__( '+1 (758) 000-0000' ) ); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="contact-subject"><?php echo esc_html( ie__( 'Subject' ) ); ?> <span class="form-required">*</span></label>
                        <input type="text" id="contact-subject" class="form-control" placeholder="<?php echo esc_attr( ie__( 'What is your message about?' ) ); ?>">
                    </div>
                    <div class="form-group full-width">
                        <label class="form-label" for="contact-message"><?php echo esc_html( ie__( 'Message' ) ); ?> <span class="form-required">*</span></label>
                        <textarea id="contact-message" class="form-control" rows="5" placeholder="<?php echo esc_attr( ie__( 'How can we help you?' ) ); ?>"></textarea>
                    </div>
                </div>

                <div class="form-error" id="contact-error"></div>
                <div class="form-success" id="contact-success"></div>

                <button type="button" id="btn-contact-submit" class="btn-save-profile">
                    <?php echo esc_html( ie__( 'Send Message' ) ); ?>
                    <i class="fa-solid fa-paper-plane" aria-hidden="true"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
