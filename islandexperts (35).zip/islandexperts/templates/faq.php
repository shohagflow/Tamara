<?php
/**
 * Template Name: FAQ
 */
get_header();

$faq_data = ie_get_faq_page_data();
$banner   = $faq_data['banner'];
$faqs     = $faq_data['items'];
?>

<div class="ie-static-page ie-faq-page">
    <div class="ie-page-hero">
        <div class="ie-page-hero__icon" aria-hidden="true">
            <i class="<?php echo esc_attr( $banner['icon'] ); ?>"></i>
        </div>
        <h1 class="ie-page-hero__title"><?php echo esc_html( $banner['title'] ); ?></h1>
        <?php if ( ! empty( $banner['subtitle'] ) ) : ?>
            <p class="ie-page-hero__subtitle"><?php echo esc_html( $banner['subtitle'] ); ?></p>
        <?php endif; ?>
    </div>

    <div class="container ie-page-content">
        <?php if ( $faqs ) : ?>
            <?php ie_faq_list( $faqs ); ?>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
