<?php
/**
 * Template Name: Home
 */
get_header();

$browse_url = ie_get_theme_page_url( 'browse' );
$home_data  = ie_get_home_page_data( ie_get_home_content_post_id() );
?>

<?php ie_render_home_hero( $home_data['hero'] ); ?>

<?php ie_render_home_categories( $browse_url, $home_data['categories'] ); ?>

<?php ie_render_home_featured_providers( $home_data['providers'], $browse_url ); ?>

<?php ie_render_home_why( $home_data['why'] ); ?>
<?php ie_render_home_cta( $home_data['cta'] ); ?>

<?php get_footer(); ?>
