<?php
/**
 * 404 Not Found template.
 */

get_header();

$home_url    = ie_get_theme_page_url( 'home' );
$browse_url  = ie_get_theme_page_url( 'browse' );
$contact_url = ie_get_theme_page_url( 'contact' );
?>

<div class="ie-static-page ie-not-found-page">
    <div class="ie-page-hero ie-not-found-hero">
        <span class="ie-not-found-hero__code" aria-hidden="true">404</span>
        <div class="ie-page-hero__icon" aria-hidden="true">
            <i class="fa-solid fa-compass"></i>
        </div>
        <h1 class="ie-page-hero__title"><?php echo esc_html( ie__( 'Page Not Found' ) ); ?></h1>
        <p class="ie-page-hero__subtitle">
            <?php echo esc_html( ie__( 'The page you are looking for may have been moved, removed, or never existed.' ) ); ?>
        </p>
    </div>

    <div class="container ie-page-content ie-not-found-content">
        <div class="ie-not-found-card">
            <div class="ie-not-found-card__content">
                <h2><?php echo esc_html( ie__( 'Let us get you back on track' ) ); ?></h2>
                <p>
                    <?php echo esc_html( ie__( 'Try one of the options below, or search for a service provider on Island Experts.' ) ); ?>
                </p>

                <form class="ie-not-found-search" role="search" method="get" action="<?php echo esc_url( $browse_url ); ?>">
                    <label class="screen-reader-text" for="ie-not-found-search-input">
                        <?php echo esc_html( ie__( 'Search providers' ) ); ?>
                    </label>
                    <input
                        type="search"
                        id="ie-not-found-search-input"
                        name="q"
                        class="form-control ie-not-found-search__input"
                        placeholder="<?php echo esc_attr( ie__( 'Search providers, services, or locations...' ) ); ?>"
                    >
                    <button type="submit" class="ie-not-found-search__btn">
                        <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                        <span><?php echo esc_html( ie__( 'Search' ) ); ?></span>
                    </button>
                </form>
            </div>

            <div class="ie-not-found-actions">
                <a href="<?php echo esc_url( $home_url ); ?>" class="ie-not-found-btn ie-not-found-btn--primary">
                    <i class="fa-solid fa-house" aria-hidden="true"></i>
                    <?php echo esc_html( ie__( 'Back to Home' ) ); ?>
                </a>
                <a href="<?php echo esc_url( $browse_url ); ?>" class="ie-not-found-btn ie-not-found-btn--secondary">
                    <i class="fa-solid fa-users" aria-hidden="true"></i>
                    <?php echo esc_html( ie__( 'Browse Providers' ) ); ?>
                </a>
                <?php if ( $contact_url ) : ?>
                    <a href="<?php echo esc_url( $contact_url ); ?>" class="ie-not-found-btn ie-not-found-btn--ghost">
                        <i class="fa-regular fa-envelope" aria-hidden="true"></i>
                        <?php echo esc_html( ie__( 'Contact Support' ) ); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="ie-not-found-tips">
            <div class="ie-not-found-tip">
                <span class="ie-not-found-tip__icon" aria-hidden="true"><i class="fa-solid fa-link-slash"></i></span>
                <div>
                    <strong><?php echo esc_html( ie__( 'Check the URL' ) ); ?></strong>
                    <p><?php echo esc_html( ie__( 'Make sure the web address is spelled correctly.' ) ); ?></p>
                </div>
            </div>
            <div class="ie-not-found-tip">
                <span class="ie-not-found-tip__icon" aria-hidden="true"><i class="fa-solid fa-rotate-left"></i></span>
                <div>
                    <strong><?php echo esc_html( ie__( 'Go back' ) ); ?></strong>
                    <p><?php echo esc_html( ie__( 'Use your browser back button to return to the previous page.' ) ); ?></p>
                </div>
            </div>
            <div class="ie-not-found-tip">
                <span class="ie-not-found-tip__icon" aria-hidden="true"><i class="fa-solid fa-life-ring"></i></span>
                <div>
                    <strong><?php echo esc_html( ie__( 'Need help?' ) ); ?></strong>
                    <p><?php echo esc_html( ie__( 'Our team can help you find the right service provider.' ) ); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
