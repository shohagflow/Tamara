<?php
/**
 * Island Experts Admin — payments module.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'IE_PAYMENT_SETTINGS_OPTION', 'ie_payment_settings' );
define( 'IE_PAYMENT_LOGS_OPTION', 'ie_payment_logs' );

function ie_admin_get_default_payment_settings() {
    return [
        'stripe_enabled'        => '0',
        'stripe_publishable'    => '',
        'stripe_secret'         => '',
        'stripe_webhook_secret' => '',
    ];
}

function ie_admin_get_payment_settings() {
    $settings = get_option( IE_PAYMENT_SETTINGS_OPTION, [] );
    if ( ! is_array( $settings ) ) {
        $settings = [];
    }

    return wp_parse_args( $settings, ie_admin_get_default_payment_settings() );
}

function ie_admin_sanitize_payment_settings( $input ) {
    if ( ! is_array( $input ) ) {
        return ie_admin_get_default_payment_settings();
    }

    return [
        'stripe_enabled'        => ! empty( $input['stripe_enabled'] ) ? '1' : '0',
        'stripe_publishable'    => sanitize_text_field( $input['stripe_publishable'] ?? '' ),
        'stripe_secret'         => sanitize_text_field( $input['stripe_secret'] ?? '' ),
        'stripe_webhook_secret' => sanitize_text_field( $input['stripe_webhook_secret'] ?? '' ),
    ];
}

function ie_admin_get_stripe_webhook_url() {
    return add_query_arg( 'ie_stripe_webhook', '1', home_url( '/' ) );
}

function ie_stripe_is_enabled() {
    $settings = ie_admin_get_payment_settings();

    return trim( (string) ( $settings['stripe_secret'] ?? '' ) ) !== '';
}

function ie_stripe_api_request( $method, $endpoint, $params = [] ) {
    $settings = ie_admin_get_payment_settings();
    $secret   = $settings['stripe_secret'] ?? '';

    if ( $secret === '' ) {
        return new WP_Error( 'missing_secret', ie__( 'Stripe secret key is required.' ) );
    }

    $url  = 'https://api.stripe.com/v1/' . ltrim( $endpoint, '/' );
    $args = [
        'headers' => [
            'Authorization' => 'Bearer ' . $secret,
        ],
        'timeout' => 30,
    ];

    if ( strtoupper( $method ) === 'GET' ) {
        if ( $params ) {
            $url = add_query_arg( $params, $url );
        }

        $response = wp_remote_get( $url, $args );
    } else {
        $args['body'] = $params;
        $response     = wp_remote_post( $url, $args );
    }

    if ( is_wp_error( $response ) ) {
        return $response;
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( $code >= 200 && $code < 300 ) {
        return $body;
    }

    $message = $body['error']['message'] ?? ie__( 'Stripe request failed.' );

    return new WP_Error( 'stripe_failed', $message );
}

function ie_activate_user_subscription_from_stripe( $user_id, $plan_id, $session = [] ) {
    $user_id = (int) $user_id;
    $plan_id = sanitize_text_field( (string) $plan_id );

    if ( ! $user_id || $plan_id === '' ) {
        return false;
    }

    $billing = strpos( $plan_id, 'annual' ) !== false ? 'yearly' : 'monthly';

    update_user_meta( $user_id, '_ie_subscription_plan', $plan_id );
    update_user_meta( $user_id, '_ie_subscription_billing', $billing );
    update_user_meta( $user_id, '_ie_subscription_status', 'active' );

    if ( ! empty( $session['subscription'] ) ) {
        update_user_meta( $user_id, '_ie_stripe_subscription_id', sanitize_text_field( $session['subscription'] ) );
        ie_sync_user_subscription_from_stripe( $user_id );
    } else {
        update_user_meta( $user_id, '_ie_subscription_started_at', time() );
    }

    if ( ! empty( $session['customer'] ) ) {
        update_user_meta( $user_id, '_ie_stripe_customer_id', sanitize_text_field( $session['customer'] ) );
    }

    return true;
}

function ie_create_stripe_checkout_session( $checkout_plan_id ) {
    if ( ! ie_stripe_is_enabled() ) {
        return new WP_Error( 'stripe_disabled', ie__( 'Stripe payments are not enabled.' ) );
    }

    $plan = ie_get_subscription_plan_by_checkout_id( $checkout_plan_id );

    if ( ! $plan ) {
        return new WP_Error( 'invalid_plan', ie__( 'Selected subscription plan was not found.' ) );
    }

    $price_id = sanitize_text_field( $plan['product_price_id'] ?? '' );

    if ( $price_id === '' ) {
        return new WP_Error( 'missing_price_id', ie__( 'This plan is missing a Stripe Product Price ID.' ) );
    }

    $price_url    = ie_get_theme_page_url( 'price' );
    $success_url  = add_query_arg(
        [
            'payment'    => 'success',
            'session_id' => '{CHECKOUT_SESSION_ID}',
        ],
        $price_url
    );
    $cancel_url   = add_query_arg( 'payment', 'cancelled', $price_url );
    $plan_label   = ie_get_subscription_checkout_plan_label( $plan );
    $request_body = [
        'mode'                       => 'subscription',
        'line_items[0][price]'       => $price_id,
        'line_items[0][quantity]'    => 1,
        'success_url'                => $success_url,
        'cancel_url'                 => $cancel_url,
        'metadata[ie_plan_id]'       => $checkout_plan_id,
        'metadata[ie_plan_label]'    => $plan_label,
        'subscription_data[metadata][ie_plan_id]' => $checkout_plan_id,
    ];

    if ( is_user_logged_in() ) {
        $user = wp_get_current_user();

        $request_body['client_reference_id'] = (string) get_current_user_id();
        $request_body['customer_email']    = $user->user_email;
    }

    return ie_stripe_api_request( 'POST', 'checkout/sessions', $request_body );
}

function ie_verify_stripe_checkout_session( $session_id ) {
    $session_id = sanitize_text_field( (string) $session_id );

    if ( $session_id === '' ) {
        return new WP_Error( 'missing_session', ie__( 'Missing Stripe checkout session.' ) );
    }

    $session = ie_stripe_api_request( 'GET', 'checkout/sessions/' . rawurlencode( $session_id ) );

    if ( is_wp_error( $session ) ) {
        return $session;
    }

    $status         = sanitize_key( $session['status'] ?? '' );
    $payment_status = sanitize_key( $session['payment_status'] ?? '' );

    if ( $status !== 'complete' && $payment_status !== 'paid' && $payment_status !== 'no_payment_required' ) {
        return new WP_Error( 'payment_incomplete', ie__( 'Payment has not been completed yet.' ) );
    }

    return $session;
}

function ie_handle_stripe_checkout_success_redirect() {
    if ( ( $_GET['payment'] ?? '' ) !== 'success' || empty( $_GET['session_id'] ) ) {
        return;
    }

    $session = ie_verify_stripe_checkout_session( wp_unslash( $_GET['session_id'] ) );

    if ( is_wp_error( $session ) ) {
        return;
    }

    $plan_id    = sanitize_text_field( $session['metadata']['ie_plan_id'] ?? '' );
    $plan_label = sanitize_text_field( $session['metadata']['ie_plan_label'] ?? '' );

    if ( $plan_id === '' ) {
        return;
    }

    $expires = time() + HOUR_IN_SECONDS;

    setcookie( 'ie_plan_id', $plan_id, $expires, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
    setcookie( 'ie_plan', $plan_label, $expires, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );

    if ( ! empty( $session['client_reference_id'] ) ) {
        ie_activate_user_subscription_from_stripe( (int) $session['client_reference_id'], $plan_id, $session );
    }

    ie_admin_add_payment_log( [
        'status'  => 'success',
        'message' => sprintf(
            ie__( 'Stripe checkout completed for plan %1$s (%2$s).' ),
            $plan_label !== '' ? $plan_label : $plan_id,
            sanitize_text_field( $session['id'] ?? '' )
        ),
        'user_id' => (int) ( $session['client_reference_id'] ?? 0 ),
    ] );

    wp_safe_redirect(
        add_query_arg(
            [
                'payment' => 'success',
                'plan'    => $plan_label !== '' ? $plan_label : $plan_id,
            ],
            ie_get_theme_page_url( 'price' )
        )
    );
    exit;
}
add_action( 'template_redirect', 'ie_handle_stripe_checkout_success_redirect', 5 );

function ie_stripe_construct_webhook_event( $payload, $signature_header ) {
    $secret = ie_admin_get_payment_settings()['stripe_webhook_secret'] ?? '';

    if ( $secret === '' ) {
        return new WP_Error( 'missing_webhook_secret', ie__( 'Stripe webhook signing secret is not configured.' ) );
    }

    $timestamp = null;
    $signatures = [];

    foreach ( explode( ',', (string) $signature_header ) as $part ) {
        $part = trim( $part );

        if ( strpos( $part, 't=' ) === 0 ) {
            $timestamp = substr( $part, 2 );
            continue;
        }

        if ( strpos( $part, 'v1=' ) === 0 ) {
            $signatures[] = substr( $part, 3 );
        }
    }

    if ( $timestamp === null || ! $signatures ) {
        return new WP_Error( 'invalid_signature', ie__( 'Invalid Stripe webhook signature.' ) );
    }

    if ( abs( time() - (int) $timestamp ) > 300 ) {
        return new WP_Error( 'invalid_timestamp', ie__( 'Stripe webhook timestamp is too old.' ) );
    }

    $signed_payload = $timestamp . '.' . $payload;
    $expected       = hash_hmac( 'sha256', $signed_payload, $secret );
    $valid          = false;

    foreach ( $signatures as $signature ) {
        if ( hash_equals( $expected, $signature ) ) {
            $valid = true;
            break;
        }
    }

    if ( ! $valid ) {
        return new WP_Error( 'invalid_signature', ie__( 'Stripe webhook signature verification failed.' ) );
    }

    $event = json_decode( $payload, true );

    if ( ! is_array( $event ) ) {
        return new WP_Error( 'invalid_payload', ie__( 'Invalid Stripe webhook payload.' ) );
    }

    return $event;
}

function ie_handle_stripe_webhook_event( $event ) {
    $type = sanitize_text_field( $event['type'] ?? '' );
    $data = $event['data']['object'] ?? [];

    if ( ! is_array( $data ) ) {
        return;
    }

    switch ( $type ) {
        case 'checkout.session.completed':
            $plan_id = sanitize_text_field( $data['metadata']['ie_plan_id'] ?? '' );
            $user_id = (int) ( $data['client_reference_id'] ?? 0 );

            if ( $user_id && $plan_id !== '' ) {
                ie_activate_user_subscription_from_stripe( $user_id, $plan_id, $data );
                ie_sync_user_subscription_from_stripe( $user_id );
            }

            ie_admin_add_payment_log( [
                'status'  => 'success',
                'message' => ie__( 'Stripe checkout session completed.' ) . ' ' . sanitize_text_field( $data['id'] ?? '' ),
                'user_id' => $user_id,
            ] );
            break;

        case 'customer.subscription.updated':
        case 'customer.subscription.deleted':
            $subscription_id = sanitize_text_field( $data['id'] ?? '' );

            if ( $subscription_id === '' ) {
                break;
            }

            $users = get_users( [
                'meta_key'   => '_ie_stripe_subscription_id',
                'meta_value' => $subscription_id,
                'number'     => 1,
                'fields'     => 'ID',
            ] );

            if ( $users ) {
                $user_id = (int) $users[0];

                if ( $type === 'customer.subscription.deleted' ) {
                    update_user_meta( $user_id, '_ie_subscription_status', 'expired' );
                }

                ie_sync_user_subscription_from_stripe( $user_id );
            }

            if ( $type === 'customer.subscription.deleted' ) {
                ie_admin_add_payment_log( [
                    'status'  => 'info',
                    'message' => ie__( 'Stripe subscription cancelled.' ) . ' ' . $subscription_id,
                ] );
            }
            break;
    }
}

function ie_admin_get_payment_logs( $limit = 50 ) {
    $logs = get_option( IE_PAYMENT_LOGS_OPTION, [] );
    if ( ! is_array( $logs ) ) {
        return [];
    }

    usort( $logs, function ( $a, $b ) {
        return strcmp( $b['date'] ?? '', $a['date'] ?? '' );
    } );

    return array_slice( $logs, 0, $limit );
}

function ie_admin_add_payment_log( $entry ) {
    $logs   = ie_admin_get_payment_logs( 200 );
    $logs[] = wp_parse_args( $entry, [
        'id'      => uniqid( 'log_', true ),
        'date'    => current_time( 'mysql' ),
        'amount'  => '0.00',
        'status'  => 'info',
        'user_id' => 0,
        'message' => '',
    ] );

    update_option( IE_PAYMENT_LOGS_OPTION, array_slice( $logs, -200 ), false );
}

function ie_admin_test_stripe_connection() {
    $settings = ie_admin_get_payment_settings();
    $secret   = $settings['stripe_secret'] ?? '';

    if ( $secret === '' ) {
        return new WP_Error( 'missing_secret', ie__( 'Stripe secret key is required.' ) );
    }

    $response = wp_remote_get(
        'https://api.stripe.com/v1/balance',
        [
            'headers' => [
                'Authorization' => 'Bearer ' . $secret,
            ],
            'timeout' => 15,
        ]
    );

    if ( is_wp_error( $response ) ) {
        return $response;
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( $code >= 200 && $code < 300 ) {
        ie_admin_add_payment_log( [
            'status'  => 'success',
            'message' => ie__( 'Stripe connection test successful.' ),
        ] );

        return [
            'message' => ie__( 'Stripe connection successful.' ),
            'livemode'=> ! empty( $body['livemode'] ),
        ];
    }

    $error = $body['error']['message'] ?? ie__( 'Stripe connection failed.' );

    ie_admin_add_payment_log( [
        'status'  => 'failed',
        'message' => $error,
    ] );

    return new WP_Error( 'stripe_failed', $error );
}

function ie_admin_handle_stripe_webhook() {
    if ( empty( $_GET['ie_stripe_webhook'] ) ) {
        return;
    }

    $payload            = file_get_contents( 'php://input' );
    $signature_header   = isset( $_SERVER['HTTP_STRIPE_SIGNATURE'] ) ? wp_unslash( $_SERVER['HTTP_STRIPE_SIGNATURE'] ) : '';
    $webhook_secret_set = ( ie_admin_get_payment_settings()['stripe_webhook_secret'] ?? '' ) !== '';

    if ( $webhook_secret_set ) {
        $event = ie_stripe_construct_webhook_event( $payload, $signature_header );

        if ( is_wp_error( $event ) ) {
            ie_admin_add_payment_log( [
                'status'  => 'failed',
                'message' => $event->get_error_message(),
            ] );

            status_header( 400 );
            echo wp_json_encode( [ 'error' => $event->get_error_message() ] );
            exit;
        }

        ie_handle_stripe_webhook_event( $event );
    } else {
        ie_admin_add_payment_log( [
            'status'  => 'info',
            'message' => ie__( 'Stripe webhook received without signature verification.' ) . ' (' . strlen( (string) $payload ) . ' bytes)',
        ] );
    }

    status_header( 200 );
    echo wp_json_encode( [ 'received' => true ] );
    exit;
}
add_action( 'init', 'ie_admin_handle_stripe_webhook' );

function ie_admin_render_payments_page() {
    if ( ! ie_admin_user_can() ) {
        return;
    }

    $current_page = ie_admin_get_current_page();
    $settings     = ie_admin_get_payment_settings();
    $logs         = ie_admin_get_payment_logs();
    $webhook_url  = ie_admin_get_stripe_webhook_url();

    ie_admin_render_shell_open( $current_page );

    if ( isset( $_GET['payments-updated'] ) ) {
        ie_admin_notice( ie__( 'Payment settings saved successfully.' ) );
    }
    ?>
    <div class="ie-ad-payments" data-section="payments">
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ie-ad-form">
            <?php wp_nonce_field( 'ie_save_payment_settings', 'ie_payment_settings_nonce' ); ?>
            <input type="hidden" name="action" value="ie_save_payment_settings">

            <div class="ie-ad-card">
                <h3><?php echo esc_html( ie__( 'Stripe Integration' ) ); ?></h3>

                <label class="ie-ad-checkbox">
                    <input type="checkbox" name="payment_settings[stripe_enabled]" value="1" <?php checked( $settings['stripe_enabled'], '1' ); ?>>
                    <?php echo esc_html( ie__( 'Enable Stripe' ) ); ?>
                </label>

                <div class="ie-ad-field">
                    <label for="stripe_publishable"><?php echo esc_html( ie__( 'Stripe Publishable Key' ) ); ?></label>
                    <input type="text" id="stripe_publishable" name="payment_settings[stripe_publishable]" value="<?php echo esc_attr( $settings['stripe_publishable'] ); ?>" class="regular-text">
                </div>

                <div class="ie-ad-field">
                    <label for="stripe_secret"><?php echo esc_html( ie__( 'Stripe Secret Key' ) ); ?></label>
                    <input type="password" id="stripe_secret" name="payment_settings[stripe_secret]" value="<?php echo esc_attr( $settings['stripe_secret'] ); ?>" class="regular-text" autocomplete="new-password">
                </div>

                <div class="ie-ad-field">
                    <label><?php echo esc_html( ie__( 'Webhook URL' ) ); ?></label>
                    <div class="ie-ad-copy-field">
                        <input type="text" readonly value="<?php echo esc_attr( $webhook_url ); ?>" class="regular-text" id="ie-stripe-webhook-url">
                        <button type="button" class="button" id="ie-copy-webhook"><?php echo esc_html( ie__( 'Copy' ) ); ?></button>
                    </div>
                    <p class="description"><?php echo esc_html( ie__( 'Add this URL to your Stripe dashboard webhook settings.' ) ); ?></p>
                </div>

                <div class="ie-ad-field">
                    <label for="stripe_webhook_secret"><?php echo esc_html( ie__( 'Signing Secret' ) ); ?></label>
                    <input type="password"
                           id="stripe_webhook_secret"
                           name="payment_settings[stripe_webhook_secret]"
                           value="<?php echo esc_attr( $settings['stripe_webhook_secret'] ); ?>"
                           class="regular-text"
                           autocomplete="new-password"
                           placeholder="<?php echo esc_attr( ie__( 'whsec_...' ) ); ?>">
                    <p class="description"><?php echo esc_html( ie__( 'Paste the signing secret from your Stripe webhook endpoint.' ) ); ?></p>
                </div>

                <div class="ie-ad-actions-bar">
                    <button type="button" class="button" id="ie-test-stripe"><?php echo esc_html( ie__( 'Test Connection' ) ); ?></button>
                    <?php submit_button( ie__( 'Save Settings' ), 'primary', 'submit', false ); ?>
                </div>
            </div>
        </form>

        <div class="ie-ad-card ie-ad-card--logs">
            <h3><?php echo esc_html( ie__( 'Payment Logs' ) ); ?></h3>
            <div class="ie-ad-table-wrap">
                <table class="ie-ad-table">
                    <thead>
                        <tr>
                            <th><?php echo esc_html( ie__( 'Date' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Status' ) ); ?></th>
                            <th><?php echo esc_html( ie__( 'Message' ) ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ( ! $logs ) : ?>
                            <tr><td colspan="3"><?php echo esc_html( ie__( 'No payment logs yet.' ) ); ?></td></tr>
                        <?php else : ?>
                            <?php foreach ( $logs as $log ) : ?>
                                <tr>
                                    <td><?php echo esc_html( $log['date'] ?? '' ); ?></td>
                                    <td><?php ie_admin_status_badge( $log['status'] ?? 'info' ); ?></td>
                                    <td><?php echo esc_html( $log['message'] ?? '' ); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php

    ie_admin_render_shell_close();
}

function ie_handle_save_payment_settings() {
    ie_admin_verify_post( 'ie_save_payment_settings', 'ie_payment_settings_nonce' );

    $input    = isset( $_POST['payment_settings'] ) ? wp_unslash( $_POST['payment_settings'] ) : [];
    $settings = ie_admin_sanitize_payment_settings( $input );

    update_option( IE_PAYMENT_SETTINGS_OPTION, $settings, false );

    wp_safe_redirect( add_query_arg( 'payments-updated', '1', admin_url( 'admin.php?page=ie-admin-payments' ) ) );
    exit;
}
add_action( 'admin_post_ie_save_payment_settings', 'ie_handle_save_payment_settings' );

function ie_ajax_admin_test_stripe() {
    ie_admin_verify_request( 'ie_admin_dashboard', 'nonce' );

    $result = ie_admin_test_stripe_connection();

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( [ 'message' => $result->get_error_message() ] );
    }

    wp_send_json_success( $result );
}
add_action( 'wp_ajax_ie_admin_test_stripe', 'ie_ajax_admin_test_stripe' );

function ie_ajax_create_stripe_checkout() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! ie_stripe_is_enabled() ) {
        wp_send_json_error( [ 'message' => ie__( 'Stripe payments are not enabled.' ) ] );
    }

    $plan_id = sanitize_text_field( wp_unslash( $_POST['plan_id'] ?? '' ) );

    if ( $plan_id === '' ) {
        wp_send_json_error( [ 'message' => ie__( 'Please choose a subscription plan.' ) ] );
    }

    $session = ie_create_stripe_checkout_session( $plan_id );

    if ( is_wp_error( $session ) ) {
        wp_send_json_error( [ 'message' => $session->get_error_message() ] );
    }

    if ( empty( $session['url'] ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Stripe did not return a checkout URL.' ) ] );
    }

    wp_send_json_success( [
        'url'        => esc_url_raw( $session['url'] ),
        'session_id' => sanitize_text_field( $session['id'] ?? '' ),
    ] );
}
add_action( 'wp_ajax_ie_create_stripe_checkout', 'ie_ajax_create_stripe_checkout' );
add_action( 'wp_ajax_nopriv_ie_create_stripe_checkout', 'ie_ajax_create_stripe_checkout' );

