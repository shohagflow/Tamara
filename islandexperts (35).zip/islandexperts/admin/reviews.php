<?php
/**
 * Island Experts Admin — reviews module.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_admin_get_reviews( $args = [] ) {
    $search = sanitize_text_field( $args['search'] ?? '' );
    $rating = (int) ( $args['rating'] ?? 0 );
    $paged  = max( 1, (int) ( $args['paged'] ?? 1 ) );
    $per    = 20;

    $query = [
        'type'    => 'ie_review',
        'status'  => 'approve',
        'number'  => $per,
        'offset'  => ( $paged - 1 ) * $per,
        'orderby' => 'comment_date_gmt',
        'order'   => 'DESC',
    ];

    if ( $search !== '' ) {
        $query['search'] = $search;
    }

    $comments = get_comments( $query );
    $rows     = [];

    foreach ( $comments as $comment ) {
        $review_rating = (int) get_comment_meta( $comment->comment_ID, '_ie_review_rating', true );
        if ( $rating > 0 && $review_rating !== $rating ) {
            continue;
        }

        $provider = get_post( $comment->comment_post_ID );
        $rows[]   = [
            'id'            => $comment->comment_ID,
            'provider_id'   => $comment->comment_post_ID,
            'provider_name' => $provider ? get_the_title( $provider ) : ie__( 'Unknown Provider' ),
            'author'        => $comment->comment_author,
            'rating'        => $review_rating ?: 5,
            'comment'       => $comment->comment_content,
            'date'          => mysql2date( get_option( 'date_format' ), get_date_from_gmt( $comment->comment_date_gmt ) ),
        ];
    }

    $count_query = $query;
    unset( $count_query['number'], $count_query['offset'] );
    $total = get_comments( array_merge( $count_query, [ 'count' => true ] ) );

    return [
        'reviews' => $rows,
        'total'   => (int) $total,
        'pages'   => (int) ceil( max( 1, (int) $total ) / $per ),
    ];
}

function ie_admin_delete_review( $comment_id ) {
    $comment = get_comment( $comment_id );
    if ( ! $comment || $comment->comment_type !== 'ie_review' ) {
        return new WP_Error( 'invalid_review', ie__( 'Review not found.' ) );
    }

    $provider_id = (int) $comment->comment_post_ID;
    $deleted     = wp_delete_comment( $comment_id, true );

    if ( ! $deleted ) {
        return new WP_Error( 'delete_failed', ie__( 'Could not delete review.' ) );
    }

    $all   = get_comments( [ 'post_id' => $provider_id, 'status' => 'approve', 'type' => 'ie_review' ] );
    $total = 0;
    $count = count( $all );
    foreach ( $all as $r ) {
        $total += (int) get_comment_meta( $r->comment_ID, '_ie_review_rating', true );
    }
    $avg = $count > 0 ? round( $total / $count, 1 ) : 0;
    update_post_meta( $provider_id, '_ie_rating', $avg );
    update_post_meta( $provider_id, '_ie_review_count', $count );

    return true;
}

function ie_admin_render_reviews_page() {
    if ( ! ie_admin_user_can() ) {
        return;
    }

    $current_page = ie_admin_get_current_page();
    ie_admin_render_shell_open( $current_page );
    ?>
    <div class="ie-ad-reviews" data-section="reviews">
        <?php
        ie_admin_render_toolbar(
            ie__( 'Search reviews...' ),
            [
                [
                    'id'      => 'ie-ad-review-rating',
                    'options' => [
                        '0' => ie__( 'All Ratings' ),
                        '5' => '5 â˜…',
                        '4' => '4 â˜…',
                        '3' => '3 â˜…',
                        '2' => '2 â˜…',
                        '1' => '1 â˜…',
                    ],
                ],
            ]
        );
        ?>
        <div class="ie-ad-table-wrap">
            <table class="ie-ad-table" id="ie-ad-reviews-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html( ie__( 'Provider' ) ); ?></th>
                        <th><?php echo esc_html( ie__( 'Rating' ) ); ?></th>
                        <th><?php echo esc_html( ie__( 'Review' ) ); ?></th>
                        <th><?php echo esc_html( ie__( 'Date' ) ); ?></th>
                        <th><?php echo esc_html( ie__( 'Actions' ) ); ?></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
        <div class="ie-ad-pagination" id="ie-ad-reviews-pagination"></div>
    </div>
    <?php

    ie_admin_render_shell_close();
}

function ie_ajax_admin_get_reviews() {
    ie_admin_verify_request( 'ie_admin_dashboard', 'nonce' );

    $result = ie_admin_get_reviews( [
        'search' => sanitize_text_field( wp_unslash( $_POST['search'] ?? '' ) ),
        'rating' => (int) ( $_POST['rating'] ?? 0 ),
        'paged'  => (int) ( $_POST['paged'] ?? 1 ),
    ] );

    wp_send_json_success( $result );
}
add_action( 'wp_ajax_ie_admin_get_reviews', 'ie_ajax_admin_get_reviews' );

function ie_ajax_admin_delete_review() {
    ie_admin_verify_request( 'ie_admin_dashboard', 'nonce' );

    $comment_id = (int) ( $_POST['review_id'] ?? 0 );
    $result     = ie_admin_delete_review( $comment_id );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( [ 'message' => $result->get_error_message() ] );
    }

    wp_send_json_success( [ 'message' => ie__( 'Review deleted successfully.' ) ] );
}
add_action( 'wp_ajax_ie_admin_delete_review', 'ie_ajax_admin_delete_review' );

