<?php
/**
 * Single Provider Template
 */
get_header();

$provider_id = get_the_ID();
$d           = ie_get_provider_data( $provider_id );
$rating      = $d['rating'];
$reviews     = $d['reviews'];
$price       = $d['price'];
$avail_cls   = $d['availability'];
$avail_label = $d['avail_label'];
$verified    = $d['verified'];
$premium     = $d['premium'];
$exp         = $d['experience'];
$area        = $d['location'];
$phone       = $d['phone'];
$email_meta  = $d['email'];
$website     = $d['website'];
$about       = $d['about'];
$services    = $d['services'];
$img_url     = $d['thumbnail'];
$cats        = get_the_terms( $provider_id, 'ie_category' );

$avail_map = [
    'available_now'  => 'avail-now',
    'available_week' => 'avail-week',
    'busy'           => 'avail-busy',
];

// Get reviews (comments on this provider post)
$provider_reviews = get_comments([
    'post_id' => $provider_id,
    'status'  => 'approve',
    'orderby' => 'comment_date',
    'order'   => 'DESC',
]);
?>

<div style="background:var(--color-bg-alt);min-height:calc(100vh - var(--header-height));padding:40px 0 64px;">
<div class="container" style="max-width:860px;">

    <!-- Back Link -->
    <a href="<?php echo esc_url(home_url('/browse/')); ?>"
       style="display:inline-flex;align-items:center;gap:6px;font-size:0.875rem;color:var(--color-text-muted);margin-bottom:20px;text-decoration:none;">
        ← <?php echo esc_html( ie__( 'Back to providers' ) ); ?>
    </a>

    <!-- Main Card -->
    <div style="background:white;border:1px solid var(--color-border);border-radius:var(--radius-xl);overflow:hidden;margin-bottom:16px;">

        <!-- Provider Image -->
        <div style="height:280px;position:relative;background:var(--color-bg-alt);">
            <?php if ($img_url) : ?>
                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($d['title']); ?>"
                     style="width:100%;height:100%;object-fit:cover;display:block;">
            <?php else : ?>
                <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:5rem;font-weight:700;color:var(--color-primary);font-family:var(--font-heading);">
                    <?php echo esc_html(strtoupper(substr($d['title'], 0, 1))); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Title + Info -->
        <div style="padding:24px;">

            <!-- Row 1: Name + Rating | Buttons -->
            <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:12px;flex-wrap:wrap;">

                <!-- Name + Verified + Rating -->
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <h1 style="font-size:1.35rem;font-family:var(--font-body);font-weight:700;margin:0;">
                        <?php the_title(); ?>
                    </h1>
                    <?php if ($verified) : ?>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" style="color:var(--color-primary);flex-shrink:0;">
                            <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    <?php endif; ?>
                    <div style="display:flex;align-items:center;gap:4px;">
                        <span style="color:#f59e0b;font-size:1rem;">★★★★★</span>
                        <strong style="font-size:0.9rem;"><?php echo esc_html($rating); ?></strong>
                        <span style="color:var(--color-text-muted);font-size:0.82rem;">(<?php echo esc_html($reviews); ?>)</span>
                    </div>
                </div>

                <!-- 3 Buttons -->
                <div style="display:flex;gap:8px;flex-shrink:0;">
                    <button onclick="document.getElementById('msg-body').scrollIntoView({behavior:'smooth'});setTimeout(()=>document.getElementById('msg-body').focus(),400);"
                        style="padding:9px 18px;border:1.5px solid var(--color-border);border-radius:var(--radius-button);font-size:0.85rem;font-weight:500;cursor:pointer;background:white;color:var(--color-text);white-space:nowrap;display:flex;align-items:center;gap:6px;">
                        💬 <?php echo esc_html( ie__( 'Chat' ) ); ?>
                    </button>
                    <button onclick="document.getElementById('msg-body').scrollIntoView({behavior:'smooth'});setTimeout(()=>document.getElementById('msg-body').focus(),400);"
                        style="padding:9px 18px;border:1.5px solid var(--color-border);border-radius:var(--radius-button);font-size:0.85rem;font-weight:500;cursor:pointer;background:white;color:var(--color-text);white-space:nowrap;">
                        <?php echo esc_html( ie__( 'Request Quote' ) ); ?>
                    </button>
                </div>
            </div>

            <!-- Row 2: Category + Availability -->
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px;">
                <?php if ($cats && !is_wp_error($cats)) : ?>
                    <span class="tag"><?php echo esc_html($cats[0]->name); ?></span>
                <?php endif; ?>
                <span class="availability-badge <?php echo esc_attr($avail_map[$avail_cls] ?? 'avail-now'); ?>"
                      style="position:static;">
                    <?php echo esc_html($avail_label); ?>
                </span>
            </div>

            <!-- Row 3: Location + Experience -->
            <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:0.82rem;color:var(--color-text-muted);margin-bottom:16px;">
                <?php if ($area) : ?>
                    <span style="display:flex;align-items:center;gap:4px;">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <?php echo esc_html($area); ?>
                    </span>
                <?php endif; ?>
                <?php if ($exp && $exp !== '0') : ?>
                    <span style="display:flex;align-items:center;gap:4px;">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        <?php echo esc_html( $exp ); ?> <?php echo esc_html( ie__( 'years experience' ) ); ?>
                    </span>
                <?php endif; ?>
            </div>

            <!-- Row 4: Phone + Email + Website -->
            <?php if ($phone || $email_meta || $website) : ?>
            <div style="display:flex;gap:20px;flex-wrap:wrap;padding-top:14px;border-top:1px solid var(--color-border);">
                <?php if ($phone) : ?>
                    <a href="tel:<?php echo esc_attr($phone); ?>"
                       style="display:inline-flex;align-items:center;gap:6px;font-size:0.875rem;color:var(--color-primary);text-decoration:none;font-weight:500;">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 10.8a19.79 19.79 0 01-3.07-8.67A2 2 0 012 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"/></svg>
                        <?php echo esc_html($phone); ?>
                    </a>
                <?php endif; ?>
                <?php if ($email_meta) : ?>
                    <a href="mailto:<?php echo esc_attr($email_meta); ?>"
                       style="display:inline-flex;align-items:center;gap:6px;font-size:0.875rem;color:var(--color-primary);text-decoration:none;font-weight:500;">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        <?php echo esc_html($email_meta); ?>
                    </a>
                <?php endif; ?>
                <?php if ($website) : ?>
                    <a href="<?php echo esc_url($website); ?>" target="_blank" rel="noopener"
                       style="display:inline-flex;align-items:center;gap:6px;font-size:0.875rem;color:var(--color-primary);text-decoration:none;font-weight:500;">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                        <?php echo esc_html($website); ?>
                    </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

        </div>
    </div>

    <!-- About -->
    <?php if ($about) : ?>
    <div style="background:white;border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:24px;margin-bottom:16px;">
        <h3 style="font-family:var(--font-body);font-size:1rem;font-weight:700;margin-bottom:12px;"><?php echo esc_html( ie__( 'About' ) ); ?></h3>
        <p style="font-size:0.9rem;line-height:1.75;color:var(--color-text-light);"><?php echo esc_html($about); ?></p>
    </div>
    <?php endif; ?>

    <!-- Services & Pricing -->
    <?php
    $services_arr = $services ? json_decode($services, true) : [];
    if (!empty($services_arr)) : ?>
    <div style="background:white;border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:24px;margin-bottom:16px;">
        <h3 style="font-family:var(--font-body);font-size:1rem;font-weight:700;margin-bottom:16px;"><?php echo esc_html( ie__( 'Services & Pricing' ) ); ?></h3>
        <?php foreach ($services_arr as $i => $svc) :
            $is_last = ($i === count($services_arr) - 1); ?>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;<?php echo !$is_last ? 'border-bottom:1px solid var(--color-border);' : ''; ?>">
            <span style="font-size:0.9rem;color:var(--color-text);"><?php echo esc_html($svc['name']); ?></span>
            <span style="font-size:0.875rem;font-weight:600;color:var(--color-primary);">
                <?php echo esc_html($svc['price']); ?> / <?php echo esc_html($svc['unit'] ?? 'job'); ?>
            </span>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Send a Message -->
    <div style="background:white;border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:24px;margin-bottom:16px;">
        <h3 style="font-family:var(--font-body);font-size:1rem;font-weight:700;margin-bottom:20px;">
            💬 <?php echo esc_html( ie__( 'Send a Message' ) ); ?>
        </h3>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
            <div class="form-group">
                <label class="form-label"><?php echo esc_html( ie__( 'Your Name *' ) ); ?></label>
                <input type="text" id="msg-name" class="form-control" placeholder="<?php echo esc_attr( ie__( 'John Smith' ) ); ?>">
            </div>
            <div class="form-group">
                <label class="form-label"><?php echo esc_html( ie__( 'Email *' ) ); ?></label>
                <input type="email" id="msg-email" class="form-control" placeholder="<?php echo esc_attr( ie__( 'john@example.com' ) ); ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label"><?php echo esc_html( ie__( 'Phone (optional)' ) ); ?></label>
            <input type="tel" id="msg-phone" class="form-control" placeholder="<?php echo esc_attr( ie__( '+1 (555) 000-0000' ) ); ?>">
        </div>
        <div class="form-group">
            <label class="form-label"><?php echo esc_html( ie__( 'Message *' ) ); ?></label>
            <textarea id="msg-body" class="form-control" rows="4"
                placeholder="<?php echo esc_attr( sprintf( ie__( "Hi %s, I'm interested in your services and would like to know more..." ), $d['title'] ) ); ?>"></textarea>
        </div>
        <div class="form-error" id="msg-error"></div>
        <div class="form-success" id="msg-success"></div>
        <input type="hidden" id="msg-provider-id" value="<?php echo esc_attr($provider_id); ?>">
        <button class="btn-auth" id="btn-send-message" style="margin-top:4px;width:100%;"><?php echo esc_html( ie__( 'Send Message' ) ); ?></button>
    </div>

    <!-- Reviews -->
    <div style="background:white;border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:24px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
            <h3 style="font-family:var(--font-body);font-size:1rem;font-weight:700;"><?php echo esc_html( ie__( 'Reviews' ) ); ?></h3>
            <span style="font-size:0.75rem;color:var(--color-text-muted);"><?php echo esc_html( ie__( 'Only customers with a confirmed booking can leave a review.' ) ); ?></span>
        </div>

        <?php if (!empty($provider_reviews)) : ?>
            <!-- Show reviews -->
            <div style="display:flex;flex-direction:column;gap:20px;margin-bottom:24px;">
            <?php foreach ($provider_reviews as $review) :
                $r_rating = get_comment_meta($review->comment_ID, '_ie_review_rating', true) ?: 5;
                $r_stars  = str_repeat('★', intval($r_rating)) . str_repeat('☆', 5 - intval($r_rating));
                $r_date   = date('M j, Y', strtotime($review->comment_date));
                $r_avatar = strtoupper(substr($review->comment_author, 0, 1));
                $r_user_id = (int) $review->user_id;
                $r_avatar_url = $r_user_id && ie_get_user_profile_image_id( $r_user_id )
                    ? ie_get_user_profile_image_url( $r_user_id, 'thumbnail' )
                    : '';
            ?>
            <div style="padding-bottom:20px;border-bottom:1px solid var(--color-border);">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
                    <!-- Avatar -->
                    <div style="width:40px;height:40px;border-radius:50%;background:var(--color-primary);color:white;font-weight:700;font-size:1rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-family:var(--font-heading);overflow:hidden;">
                        <?php if ( $r_avatar_url ) : ?>
                            <img src="<?php echo esc_url( $r_avatar_url ); ?>" alt="<?php echo esc_attr( $review->comment_author ); ?>" style="width:100%;height:100%;object-fit:cover;display:block;" loading="lazy">
                        <?php else : ?>
                            <?php echo esc_html($r_avatar); ?>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div style="font-weight:600;font-size:0.9rem;"><?php echo esc_html($review->comment_author); ?></div>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <span style="color:#f59e0b;font-size:0.85rem;"><?php echo $r_stars; ?></span>
                            <span style="font-size:0.75rem;color:var(--color-text-muted);"><?php echo esc_html($r_date); ?></span>
                        </div>
                    </div>
                </div>
                <p style="font-size:0.875rem;line-height:1.7;color:var(--color-text-light);margin:0;">
                    <?php echo esc_html($review->comment_content); ?>
                </p>
            </div>
            <?php endforeach; ?>
            </div>
        <?php else : ?>
            <p style="text-align:center;color:var(--color-text-muted);font-size:0.875rem;padding:20px 0 24px;">
                <?php echo esc_html( ie__( 'No reviews yet. Be the first to leave one!' ) ); ?>
            </p>
        <?php endif; ?>

        <!-- Review Submit Form -->
        <?php if (is_user_logged_in()) :
            $current_user = wp_get_current_user();
            // Check if user has a completed booking with this provider
            $has_booking = get_posts([
                'post_type'   => 'ie_booking',
                'author'      => get_current_user_id(),
                'meta_query'  => [
                    ['key' => '_ie_provider_id', 'value' => $provider_id],
                    ['key' => '_ie_status',      'value' => 'completed'],
                ],
                'numberposts' => 1,
            ]);
        ?>
        <?php if ($has_booking) : ?>
        <div style="border-top:1px solid var(--color-border);padding-top:20px;">
            <h4 style="font-family:var(--font-body);font-size:0.9rem;font-weight:700;margin-bottom:16px;"><?php echo esc_html( ie__( 'Leave a Review' ) ); ?></h4>

            <!-- Star Rating -->
            <div class="form-group">
                <label class="form-label"><?php echo esc_html( ie__( 'Rating' ) ); ?></label>
                <div id="star-rating" style="display:flex;gap:6px;font-size:1.6rem;cursor:pointer;margin-bottom:4px;">
                    <?php for ($s = 1; $s <= 5; $s++) : ?>
                        <span class="star-pick" data-val="<?php echo $s; ?>"
                              style="color:#d1d5db;transition:color 0.15s;">★</span>
                    <?php endfor; ?>
                </div>
                <input type="hidden" id="review-rating" value="5">
            </div>

            <div class="form-group">
                <label class="form-label"><?php echo esc_html( ie__( 'Your Review *' ) ); ?></label>
                <textarea id="review-body" class="form-control" rows="3"
                    placeholder="<?php echo esc_attr( ie__( 'Share your experience with this provider...' ) ); ?>"></textarea>
            </div>
            <div class="form-error" id="review-error"></div>
            <div class="form-success" id="review-success"></div>
            <input type="hidden" id="review-provider-id" value="<?php echo esc_attr($provider_id); ?>">
            <button class="btn-save-profile" id="btn-submit-review"><?php echo esc_html( ie__( 'Submit Review' ) ); ?></button>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>

</div><!-- /.container -->
</div><!-- /.bg-wrap -->

<?php get_footer(); ?>