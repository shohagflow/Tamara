<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="toast-container" id="ie-toast-container"></div>

<header class="site-header" id="site-header">
    <div class="header-inner">
        <a href="<?php echo esc_url( ie_get_theme_page_url( 'home' ) ); ?>" class="site-logo">
            <img src="<?php echo esc_url( ie_get_header_logo_url() ); ?>"
                 alt="<?php echo esc_attr( ie_get_header_logo_alt() ); ?>" class="custom-logo">
        </a>

        <nav class="site-nav" id="site-nav">
            <?php ie_render_header_nav(); ?>
            <div class="header-actions header-actions-mobile">
                <?php ie_render_header_auth_actions( 'mobile' ); ?>
            </div>
        </nav>

        <div class="header-actions header-actions-desktop">
            <?php ie_render_header_auth_actions( 'desktop' ); ?>
        </div>

        <button class="mobile-menu-toggle" id="mobile-menu-toggle" type="button"
                aria-label="<?php esc_attr_e( 'Toggle menu', IE_TEXT_DOMAIN ); ?>"
                aria-expanded="false"
                aria-controls="site-nav">
            <span></span><span></span><span></span>
        </button>
    </div>
</header>
