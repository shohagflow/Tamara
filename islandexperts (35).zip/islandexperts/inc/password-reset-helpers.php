<?php
/**
 * Password reset helpers for the account sign-in flow.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_password_reset_page_url( $user, $key ) {
    return add_query_arg(
        [
            'action' => 'rp',
            'key'    => $key,
            'login'  => rawurlencode( $user->user_login ),
        ],
        ie_get_theme_page_url( 'account' )
    );
}

function ie_send_password_reset_email( $user ) {
    if ( ! $user instanceof WP_User ) {
        return new WP_Error( 'invalid_user', ie__( 'Invalid user account.' ) );
    }

    $key = get_password_reset_key( $user );
    if ( is_wp_error( $key ) ) {
        return $key;
    }

    $reset_url = ie_get_password_reset_page_url( $user, $key );
    $subject   = ie__( 'Reset your Island Experts password' );
    $message   = sprintf(
        ie__( "Hi %1\$s,\n\nWe received a request to reset your password.\n\nReset your password using this link:\n%2\$s\n\nIf you did not request this, you can ignore this email.\n\nIsland Experts" ),
        $user->display_name ?: $user->user_login,
        $reset_url
    );

    $sent = wp_mail( $user->user_email, $subject, $message );
    if ( ! $sent ) {
        return new WP_Error( 'email_failed', ie__( 'Unable to send the reset email. Please try again later.' ) );
    }

    return true;
}

function ie_get_password_reset_user_from_request() {
    if ( ! isset( $_GET['action'] ) || sanitize_key( wp_unslash( $_GET['action'] ) ) !== 'rp' ) {
        return null;
    }

    $key   = sanitize_text_field( wp_unslash( $_GET['key'] ?? '' ) );
    $login = sanitize_text_field( wp_unslash( $_GET['login'] ?? '' ) );

    if ( ! $key || ! $login ) {
        return new WP_Error( 'invalid_link', ie__( 'This password reset link is invalid or has expired.' ) );
    }

    $user = check_password_reset_key( $key, $login );
    if ( is_wp_error( $user ) ) {
        return new WP_Error( 'invalid_link', ie__( 'This password reset link is invalid or has expired.' ) );
    }

    return $user;
}

function ie_ajax_request_password_reset() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    $email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
    if ( ! $email || ! is_email( $email ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Please enter a valid email address.' ) ] );
    }

    $user = get_user_by( 'email', $email );
    if ( $user ) {
        $result = ie_send_password_reset_email( $user );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }
    }

    wp_send_json_success( [
        'message' => ie__( 'If an account exists for that email, we sent a password reset link.' ),
    ] );
}
add_action( 'wp_ajax_nopriv_ie_request_password_reset', 'ie_ajax_request_password_reset' );
add_action( 'wp_ajax_ie_request_password_reset', 'ie_ajax_request_password_reset' );

function ie_ajax_reset_password() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    $key      = sanitize_text_field( wp_unslash( $_POST['key'] ?? '' ) );
    $login    = sanitize_text_field( wp_unslash( $_POST['login'] ?? '' ) );
    $password = (string) ( $_POST['password'] ?? '' );
    $confirm  = (string) ( $_POST['confirm_password'] ?? '' );

    if ( ! $key || ! $login || ! $password || ! $confirm ) {
        wp_send_json_error( [ 'message' => ie__( 'Please fill in all required fields.' ) ] );
    }

    if ( strlen( $password ) < 6 ) {
        wp_send_json_error( [ 'message' => ie__( 'Password must be at least 6 characters.' ) ] );
    }

    if ( $password !== $confirm ) {
        wp_send_json_error( [ 'message' => ie__( 'Passwords do not match.' ) ] );
    }

    $user = check_password_reset_key( $key, $login );
    if ( is_wp_error( $user ) ) {
        wp_send_json_error( [ 'message' => ie__( 'This password reset link is invalid or has expired.' ) ] );
    }

    reset_password( $user, $password );

    wp_send_json_success( [
        'message'      => ie__( 'Your password has been reset. You can now sign in.' ),
        'redirect_url' => ie_get_theme_page_url( 'account' ),
    ] );
}
add_action( 'wp_ajax_nopriv_ie_reset_password', 'ie_ajax_reset_password' );
add_action( 'wp_ajax_ie_reset_password', 'ie_ajax_reset_password' );
