<?php
/**
 * Provider subscription management helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_format_subscription_date( $timestamp ) {
    $timestamp = (int) $timestamp;

    if ( $timestamp <= 0 ) {
        return '—';
    }

    return date_i18n( get_option( 'date_format' ), $timestamp );
}

function ie_stripe_extract_subscription_period( $subscription ) {
    if ( ! is_array( $subscription ) ) {
        return [
            'start' => 0,
            'end'   => 0,
        ];
    }

    $period_start = (int) ( $subscription['current_period_start'] ?? 0 );
    $period_end   = (int) ( $subscription['current_period_end'] ?? 0 );

    if ( ! empty( $subscription['items']['data'] ) && is_array( $subscription['items']['data'] ) ) {
        foreach ( $subscription['items']['data'] as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }

            $item_start = (int) ( $item['current_period_start'] ?? 0 );
            $item_end   = (int) ( $item['current_period_end'] ?? 0 );

            if ( $item_start > 0 && ( ! $period_start || $item_start < $period_start ) ) {
                $period_start = $item_start;
            }

            if ( $item_end > 0 && $item_end > $period_end ) {
                $period_end = $item_end;
            }
        }
    }

    if ( ! $period_start ) {
        $period_start = (int) ( $subscription['start_date'] ?? $subscription['billing_cycle_anchor'] ?? $subscription['created'] ?? 0 );
    }

    return [
        'start' => $period_start,
        'end'   => $period_end,
    ];
}

function ie_stripe_fetch_subscription( $subscription_id ) {
    $subscription_id = sanitize_text_field( (string) $subscription_id );

    if ( $subscription_id === '' ) {
        return new WP_Error( 'missing_subscription', ie__( 'Missing Stripe subscription ID.' ) );
    }

    return ie_stripe_api_request( 'GET', 'subscriptions/' . rawurlencode( $subscription_id ) );
}

function ie_format_stripe_amount( $amount, $currency = 'usd' ) {
    $amount   = (int) $amount;
    $currency = strtoupper( sanitize_text_field( (string) $currency ) );

    if ( $currency === 'USD' ) {
        return '$' . number_format( $amount / 100, 2 );
    }

    return number_format( $amount / 100, 2 ) . ' ' . $currency;
}

function ie_get_subscription_plan_label( $checkout_plan_id ) {
    $checkout_plan_id = sanitize_text_field( (string) $checkout_plan_id );

    if ( $checkout_plan_id === '' ) {
        return ie__( 'No active plan' );
    }

    $plan = ie_get_subscription_plan_by_checkout_id( $checkout_plan_id );

    if ( $plan ) {
        return ie_get_subscription_checkout_plan_label( $plan );
    }

    $legacy_labels = [
        'basic-monthly'   => ie__( 'Basic Plan (Monthly)' ),
        'basic-annual'    => ie__( 'Basic Plan (Yearly)' ),
        'premium-monthly' => ie__( 'Premium Plan (Monthly)' ),
        'premium-annual'  => ie__( 'Premium Plan (Yearly)' ),
    ];

    return $legacy_labels[ $checkout_plan_id ] ?? ucwords( str_replace( '-', ' ', $checkout_plan_id ) );
}

function ie_sync_user_subscription_from_stripe( $user_id ) {
    $user_id = (int) $user_id;

    if ( ! $user_id || ! ie_stripe_is_enabled() ) {
        return;
    }

    $subscription_id = sanitize_text_field( get_user_meta( $user_id, '_ie_stripe_subscription_id', true ) );

    if ( $subscription_id === '' ) {
        return;
    }

    $subscription = ie_stripe_fetch_subscription( $subscription_id );

    if ( is_wp_error( $subscription ) ) {
        return;
    }

    $period        = ie_stripe_extract_subscription_period( $subscription );
    $period_start  = (int) ( $period['start'] ?? 0 );
    $period_end    = (int) ( $period['end'] ?? 0 );
    $stripe_status = sanitize_key( $subscription['status'] ?? '' );

    if ( $period_start > 0 ) {
        update_user_meta( $user_id, '_ie_subscription_started_at', $period_start );
    }

    if ( $period_end > 0 ) {
        update_user_meta( $user_id, '_ie_subscription_expires_at', $period_end );
    }

    if ( ! empty( $subscription['customer'] ) ) {
        update_user_meta( $user_id, '_ie_stripe_customer_id', sanitize_text_field( $subscription['customer'] ) );
    }

    $wp_status = 'active';

    if ( in_array( $stripe_status, [ 'canceled', 'unpaid', 'incomplete_expired' ], true ) ) {
        $wp_status = $period_end > 0 && $period_end < time() ? 'expired' : 'cancelled';
    } elseif ( in_array( $stripe_status, [ 'past_due', 'incomplete' ], true ) ) {
        $wp_status = 'past_due';
    } elseif ( $period_end > 0 && $period_end < time() ) {
        $wp_status = 'expired';
    }

    update_user_meta( $user_id, '_ie_subscription_status', $wp_status );
}

function ie_user_subscription_is_expired( $user_id ) {
    $user_id = (int) $user_id;
    $status  = sanitize_key( get_user_meta( $user_id, '_ie_subscription_status', true ) ?: 'none' );
    $expires = (int) get_user_meta( $user_id, '_ie_subscription_expires_at', true );

    if ( $status === 'expired' ) {
        return true;
    }

    return $expires > 0 && $expires < time();
}

function ie_get_user_subscription_invoices( $user_id ) {
    $user_id     = (int) $user_id;
    $customer_id = sanitize_text_field( get_user_meta( $user_id, '_ie_stripe_customer_id', true ) );

    if ( $customer_id === '' || ! ie_stripe_is_enabled() ) {
        return [];
    }

    $response = ie_stripe_api_request(
        'GET',
        'invoices',
        [
            'customer' => $customer_id,
            'limit'    => 12,
        ]
    );

    if ( is_wp_error( $response ) || empty( $response['data'] ) || ! is_array( $response['data'] ) ) {
        return [];
    }

    $invoices = [];

    foreach ( $response['data'] as $invoice ) {
        if ( ! is_array( $invoice ) ) {
            continue;
        }

        $invoice_id = sanitize_text_field( $invoice['id'] ?? '' );

        $invoices[] = [
            'id'             => $invoice_id,
            'number'         => sanitize_text_field( $invoice['number'] ?? $invoice_id ),
            'date'           => (int) ( $invoice['created'] ?? 0 ),
            'amount'         => ie_format_stripe_amount( $invoice['total'] ?? 0, $invoice['currency'] ?? 'usd' ),
            'status'         => sanitize_key( $invoice['status'] ?? '' ),
            'has_pdf'        => $invoice_id !== '',
            'stripe_pdf_url' => esc_url_raw( $invoice['invoice_pdf'] ?? '' ),
            'download_url'   => $invoice_id !== '' ? ie_get_branded_invoice_url( $invoice_id, $user_id, true ) : '',
            'pdf_filename'   => sanitize_file_name( ( $invoice['number'] ?? $invoice_id ) . '.pdf' ),
        ];
    }

    return $invoices;
}

function ie_get_invoice_status_label( $status ) {
    $status = sanitize_key( (string) $status );

    $labels = [
        'paid'          => ie__( 'Paid' ),
        'open'          => ie__( 'Open' ),
        'void'          => ie__( 'Void' ),
        'uncollectible' => ie__( 'Uncollectible' ),
        'draft'         => ie__( 'Draft' ),
    ];

    return $labels[ $status ] ?? ucfirst( str_replace( '_', ' ', $status ) );
}

function ie_format_invoice_display_number( $number, $invoice_id = '' ) {
    $number = trim( (string) $number );

    if ( $number !== '' ) {
        return strpos( strtoupper( $number ), 'INV' ) === 0 ? $number : sprintf( '#%s', $number );
    }

    if ( $invoice_id !== '' ) {
        return sprintf( '#%s', strtoupper( substr( sanitize_text_field( $invoice_id ), -8 ) ) );
    }

    return '—';
}

function ie_get_user_subscription_management( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();

    if ( ! $user_id ) {
        return [];
    }

    ie_sync_user_subscription_from_stripe( $user_id );

    $plan_id    = sanitize_text_field( get_user_meta( $user_id, '_ie_subscription_plan', true ) ?: '' );
    $billing    = sanitize_text_field( get_user_meta( $user_id, '_ie_subscription_billing', true ) ?: '' );
    $status     = sanitize_key( get_user_meta( $user_id, '_ie_subscription_status', true ) ?: 'none' );
    $started_at = (int) get_user_meta( $user_id, '_ie_subscription_started_at', true );
    $expires_at = (int) get_user_meta( $user_id, '_ie_subscription_expires_at', true );

    if ( ( ! $started_at || ! $expires_at ) && ie_stripe_is_enabled() ) {
        $subscription_id = sanitize_text_field( get_user_meta( $user_id, '_ie_stripe_subscription_id', true ) );

        if ( $subscription_id !== '' ) {
            $subscription = ie_stripe_fetch_subscription( $subscription_id );

            if ( ! is_wp_error( $subscription ) ) {
                $period = ie_stripe_extract_subscription_period( $subscription );

                if ( ! $started_at && ! empty( $period['start'] ) ) {
                    $started_at = (int) $period['start'];
                    update_user_meta( $user_id, '_ie_subscription_started_at', $started_at );
                }

                if ( ! $expires_at && ! empty( $period['end'] ) ) {
                    $expires_at = (int) $period['end'];
                    update_user_meta( $user_id, '_ie_subscription_expires_at', $expires_at );
                }
            }
        }
    }

    $is_expired = ie_user_subscription_is_expired( $user_id );
    $has_plan   = $plan_id !== '' && $status !== 'none';

    if ( $is_expired && $status === 'active' ) {
        $status = 'expired';
        update_user_meta( $user_id, '_ie_subscription_status', 'expired' );
    }

    $is_active = $has_plan && ! $is_expired && in_array( $status, [ 'active', 'past_due' ], true );

    $plan_config = $plan_id ? ie_get_subscription_plan_by_checkout_id( $plan_id ) : null;
    $price_label = '';

    if ( $plan_config ) {
        $billing_data = ie_admin_get_plan_billing( $plan_config );
        $price_label  = ie_format_subscription_price( $billing_data['price'] );
    }

    $trial          = ie_get_provider_free_trial_data( $user_id );
    $on_free_trial  = ie_provider_on_free_trial_plan( $user_id );
    $trial_expired  = ! $has_plan && ! empty( $trial['is_expired'] );
    $plan_label     = ie__( 'No active plan' );

    if ( $on_free_trial ) {
        $plan_label   = $trial['plan_label'];
        $status       = 'trial';
        $is_active    = true;
        $started_at   = (int) $trial['started_at'];
        $expires_at   = (int) $trial['expires_at'];
        $started_label = $trial['started_label'];
        $expires_label = $trial['expires_label'];
    }

    $status_labels = [
        'active'    => ie__( 'Active' ),
        'past_due'  => ie__( 'Past Due' ),
        'expired'   => ie__( 'Expired' ),
        'cancelled' => ie__( 'Cancelled' ),
        'none'      => ie__( 'Inactive' ),
        'trial'     => ie__( 'Free Trial Active' ),
        'trial_expired' => ie__( 'Free Trial Finished' ),
    ];

    if ( $trial_expired ) {
        $plan_label    = ie__( 'Free Account' );
        $status        = 'trial_expired';
        $status_label  = $status_labels['trial_expired'];
        $started_at    = (int) $trial['started_at'];
        $expires_at    = (int) $trial['expires_at'];
        $started_label = $trial['started_label'];
        $expires_label = $trial['expires_label'];
    }

    return [
        'plan'              => $plan_id,
        'billing'           => $billing,
        'status'            => $status,
        'is_active'         => $is_active,
        'is_expired'        => $is_expired,
        'has_plan'          => $has_plan,
        'on_free_trial'     => $on_free_trial,
        'trial_expired'     => $trial_expired,
        'has_benefits'      => ie_provider_has_plan_benefits( $user_id ),
        'free_trial'        => $trial,
        'plan_label'        => $has_plan ? ie_get_subscription_plan_label( $plan_id ) : ( $on_free_trial || $trial_expired ? $plan_label : ie__( 'No active plan' ) ),
        'billing_label'     => $billing === 'yearly' ? ie__( 'Yearly' ) : ( $billing === 'monthly' ? ie__( 'Monthly' ) : '—' ),
        'price_label'       => $price_label,
        'status_label'      => $status_labels[ $status ] ?? ie__( 'Inactive' ),
        'started_at'        => $started_at,
        'expires_at'        => $expires_at,
        'started_label'     => $started_at ? ie_format_subscription_date( $started_at ) : ( $started_label ?? '—' ),
        'expires_label'     => $expires_at ? ie_format_subscription_date( $expires_at ) : ( $expires_label ?? '—' ),
        'invoices'          => $has_plan ? ie_get_user_subscription_invoices( $user_id ) : [],
        'can_remove'        => $has_plan && $is_expired,
        'stripe_subscription_id' => sanitize_text_field( get_user_meta( $user_id, '_ie_stripe_subscription_id', true ) ),
    ];
}

function ie_clear_user_subscription( $user_id ) {
    $user_id = (int) $user_id;

    if ( ! $user_id ) {
        return false;
    }

    $keys = [
        '_ie_subscription_plan',
        '_ie_subscription_billing',
        '_ie_subscription_status',
        '_ie_subscription_started_at',
        '_ie_subscription_expires_at',
        '_ie_stripe_subscription_id',
        '_ie_stripe_customer_id',
    ];

    foreach ( $keys as $key ) {
        delete_user_meta( $user_id, $key );
    }

    return true;
}

function ie_get_stripe_invoice_for_user( $user_id, $invoice_id ) {
    $user_id     = (int) $user_id;
    $invoice_id  = sanitize_text_field( (string) $invoice_id );
    $customer_id = sanitize_text_field( get_user_meta( $user_id, '_ie_stripe_customer_id', true ) );

    if ( $invoice_id === '' || $customer_id === '' || ! ie_stripe_is_enabled() ) {
        return new WP_Error( 'invalid_invoice', ie__( 'Invoice not found.' ) );
    }

    $invoice = ie_stripe_api_request( 'GET', 'invoices/' . rawurlencode( $invoice_id ) );

    if ( is_wp_error( $invoice ) ) {
        return $invoice;
    }

    if ( sanitize_text_field( $invoice['customer'] ?? '' ) !== $customer_id ) {
        return new WP_Error( 'forbidden', ie__( 'You do not have access to this invoice.' ) );
    }

    return $invoice;
}

function ie_ajax_download_subscription_invoice() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Permission denied.' ) ] );
    }

    $invoice_id = sanitize_text_field( wp_unslash( $_POST['invoice_id'] ?? '' ) );
    $user       = wp_get_current_user();
    $invoice    = ie_get_stripe_invoice_for_user( $user->ID, $invoice_id );

    if ( is_wp_error( $invoice ) ) {
        wp_send_json_error( [ 'message' => $invoice->get_error_message() ] );
    }

    $invoice_data = ie_prepare_branded_invoice_data( $invoice, $user );

    wp_send_json_success( [
        'url'      => esc_url_raw( ie_get_branded_invoice_url( $invoice_id, $user->ID, true ) ),
        'filename' => sanitize_file_name( $invoice_data['pdf_filename'] ?? 'invoice.pdf' ),
    ] );
}
add_action( 'wp_ajax_ie_download_subscription_invoice', 'ie_ajax_download_subscription_invoice' );

function ie_ajax_remove_expired_subscription() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Permission denied.' ) ] );
    }

    $user_id = get_current_user_id();

    if ( ! ie_user_subscription_is_expired( $user_id ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Only expired subscriptions can be removed.' ) ] );
    }

    ie_clear_user_subscription( $user_id );

    wp_send_json_success( [
        'message' => ie__( 'Expired subscription removed successfully.' ),
    ] );
}
add_action( 'wp_ajax_ie_remove_expired_subscription', 'ie_ajax_remove_expired_subscription' );

function ie_render_provider_subscription_status_badge( $subscription ) {
    $status = sanitize_key( $subscription['status'] ?? 'none' );
    $class  = 'provider-sub-status';

    if ( ! empty( $subscription['on_free_trial'] ) ) {
        $class .= ' is-trial';
        echo '<span class="' . esc_attr( $class ) . '">' . esc_html( $subscription['status_label'] ?? ie__( 'Free Trial Active' ) ) . '</span>';
        return;
    }

    if ( ! empty( $subscription['trial_expired'] ) && empty( $subscription['has_plan'] ) ) {
        $class .= ' is-expired';
        echo '<span class="' . esc_attr( $class ) . '">' . esc_html( $subscription['status_label'] ?? ie__( 'Free Trial Finished' ) ) . '</span>';
        return;
    }

    if ( ! empty( $subscription['is_active'] ) ) {
        $class .= ' is-active';
    } elseif ( ! empty( $subscription['is_expired'] ) || $status === 'expired' ) {
        $class .= ' is-expired';
    } elseif ( $status === 'cancelled' ) {
        $class .= ' is-cancelled';
    } elseif ( $status === 'past_due' ) {
        $class .= ' is-warning';
    }

    echo '<span class="' . esc_attr( $class ) . '">' . esc_html( $subscription['status_label'] ?? ie__( 'Inactive' ) ) . '</span>';
}
