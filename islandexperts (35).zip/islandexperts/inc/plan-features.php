<?php
/**
 * Subscription plan feature resolution and provider capability checks.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'IE_PLAN_LIMITED_MESSAGES', 30 );
define( 'IE_PLAN_BASIC_MAX_SERVICES', 3 );

function ie_get_plan_feature_key_patterns() {
    return [
        'messaging_unlimited' => [ 'unlimited messag', 'unlimited chat' ],
        'messaging_limited'   => [ 'limited messag', 'limited chat' ],
        'profile_featured'      => [ 'featured profile', 'featured listing', 'premium visibility', 'featured provider' ],
        'profile_basic'         => [ 'basic profile', 'profile access', 'public profile', 'business profile' ],
        'priority_support'      => [ 'priority support' ],
        'services_manage'       => [ 'service listing', 'manage service', 'services management', 'listing management' ],
        'work_gallery'          => [ 'work gallery', 'previous work', 'portfolio', 'work preview' ],
        'social_links'          => [ 'social link', 'social media' ],
        'chat_attachments'      => [ 'attachment', 'file sharing', 'media sharing', 'chat file' ],
    ];
}

function ie_resolve_plan_feature_key( $text ) {
    $normalized = strtolower( trim( wp_strip_all_tags( (string) $text ) ) );

    if ( $normalized === '' ) {
        return '';
    }

    foreach ( ie_get_plan_feature_key_patterns() as $key => $needles ) {
        foreach ( $needles as $needle ) {
            if ( strpos( $normalized, $needle ) !== false ) {
                return $key;
            }
        }
    }

    return '';
}

function ie_get_default_plan_feature_keys( $checkout_plan_id ) {
    $checkout_plan_id = sanitize_text_field( (string) $checkout_plan_id );

    if ( strpos( $checkout_plan_id, 'premium' ) !== false ) {
        return [
            'profile_basic',
            'profile_featured',
            'messaging_unlimited',
            'services_manage',
            'work_gallery',
            'social_links',
            'chat_attachments',
            'priority_support',
        ];
    }

    if ( strpos( $checkout_plan_id, 'basic' ) !== false ) {
        return [
            'profile_basic',
            'messaging_limited',
            'services_manage',
            'social_links',
            'work_gallery',
        ];
    }

    return [ 'profile_basic' ];
}

function ie_provider_has_active_subscription( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    $sub     = ie_get_user_subscription( $user_id );

    return ! empty( $sub['is_active'] );
}

function ie_get_provider_plan_feature_keys( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();

    if ( ! $user_id ) {
        return [];
    }

    if ( ie_provider_has_active_free_trial( $user_id ) && ! ie_provider_has_active_subscription( $user_id ) ) {
        return ie_get_basic_plan_feature_keys();
    }

    $plan_checkout_id = sanitize_text_field( get_user_meta( $user_id, '_ie_subscription_plan', true ) ?: '' );

    if ( $plan_checkout_id === '' ) {
        if ( ie_provider_has_active_subscription( $user_id ) ) {
            return ie_get_default_plan_feature_keys( 'plan-basic-monthly' );
        }

        return [];
    }

    $plan   = ie_get_subscription_plan_by_checkout_id( $plan_checkout_id );
    $keys   = [];

    if ( $plan ) {
        foreach ( ie_admin_get_plan_editor_features( $plan ) as $feature ) {
            $key = sanitize_key( $feature['key'] ?? '' );

            if ( $key === '' ) {
                $key = ie_resolve_plan_feature_key( $feature['text'] ?? '' );
            }

            if ( $key !== '' ) {
                $keys[] = $key;
            }
        }
    }

    if ( ! $keys ) {
        $keys = ie_get_default_plan_feature_keys( $plan_checkout_id );
    } else {
        $defaults = ie_get_default_plan_feature_keys( $plan_checkout_id );

        foreach ( $defaults as $default_key ) {
            if ( ! in_array( $default_key, $keys, true ) ) {
                $keys[] = $default_key;
            }
        }
    }

    $keys = array_values( array_unique( $keys ) );

    if ( in_array( 'messaging_unlimited', $keys, true ) ) {
        $keys = array_values( array_diff( $keys, [ 'messaging_limited' ] ) );
    }

    return $keys;
}

function ie_provider_can_use_feature( $user_id, $feature_key ) {
    $user_id     = (int) $user_id;
    $feature_key = sanitize_key( (string) $feature_key );

    if ( ! $user_id || $feature_key === '' || ! ie_provider_has_plan_benefits( $user_id ) ) {
        return false;
    }

    return in_array( $feature_key, ie_get_provider_plan_feature_keys( $user_id ), true );
}

function ie_provider_can_appear_in_directory( $user_id ) {
    $user_id = (int) $user_id;

    if ( ! $user_id || ie_is_dummy_provider_user( $user_id ) ) {
        return false;
    }

    $provider_post = ie_get_provider_post_by_user( $user_id );
    if ( ! $provider_post || ! ie_is_registered_provider_listing( $provider_post->ID ) ) {
        return false;
    }

    if ( $provider_post->post_status !== 'publish' ) {
        return false;
    }

    if ( ie_subscription_show_all_users() ) {
        return true;
    }

    ie_ensure_provider_free_trial_started( $user_id );

    if ( ie_provider_has_active_subscription( $user_id ) ) {
        return true;
    }

    if ( ie_provider_has_active_free_trial( $user_id ) ) {
        return true;
    }

    if ( ie_provider_free_trial_is_expired( $user_id ) ) {
        return false;
    }

    return (bool) get_post_meta( $provider_post->ID, '_ie_registered_listing', true );
}

function ie_provider_has_featured_listing( $user_id ) {
    return ie_provider_can_use_feature( $user_id, 'profile_featured' );
}

function ie_provider_has_priority_support( $user_id ) {
    return ie_provider_can_use_feature( $user_id, 'priority_support' );
}

function ie_get_provider_message_period_start( $user_id ) {
    $trial_start = (int) get_user_meta( $user_id, '_ie_free_trial_started_at', true );

    if ( ie_provider_has_active_free_trial( $user_id ) && $trial_start > 0 ) {
        return $trial_start;
    }

    $started = (int) get_user_meta( $user_id, '_ie_subscription_started_at', true );
    $expires = (int) get_user_meta( $user_id, '_ie_subscription_expires_at', true );

    if ( $started > 0 ) {
        return $started;
    }

    if ( $expires > 0 ) {
        $billing = sanitize_text_field( get_user_meta( $user_id, '_ie_subscription_billing', true ) ?: 'monthly' );
        $period  = $billing === 'yearly' ? YEAR_IN_SECONDS : MONTH_IN_SECONDS;

        return max( 0, $expires - $period );
    }

    return strtotime( '-30 days', current_time( 'timestamp' ) );
}

function ie_get_provider_sent_message_count( $user_id, $period_start = null ) {
    $user_id = (int) $user_id;
    $post    = ie_get_provider_post_by_user( $user_id );

    if ( ! $post ) {
        return 0;
    }

    if ( $period_start === null ) {
        $period_start = ie_get_provider_message_period_start( $user_id );
    }

    $query = new WP_Query( [
        'post_type'              => 'ie_message',
        'post_status'            => 'publish',
        'posts_per_page'         => -1,
        'fields'                 => 'ids',
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
        'date_query'             => [
            [
                'after'     => gmdate( 'Y-m-d H:i:s', (int) $period_start ),
                'inclusive' => true,
            ],
        ],
        'meta_query'             => [
            'relation' => 'AND',
            [
                'key'   => '_ie_provider_id',
                'value' => (int) $post->ID,
            ],
            [
                'key'   => '_ie_sender',
                'value' => 'provider',
            ],
        ],
    ] );

    return (int) $query->post_count;
}

function ie_get_provider_messaging_quota( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();

    if ( ! $user_id ) {
        return [
            'unlimited' => false,
            'limit'     => 0,
            'used'      => 0,
            'remaining' => 0,
            'can_send'  => false,
        ];
    }

    if ( ! ie_provider_has_plan_benefits( $user_id ) ) {
        return [
            'unlimited' => false,
            'limit'     => 0,
            'used'      => 0,
            'remaining' => 0,
            'can_send'  => false,
        ];
    }

    if ( ie_provider_on_free_trial_plan( $user_id ) ) {
        $limit = (int) apply_filters( 'ie_plan_limited_messages', IE_PLAN_LIMITED_MESSAGES, $user_id );
        $used  = ie_get_provider_sent_message_count( $user_id );

        return [
            'unlimited' => false,
            'limit'     => $limit,
            'used'      => $used,
            'remaining' => max( 0, $limit - $used ),
            'can_send'  => $used < $limit,
            'trial'     => true,
        ];
    }

    if ( ie_provider_can_use_feature( $user_id, 'messaging_unlimited' ) ) {
        return [
            'unlimited' => true,
            'limit'     => 0,
            'used'      => ie_get_provider_sent_message_count( $user_id ),
            'remaining' => -1,
            'can_send'  => true,
        ];
    }

    if ( ! ie_provider_can_use_feature( $user_id, 'messaging_limited' ) ) {
        return [
            'unlimited' => false,
            'limit'     => 0,
            'used'      => 0,
            'remaining' => 0,
            'can_send'  => false,
        ];
    }

    $limit = (int) apply_filters( 'ie_plan_limited_messages', IE_PLAN_LIMITED_MESSAGES, $user_id );
    $used  = ie_get_provider_sent_message_count( $user_id );

    return [
        'unlimited' => false,
        'limit'     => $limit,
        'used'      => $used,
        'remaining' => max( 0, $limit - $used ),
        'can_send'  => $used < $limit,
    ];
}

function ie_provider_can_send_message( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    $quota   = ie_get_provider_messaging_quota( $user_id );

    return ! empty( $quota['can_send'] );
}

function ie_get_provider_services_limit( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();

    if ( ! ie_provider_has_plan_benefits( $user_id ) ) {
        return 0;
    }

    if ( ! ie_provider_can_use_feature( $user_id, 'services_manage' ) ) {
        return 0;
    }

    $plan_id = sanitize_text_field( get_user_meta( $user_id, '_ie_subscription_plan', true ) ?: '' );

    if ( strpos( $plan_id, 'premium' ) !== false || ie_provider_can_use_feature( $user_id, 'profile_featured' ) ) {
        return 0;
    }

    return (int) apply_filters( 'ie_plan_basic_max_services', IE_PLAN_BASIC_MAX_SERVICES, $user_id );
}

function ie_get_provider_work_gallery_limit( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();

    if ( ! ie_provider_can_use_feature( $user_id, 'work_gallery' ) ) {
        return 0;
    }

    return ie_get_provider_work_gallery_max();
}

function ie_get_provider_plan_features_ui( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    $keys    = ie_get_provider_plan_feature_keys( $user_id );
    $plan_id = sanitize_text_field( get_user_meta( $user_id, '_ie_subscription_plan', true ) ?: '' );
    $plan    = $plan_id ? ie_get_subscription_plan_by_checkout_id( $plan_id ) : null;
    $items   = [];

    if ( ! $plan && ie_provider_on_free_trial_plan( $user_id ) ) {
        $plan = ie_get_subscription_plan_by_checkout_id( 'plan-basic-monthly' );
    }

    if ( $plan ) {
        foreach ( ie_admin_get_plan_editor_features( $plan ) as $feature ) {
            $text = trim( (string) ( $feature['text'] ?? '' ) );

            if ( $text === '' ) {
                continue;
            }

            $key = sanitize_key( $feature['key'] ?? '' );

            if ( $key === '' ) {
                $key = ie_resolve_plan_feature_key( $text );
            }

            $enabled = $key === '' ? ie_provider_has_plan_benefits( $user_id ) : ie_provider_can_use_feature( $user_id, $key );

            $items[] = [
                'key'     => $key,
                'text'    => $text,
                'icon'    => ie_admin_resolve_plan_feature_icon( $feature['icon'] ?? 'fa-solid fa-check' ),
                'enabled' => $enabled,
            ];
        }
    }

    return $items;
}

function ie_get_provider_plan_access_payload( $user_id = null ) {
    $user_id = $user_id ?: get_current_user_id();
    $trial   = ie_get_provider_free_trial_data( $user_id );

    return [
        'active'        => ie_provider_has_plan_benefits( $user_id ),
        'paid'          => ie_provider_has_active_subscription( $user_id ),
        'trialActive'   => ! empty( $trial['is_active'] ),
        'trialExpired'  => ! empty( $trial['is_expired'] ),
        'features'      => ie_get_provider_plan_feature_keys( $user_id ),
        'messaging'     => ie_get_provider_messaging_quota( $user_id ),
        'servicesMax'   => ie_get_provider_services_limit( $user_id ),
        'galleryMax'    => ie_get_provider_work_gallery_limit( $user_id ),
        'socialLinks'   => ie_provider_can_use_feature( $user_id, 'social_links' ),
        'attachments'   => ie_provider_can_use_feature( $user_id, 'chat_attachments' ),
        'priceUrl'      => ie_get_theme_page_url( 'price' ),
        'trialExpires'  => (int) ( $trial['expires_at'] ?? 0 ),
    ];
}

function ie_provider_plan_error( $feature_key = '' ) {
    $user_id = get_current_user_id();

    if ( $user_id && ie_provider_free_trial_is_expired( $user_id ) && ! ie_provider_has_active_subscription( $user_id ) ) {
        return ie__( 'Your free trial has finished. Subscribe to a plan to access premium features.' );
    }

    $messages = [
        'subscription'      => ie__( 'An active subscription or free trial is required for this feature.' ),
        'messaging_limited' => ie__( 'You have reached your plan messaging limit. Upgrade your plan to send more messages.' ),
        'messaging'         => ie__( 'Messaging is not included in your current plan.' ),
        'profile_basic'     => ie__( 'Your plan does not include public profile listing.' ),
        'profile_featured'  => ie__( 'Featured profile is not included in your current plan.' ),
        'services_manage'   => ie__( 'Service management is not included in your current plan.' ),
        'work_gallery'      => ie__( 'Work gallery uploads are not included in your current plan.' ),
        'social_links'      => ie__( 'Social links are not included in your current plan.' ),
        'chat_attachments'  => ie__( 'Chat attachments are not included in your current plan.' ),
    ];

    if ( $feature_key && isset( $messages[ $feature_key ] ) ) {
        return $messages[ $feature_key ];
    }

    return ie__( 'This feature is not available on your current plan.' );
}

function ie_enqueue_provider_plan_access_script() {
    if ( ! is_page_template( 'templates/provider-profile.php' ) || ! is_user_logged_in() ) {
        return;
    }

    wp_localize_script( 'island-experts-main', 'IE_PROVIDER_PLAN', ie_get_provider_plan_access_payload() );
}
add_action( 'wp_enqueue_scripts', 'ie_enqueue_provider_plan_access_script', 20 );
