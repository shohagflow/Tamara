<?php
/**
 * Provider free trial and pricing page subscription settings helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_subscription_show_all_users() {
    $settings = ie_get_subscription_settings();

    return ! empty( $settings['default_show_all_users'] ) && $settings['default_show_all_users'] === '1';
}

function ie_get_configured_free_trial_days() {
    $settings = ie_get_subscription_settings();
    $days     = (int) ( $settings['free_trial_days'] ?? 0 );

    return max( 0, min( 365, $days ) );
}

function ie_get_basic_plan_feature_keys() {
    return ie_get_default_plan_feature_keys( 'plan-basic-monthly' );
}

function ie_maybe_expire_provider_free_trial( $user_id = null ) {
    $user_id = (int) ( $user_id ?: get_current_user_id() );

    if ( ! $user_id ) {
        return;
    }

    if ( ie_provider_has_active_subscription( $user_id ) ) {
        return;
    }

    $status = sanitize_key( get_user_meta( $user_id, '_ie_free_trial_status', true ) ?: 'none' );

    if ( $status !== 'active' ) {
        return;
    }

    $expires_at = (int) get_user_meta( $user_id, '_ie_free_trial_expires_at', true );

    if ( $expires_at > 0 && $expires_at <= time() ) {
        update_user_meta( $user_id, '_ie_free_trial_status', 'expired' );
    }
}

function ie_ensure_provider_free_trial_started( $user_id = null ) {
    $user_id = (int) ( $user_id ?: get_current_user_id() );

    if ( ! $user_id || ie_get_user_type( $user_id ) !== 'provider' ) {
        return false;
    }

    if ( ie_provider_has_active_subscription( $user_id ) ) {
        return false;
    }

    $status = sanitize_key( get_user_meta( $user_id, '_ie_free_trial_status', true ) ?: 'none' );

    if ( $status !== 'none' || ie_get_configured_free_trial_days() < 1 ) {
        return false;
    }

    return ie_start_provider_free_trial( $user_id );
}

function ie_sync_directory_provider_trials() {
    static $synced = false;

    if ( $synced || ie_get_configured_free_trial_days() < 1 ) {
        return;
    }

    $synced = true;

    $provider_ids = get_posts(
        [
            'post_type'              => 'ie_provider',
            'post_status'            => 'publish',
            'posts_per_page'         => -1,
            'fields'                 => 'ids',
            'no_found_rows'          => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]
    );

    foreach ( $provider_ids as $post_id ) {
        if ( ! ie_is_registered_provider_listing( $post_id ) ) {
            continue;
        }

        $author_id = (int) get_post_field( 'post_author', $post_id );
        ie_ensure_provider_free_trial_started( $author_id );
    }
}

function ie_start_provider_free_trial( $user_id ) {
    $user_id = (int) $user_id;
    $days    = ie_get_configured_free_trial_days();

    if ( ! $user_id || $days < 1 ) {
        return false;
    }

    if ( ie_get_user_type( $user_id ) !== 'provider' ) {
        return false;
    }

    if ( ie_provider_has_active_subscription( $user_id ) ) {
        return false;
    }

    $existing_status = sanitize_key( get_user_meta( $user_id, '_ie_free_trial_status', true ) ?: 'none' );

    if ( in_array( $existing_status, [ 'active', 'expired' ], true ) ) {
        return false;
    }

    $started_at = time();
    $expires_at = strtotime( '+' . $days . ' days', $started_at );

    update_user_meta( $user_id, '_ie_free_trial_started_at', $started_at );
    update_user_meta( $user_id, '_ie_free_trial_expires_at', $expires_at );
    update_user_meta( $user_id, '_ie_free_trial_status', 'active' );
    update_user_meta( $user_id, '_ie_free_trial_days', $days );

    return true;
}

function ie_provider_has_active_free_trial( $user_id = null ) {
    $user_id = (int) ( $user_id ?: get_current_user_id() );

    if ( ! $user_id || ie_provider_has_active_subscription( $user_id ) ) {
        return false;
    }

    ie_maybe_expire_provider_free_trial( $user_id );

    return sanitize_key( get_user_meta( $user_id, '_ie_free_trial_status', true ) ?: 'none' ) === 'active';
}

function ie_provider_free_trial_is_expired( $user_id = null ) {
    $user_id = (int) ( $user_id ?: get_current_user_id() );

    if ( ! $user_id || ie_provider_has_active_subscription( $user_id ) ) {
        return false;
    }

    ie_maybe_expire_provider_free_trial( $user_id );

    return sanitize_key( get_user_meta( $user_id, '_ie_free_trial_status', true ) ?: 'none' ) === 'expired';
}

function ie_provider_has_plan_benefits( $user_id = null ) {
    $user_id = (int) ( $user_id ?: get_current_user_id() );

    if ( ! $user_id ) {
        return false;
    }

    ie_ensure_provider_free_trial_started( $user_id );

    if ( ie_provider_has_active_subscription( $user_id ) ) {
        return true;
    }

    return ie_provider_has_active_free_trial( $user_id );
}

function ie_get_provider_free_trial_data( $user_id = null ) {
    $user_id = (int) ( $user_id ?: get_current_user_id() );
    $days    = ie_get_configured_free_trial_days();

    ie_maybe_expire_provider_free_trial( $user_id );

    $status     = sanitize_key( get_user_meta( $user_id, '_ie_free_trial_status', true ) ?: 'none' );
    $started_at = (int) get_user_meta( $user_id, '_ie_free_trial_started_at', true );
    $expires_at = (int) get_user_meta( $user_id, '_ie_free_trial_expires_at', true );
    $is_active  = $status === 'active';
    $is_expired = $status === 'expired';
    $remaining  = 0;

    if ( $is_active && $expires_at > time() ) {
        $remaining = (int) ceil( ( $expires_at - time() ) / DAY_IN_SECONDS );
    }

    return [
        'configured_days' => $days,
        'status'          => $status,
        'is_active'       => $is_active,
        'is_expired'      => $is_expired,
        'started_at'      => $started_at,
        'expires_at'      => $expires_at,
        'started_label'   => $started_at ? ie_format_subscription_date( $started_at ) : '—',
        'expires_label'   => $expires_at ? ie_format_subscription_date( $expires_at ) : '—',
        'days_remaining'  => max( 0, $remaining ),
        'plan_label'      => ie__( 'Basic Plan (Free Trial)' ),
    ];
}

function ie_provider_on_free_trial_plan( $user_id = null ) {
    return ie_provider_has_active_free_trial( $user_id ) && ! ie_provider_has_active_subscription( $user_id );
}
