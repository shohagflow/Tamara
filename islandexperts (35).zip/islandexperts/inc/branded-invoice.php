<?php
/**
 * Branded subscription invoice rendering and PDF download.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_invoice_brand_context() {
    $settings = ie_get_theme_settings();
    $global   = $settings['global'] ?? [];
    $defaults = ie_get_theme_global_defaults();

    $primary = ie_sanitize_theme_hex_color( $global['color_primary'] ?? '', $defaults['color_primary'] );
    $accent  = ie_sanitize_theme_hex_color( $global['color_accent'] ?? '', $defaults['color_accent'] );
    $logo    = ie_get_header_logo_url();

    if ( $logo === '' ) {
        $logo = ie_get_footer_logo_url();
    }

    if ( $logo !== '' && ! preg_match( '#^https?://#i', $logo ) ) {
        $logo = home_url( $logo );
    }

    return [
        'site_name'     => get_bloginfo( 'name' ),
        'site_url'      => home_url( '/' ),
        'site_email'    => get_option( 'admin_email' ),
        'logo_url'      => $logo,
        'primary'       => $primary,
        'primary_dark'  => ie_theme_adjust_hex( $primary, 0.18 ),
        'primary_light' => ie_theme_adjust_hex( $primary, 0.9, true ),
        'accent'        => $accent,
    ];
}

function ie_prepare_branded_invoice_data( $invoice, $user = null ) {
    if ( ! is_array( $invoice ) || ! $user instanceof WP_User ) {
        return [];
    }

    $brand         = ie_get_invoice_brand_context();
    $invoice_id    = sanitize_text_field( $invoice['id'] ?? '' );
    $invoice_number = ie_format_invoice_display_number( $invoice['number'] ?? '', $invoice_id );
    $status        = sanitize_key( $invoice['status'] ?? '' );
    $currency      = strtoupper( sanitize_text_field( $invoice['currency'] ?? 'usd' ) );
    $subtotal      = ie_format_stripe_amount( $invoice['subtotal'] ?? 0, $currency );
    $total         = ie_format_stripe_amount( $invoice['total'] ?? 0, $currency );
    $created       = (int) ( $invoice['created'] ?? 0 );
    $period_start  = (int) ( $invoice['period_start'] ?? 0 );
    $period_end    = (int) ( $invoice['period_end'] ?? 0 );
    $lines         = [];

    if ( ! empty( $invoice['lines']['data'] ) && is_array( $invoice['lines']['data'] ) ) {
        foreach ( $invoice['lines']['data'] as $line ) {
            if ( ! is_array( $line ) ) {
                continue;
            }

            $description = sanitize_text_field( $line['description'] ?? ie__( 'Subscription charge' ) );
            $amount      = ie_format_stripe_amount( $line['amount'] ?? 0, $currency );

            $lines[] = [
                'description' => $description,
                'amount'      => $amount,
            ];
        }
    }

    if ( ! $lines ) {
        $lines[] = [
            'description' => ie_get_subscription_plan_label(
                sanitize_text_field( get_user_meta( $user->ID, '_ie_subscription_plan', true ) ?: '' )
            ),
            'amount'      => $total,
        ];
    }

    return array_merge(
        $brand,
        [
            'invoice_id'     => $invoice_id,
            'invoice_number' => $invoice_number,
            'status'         => $status,
            'status_label'   => ie_get_invoice_status_label( $status ),
            'date_label'     => ie_format_subscription_date( $created ),
            'period_label'   => $period_start && $period_end
                ? sprintf(
                    '%1$s – %2$s',
                    ie_format_subscription_date( $period_start ),
                    ie_format_subscription_date( $period_end )
                )
                : '—',
            'customer_name'  => $user->display_name,
            'customer_email' => $user->user_email,
            'subtotal'       => $subtotal,
            'total'          => $total,
            'lines'          => $lines,
            'pdf_filename'   => sanitize_file_name(
                strtolower( preg_replace( '/[^a-z0-9]+/i', '-', $brand['site_name'] ) )
                . '-invoice-'
                . strtolower( preg_replace( '/[^a-z0-9]+/i', '-', $invoice_number ) )
                . '.pdf'
            ),
        ]
    );
}

function ie_get_branded_invoice_url( $invoice_id, $user_id = null, $download = false ) {
    $invoice_id = sanitize_text_field( (string) $invoice_id );
    $user_id    = $user_id ?: get_current_user_id();

    if ( $invoice_id === '' || ! $user_id ) {
        return '';
    }

    $args = [
        'action'     => 'ie_view_branded_invoice',
        'invoice_id' => $invoice_id,
        'nonce'      => wp_create_nonce( 'ie_invoice_' . $invoice_id ),
    ];

    if ( $download ) {
        $args['download'] = '1';
    }

    return add_query_arg( $args, admin_url( 'admin-ajax.php' ) );
}

function ie_render_branded_invoice_document( $data ) {
    if ( ! $data ) {
        return;
    }
    ?>
    <div id="ie-branded-invoice-document" class="ie-branded-invoice-document">
        <div class="ie-branded-invoice-document__header" style="background: linear-gradient(135deg, <?php echo esc_attr( $data['primary'] ); ?> 0%, <?php echo esc_attr( $data['primary_dark'] ); ?> 100%);">
            <div class="ie-branded-invoice-document__brand">
                <?php if ( ! empty( $data['logo_url'] ) ) : ?>
                    <img src="<?php echo esc_url( $data['logo_url'] ); ?>" alt="<?php echo esc_attr( $data['site_name'] ); ?>" class="ie-branded-invoice-document__logo" crossorigin="anonymous">
                <?php else : ?>
                    <div class="ie-branded-invoice-document__logo-fallback" aria-hidden="true">
                        <?php echo esc_html( mb_strtoupper( mb_substr( $data['site_name'], 0, 1 ) ) ); ?>
                    </div>
                <?php endif; ?>
                <div>
                    <h1><?php echo esc_html( $data['site_name'] ); ?></h1>
                    <p><?php echo esc_html( $data['site_url'] ); ?></p>
                </div>
            </div>
            <div class="ie-branded-invoice-document__title-wrap">
                <span class="ie-branded-invoice-document__eyebrow"><?php echo esc_html( ie__( 'Official Receipt' ) ); ?></span>
                <h2><?php echo esc_html( ie__( 'Subscription Invoice' ) ); ?></h2>
            </div>
        </div>

        <div class="ie-branded-invoice-document__body">
            <div class="ie-branded-invoice-document__meta-grid">
                <div>
                    <span class="ie-branded-invoice-document__label"><?php echo esc_html( ie__( 'Invoice Number' ) ); ?></span>
                    <strong><?php echo esc_html( $data['invoice_number'] ); ?></strong>
                </div>
                <div>
                    <span class="ie-branded-invoice-document__label"><?php echo esc_html( ie__( 'Invoice Date' ) ); ?></span>
                    <strong><?php echo esc_html( $data['date_label'] ); ?></strong>
                </div>
                <div>
                    <span class="ie-branded-invoice-document__label"><?php echo esc_html( ie__( 'Status' ) ); ?></span>
                    <strong><?php echo esc_html( $data['status_label'] ); ?></strong>
                </div>
                <div>
                    <span class="ie-branded-invoice-document__label"><?php echo esc_html( ie__( 'Billing Period' ) ); ?></span>
                    <strong><?php echo esc_html( $data['period_label'] ); ?></strong>
                </div>
            </div>

            <div class="ie-branded-invoice-document__parties">
                <div class="ie-branded-invoice-document__party">
                    <span class="ie-branded-invoice-document__label"><?php echo esc_html( ie__( 'Billed To' ) ); ?></span>
                    <strong><?php echo esc_html( $data['customer_name'] ); ?></strong>
                    <p><?php echo esc_html( $data['customer_email'] ); ?></p>
                </div>
                <div class="ie-branded-invoice-document__party">
                    <span class="ie-branded-invoice-document__label"><?php echo esc_html( ie__( 'Issued By' ) ); ?></span>
                    <strong><?php echo esc_html( $data['site_name'] ); ?></strong>
                    <p><?php echo esc_html( $data['site_email'] ); ?></p>
                </div>
            </div>

            <table class="ie-branded-invoice-document__table">
                <thead>
                    <tr>
                        <th><?php echo esc_html( ie__( 'Description' ) ); ?></th>
                        <th><?php echo esc_html( ie__( 'Amount' ) ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $data['lines'] as $line ) : ?>
                        <tr>
                            <td><?php echo esc_html( $line['description'] ); ?></td>
                            <td><?php echo esc_html( $line['amount'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td><?php echo esc_html( ie__( 'Subtotal' ) ); ?></td>
                        <td><?php echo esc_html( $data['subtotal'] ); ?></td>
                    </tr>
                    <tr class="is-total">
                        <td><?php echo esc_html( ie__( 'Total Paid' ) ); ?></td>
                        <td><?php echo esc_html( $data['total'] ); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="ie-branded-invoice-document__footer" style="border-top-color: <?php echo esc_attr( $data['primary_light'] ); ?>;">
            <p>
                <?php echo esc_html( sprintf( ie__( 'Thank you for subscribing with %s.' ), $data['site_name'] ) ); ?>
            </p>
            <p class="ie-branded-invoice-document__footer-note">
                <?php echo esc_html( $data['site_name'] ); ?> · <?php echo esc_html( $data['site_url'] ); ?>
            </p>
        </div>
    </div>
    <?php
}

function ie_ajax_view_branded_invoice() {
    $invoice_id = sanitize_text_field( wp_unslash( $_GET['invoice_id'] ?? '' ) );
    $nonce      = sanitize_text_field( wp_unslash( $_GET['nonce'] ?? '' ) );
    $download   = ! empty( $_GET['download'] );

    if ( $invoice_id === '' || ! wp_verify_nonce( $nonce, 'ie_invoice_' . $invoice_id ) ) {
        wp_die( esc_html( ie__( 'Invalid invoice request.' ) ), esc_html( ie__( 'Invoice' ) ), [ 'response' => 403 ] );
    }

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_die( esc_html( ie__( 'Permission denied.' ) ), esc_html( ie__( 'Invoice' ) ), [ 'response' => 403 ] );
    }

    $user    = wp_get_current_user();
    $invoice = ie_get_stripe_invoice_for_user( $user->ID, $invoice_id );

    if ( is_wp_error( $invoice ) ) {
        wp_die( esc_html( $invoice->get_error_message() ), esc_html( ie__( 'Invoice' ) ), [ 'response' => 404 ] );
    }

    $data     = ie_prepare_branded_invoice_data( $invoice, $user );
    $brand    = ie_get_invoice_brand_context();
    $filename = $data['pdf_filename'] ?? 'invoice.pdf';

    if ( $download ) {
        require_once get_template_directory() . '/inc/invoice-pdf-generator.php';
        ie_stream_branded_invoice_pdf( $data );
    }

    status_header( 200 );
    nocache_headers();
    ?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo esc_html( sprintf( ie__( '%1$s — Invoice %2$s' ), $brand['site_name'], $data['invoice_number'] ) ); ?></title>
        <style>
            :root {
                --invoice-primary: <?php echo esc_html( $brand['primary'] ); ?>;
                --invoice-primary-dark: <?php echo esc_html( $brand['primary_dark'] ); ?>;
                --invoice-primary-light: <?php echo esc_html( $brand['primary_light'] ); ?>;
                --invoice-accent: <?php echo esc_html( $brand['accent'] ); ?>;
            }
            * { box-sizing: border-box; }
            body {
                margin: 0;
                padding: 32px 16px;
                background: #eef3f7;
                font-family: Arial, Helvetica, sans-serif;
                color: #1a2332;
            }
            .ie-branded-invoice-shell {
                max-width: 820px;
                margin: 0 auto;
            }
            .ie-branded-invoice-toolbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 12px;
                margin-bottom: 16px;
            }
            .ie-branded-invoice-toolbar__title {
                font-size: 14px;
                color: #5f6f82;
            }
            .ie-branded-invoice-toolbar__actions {
                display: flex;
                gap: 10px;
            }
            .ie-branded-invoice-btn {
                appearance: none;
                border: 0;
                border-radius: 999px;
                padding: 10px 18px;
                font-size: 13px;
                font-weight: 700;
                cursor: pointer;
            }
            .ie-branded-invoice-btn--primary {
                background: var(--invoice-primary);
                color: #fff;
            }
            .ie-branded-invoice-btn--ghost {
                background: #fff;
                color: var(--invoice-primary);
                border: 1px solid rgba(0,0,0,0.08);
            }
            .ie-branded-invoice-document {
                background: #fff;
                border-radius: 18px;
                overflow: hidden;
                box-shadow: 0 18px 50px rgba(15, 35, 52, 0.12);
            }
            .ie-branded-invoice-document__header {
                color: #fff;
                padding: 28px 32px 34px;
                display: flex;
                justify-content: space-between;
                gap: 24px;
                align-items: center;
            }
            .ie-branded-invoice-document__brand {
                display: flex;
                align-items: center;
                gap: 16px;
            }
            .ie-branded-invoice-document__title-wrap {
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: flex-end;
                text-align: right;
            }
            .ie-branded-invoice-document__logo {
                width: 58px;
                height: 58px;
                object-fit: contain;
                border-radius: 12px;
                background: transparent;
                padding: 0;
            }
            .ie-branded-invoice-document__logo-fallback {
                width: 58px;
                height: 58px;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                background: rgba(255,255,255,0.18);
                font-size: 24px;
                font-weight: 800;
                letter-spacing: 0.04em;
            }
            .ie-branded-invoice-document__brand h1,
            .ie-branded-invoice-document__title-wrap h2 {
                margin: 0;
            }
            .ie-branded-invoice-document__brand h1 {
                font-size: 24px;
            }
            .ie-branded-invoice-document__brand p,
            .ie-branded-invoice-document__party p,
            .ie-branded-invoice-document__footer p {
                margin: 6px 0 0;
                opacity: 0.92;
            }
            .ie-branded-invoice-document__eyebrow {
                display: block;
                font-size: 11px;
                letter-spacing: 0.12em;
                text-transform: uppercase;
                opacity: 0.82;
                margin-bottom: 6px;
            }
            .ie-branded-invoice-document__title-wrap h2 {
                font-size: 28px;
            }
            .ie-branded-invoice-document__body {
                padding: 28px 32px 10px;
            }
            .ie-branded-invoice-document__meta-grid,
            .ie-branded-invoice-document__parties {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 18px 24px;
                margin-bottom: 24px;
            }
            .ie-branded-invoice-document__meta-grid {
                grid-template-columns: repeat(4, minmax(0, 1fr));
                padding-bottom: 22px;
                border-bottom: 1px solid #e7edf2;
            }
            .ie-branded-invoice-document__label {
                display: block;
                font-size: 11px;
                text-transform: uppercase;
                letter-spacing: 0.08em;
                color: #7b8794;
                margin-bottom: 6px;
            }
            .ie-branded-invoice-document__table {
                width: 100%;
                border-collapse: collapse;
            }
            .ie-branded-invoice-document__table th,
            .ie-branded-invoice-document__table td {
                padding: 14px 0;
                border-bottom: 1px solid #e7edf2;
                text-align: left;
            }
            .ie-branded-invoice-document__table th {
                font-size: 11px;
                text-transform: uppercase;
                letter-spacing: 0.08em;
                color: #7b8794;
            }
            .ie-branded-invoice-document__table td:last-child,
            .ie-branded-invoice-document__table th:last-child,
            .ie-branded-invoice-document__table tfoot td:last-child {
                text-align: right;
                white-space: nowrap;
            }
            .ie-branded-invoice-document__table tfoot td {
                padding-top: 12px;
                font-weight: 600;
            }
            .ie-branded-invoice-document__table tr.is-total td {
                font-size: 18px;
                color: var(--invoice-primary);
                border-bottom: 0;
                padding-top: 18px;
            }
            .ie-branded-invoice-document__footer {
                padding: 18px 32px 28px;
                border-top: 1px solid;
                background: #fafcfd;
            }
            .ie-branded-invoice-document__footer-note {
                font-size: 12px;
                color: #7b8794;
            }
            .ie-branded-invoice-loading {
                display: none;
                margin-top: 12px;
                font-size: 13px;
                color: #5f6f82;
            }
            .ie-branded-invoice-loading.is-visible {
                display: block;
            }
            @media (max-width: 720px) {
                .ie-branded-invoice-document__header,
                .ie-branded-invoice-document__meta-grid,
                .ie-branded-invoice-document__parties {
                    grid-template-columns: 1fr;
                    display: grid;
                }
                .ie-branded-invoice-document__header {
                    gap: 18px;
                }
            }
            @media print {
                body { background: #fff; padding: 0; }
                .ie-branded-invoice-toolbar,
                .ie-branded-invoice-loading { display: none !important; }
                .ie-branded-invoice-document { box-shadow: none; border-radius: 0; }
            }
        </style>
    </head>
    <body>
        <div class="ie-branded-invoice-shell">
            <div class="ie-branded-invoice-toolbar">
                <div class="ie-branded-invoice-toolbar__title">
                    <?php echo esc_html( $brand['site_name'] ); ?> · <?php echo esc_html( $data['invoice_number'] ); ?>
                </div>
                <div class="ie-branded-invoice-toolbar__actions">
                    <button type="button" class="ie-branded-invoice-btn ie-branded-invoice-btn--ghost" onclick="window.close()">
                        <?php echo esc_html( ie__( 'Close' ) ); ?>
                    </button>
                    <button type="button" class="ie-branded-invoice-btn ie-branded-invoice-btn--primary" id="ie-download-branded-invoice">
                        <?php echo esc_html( ie__( 'Download PDF' ) ); ?>
                    </button>
                </div>
            </div>

            <?php ie_render_branded_invoice_document( $data ); ?>

            <p class="ie-branded-invoice-loading<?php echo $download ? ' is-visible' : ''; ?>" id="ie-branded-invoice-loading">
                <?php echo esc_html( ie__( 'Preparing your branded PDF invoice...' ) ); ?>
            </p>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSDeiW9+SLyd6lEh3wHhtXpK2Ds4qKq5hEgYLK4IRXUsX/OGfj/WhmXrA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
        (function() {
            var filename = <?php echo wp_json_encode( $filename ); ?>;
            var autoDownload = <?php echo $download ? 'true' : 'false'; ?>;

            function downloadInvoicePdf() {
                var element = document.getElementById('ie-branded-invoice-document');
                var loading = document.getElementById('ie-branded-invoice-loading');
                var button = document.getElementById('ie-download-branded-invoice');

                if (!element || typeof html2pdf === 'undefined') {
                    window.print();
                    return;
                }

                if (loading) {
                    loading.classList.add('is-visible');
                }
                if (button) {
                    button.disabled = true;
                }

                html2pdf().set({
                    margin: [12, 12, 16, 12],
                    filename: filename,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: { scale: 2, useCORS: true, logging: false },
                    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
                }).from(element).save().then(function() {
                    if (loading) {
                        loading.classList.remove('is-visible');
                    }
                    if (button) {
                        button.disabled = false;
                    }
                }).catch(function() {
                    if (loading) {
                        loading.classList.remove('is-visible');
                    }
                    if (button) {
                        button.disabled = false;
                    }
                    window.print();
                });
            }

            document.getElementById('ie-download-branded-invoice').addEventListener('click', downloadInvoicePdf);

            if (autoDownload) {
                window.addEventListener('load', function() {
                    setTimeout(downloadInvoicePdf, 500);
                });
            }
        })();
        </script>
    </body>
    </html>
    <?php
    exit;
}
add_action( 'wp_ajax_ie_view_branded_invoice', 'ie_ajax_view_branded_invoice' );
