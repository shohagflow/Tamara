<?php
/**
 * FAQ template helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_faq_card( $faq ) { ?>
    <div class="ie-faq-card">
        <button type="button" class="ie-faq-card__toggle" onclick="IEApp.toggleFaq(this)">
            <span><?php echo esc_html( $faq[0] ); ?></span>
            <i class="fa-solid fa-chevron-down ie-faq-card__arrow" aria-hidden="true"></i>
        </button>
        <div class="faq-body">
            <div class="ie-faq-card__answer"><?php echo esc_html( $faq[1] ); ?></div>
        </div>
    </div>
<?php }

function ie_faq_list( $faqs ) { ?>
    <div class="ie-faq-list">
        <?php foreach ( $faqs as $faq ) { ie_faq_card( $faq ); } ?>
    </div>
    <?php
}
