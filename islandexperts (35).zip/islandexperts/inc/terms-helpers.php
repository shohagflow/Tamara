<?php
/**
 * Terms page template helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_render_terms_notice( $notice ) {
    if ( empty( $notice['text'] ) ) {
        return;
    }
    ?>
    <div class="ie-notice-banner">
        <i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i>
        <p>
            <?php if ( ! empty( $notice['label'] ) ) : ?>
                <strong><?php echo esc_html( $notice['label'] ); ?></strong>
                <?php echo ' '; ?>
            <?php endif; ?>
            <?php echo esc_html( $notice['text'] ); ?>
        </p>
    </div>
    <?php
}

function ie_render_terms_sections( $sections ) {
    if ( ! $sections ) {
        return;
    }
    ?>
    <div class="ie-legal-content">
        <?php foreach ( $sections as $section ) : ?>
            <section id="tc-<?php echo esc_attr( $section['slug'] ); ?>" class="ie-legal-section">
                <?php if ( ! empty( $section['title'] ) ) : ?>
                    <h3><?php echo esc_html( $section['title'] ); ?></h3>
                <?php endif; ?>
                <?php if ( ! empty( $section['content'] ) ) : ?>
                    <p><?php echo esc_html( $section['content'] ); ?></p>
                <?php endif; ?>
                <?php if ( ! empty( $section['list_items'] ) ) : ?>
                    <ul class="ie-legal-list">
                        <?php foreach ( $section['list_items'] as $item ) : ?>
                            <li><?php echo esc_html( $item ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>
        <?php endforeach; ?>
    </div>
    <?php
}
