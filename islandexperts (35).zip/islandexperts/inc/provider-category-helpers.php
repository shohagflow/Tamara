<?php
/**
 * Provider category display helpers (Browse by Category).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_default_provider_categories() {
    return [
        [
            'title'             => ie__( 'Plumbing' ),
            'slug'              => 'plumbing',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-wrench',
            'short_description' => ie__( 'Repairs, installations, and emergency plumbing services.' ),
            'menu_order'        => 1,
        ],
        [
            'title'             => ie__( 'Electrical' ),
            'slug'              => 'electrical',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-bolt',
            'short_description' => ie__( 'Wiring, lighting, and certified electrical work.' ),
            'menu_order'        => 2,
        ],
        [
            'title'             => ie__( 'Cleaning' ),
            'slug'              => 'cleaning',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-broom',
            'short_description' => ie__( 'Home, office, and deep cleaning services.' ),
            'menu_order'        => 3,
        ],
        [
            'title'             => ie__( 'Painting' ),
            'slug'              => 'painting',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-paint-roller',
            'short_description' => ie__( 'Interior and exterior painting professionals.' ),
            'menu_order'        => 4,
        ],
        [
            'title'             => ie__( 'Landscaping' ),
            'slug'              => 'landscaping',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-leaf',
            'short_description' => ie__( 'Garden design, lawn care, and outdoor upkeep.' ),
            'menu_order'        => 5,
        ],
        [
            'title'             => ie__( 'Carpentry' ),
            'slug'              => 'carpentry',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-hammer',
            'short_description' => ie__( 'Custom woodwork, repairs, and installations.' ),
            'menu_order'        => 6,
        ],
        [
            'title'             => ie__( 'HVAC' ),
            'slug'              => 'hvac',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-fan',
            'short_description' => ie__( 'Heating, cooling, and ventilation services.' ),
            'menu_order'        => 7,
        ],
        [
            'title'             => ie__( 'Roofing' ),
            'slug'              => 'roofing',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-house-chimney',
            'short_description' => ie__( 'Roof repairs, replacements, and inspections.' ),
            'menu_order'        => 8,
        ],
        [
            'title'             => ie__( 'Pest Control' ),
            'slug'              => 'pest-control',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-bug',
            'short_description' => ie__( 'Safe and effective pest removal solutions.' ),
            'menu_order'        => 9,
        ],
        [
            'title'             => ie__( 'Moving' ),
            'slug'              => 'moving',
            'icon_type'         => 'fontawesome',
            'icon_class'        => 'fa-solid fa-truck-moving',
            'short_description' => ie__( 'Local moves, packing, and delivery help.' ),
            'menu_order'        => 10,
        ],
    ];
}

function ie_get_provider_category_fa_presets() {
    return [
        'fa-solid fa-wrench'         => ie__( 'Wrench (Plumbing)' ),
        'fa-solid fa-bolt'           => ie__( 'Bolt (Electrical)' ),
        'fa-solid fa-broom'          => ie__( 'Broom (Cleaning)' ),
        'fa-solid fa-paint-roller'   => ie__( 'Paint Roller' ),
        'fa-solid fa-leaf'           => ie__( 'Leaf (Landscaping)' ),
        'fa-solid fa-hammer'         => ie__( 'Hammer (Carpentry)' ),
        'fa-solid fa-fan'            => ie__( 'Fan (HVAC)' ),
        'fa-solid fa-house-chimney'  => ie__( 'House (Roofing)' ),
        'fa-solid fa-bug'            => ie__( 'Bug (Pest Control)' ),
        'fa-solid fa-truck-moving'   => ie__( 'Truck (Moving)' ),
        'fa-solid fa-calendar-days'  => ie__( 'Calendar (Events)' ),
        'fa-solid fa-screwdriver-wrench' => ie__( 'Tools (General)' ),
        'fa-solid fa-star'           => ie__( 'Star' ),
        'fa-solid fa-shield-halved'  => ie__( 'Shield' ),
    ];
}

function ie_sanitize_provider_category_image_dimension( $value, $default = 28 ) {
    $value = (int) $value;

    if ( $value <= 0 ) {
        $value = (int) $default;
    }

    return max( 12, min( 120, $value ) );
}

function ie_get_provider_category_icon_bg_defaults() {
    return [
        'plumbing'        => 'rgba(99, 102, 241, 0.12)',
        'electrical'      => 'rgba(245, 158, 11, 0.14)',
        'cleaning'        => 'rgba(16, 185, 129, 0.12)',
        'painting'        => 'rgba(139, 92, 246, 0.12)',
        'landscaping'     => 'rgba(34, 197, 94, 0.12)',
        'carpentry'       => 'rgba(51, 109, 235, 0.12)',
        'hvac'            => 'rgba(6, 182, 212, 0.12)',
        'roofing'         => 'rgba(120, 113, 108, 0.14)',
        'pest-control'    => 'rgba(239, 68, 68, 0.12)',
        'moving'          => 'rgba(99, 102, 241, 0.12)',
        'event-planning'  => 'rgba(236, 72, 153, 0.12)',
    ];
}

function ie_get_provider_category_default_icon_bg( $slug ) {
    $slug     = sanitize_title( (string) $slug );
    $defaults = ie_get_provider_category_icon_bg_defaults();

    if ( $slug && isset( $defaults[ $slug ] ) ) {
        return $defaults[ $slug ];
    }

    return 'rgba(' . ie_theme_hex_to_rgb_string( ie_get_theme_primary_color() ) . ', 0.12)';
}

function ie_css_color_to_hex_for_picker( $color ) {
    $color = trim( (string) $color );
    $hex   = sanitize_hex_color( $color );

    if ( $hex ) {
        return $hex;
    }

    if ( preg_match( '/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)/', $color, $matches ) ) {
        $r = (int) $matches[1];
        $g = (int) $matches[2];
        $b = (int) $matches[3];
        $a = isset( $matches[4] ) ? (float) $matches[4] : 1.0;

        $r = (int) round( 255 * ( 1 - $a ) + $r * $a );
        $g = (int) round( 255 * ( 1 - $a ) + $g * $a );
        $b = (int) round( 255 * ( 1 - $a ) + $b * $a );

        return sprintf( '#%02x%02x%02x', $r, $g, $b );
    }

    return '#f0f4f8';
}

function ie_sanitize_provider_category_icon_bg_color( $value ) {
    $value = trim( (string) $value );

    if ( $value === '' ) {
        return '';
    }

    $hex = sanitize_hex_color( $value );
    if ( $hex ) {
        return $hex;
    }

    if ( preg_match( '/^rgba?\([^)]+\)$/i', $value ) ) {
        return $value;
    }

    return '';
}

function ie_resolve_provider_category_icon_bg( $post_id_or_category ) {
    $custom = '';
    $slug   = '';

    if ( is_array( $post_id_or_category ) ) {
        $custom = trim( (string) ( $post_id_or_category['icon_bg_color_custom'] ?? '' ) );
        $slug   = (string) ( $post_id_or_category['browse_slug'] ?? '' );
    } else {
        $post_id = (int) $post_id_or_category;
        $custom  = trim( (string) get_post_meta( $post_id, '_ie_cat_icon_bg_color', true ) );
        $slug    = (string) get_post_meta( $post_id, '_ie_cat_browse_slug', true );

        if ( $slug === '' && $post_id ) {
            $slug = (string) get_post_field( 'post_name', $post_id );
        }
    }

    $custom = ie_sanitize_provider_category_icon_bg_color( $custom );
    if ( $custom !== '' ) {
        return $custom;
    }

    return ie_get_provider_category_default_icon_bg( $slug );
}

function ie_get_provider_category_image_dimensions( $post_id_or_category ) {
    $width  = 0;
    $height = 0;

    if ( is_array( $post_id_or_category ) ) {
        $width  = (int) ( $post_id_or_category['icon_image_width'] ?? 0 );
        $height = (int) ( $post_id_or_category['icon_image_height'] ?? 0 );
    } else {
        $post_id = (int) $post_id_or_category;
        $width   = (int) get_post_meta( $post_id, '_ie_cat_icon_image_width', true );
        $height  = (int) get_post_meta( $post_id, '_ie_cat_icon_image_height', true );
    }

    return [
        'width'  => ie_sanitize_provider_category_image_dimension( $width ),
        'height' => ie_sanitize_provider_category_image_dimension( $height ),
    ];
}

function ie_get_provider_category_data( $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id ) {
        return [];
    }

    $browse_slug = (string) get_post_meta( $post_id, '_ie_cat_browse_slug', true );
    if ( $browse_slug === '' ) {
        $browse_slug = get_post_field( 'post_name', $post_id );
    }

    $term  = $browse_slug ? get_term_by( 'slug', $browse_slug, 'ie_category' ) : null;
    $count = ( $term && ! is_wp_error( $term ) ) ? (int) $term->count : 0;

    $icon_type = get_post_meta( $post_id, '_ie_cat_icon_type', true );
    if ( ! in_array( $icon_type, [ 'fontawesome', 'image' ], true ) ) {
        $icon_type = 'fontawesome';
    }

    $image_dims       = ie_get_provider_category_image_dimensions( $post_id );
    $icon_bg_custom   = ie_sanitize_provider_category_icon_bg_color( get_post_meta( $post_id, '_ie_cat_icon_bg_color', true ) );
    $icon_bg_resolved = ie_resolve_provider_category_icon_bg(
        [
            'icon_bg_color_custom' => $icon_bg_custom,
            'browse_slug'          => $browse_slug,
        ]
    );

    return [
        'id'                  => $post_id,
        'title'               => get_the_title( $post_id ),
        'short_description'   => (string) get_post_meta( $post_id, '_ie_cat_short_description', true ),
        'browse_slug'         => sanitize_title( $browse_slug ),
        'icon_type'           => $icon_type,
        'icon_class'          => (string) get_post_meta( $post_id, '_ie_cat_icon_class', true ) ?: 'fa-solid fa-screwdriver-wrench',
        'icon_image'          => (string) get_post_meta( $post_id, '_ie_cat_icon_image', true ),
        'icon_image_width'    => $image_dims['width'],
        'icon_image_height'   => $image_dims['height'],
        'icon_bg_color_custom' => $icon_bg_custom,
        'icon_bg_color'       => $icon_bg_resolved,
        'provider_count'      => $count,
    ];
}

function ie_get_published_provider_categories( $limit = 0 ) {
    $query = new WP_Query( [
        'post_type'      => 'ie_provider_category',
        'post_status'    => 'publish',
        'posts_per_page' => $limit > 0 ? (int) $limit : -1,
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'no_found_rows'  => true,
    ] );

    $categories = [];
    foreach ( $query->posts as $post ) {
        $categories[] = ie_get_provider_category_data( $post->ID );
    }

    wp_reset_postdata();

    return $categories;
}

function ie_render_provider_category_icon( $category ) {
    if ( ( $category['icon_type'] ?? '' ) === 'image' && ! empty( $category['icon_image'] ) ) {
        $dims = ie_get_provider_category_image_dimensions( $category );
        echo '<img src="' . esc_url( $category['icon_image'] ) . '" alt="" width="' . esc_attr( (string) $dims['width'] ) . '" height="' . esc_attr( (string) $dims['height'] ) . '" loading="lazy" style="width:' . esc_attr( (string) $dims['width'] ) . 'px;height:' . esc_attr( (string) $dims['height'] ) . 'px;object-fit:contain;">';
        return;
    }

    $icon_class = $category['icon_class'] ?? 'fa-solid fa-screwdriver-wrench';
    echo '<i class="' . esc_attr( $icon_class ) . '" aria-hidden="true"></i>';
}

function ie_render_provider_category_icon_preview( $category, $size = 36 ) {
    $category = wp_parse_args(
        (array) $category,
        [
            'icon_type'           => 'fontawesome',
            'icon_class'          => 'fa-solid fa-screwdriver-wrench',
            'icon_image'          => '',
            'icon_image_width'    => 28,
            'icon_image_height'   => 28,
            'icon_bg_color'       => '',
            'icon_bg_color_custom' => '',
            'browse_slug'         => '',
        ]
    );

    $primary = ie_get_theme_primary_color();
    $bg      = $category['icon_bg_color'] ?: ie_resolve_provider_category_icon_bg( $category );

    if ( $category['icon_type'] === 'image' && ! empty( $category['icon_image'] ) ) {
        $dims      = ie_get_provider_category_image_dimensions( $category );
        $box_width = max( $size, $dims['width'] + 8 );
        $box_height = max( $size, $dims['height'] + 8 );

        echo '<span class="ie-provider-cat-icon-preview" style="display:inline-flex;align-items:center;justify-content:center;width:' . esc_attr( (string) $box_width ) . 'px;height:' . esc_attr( (string) $box_height ) . 'px;border-radius:8px;background:' . esc_attr( $bg ) . ';">';
        echo '<img src="' . esc_url( $category['icon_image'] ) . '" alt="" width="' . esc_attr( (string) $dims['width'] ) . '" height="' . esc_attr( (string) $dims['height'] ) . '" style="width:' . esc_attr( (string) $dims['width'] ) . 'px;height:' . esc_attr( (string) $dims['height'] ) . 'px;object-fit:contain;">';
        echo '</span>';
        return;
    }

    $size = max( 28, (int) $size );

    echo '<span class="ie-provider-cat-icon-preview" style="display:inline-flex;align-items:center;justify-content:center;width:' . esc_attr( (string) $size ) . 'px;height:' . esc_attr( (string) $size ) . 'px;border-radius:8px;background:' . esc_attr( $bg ) . ';">';
    echo '<i class="' . esc_attr( $category['icon_class'] ) . '" aria-hidden="true" style="color:' . esc_attr( $primary ) . ';"></i>';
    echo '</span>';
}

function ie_render_home_categories( $browse_url = '', $section = [] ) {
    if ( ! $browse_url ) {
        $browse_url = ie_get_theme_page_url( 'browse' );
    }

    if ( ! $section ) {
        $section = ie_get_home_categories( ie_get_home_content_post_id() );
    }

    $categories = ie_get_published_provider_categories( 10 );
    ?>
    <section class="categories-section">
        <div class="container">
            <div class="categories-section-header">
                <?php if ( ! empty( $section['title'] ) ) : ?>
                    <h2><?php echo esc_html( $section['title'] ); ?></h2>
                <?php endif; ?>
                <?php if ( ! empty( $section['subtitle'] ) ) : ?>
                    <p><?php echo esc_html( $section['subtitle'] ); ?></p>
                <?php endif; ?>
            </div>
            <?php if ( $categories ) : ?>
                <div class="categories-grid">
                    <?php foreach ( $categories as $category ) :
                        $slug = $category['browse_slug'] ?: sanitize_title( $category['title'] );
                        $url  = add_query_arg( 'category', $slug, $browse_url );
                        ?>
                        <a href="<?php echo esc_url( $url ); ?>" class="category-card cat-<?php echo esc_attr( $slug ); ?>">
                            <div class="category-icon-wrap" style="background:<?php echo esc_attr( $category['icon_bg_color'] ); ?>;">
                                <?php ie_render_provider_category_icon( $category ); ?>
                            </div>
                            <div class="cat-name"><?php echo esc_html( $category['title'] ); ?></div>
                            <?php if ( ! empty( $category['short_description'] ) ) : ?>
                                <div class="cat-desc"><?php echo esc_html( $category['short_description'] ); ?></div>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <?php
}
