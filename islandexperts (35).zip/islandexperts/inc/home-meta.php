<?php
/**
 * Home page meta fields (hero, why, CTA).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_home_hero_slide_urls( $post_id = null ) {
    $post_id = $post_id ?: get_queried_object_id();
    $raw     = get_post_meta( $post_id, '_ie_home_hero_slides', true );
    $slides  = [];

    if ( is_string( $raw ) && $raw !== '' ) {
        $decoded = json_decode( $raw, true );
        if ( is_array( $decoded ) ) {
            foreach ( $decoded as $url ) {
                $url = esc_url_raw( (string) $url );
                if ( $url !== '' ) {
                    $slides[] = $url;
                }
            }
        } else {
            $slides = ie_parse_home_slide_urls( $raw );
        }
    } elseif ( is_array( $raw ) ) {
        foreach ( $raw as $url ) {
            $url = esc_url_raw( (string) $url );
            if ( $url !== '' ) {
                $slides[] = $url;
            }
        }
    }

    return $slides;
}

function ie_parse_home_slide_urls( $text ) {
    if ( ! is_string( $text ) || trim( $text ) === '' ) {
        return [];
    }

    $slides = [];
    foreach ( preg_split( '/\r\n|\r|\n/', $text ) as $line ) {
        $line = trim( $line );
        if ( $line !== '' ) {
            $slides[] = esc_url_raw( $line );
        }
    }

    return array_values( array_filter( $slides ) );
}

function ie_get_home_default_hero_slides() {
    return [
        ie_image_uri( 'hero-1.jpg' ),
        ie_image_uri( 'hero-2.jpg' ),
        ie_image_uri( 'hero-3.jpg' ),
        ie_image_uri( 'hero-4.jpg' ),
    ];
}

function ie_get_home_default_hero() {
    return [
        'slides'        => ie_get_home_default_hero_slides(),
        'title'         => ie__( 'Find trusted local service providers' ),
        'subtitle'      => ie__( "St. Lucia's #1 platform for finding trusted local professionals. Browse profiles, compare prices, read reviews — and book the right service provider for your needs." ),
        'primary_text'  => ie__( 'Browse Experts' ),
        'primary_url'   => ie_get_theme_page_url( 'browse' ),
        'secondary_text'=> ie__( 'View Pricing' ),
        'secondary_url' => ie_get_theme_page_url( 'price' ),
    ];
}

function ie_get_home_default_why_items() {
    return [
        [
            'icon'  => 'fa-solid fa-shield-halved',
            'title' => ie__( 'Verified Pros' ),
            'text'  => ie__( 'Every provider is vetted and reviewed by real customers' ),
        ],
        [
            'icon'  => 'fa-solid fa-star',
            'title' => ie__( 'Honest Reviews' ),
            'text'  => ie__( 'Transparent ratings help you choose with confidence' ),
        ],
        [
            'icon'  => 'fa-solid fa-bolt',
            'title' => ie__( 'Quick Booking' ),
            'text'  => ie__( 'Book your preferred service in just a few taps' ),
        ],
    ];
}

function ie_get_home_default_why() {
    return [
        'title'    => ie__( 'Why Choose Island Experts' ),
        'subtitle' => ie__( 'Trusted local professionals, transparent reviews, and booking made simple.' ),
        'items'    => ie_get_home_default_why_items(),
    ];
}

function ie_get_home_default_categories() {
    return [
        'title'    => ie__( 'Browse by Category' ),
        'subtitle' => ie__( 'Explore trusted professionals across every service you need' ),
    ];
}

function ie_get_home_default_providers() {
    return [
        'title'    => ie__( 'Top-Rated Providers' ),
        'subtitle' => ie__( 'Featured service providers trusted by customers across St. Lucia' ),
    ];
}

function ie_get_home_default_cta() {
    return [
        'title'          => ie__( 'Are You a Service Provider?' ),
        'text'           => ie__( 'Join our platform and grow your business by connecting with potential clients.' ),
        'primary_text'   => ie__( 'Become a Provider' ),
        'primary_url'    => ie_get_provider_register_url(),
        'secondary_text' => ie__( 'Learn More' ),
        'secondary_url'  => ie_get_theme_page_url( 'price' ),
    ];
}

function ie_normalize_home_why_items( $items ) {
    if ( ! is_array( $items ) ) {
        return [];
    }

    $normalized = [];

    foreach ( $items as $item ) {
        $icon  = sanitize_text_field( $item['icon'] ?? '' );
        $title = sanitize_text_field( $item['title'] ?? '' );
        $text  = sanitize_text_field( $item['text'] ?? '' );

        if ( $title === '' && $text === '' ) {
            continue;
        }

        $normalized[] = [
            'icon'  => $icon ?: 'fa-solid fa-star',
            'title' => $title,
            'text'  => $text,
        ];
    }

    return $normalized;
}

function ie_get_home_hero( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_home_default_hero();
    $slides   = ie_get_home_hero_slide_urls( $post_id );

    if ( ! $slides ) {
        $slides = $defaults['slides'];
    }

    return [
        'slides'         => $slides,
        'title'          => get_post_meta( $post_id, '_ie_home_hero_title', true ) ?: $defaults['title'],
        'subtitle'       => get_post_meta( $post_id, '_ie_home_hero_subtitle', true ) ?: $defaults['subtitle'],
        'primary_text'   => get_post_meta( $post_id, '_ie_home_hero_primary_text', true ) ?: $defaults['primary_text'],
        'primary_url'    => get_post_meta( $post_id, '_ie_home_hero_primary_url', true ) ?: $defaults['primary_url'],
        'secondary_text' => get_post_meta( $post_id, '_ie_home_hero_secondary_text', true ) ?: $defaults['secondary_text'],
        'secondary_url'  => get_post_meta( $post_id, '_ie_home_hero_secondary_url', true ) ?: $defaults['secondary_url'],
    ];
}

function ie_get_home_why( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_home_default_why();
    $raw      = get_post_meta( $post_id, '_ie_home_why_items', true );
    $items    = [];

    if ( is_string( $raw ) && $raw !== '' ) {
        $decoded = json_decode( $raw, true );
        if ( is_array( $decoded ) ) {
            $items = ie_normalize_home_why_items( $decoded );
        }
    } elseif ( is_array( $raw ) ) {
        $items = ie_normalize_home_why_items( $raw );
    }

    if ( ! $items ) {
        $items = $defaults['items'];
    }

    return [
        'title'    => get_post_meta( $post_id, '_ie_home_why_title', true ) ?: $defaults['title'],
        'subtitle' => get_post_meta( $post_id, '_ie_home_why_subtitle', true ) ?: $defaults['subtitle'],
        'items'    => $items,
    ];
}

function ie_get_home_categories( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_home_default_categories();

    return [
        'title'    => get_post_meta( $post_id, '_ie_home_categories_title', true ) ?: $defaults['title'],
        'subtitle' => get_post_meta( $post_id, '_ie_home_categories_subtitle', true ) ?: $defaults['subtitle'],
    ];
}

function ie_get_home_providers( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_home_default_providers();

    return [
        'title'    => get_post_meta( $post_id, '_ie_home_providers_title', true ) ?: $defaults['title'],
        'subtitle' => get_post_meta( $post_id, '_ie_home_providers_subtitle', true ) ?: $defaults['subtitle'],
    ];
}

function ie_get_home_cta( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_home_default_cta();

    return [
        'title'          => get_post_meta( $post_id, '_ie_home_cta_title', true ) ?: $defaults['title'],
        'text'           => get_post_meta( $post_id, '_ie_home_cta_text', true ) ?: $defaults['text'],
        'primary_text'   => get_post_meta( $post_id, '_ie_home_cta_primary_text', true ) ?: $defaults['primary_text'],
        'primary_url'    => get_post_meta( $post_id, '_ie_home_cta_primary_url', true ) ?: $defaults['primary_url'],
        'secondary_text' => get_post_meta( $post_id, '_ie_home_cta_secondary_text', true ) ?: $defaults['secondary_text'],
        'secondary_url'  => get_post_meta( $post_id, '_ie_home_cta_secondary_url', true ) ?: $defaults['secondary_url'],
    ];
}

function ie_get_home_page_data( $post_id = null ) {
    return [
        'hero'       => ie_get_home_hero( $post_id ),
        'categories' => ie_get_home_categories( $post_id ),
        'providers'  => ie_get_home_providers( $post_id ),
        'why'        => ie_get_home_why( $post_id ),
        'cta'        => ie_get_home_cta( $post_id ),
    ];
}

function ie_seed_home_page_defaults( $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id || get_post_type( $post_id ) !== 'page' ) {
        return;
    }

    $hero       = ie_get_home_default_hero();
    $categories = ie_get_home_default_categories();
    $providers  = ie_get_home_default_providers();
    $why        = ie_get_home_default_why();
    $cta        = ie_get_home_default_cta();

    if ( ! get_post_meta( $post_id, '_ie_home_hero_slides', true ) ) {
        update_post_meta( $post_id, '_ie_home_hero_slides', wp_json_encode( $hero['slides'] ) );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_hero_title', true ) ) {
        update_post_meta( $post_id, '_ie_home_hero_title', $hero['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_hero_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_home_hero_subtitle', $hero['subtitle'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_hero_primary_text', true ) ) {
        update_post_meta( $post_id, '_ie_home_hero_primary_text', $hero['primary_text'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_hero_primary_url', true ) ) {
        update_post_meta( $post_id, '_ie_home_hero_primary_url', $hero['primary_url'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_hero_secondary_text', true ) ) {
        update_post_meta( $post_id, '_ie_home_hero_secondary_text', $hero['secondary_text'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_hero_secondary_url', true ) ) {
        update_post_meta( $post_id, '_ie_home_hero_secondary_url', $hero['secondary_url'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_categories_title', true ) ) {
        update_post_meta( $post_id, '_ie_home_categories_title', $categories['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_categories_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_home_categories_subtitle', $categories['subtitle'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_providers_title', true ) ) {
        update_post_meta( $post_id, '_ie_home_providers_title', $providers['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_providers_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_home_providers_subtitle', $providers['subtitle'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_why_title', true ) ) {
        update_post_meta( $post_id, '_ie_home_why_title', $why['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_why_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_home_why_subtitle', $why['subtitle'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_why_items', true ) ) {
        update_post_meta( $post_id, '_ie_home_why_items', wp_json_encode( $why['items'] ) );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_cta_title', true ) ) {
        update_post_meta( $post_id, '_ie_home_cta_title', $cta['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_cta_text', true ) ) {
        update_post_meta( $post_id, '_ie_home_cta_text', $cta['text'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_cta_primary_text', true ) ) {
        update_post_meta( $post_id, '_ie_home_cta_primary_text', $cta['primary_text'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_cta_primary_url', true ) ) {
        update_post_meta( $post_id, '_ie_home_cta_primary_url', $cta['primary_url'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_cta_secondary_text', true ) ) {
        update_post_meta( $post_id, '_ie_home_cta_secondary_text', $cta['secondary_text'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_home_cta_secondary_url', true ) ) {
        update_post_meta( $post_id, '_ie_home_cta_secondary_url', $cta['secondary_url'] );
    }
}

function ie_home_uses_template( $post_id ) {
    if ( ie_page_uses_template( $post_id, 'home.php' ) ) {
        return true;
    }

    return (int) get_option( 'page_on_front' ) === (int) $post_id;
}

function ie_add_home_page_meta_box( $post_type, $post ) {
    if ( $post_type !== 'page' || ! $post instanceof WP_Post ) {
        return;
    }

    if ( ! ie_home_uses_template( $post->ID ) ) {
        return;
    }

    add_meta_box(
        'ie_home_page_settings',
        ie__( 'Home Page Settings' ),
        'ie_home_page_meta_box_cb',
        'page',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'ie_add_home_page_meta_box', 10, 2 );

function ie_home_page_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_home_page', 'ie_home_page_nonce' );

    $data       = ie_get_home_page_data( $post->ID );
    $hero       = $data['hero'];
    $categories = $data['categories'];
    $providers  = $data['providers'];
    $why        = $data['why'];
    $cta        = $data['cta'];
    $why_items = ie_normalize_home_why_items( json_decode( (string) get_post_meta( $post->ID, '_ie_home_why_items', true ), true ) );

    if ( ! $why_items ) {
        $why_items = ie_get_home_default_why_items();
    }

    $slide_urls = ie_get_home_hero_slide_urls( $post->ID );
    if ( ! $slide_urls ) {
        $slide_urls = ie_get_home_default_hero_slides();
    }
    ?>
    <style>
        .ie-home-meta-section { margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid #dcdcde; }
        .ie-home-meta-section:last-child { border-bottom: 0; margin-bottom: 0; padding-bottom: 0; }
        .ie-home-meta-section h4 { margin: 0 0 12px; font-size: 14px; }
        .ie-home-meta-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
        .ie-home-meta-field { margin-bottom: 14px; }
        .ie-home-meta-field label { display: block; font-weight: 600; margin-bottom: 6px; }
        .ie-home-meta-field input[type="text"],
        .ie-home-meta-field input[type="url"],
        .ie-home-meta-field textarea { width: 100%; }
        .ie-home-meta-hint { color: #646970; font-size: 12px; margin-top: 4px; }
        .ie-home-repeater { display: flex; flex-direction: column; gap: 12px; }
        .ie-home-repeater-item { padding: 14px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 4px; }
        .ie-home-repeater-item__head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
        .ie-home-remove-item { color: #b32d2e; border: 0; background: none; cursor: pointer; font-weight: 600; }
        .ie-home-add-item { margin-top: 12px; }
        .ie-home-slides { display: flex; flex-direction: column; gap: 12px; margin-bottom: 12px; }
        .ie-home-slide-item { display: flex; align-items: center; gap: 14px; padding: 12px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 4px; }
        .ie-home-slide-preview { width: 120px; height: 72px; border-radius: 4px; overflow: hidden; background: #dcdcde; flex-shrink: 0; }
        .ie-home-slide-preview img { width: 100%; height: 100%; object-fit: cover; display: block; }
        .ie-home-slide-preview.is-empty { display: flex; align-items: center; justify-content: center; color: #646970; font-size: 11px; text-align: center; padding: 8px; }
        .ie-home-slide-actions { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
        @media (max-width: 782px) { .ie-home-meta-grid { grid-template-columns: 1fr; } .ie-home-slide-item { flex-direction: column; align-items: flex-start; } }
    </style>

    <div class="ie-home-meta-section">
        <h4><?php echo esc_html( ie__( 'Hero Section' ) ); ?></h4>

        <div class="ie-home-meta-field">
            <label><?php echo esc_html( ie__( 'Slide Images' ) ); ?></label>
            <div id="ie-home-slides" class="ie-home-slides">
                <?php foreach ( $slide_urls as $index => $slide_url ) : ?>
                    <?php ie_render_home_hero_slide_row( $index, $slide_url ); ?>
                <?php endforeach; ?>
            </div>
            <button type="button" class="button ie-home-add-slide" id="ie-home-add-slide">
                <?php echo esc_html( ie__( 'Add Slide Image' ) ); ?>
            </button>
            <p class="ie-home-meta-hint"><?php echo esc_html( ie__( 'Upload hero background images. The first slide shows initially.' ) ); ?></p>
        </div>

        <div class="ie-home-meta-field">
            <label for="ie_home_hero_title"><?php echo esc_html( ie__( 'Hero Title' ) ); ?></label>
            <input type="text" id="ie_home_hero_title" name="_ie_home_hero_title" value="<?php echo esc_attr( $hero['title'] ); ?>">
        </div>

        <div class="ie-home-meta-field">
            <label for="ie_home_hero_subtitle"><?php echo esc_html( ie__( 'Hero Subtitle' ) ); ?></label>
            <textarea id="ie_home_hero_subtitle" name="_ie_home_hero_subtitle" rows="3"><?php echo esc_textarea( $hero['subtitle'] ); ?></textarea>
        </div>

        <div class="ie-home-meta-grid">
            <div class="ie-home-meta-field">
                <label for="ie_home_hero_primary_text"><?php echo esc_html( ie__( 'Primary Button Text' ) ); ?></label>
                <input type="text" id="ie_home_hero_primary_text" name="_ie_home_hero_primary_text" value="<?php echo esc_attr( $hero['primary_text'] ); ?>">
            </div>
            <div class="ie-home-meta-field">
                <label for="ie_home_hero_primary_url"><?php echo esc_html( ie__( 'Primary Button URL' ) ); ?></label>
                <input type="url" id="ie_home_hero_primary_url" name="_ie_home_hero_primary_url" value="<?php echo esc_attr( $hero['primary_url'] ); ?>">
            </div>
            <div class="ie-home-meta-field">
                <label for="ie_home_hero_secondary_text"><?php echo esc_html( ie__( 'Secondary Button Text' ) ); ?></label>
                <input type="text" id="ie_home_hero_secondary_text" name="_ie_home_hero_secondary_text" value="<?php echo esc_attr( $hero['secondary_text'] ); ?>">
            </div>
            <div class="ie-home-meta-field">
                <label for="ie_home_hero_secondary_url"><?php echo esc_html( ie__( 'Secondary Button URL' ) ); ?></label>
                <input type="url" id="ie_home_hero_secondary_url" name="_ie_home_hero_secondary_url" value="<?php echo esc_attr( $hero['secondary_url'] ); ?>">
            </div>
        </div>
    </div>

    <div class="ie-home-meta-section">
        <h4><?php echo esc_html( ie__( 'Browse by Category' ) ); ?></h4>

        <div class="ie-home-meta-field">
            <label for="ie_home_categories_title"><?php echo esc_html( ie__( 'Section Title' ) ); ?></label>
            <input type="text" id="ie_home_categories_title" name="_ie_home_categories_title" value="<?php echo esc_attr( $categories['title'] ); ?>">
        </div>

        <div class="ie-home-meta-field">
            <label for="ie_home_categories_subtitle"><?php echo esc_html( ie__( 'Section Subtitle' ) ); ?></label>
            <textarea id="ie_home_categories_subtitle" name="_ie_home_categories_subtitle" rows="2"><?php echo esc_textarea( $categories['subtitle'] ); ?></textarea>
        </div>
    </div>

    <div class="ie-home-meta-section">
        <h4><?php echo esc_html( ie__( 'Top-Rated Providers' ) ); ?></h4>

        <div class="ie-home-meta-field">
            <label for="ie_home_providers_title"><?php echo esc_html( ie__( 'Section Title' ) ); ?></label>
            <input type="text" id="ie_home_providers_title" name="_ie_home_providers_title" value="<?php echo esc_attr( $providers['title'] ); ?>">
        </div>

        <div class="ie-home-meta-field">
            <label for="ie_home_providers_subtitle"><?php echo esc_html( ie__( 'Section Subtitle' ) ); ?></label>
            <textarea id="ie_home_providers_subtitle" name="_ie_home_providers_subtitle" rows="2"><?php echo esc_textarea( $providers['subtitle'] ); ?></textarea>
        </div>
    </div>

    <div class="ie-home-meta-section">
        <h4><?php echo esc_html( ie__( 'Why Choose Island Experts' ) ); ?></h4>

        <div class="ie-home-meta-field">
            <label for="ie_home_why_title"><?php echo esc_html( ie__( 'Section Title' ) ); ?></label>
            <input type="text" id="ie_home_why_title" name="_ie_home_why_title" value="<?php echo esc_attr( $why['title'] ); ?>">
        </div>

        <div class="ie-home-meta-field">
            <label for="ie_home_why_subtitle"><?php echo esc_html( ie__( 'Section Subtitle' ) ); ?></label>
            <textarea id="ie_home_why_subtitle" name="_ie_home_why_subtitle" rows="2"><?php echo esc_textarea( $why['subtitle'] ); ?></textarea>
        </div>

        <div id="ie-home-why-repeater" class="ie-home-repeater">
            <?php foreach ( $why_items as $index => $item ) : ?>
                <?php ie_render_home_why_repeater_row( $index, $item ); ?>
            <?php endforeach; ?>
        </div>

        <button type="button" class="button ie-home-add-item" id="ie-home-add-why-item">
            <?php echo esc_html( ie__( 'Add Feature' ) ); ?>
        </button>
    </div>

    <div class="ie-home-meta-section">
        <h4><?php echo esc_html( ie__( 'Provider CTA Section' ) ); ?></h4>

        <div class="ie-home-meta-field">
            <label for="ie_home_cta_title"><?php echo esc_html( ie__( 'CTA Title' ) ); ?></label>
            <input type="text" id="ie_home_cta_title" name="_ie_home_cta_title" value="<?php echo esc_attr( $cta['title'] ); ?>">
        </div>

        <div class="ie-home-meta-field">
            <label for="ie_home_cta_text"><?php echo esc_html( ie__( 'CTA Text' ) ); ?></label>
            <textarea id="ie_home_cta_text" name="_ie_home_cta_text" rows="2"><?php echo esc_textarea( $cta['text'] ); ?></textarea>
        </div>

        <div class="ie-home-meta-grid">
            <div class="ie-home-meta-field">
                <label for="ie_home_cta_primary_text"><?php echo esc_html( ie__( 'Primary Button Text' ) ); ?></label>
                <input type="text" id="ie_home_cta_primary_text" name="_ie_home_cta_primary_text" value="<?php echo esc_attr( $cta['primary_text'] ); ?>">
            </div>
            <div class="ie-home-meta-field">
                <label for="ie_home_cta_primary_url"><?php echo esc_html( ie__( 'Primary Button URL' ) ); ?></label>
                <input type="url" id="ie_home_cta_primary_url" name="_ie_home_cta_primary_url" value="<?php echo esc_attr( $cta['primary_url'] ); ?>">
            </div>
            <div class="ie-home-meta-field">
                <label for="ie_home_cta_secondary_text"><?php echo esc_html( ie__( 'Secondary Button Text' ) ); ?></label>
                <input type="text" id="ie_home_cta_secondary_text" name="_ie_home_cta_secondary_text" value="<?php echo esc_attr( $cta['secondary_text'] ); ?>">
            </div>
            <div class="ie-home-meta-field">
                <label for="ie_home_cta_secondary_url"><?php echo esc_html( ie__( 'Secondary Button URL' ) ); ?></label>
                <input type="url" id="ie_home_cta_secondary_url" name="_ie_home_cta_secondary_url" value="<?php echo esc_attr( $cta['secondary_url'] ); ?>">
            </div>
        </div>
    </div>

    <script type="text/template" id="ie-home-slide-template">
        <?php ie_render_home_hero_slide_row( '__INDEX__', '', true ); ?>
    </script>

    <script type="text/template" id="ie-home-why-row-template">
        <?php ie_render_home_why_repeater_row( '__INDEX__', ie_get_home_default_why_items()[0], true ); ?>
    </script>
    <?php
}

function ie_render_home_hero_slide_row( $index, $url, $is_template = false ) {
    $num     = is_numeric( $index ) ? ( (int) $index + 1 ) : '__NUM__';
    $url     = $is_template ? '' : (string) $url;
    $has_img = $url !== '';
    ?>
    <div class="ie-home-slide-item" data-index="<?php echo esc_attr( $index ); ?>">
        <div class="ie-home-slide-preview<?php echo $has_img ? '' : ' is-empty'; ?>">
            <?php if ( $has_img ) : ?>
                <img src="<?php echo esc_url( $url ); ?>" alt="">
            <?php else : ?>
                <?php echo esc_html( ie__( 'No image' ) ); ?>
            <?php endif; ?>
        </div>
        <div class="ie-home-slide-actions">
            <strong><?php echo esc_html( ie__( 'Slide' ) ); ?> #<span class="ie-home-slide-num"><?php echo esc_html( $num ); ?></span></strong>
            <input type="hidden" name="ie_home_hero_slide_url[]" value="<?php echo esc_attr( $url ); ?>">
            <button type="button" class="button ie-home-upload-slide"><?php echo esc_html( ie__( 'Upload Image' ) ); ?></button>
            <button type="button" class="button-link ie-home-clear-slide"><?php echo esc_html( ie__( 'Remove Image' ) ); ?></button>
            <button type="button" class="button-link ie-home-remove-slide"><?php echo esc_html( ie__( 'Delete Slide' ) ); ?></button>
        </div>
    </div>
    <?php
}

function ie_render_home_why_repeater_row( $index, $item, $is_template = false ) {
    $num = is_numeric( $index ) ? ( (int) $index + 1 ) : '__NUM__';
    ?>
    <div class="ie-home-repeater-item" data-index="<?php echo esc_attr( $index ); ?>">
        <div class="ie-home-repeater-item__head">
            <strong><?php echo esc_html( ie__( 'Feature' ) ); ?> #<span class="ie-home-item-num"><?php echo esc_html( $num ); ?></span></strong>
            <button type="button" class="ie-home-remove-item"><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
        </div>
        <div class="ie-home-meta-grid">
            <div class="ie-home-meta-field">
                <label><?php echo esc_html( ie__( 'Icon Class' ) ); ?></label>
                <input type="text" name="ie_home_why_icon[]" value="<?php echo $is_template ? '' : esc_attr( $item['icon'] ?? '' ); ?>" placeholder="fa-solid fa-star">
            </div>
            <div class="ie-home-meta-field">
                <label><?php echo esc_html( ie__( 'Feature Title' ) ); ?></label>
                <input type="text" name="ie_home_why_title_item[]" value="<?php echo $is_template ? '' : esc_attr( $item['title'] ?? '' ); ?>">
            </div>
        </div>
        <div class="ie-home-meta-field">
            <label><?php echo esc_html( ie__( 'Feature Text' ) ); ?></label>
            <textarea name="ie_home_why_text[]" rows="2"><?php echo $is_template ? '' : esc_textarea( $item['text'] ?? '' ); ?></textarea>
        </div>
    </div>
    <?php
}

function ie_save_home_page_meta( $post_id ) {
    if ( ! isset( $_POST['ie_home_page_nonce'] ) || ! wp_verify_nonce( $_POST['ie_home_page_nonce'], 'ie_save_home_page' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( get_post_type( $post_id ) !== 'page' ) {
        return;
    }
    if ( ! ie_home_uses_template( $post_id ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['ie_home_hero_slide_url'] ) && is_array( $_POST['ie_home_hero_slide_url'] ) ) {
        $slides = [];
        foreach ( wp_unslash( $_POST['ie_home_hero_slide_url'] ) as $url ) {
            $url = esc_url_raw( $url );
            if ( $url !== '' ) {
                $slides[] = $url;
            }
        }
        update_post_meta( $post_id, '_ie_home_hero_slides', wp_json_encode( $slides ) );
    }

    $text_fields = [
        '_ie_home_hero_title'           => 'sanitize_text_field',
        '_ie_home_hero_subtitle'        => 'sanitize_textarea_field',
        '_ie_home_hero_primary_text'    => 'sanitize_text_field',
        '_ie_home_hero_secondary_text'  => 'sanitize_text_field',
        '_ie_home_categories_title'     => 'sanitize_text_field',
        '_ie_home_categories_subtitle'  => 'sanitize_textarea_field',
        '_ie_home_providers_title'      => 'sanitize_text_field',
        '_ie_home_providers_subtitle'   => 'sanitize_textarea_field',
        '_ie_home_why_title'            => 'sanitize_text_field',
        '_ie_home_why_subtitle'         => 'sanitize_textarea_field',
        '_ie_home_cta_title'            => 'sanitize_text_field',
        '_ie_home_cta_text'             => 'sanitize_textarea_field',
        '_ie_home_cta_primary_text'     => 'sanitize_text_field',
        '_ie_home_cta_secondary_text'   => 'sanitize_text_field',
    ];

    foreach ( $text_fields as $key => $callback ) {
        if ( isset( $_POST[ $key ] ) ) {
            update_post_meta( $post_id, $key, $callback( wp_unslash( $_POST[ $key ] ) ) );
        }
    }

    $url_fields = [
        '_ie_home_hero_primary_url',
        '_ie_home_hero_secondary_url',
        '_ie_home_cta_primary_url',
        '_ie_home_cta_secondary_url',
    ];

    foreach ( $url_fields as $key ) {
        if ( isset( $_POST[ $key ] ) ) {
            update_post_meta( $post_id, $key, esc_url_raw( wp_unslash( $_POST[ $key ] ) ) );
        }
    }

    $icons  = isset( $_POST['ie_home_why_icon'] ) ? wp_unslash( $_POST['ie_home_why_icon'] ) : [];
    $titles = isset( $_POST['ie_home_why_title_item'] ) ? wp_unslash( $_POST['ie_home_why_title_item'] ) : [];
    $texts  = isset( $_POST['ie_home_why_text'] ) ? wp_unslash( $_POST['ie_home_why_text'] ) : [];
    $items  = [];

    if ( is_array( $titles ) ) {
        foreach ( $titles as $i => $title ) {
            $items[] = [
                'icon'  => $icons[ $i ] ?? '',
                'title' => $title,
                'text'  => $texts[ $i ] ?? '',
            ];
        }
    }

    update_post_meta( $post_id, '_ie_home_why_items', wp_json_encode( ie_normalize_home_why_items( $items ) ) );
}
add_action( 'save_post_page', 'ie_save_home_page_meta' );

function ie_enqueue_home_admin_assets( $hook ) {
    if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
        return;
    }

    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'page' ) {
        return;
    }

    wp_enqueue_media();

    wp_enqueue_script(
        'ie-admin-home',
        ie_asset_uri( 'js/admin-home.js' ),
        [ 'jquery', 'media-editor' ],
        IE_THEME_VERSION,
        true
    );

    wp_localize_script(
        'ie-admin-home',
        'IE_HOME_ADMIN',
        [
            'selectImage' => ie__( 'Select Slide Image' ),
            'useImage'    => ie__( 'Use this image' ),
            'noImage'     => ie__( 'No image' ),
        ]
    );
}
add_action( 'admin_enqueue_scripts', 'ie_enqueue_home_admin_assets' );

function ie_get_home_content_post_id() {
    if ( is_front_page() && get_option( 'show_on_front' ) === 'page' ) {
        $front_id = (int) get_option( 'page_on_front' );
        if ( $front_id ) {
            return $front_id;
        }
    }

    return get_queried_object_id();
}
