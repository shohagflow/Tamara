<?php
/**
 * Server-side branded subscription invoice PDF generator.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_resolve_invoice_logo_path( $logo_url ) {
    $logo_url = trim( (string) $logo_url );

    if ( $logo_url === '' ) {
        return '';
    }

    $logo_url = preg_replace( '/\?.*$/', '', $logo_url );
    $candidates = [];

    $upload = wp_upload_dir();
    if ( ! empty( $upload['baseurl'] ) && strpos( $logo_url, $upload['baseurl'] ) === 0 ) {
        $candidates[] = str_replace( $upload['baseurl'], $upload['basedir'], $logo_url );
    }

    $theme_uri = get_template_directory_uri();
    $theme_dir = get_template_directory();
    if ( strpos( $logo_url, $theme_uri ) === 0 ) {
        $candidates[] = str_replace( $theme_uri, $theme_dir, $logo_url );
    }

    $path = wp_parse_url( $logo_url, PHP_URL_PATH );
    if ( $path ) {
        $candidates[] = ABSPATH . ltrim( $path, '/' );
    }

    foreach ( array_unique( array_filter( $candidates ) ) as $candidate ) {
        if ( is_readable( $candidate ) ) {
            return $candidate;
        }
    }

    return '';
}

function ie_invoice_pdf_flatten_logo_to_jpeg( $path, array $bg_rgb ) {
    if ( ! function_exists( 'imagecreatefromstring' ) ) {
        return '';
    }

    $binary = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
    if ( $binary === false || $binary === '' ) {
        return '';
    }

    $source = @imagecreatefromstring( $binary );
    if ( ! $source ) {
        return '';
    }

    $width  = imagesx( $source );
    $height = imagesy( $source );
    $canvas = imagecreatetruecolor( $width, $height );

    if ( ! $canvas ) {
        imagedestroy( $source );
        return '';
    }

    $bg_color = imagecolorallocate( $canvas, $bg_rgb[0], $bg_rgb[1], $bg_rgb[2] );
    imagefill( $canvas, 0, 0, $bg_color );

    imagealphablending( $canvas, true );
    imagesavealpha( $canvas, false );
    imagealphablending( $source, true );
    imagesavealpha( $source, true );
    imagecopy( $canvas, $source, 0, 0, 0, 0, $width, $height );

    imagedestroy( $source );

    $temp = wp_tempnam( 'ie-invoice-logo' );
    if ( ! $temp ) {
        imagedestroy( $canvas );
        return '';
    }

    $temp .= '.jpg';
    imagejpeg( $canvas, $temp, 92 );
    imagedestroy( $canvas );

    return $temp;
}

function ie_invoice_pdf_prepare_logo_image( $logo_url, array $bg_rgb ) {
    $path = ie_resolve_invoice_logo_path( $logo_url );

    if ( $path === '' ) {
        return [
            'path'    => '',
            'is_temp' => false,
        ];
    }

    $extension = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

    if ( in_array( $extension, [ 'jpg', 'jpeg' ], true ) ) {
        return [
            'path'    => $path,
            'is_temp' => false,
        ];
    }

    $temp = ie_invoice_pdf_flatten_logo_to_jpeg( $path, $bg_rgb );

    return [
        'path'    => $temp,
        'is_temp' => $temp !== '',
    ];
}

function ie_invoice_pdf_escape_text( $text ) {
    $text = wp_strip_all_tags( (string) $text );
    $text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );

    if ( function_exists( 'iconv' ) ) {
        $converted = @iconv( 'UTF-8', 'ISO-8859-1//TRANSLIT', $text );
        if ( $converted !== false ) {
            $text = $converted;
        }
    }

    return str_replace( [ '\\', '(', ')' ], [ '\\\\', '\\(', '\\)' ], $text );
}

function ie_generate_branded_invoice_pdf( array $data ) {
    $generator = new IE_Invoice_Pdf_Generator();
    return $generator->generate( $data );
}

function ie_stream_branded_invoice_pdf( array $data ) {
    if ( ! $data ) {
        wp_die( esc_html( ie__( 'Invalid invoice request.' ) ), esc_html( ie__( 'Invoice' ) ), [ 'response' => 400 ] );
    }

    $pdf      = ie_generate_branded_invoice_pdf( $data );
    $filename = sanitize_file_name( $data['pdf_filename'] ?? 'invoice.pdf' );

    nocache_headers();
    header( 'Content-Type: application/pdf' );
    header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
    header( 'Content-Length: ' . strlen( $pdf ) );
    header( 'X-Robots-Tag: noindex, nofollow', true );

    echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    exit;
}

class IE_Invoice_Pdf_Generator {
    private $objects   = [];
    private $offsets   = [];
    private $temp_logo = '';

    public function generate( array $data ) {
        $this->objects   = [];
        $this->offsets   = [];
        $this->temp_logo = '';

        $primary = ie_theme_hex_to_rgb( $data['primary'] ?? '#1f6f8f' );
        $dark    = ie_theme_hex_to_rgb( $data['primary_dark'] ?? '#184f66' );
        $light   = ie_theme_hex_to_rgb( $data['primary_light'] ?? '#e8f2f7' );

        $logo_path = ie_invoice_pdf_prepare_logo_image( $data['logo_url'] ?? '', $primary );
        if ( ! empty( $logo_path['is_temp'] ) && ! empty( $logo_path['path'] ) ) {
            $this->temp_logo = $logo_path['path'];
        }

        $image_obj = 0;
        $image_w   = 0;
        $image_h   = 0;
        $logo_file = $logo_path['path'] ?? '';

        if ( $logo_file && is_readable( $logo_file ) ) {
            $size = @getimagesize( $logo_file );
            if ( $size ) {
                $image_w   = (int) $size[0];
                $image_h   = (int) $size[1];
                $jpeg_data = file_get_contents( $logo_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
                if ( $jpeg_data ) {
                    $image_obj = $this->add_object(
                        '<< /Type /XObject /Subtype /Image /Width ' . $image_w
                        . ' /Height ' . $image_h
                        . ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '
                        . strlen( $jpeg_data ) . " >>\nstream\n" . $jpeg_data . "\nendstream"
                    );
                }
            }
        }

        $font_regular = $this->add_object( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>' );
        $font_bold    = $this->add_object( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>' );

        $resources = '<< /Font << /F1 ' . $font_regular . ' 0 R /F2 ' . $font_bold . ' 0 R >>';
        if ( $image_obj ) {
            $resources .= ' /XObject << /Logo ' . $image_obj . ' 0 R >>';
        }
        $resources .= ' >>';

        $content = $this->build_content_stream( $data, $primary, $dark, $light, $image_obj, $image_w, $image_h );
        $content_obj = $this->add_object( '<< /Length ' . strlen( $content ) . " >>\nstream\n" . $content . "\nendstream" );

        $page_obj = $this->add_object(
            '<< /Type /Page /Parent PAGES_PLACEHOLDER /MediaBox [0 0 595.28 841.89] /Resources '
            . $resources . ' /Contents ' . $content_obj . ' 0 R >>'
        );

        $pages_obj = $this->add_object( '<< /Type /Pages /Kids [' . $page_obj . ' 0 R] /Count 1 >>' );
        $this->objects[ $page_obj - 1 ] = str_replace( 'PAGES_PLACEHOLDER', $pages_obj . ' 0 R', $this->objects[ $page_obj - 1 ] );

        $catalog_obj = $this->add_object( '<< /Type /Catalog /Pages ' . $pages_obj . ' 0 R >>' );

        $pdf = "%PDF-1.4\n";
        foreach ( $this->objects as $index => $object ) {
            $this->offsets[ $index + 1 ] = strlen( $pdf );
            $pdf .= ( $index + 1 ) . " 0 obj\n" . $object . "\nendobj\n";
        }

        $xref_offset = strlen( $pdf );
        $pdf .= "xref\n0 " . ( count( $this->objects ) + 1 ) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ( $i = 1; $i <= count( $this->objects ); $i++ ) {
            $pdf .= sprintf( "%010d 00000 n \n", $this->offsets[ $i ] );
        }

        $pdf .= "trailer\n<< /Size " . ( count( $this->objects ) + 1 ) . ' /Root ' . $catalog_obj . " 0 R >>\n";
        $pdf .= "startxref\n" . $xref_offset . "\n%%EOF";

        if ( $this->temp_logo && file_exists( $this->temp_logo ) ) {
            @unlink( $this->temp_logo );
        }

        return $pdf;
    }

    private function add_object( $body ) {
        $this->objects[] = $body;
        return count( $this->objects );
    }

    private function build_content_stream( array $data, array $primary, array $dark, array $light, $image_obj, $image_w, $image_h ) {
        $parts   = [];
        $page_h  = 841.89;
        $header_h = 112;
        $header_y = $page_h - $header_h;
        $pad_x    = 42;
        $mid_y    = $header_y + ( $header_h / 2 );

        $this->rect_fill( $parts, 0, $header_y, 595.28, $header_h, $primary );

        $logo_slot = 48;
        $text_x    = $pad_x;

        if ( $image_obj && $image_w > 0 && $image_h > 0 ) {
            $draw_h  = min( ( $image_h / $image_w ) * $logo_slot, $logo_slot );
            $draw_w  = min( ( $image_w / $image_h ) * $draw_h, $logo_slot );
            $logo_x  = $pad_x + ( ( $logo_slot - $draw_w ) / 2 );
            $logo_y  = $mid_y - ( $draw_h / 2 );

            $parts[] = 'q';
            $parts[] = sprintf( '%.3F 0 0 %.3F %.3F %.3F cm', $draw_w, $draw_h, $logo_x, $logo_y );
            $parts[] = '/Logo Do';
            $parts[] = 'Q';

            $text_x = $pad_x + $logo_slot + 14;
        }

        $this->text( $parts, $text_x, $mid_y + 8, '/F2', 18, $data['site_name'] ?? '', [ 255, 255, 255 ] );
        $this->text( $parts, $text_x, $mid_y - 11, '/F1', 10, $data['site_url'] ?? '', [ 255, 255, 255 ] );
        $this->text( $parts, 360, $mid_y + 10, '/F1', 10, ie__( 'Official Receipt' ), [ 255, 255, 255 ] );
        $this->text( $parts, 360, $mid_y - 15, '/F2', 22, ie__( 'Subscription Invoice' ), [ 255, 255, 255 ] );

        $section_y = $header_y - 38;
        $meta      = [
            [ 42, ie__( 'Invoice Number' ), $data['invoice_number'] ?? '' ],
            [ 170, ie__( 'Invoice Date' ), $data['date_label'] ?? '' ],
            [ 298, ie__( 'Status' ), $data['status_label'] ?? '' ],
            [ 426, ie__( 'Billing Period' ), $data['period_label'] ?? '' ],
        ];

        foreach ( $meta as $item ) {
            $this->text( $parts, $item[0], $section_y, '/F1', 8, strtoupper( $item[1] ), [ 123, 135, 148 ] );
            $this->text( $parts, $item[0], $section_y - 14, '/F2', 11, $item[2], [ 26, 35, 50 ] );
        }

        $parties_y = $section_y - 58;
        $this->rect_fill( $parts, 42, $parties_y - 8, 511, 1, $light );

        $this->text( $parts, 42, $parties_y + 8, '/F1', 8, strtoupper( ie__( 'Billed To' ) ), [ 123, 135, 148 ] );
        $this->text( $parts, 322, $parties_y + 8, '/F1', 8, strtoupper( ie__( 'Issued By' ) ), [ 123, 135, 148 ] );
        $this->text( $parts, 42, $parties_y - 10, '/F2', 12, $data['customer_name'] ?? '', [ 26, 35, 50 ] );
        $this->text( $parts, 322, $parties_y - 10, '/F2', 12, $data['site_name'] ?? '', [ 26, 35, 50 ] );
        $this->text( $parts, 42, $parties_y - 25, '/F1', 10, $data['customer_email'] ?? '', [ 26, 35, 50 ] );
        $this->text( $parts, 322, $parties_y - 25, '/F1', 10, $data['site_email'] ?? '', [ 26, 35, 50 ] );

        $table_head_y = $parties_y - 58;
        $this->rect_fill( $parts, 42, $table_head_y - 4, 511, 24, $primary );
        $this->text( $parts, 50, $table_head_y + 4, '/F2', 9, strtoupper( ie__( 'Description' ) ), [ 255, 255, 255 ] );
        $this->text( $parts, 470, $table_head_y + 4, '/F2', 9, strtoupper( ie__( 'Amount' ) ), [ 255, 255, 255 ] );

        $row_y = $table_head_y - 24;
        foreach ( (array) ( $data['lines'] ?? [] ) as $line ) {
            $this->text( $parts, 50, $row_y, '/F1', 10, $line['description'] ?? '', [ 26, 35, 50 ] );
            $this->text( $parts, 470, $row_y, '/F1', 10, $line['amount'] ?? '', [ 26, 35, 50 ] );
            $row_y -= 22;
        }

        $row_y -= 8;
        $parts[] = '0.850 0.890 0.920 RG';
        $parts[] = '42 ' . $row_y . ' m 553 ' . $row_y . ' l S';

        $row_y -= 18;
        $this->text( $parts, 390, $row_y, '/F1', 10, ie__( 'Subtotal' ), [ 26, 35, 50 ] );
        $this->text( $parts, 470, $row_y, '/F1', 10, $data['subtotal'] ?? '', [ 26, 35, 50 ] );

        $row_y -= 22;
        $this->text( $parts, 390, $row_y, '/F2', 13, ie__( 'Total Paid' ), $primary );
        $this->text( $parts, 470, $row_y, '/F2', 13, $data['total'] ?? '', $primary );

        $this->rect_fill( $parts, 42, 62, 511, 52, $light );
        $this->text( $parts, 52, 94, '/F1', 10, sprintf( ie__( 'Thank you for subscribing with %s.' ), $data['site_name'] ?? '' ), [ 26, 35, 50 ] );
        $footer_line = trim( ( $data['site_name'] ?? '' ) . ' - ' . ( $data['site_url'] ?? '' ) );
        $this->text( $parts, 52, 78, '/F1', 9, $footer_line, [ 123, 135, 148 ] );

        return implode( "\n", $parts );
    }

    private function rect_fill( array &$parts, $x, $y, $w, $h, array $rgb ) {
        $parts[] = sprintf( '%.3F %.3F %.3F rg', $rgb[0] / 255, $rgb[1] / 255, $rgb[2] / 255 );
        $parts[] = $x . ' ' . $y . ' ' . $w . ' ' . $h . ' re f';
    }

    private function text( array &$parts, $x, $y, $font, $size, $text, array $rgb ) {
        $parts[] = sprintf( '%.3F %.3F %.3F rg', $rgb[0] / 255, $rgb[1] / 255, $rgb[2] / 255 );
        $parts[] = 'BT';
        $parts[] = $font . ' ' . $size . ' Tf';
        $parts[] = '1 0 0 1 ' . $x . ' ' . $y . ' Tm';
        $parts[] = '(' . ie_invoice_pdf_escape_text( $text ) . ') Tj';
        $parts[] = 'ET';
    }
}
