<?php
/**
 * Price page template helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_price_page_subtitle_text() {
    $trial_days = ie_get_configured_free_trial_days();

    if ( $trial_days > 0 ) {
        return sprintf(
            ie__( 'Register as a service provider and get a %d-day free trial with all Basic Plan features included. Choose the plan that fits your business and switch between monthly and yearly billing anytime.' ),
            $trial_days
        );
    }

    return ie__( 'Choose the plan that fits your business. Switch between monthly and yearly billing anytime.' );
}

function ie_render_price_intro( $intro ) {
    if ( empty( $intro['badge'] ) && empty( $intro['title'] ) && empty( $intro['subtitle'] ) ) {
        return;
    }
    ?>
    <div class="pricing-intro">
        <?php if ( ! empty( $intro['badge'] ) ) : ?>
            <span class="pricing-badge"><?php echo esc_html( $intro['badge'] ); ?></span>
        <?php endif; ?>
        <?php if ( ! empty( $intro['title'] ) ) : ?>
            <h1><?php echo esc_html( $intro['title'] ); ?></h1>
        <?php endif; ?>
        <?php if ( ! empty( $intro['subtitle'] ) ) : ?>
            <p><?php echo esc_html( $intro['subtitle'] ); ?></p>
        <?php endif; ?>
    </div>
    <?php
}

function ie_get_subscription_plan_by_checkout_id( $checkout_id ) {
    $checkout_id = sanitize_text_field( (string) $checkout_id );

    if ( ! preg_match( '/-(monthly|annual)$/', $checkout_id, $matches ) ) {
        return null;
    }

    $period = $matches[1] === 'monthly' ? 'monthly' : 'yearly';
    $slug   = substr( $checkout_id, 0, -strlen( $matches[0] ) );

    foreach ( ie_get_active_subscription_plans() as $plan ) {
        $plan_slug = ie_get_subscription_plan_slug( $plan['id'] ?? '' );

        if ( $plan_slug !== $slug ) {
            continue;
        }

        $billing = ie_admin_get_plan_billing( $plan );

        if ( $billing['period'] === $period ) {
            return $plan;
        }
    }

    return null;
}

function ie_get_subscription_checkout_plan_label( $plan ) {
    if ( ! is_array( $plan ) ) {
        return '';
    }

    $billing      = ie_admin_get_plan_billing( $plan );
    $plan_name    = $plan['name'] ?? ie__( 'Plan' );
    $billing_label = $billing['period'] === 'yearly' ? ie__( 'Yearly' ) : ie__( 'Monthly' );

    return sprintf( ie__( '%1$s (%2$s)' ), $plan_name, $billing_label );
}

function ie_get_active_subscription_plans_by_billing( $period = '' ) {
    $plans = ie_get_active_subscription_plans();

    if ( $period === '' ) {
        return $plans;
    }

    $period = sanitize_key( $period );

    if ( ! in_array( $period, [ 'monthly', 'yearly' ], true ) ) {
        return $plans;
    }

    return array_values( array_filter( $plans, function ( $plan ) use ( $period ) {
        $billing = ie_admin_get_plan_billing( $plan );

        return $billing['period'] === $period;
    } ) );
}

function ie_render_subscription_pricing_cards() {
    $plans = ie_get_active_subscription_plans();

    if ( ! $plans ) {
        echo '<p class="pricing-empty-message">' . esc_html( ie__( 'No subscription plans are available right now.' ) ) . '</p>';
        return;
    }

    $monthly_plans = ie_get_active_subscription_plans_by_billing( 'monthly' );
    $yearly_plans  = ie_get_active_subscription_plans_by_billing( 'yearly' );

    foreach ( $plans as $plan ) {
        $billing      = ie_admin_get_plan_billing( $plan );
        $period       = $billing['period'];
        $period_plans = $period === 'yearly' ? $yearly_plans : $monthly_plans;
        $period_index = 0;

        foreach ( $period_plans as $idx => $period_plan ) {
            if ( ( $period_plan['id'] ?? '' ) === ( $plan['id'] ?? '' ) ) {
                $period_index = $idx;
                break;
            }
        }

        $slug           = ie_get_subscription_plan_slug( $plan['id'] ?? '' );
        $price          = ie_format_subscription_price( $billing['price'] );
        $period_label   = $period === 'yearly' ? ie__( '/ year' ) : ie__( '/ month' );
        $features       = ie_admin_get_plan_editor_features( $plan );
        $is_featured    = count( $period_plans ) > 1 && $period_index === ( count( $period_plans ) - 1 );
        $icon_class     = $is_featured ? 'subscription-plan-icon-premium' : 'subscription-plan-icon-basic';
        $icon           = $is_featured ? 'fa-solid fa-crown' : 'fa-solid fa-layer-group';
        $card_class     = 'pricing-card subscription-card' . ( $is_featured ? ' featured' : '' );
        $card_class    .= $period === 'monthly' ? ' is-billing-active' : '';
        $button_class   = $is_featured ? 'btn-pricing-filled' : 'btn-pricing-outline';
        $plan_name      = $plan['name'] ?? ie__( 'Plan' );
        $description    = $plan['description'] ?? '';
        $billing_label  = $period === 'yearly' ? ie__( 'Yearly' ) : ie__( 'Monthly' );
        $plan_label     = sprintf( ie__( '%1$s (%2$s)' ), $plan_name, $billing_label );
        $price_label    = $price . ' / ' . ( $period === 'yearly' ? ie__( 'year' ) : ie__( 'month' ) );
        $plan_id        = $slug . ( $period === 'yearly' ? '-annual' : '-monthly' );
        $subscribe_text = sprintf( ie__( 'Subscribe to %s' ), preg_replace( '/\s+Plan$/i', '', $plan_name ) );
        ?>
        <article class="<?php echo esc_attr( $card_class ); ?>"
                 data-plan="<?php echo esc_attr( $slug ); ?>"
                 data-billing-period="<?php echo esc_attr( $period ); ?>">
            <?php if ( $is_featured ) : ?>
                <span class="pricing-card-badge badge-popular"><?php echo esc_html( ie__( 'Most Popular' ) ); ?></span>
            <?php endif; ?>

            <div class="subscription-card-head">
                <div class="subscription-plan-icon <?php echo esc_attr( $icon_class ); ?>">
                    <i class="<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></i>
                </div>
                <h3><?php echo esc_html( $plan_name ); ?></h3>
                <?php if ( $description !== '' ) : ?>
                    <p class="pricing-desc"><?php echo esc_html( $description ); ?></p>
                <?php endif; ?>
            </div>

            <div class="pricing-price">
                <span class="amount"><?php echo esc_html( $price ); ?></span>
                <span class="period"><?php echo esc_html( $period_label ); ?></span>
            </div>

            <ul class="pricing-features">
                <?php foreach ( $features as $feature ) : ?>
                    <?php if ( ( $feature['text'] ?? '' ) === '' ) : ?>
                        <?php continue; ?>
                    <?php endif; ?>
                    <?php
                    $icon_slug = ie_admin_get_plan_feature_icon_modifier( $feature['icon'] ?? 'fa-solid fa-check' );
                    $icon_cls  = ie_admin_resolve_plan_feature_icon( $feature['icon'] ?? 'fa-solid fa-check' );
                    ?>
                    <li>
                        <span class="feat-check feat-check--<?php echo esc_attr( str_replace( 'is-', '', $icon_slug ) ); ?>">
                            <i class="<?php echo esc_attr( $icon_cls ); ?>" aria-hidden="true"></i>
                        </span>
                        <?php echo esc_html( $feature['text'] ); ?>
                    </li>
                <?php endforeach; ?>
            </ul>

            <button type="button"
                    class="<?php echo esc_attr( $button_class ); ?> ie-choose-plan"
                    data-plan="<?php echo esc_attr( $plan_label ); ?>"
                    data-price="<?php echo esc_attr( $price_label ); ?>"
                    data-plan-id="<?php echo esc_attr( $plan_id ); ?>"
                    data-paypal="#">
                <?php echo esc_html( $subscribe_text ); ?>
            </button>
        </article>
        <?php
    }

    ?>
    <p class="pricing-empty-message pricing-empty-message--monthly"<?php echo $monthly_plans ? ' hidden' : ''; ?>>
        <?php echo esc_html( ie__( 'No monthly subscription plans are available right now.' ) ); ?>
    </p>
    <p class="pricing-empty-message pricing-empty-message--yearly" hidden>
        <?php echo esc_html( ie__( 'No yearly subscription plans are available right now.' ) ); ?>
    </p>
    <?php
}
