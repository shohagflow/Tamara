<?php
/**
 * Privacy page meta fields (banner, notice, sections repeater).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_privacy_default_banner() {
    return [
        'icon'         => 'fa-solid fa-shield-halved',
        'title'        => ie__( 'Privacy Policy' ),
        'subtitle'     => ie__( 'How Island Experts collects, uses, and protects your information' ),
        'last_updated' => ie__( 'Last updated: June 2025' ),
    ];
}

function ie_get_privacy_default_notice() {
    return [
        'label' => ie__( 'Interim Notice:' ),
        'text'  => ie__( 'This Privacy Policy is a standard interim document prepared for the launch of Island Experts. It will be reviewed and updated by qualified legal counsel prior to or shortly after the platform official launch.' ),
    ];
}

function ie_get_privacy_default_sections() {
    return [
        [
            'title'      => ie__( '1. Introduction' ),
            'content'    => ie__( 'Island Experts is committed to protecting your personal information. This Privacy Policy explains how we collect, use, store, and share your data when you use our platform. By using Island Experts, you agree to the collection and use of information as described in this policy.' ),
            'list_items' => [],
        ],
        [
            'title'      => ie__( '2. Information We Collect' ),
            'content'    => '',
            'list_items' => [
                ie__( 'Account information — name, email address, phone number, and password when you register' ),
                ie__( 'Provider profile — business name, description, service area, pricing, photos, and contact details' ),
                ie__( 'Booking information — service requested, preferred date and time, and notes provided' ),
                ie__( 'Payment records — billing details associated with your plan (card details are processed securely by PayPal)' ),
                ie__( 'Usage data — pages visited, search terms, device type, browser, and IP address' ),
                ie__( 'Reviews and ratings — content submitted through our review system' ),
            ],
        ],
        [
            'title'      => ie__( '3. How We Use Your Information' ),
            'content'    => '',
            'list_items' => [
                ie__( 'Create and manage your account' ),
                ie__( 'Display your provider profile to potential customers' ),
                ie__( 'Process booking requests and facilitate connections between users' ),
                ie__( 'Send important notifications related to your account, bookings, or listing approvals' ),
                ie__( 'Respond to your support requests' ),
                ie__( 'Improve our platform, features, and user experience' ),
                ie__( 'Comply with legal obligations' ),
            ],
        ],
        [
            'title'      => ie__( '4. How We Share Your Information' ),
            'content'    => ie__( 'We do not sell your personal data. We may share your information only in the following circumstances:' ),
            'list_items' => [
                ie__( 'With other users — provider profile information is visible to customers on the platform' ),
                ie__( 'With service providers — we use PayPal for payment processing and trusted hosting providers' ),
                ie__( 'For legal compliance — we may disclose information if required by law or to protect users' ),
            ],
        ],
        [
            'title'      => ie__( '5. Data Storage and Security' ),
            'content'    => ie__( 'Your data is stored securely on our web servers. We implement reasonable technical and organisational measures to protect your information against unauthorised access, loss, or misuse. However, no method of transmission over the internet is 100% secure.' ),
            'list_items' => [],
        ],
        [
            'title'      => ie__( '6. Cookies' ),
            'content'    => ie__( 'Island Experts uses cookies to enhance your browsing experience. Cookies help us keep you logged in, remember your preferences, and analyse how our platform is used. You can disable cookies in your browser settings, though this may affect functionality.' ),
            'list_items' => [],
        ],
        [
            'title'      => ie__( '7. Your Rights' ),
            'content'    => ie__( 'You have the right to:' ),
            'list_items' => [
                ie__( 'Access the personal data we hold about you' ),
                ie__( 'Request correction of inaccurate data' ),
                ie__( 'Request deletion of your account and associated data' ),
                ie__( 'Opt out of non-essential communications' ),
            ],
        ],
        [
            'title'      => ie__( '8. Children\'s Privacy' ),
            'content'    => ie__( 'Island Experts is not intended for use by individuals under the age of 18. We do not knowingly collect personal information from children. If we become aware that a child has registered, we will promptly delete their account.' ),
            'list_items' => [],
        ],
        [
            'title'      => ie__( '9. Third-Party Links' ),
            'content'    => ie__( 'Our platform may contain links to third-party websites, including provider websites and social media profiles. We are not responsible for the privacy practices of those external sites.' ),
            'list_items' => [],
        ],
        [
            'title'      => ie__( '10. Changes to This Policy' ),
            'content'    => ie__( 'We may update this Privacy Policy from time to time. When we do, we will update the date at the top of this page and notify registered users by email of any significant changes.' ),
            'list_items' => [],
        ],
        [
            'title'      => ie__( '11. Contact Us' ),
            'content'    => ie__( 'If you have any questions, concerns, or requests regarding this Privacy Policy or your personal data, please contact us through the Contact Us page on our website.' ),
            'list_items' => [],
        ],
    ];
}

function ie_get_privacy_sections( $post_id = null ) {
    $post_id = $post_id ?: get_queried_object_id();
    $raw     = get_post_meta( $post_id, '_ie_privacy_sections', true );
    $items   = [];

    if ( is_string( $raw ) && $raw !== '' ) {
        $decoded = json_decode( $raw, true );
        if ( is_array( $decoded ) ) {
            $items = ie_normalize_terms_sections( $decoded );
        }
    } elseif ( is_array( $raw ) ) {
        $items = ie_normalize_terms_sections( $raw );
    }

    if ( ! $items ) {
        $items = ie_normalize_terms_sections( ie_get_privacy_default_sections() );
    }

    return $items;
}

function ie_get_privacy_page_data( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_privacy_default_banner();
    $notice   = ie_get_privacy_default_notice();

    return [
        'banner'   => [
            'icon'         => get_post_meta( $post_id, '_ie_privacy_banner_icon', true ) ?: $defaults['icon'],
            'title'        => get_post_meta( $post_id, '_ie_privacy_banner_title', true ) ?: $defaults['title'],
            'subtitle'     => get_post_meta( $post_id, '_ie_privacy_banner_subtitle', true ) ?: $defaults['subtitle'],
            'last_updated' => get_post_meta( $post_id, '_ie_privacy_last_updated', true ) ?: $defaults['last_updated'],
        ],
        'notice'   => [
            'label' => get_post_meta( $post_id, '_ie_privacy_notice_label', true ) ?: $notice['label'],
            'text'  => get_post_meta( $post_id, '_ie_privacy_notice_text', true ) ?: $notice['text'],
        ],
        'sections' => ie_get_privacy_sections( $post_id ),
    ];
}

function ie_seed_privacy_page_defaults( $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id || get_post_type( $post_id ) !== 'page' ) {
        return;
    }

    $banner = ie_get_privacy_default_banner();
    $notice = ie_get_privacy_default_notice();

    if ( ! get_post_meta( $post_id, '_ie_privacy_banner_icon', true ) ) {
        update_post_meta( $post_id, '_ie_privacy_banner_icon', $banner['icon'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_privacy_banner_title', true ) ) {
        update_post_meta( $post_id, '_ie_privacy_banner_title', $banner['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_privacy_banner_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_privacy_banner_subtitle', $banner['subtitle'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_privacy_last_updated', true ) ) {
        update_post_meta( $post_id, '_ie_privacy_last_updated', $banner['last_updated'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_privacy_notice_label', true ) ) {
        update_post_meta( $post_id, '_ie_privacy_notice_label', $notice['label'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_privacy_notice_text', true ) ) {
        update_post_meta( $post_id, '_ie_privacy_notice_text', $notice['text'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_privacy_sections', true ) ) {
        update_post_meta( $post_id, '_ie_privacy_sections', wp_json_encode( ie_normalize_terms_sections( ie_get_privacy_default_sections() ) ) );
    }
}

function ie_add_privacy_page_meta_box( $post_type, $post ) {
    if ( $post_type !== 'page' || ! $post instanceof WP_Post ) {
        return;
    }

    if ( ! ie_page_uses_template( $post->ID, 'privacy.php' ) ) {
        return;
    }

    add_meta_box(
        'ie_privacy_page_settings',
        ie__( 'Privacy Page Settings' ),
        'ie_privacy_page_meta_box_cb',
        'page',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'ie_add_privacy_page_meta_box', 10, 2 );

function ie_privacy_page_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_privacy_page', 'ie_privacy_page_nonce' );

    $data     = ie_get_privacy_page_data( $post->ID );
    $banner   = $data['banner'];
    $notice   = $data['notice'];
    $sections = ie_normalize_terms_sections( json_decode( (string) get_post_meta( $post->ID, '_ie_privacy_sections', true ), true ) );

    if ( ! $sections ) {
        $sections = ie_normalize_terms_sections( ie_get_privacy_default_sections() );
    }
    ?>
    <style>
        .ie-privacy-meta-section { margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid #dcdcde; }
        .ie-privacy-meta-section:last-child { border-bottom: 0; margin-bottom: 0; padding-bottom: 0; }
        .ie-privacy-meta-section h4 { margin: 0 0 12px; font-size: 14px; }
        .ie-privacy-meta-field { margin-bottom: 14px; }
        .ie-privacy-meta-field label { display: block; font-weight: 600; margin-bottom: 6px; }
        .ie-privacy-meta-field input[type="text"],
        .ie-privacy-meta-field textarea { width: 100%; }
        .ie-privacy-meta-hint { color: #646970; font-size: 12px; margin-top: 4px; }
        .ie-privacy-repeater { display: flex; flex-direction: column; gap: 12px; }
        .ie-privacy-repeater-item { padding: 14px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 4px; }
        .ie-privacy-repeater-item__head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
        .ie-privacy-repeater-item__head strong { font-size: 13px; }
        .ie-privacy-remove-item { color: #b32d2e; border: 0; background: none; cursor: pointer; font-weight: 600; }
        .ie-privacy-add-item { margin-top: 12px; }
    </style>

    <div class="ie-privacy-meta-section">
        <h4><?php echo esc_html( ie__( 'Banner Section' ) ); ?></h4>

        <div class="ie-privacy-meta-field">
            <label for="ie_privacy_banner_icon"><?php echo esc_html( ie__( 'Icon Class' ) ); ?></label>
            <input type="text" id="ie_privacy_banner_icon" name="_ie_privacy_banner_icon" value="<?php echo esc_attr( $banner['icon'] ); ?>">
            <p class="ie-privacy-meta-hint"><?php echo esc_html( ie__( 'Font Awesome class, e.g. fa-solid fa-shield-halved' ) ); ?></p>
        </div>

        <div class="ie-privacy-meta-field">
            <label for="ie_privacy_banner_title"><?php echo esc_html( ie__( 'Banner Title' ) ); ?></label>
            <input type="text" id="ie_privacy_banner_title" name="_ie_privacy_banner_title" value="<?php echo esc_attr( $banner['title'] ); ?>">
        </div>

        <div class="ie-privacy-meta-field">
            <label for="ie_privacy_banner_subtitle"><?php echo esc_html( ie__( 'Banner Subtitle' ) ); ?></label>
            <textarea id="ie_privacy_banner_subtitle" name="_ie_privacy_banner_subtitle" rows="2"><?php echo esc_textarea( $banner['subtitle'] ); ?></textarea>
        </div>

        <div class="ie-privacy-meta-field">
            <label for="ie_privacy_last_updated"><?php echo esc_html( ie__( 'Last Updated Text' ) ); ?></label>
            <input type="text" id="ie_privacy_last_updated" name="_ie_privacy_last_updated" value="<?php echo esc_attr( $banner['last_updated'] ); ?>">
        </div>
    </div>

    <div class="ie-privacy-meta-section">
        <h4><?php echo esc_html( ie__( 'Notice Banner' ) ); ?></h4>

        <div class="ie-privacy-meta-field">
            <label for="ie_privacy_notice_label"><?php echo esc_html( ie__( 'Notice Label' ) ); ?></label>
            <input type="text" id="ie_privacy_notice_label" name="_ie_privacy_notice_label" value="<?php echo esc_attr( $notice['label'] ); ?>">
        </div>

        <div class="ie-privacy-meta-field">
            <label for="ie_privacy_notice_text"><?php echo esc_html( ie__( 'Notice Text' ) ); ?></label>
            <textarea id="ie_privacy_notice_text" name="_ie_privacy_notice_text" rows="3"><?php echo esc_textarea( $notice['text'] ); ?></textarea>
        </div>
    </div>

    <div class="ie-privacy-meta-section">
        <h4><?php echo esc_html( ie__( 'Privacy Sections' ) ); ?></h4>
        <p class="ie-privacy-meta-hint"><?php echo esc_html( ie__( 'Add each section with a title, content, and optional bullet points (one per line).' ) ); ?></p>

        <div id="ie-privacy-repeater" class="ie-privacy-repeater">
            <?php foreach ( $sections as $index => $section ) : ?>
                <?php ie_render_privacy_repeater_row( $index, $section ); ?>
            <?php endforeach; ?>
        </div>

        <button type="button" class="button ie-privacy-add-item" id="ie-privacy-add-item">
            <?php echo esc_html( ie__( 'Add Section' ) ); ?>
        </button>
    </div>

    <script type="text/template" id="ie-privacy-row-template">
        <?php ie_render_privacy_repeater_row( '__INDEX__', ie_get_privacy_default_sections()[0], true ); ?>
    </script>
    <?php
}

function ie_render_privacy_repeater_row( $index, $section, $is_template = false ) {
    $num = is_numeric( $index ) ? ( (int) $index + 1 ) : '__NUM__';
    ?>
    <div class="ie-privacy-repeater-item" data-index="<?php echo esc_attr( $index ); ?>">
        <div class="ie-privacy-repeater-item__head">
            <strong><?php echo esc_html( ie__( 'Section' ) ); ?> #<span class="ie-privacy-item-num"><?php echo esc_html( $num ); ?></span></strong>
            <button type="button" class="ie-privacy-remove-item"><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
        </div>

        <div class="ie-privacy-meta-field">
            <label><?php echo esc_html( ie__( 'Section Title' ) ); ?></label>
            <input type="text" name="ie_privacy_title[]" value="<?php echo $is_template ? '' : esc_attr( $section['title'] ?? '' ); ?>">
        </div>

        <div class="ie-privacy-meta-field">
            <label><?php echo esc_html( ie__( 'Section Content' ) ); ?></label>
            <textarea name="ie_privacy_content[]" rows="4"><?php echo $is_template ? '' : esc_textarea( $section['content'] ?? '' ); ?></textarea>
        </div>

        <div class="ie-privacy-meta-field">
            <label><?php echo esc_html( ie__( 'Bullet Points (one per line)' ) ); ?></label>
            <textarea name="ie_privacy_list_items[]" rows="4"><?php echo $is_template ? '' : esc_textarea( ie_format_terms_list_items( $section['list_items'] ?? [] ) ); ?></textarea>
        </div>
    </div>
    <?php
}

function ie_save_privacy_page_meta( $post_id ) {
    if ( ! isset( $_POST['ie_privacy_page_nonce'] ) || ! wp_verify_nonce( $_POST['ie_privacy_page_nonce'], 'ie_save_privacy_page' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( get_post_type( $post_id ) !== 'page' ) {
        return;
    }
    if ( ! ie_page_uses_template( $post_id, 'privacy.php' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
        return;
    }

    $text_fields = [
        '_ie_privacy_banner_icon'     => 'sanitize_text_field',
        '_ie_privacy_banner_title'    => 'sanitize_text_field',
        '_ie_privacy_banner_subtitle' => 'sanitize_textarea_field',
        '_ie_privacy_last_updated'    => 'sanitize_text_field',
        '_ie_privacy_notice_label'    => 'sanitize_text_field',
        '_ie_privacy_notice_text'     => 'sanitize_textarea_field',
    ];

    foreach ( $text_fields as $key => $callback ) {
        if ( isset( $_POST[ $key ] ) ) {
            update_post_meta( $post_id, $key, $callback( wp_unslash( $_POST[ $key ] ) ) );
        }
    }

    $titles   = isset( $_POST['ie_privacy_title'] ) ? wp_unslash( $_POST['ie_privacy_title'] ) : [];
    $contents = isset( $_POST['ie_privacy_content'] ) ? wp_unslash( $_POST['ie_privacy_content'] ) : [];
    $lists    = isset( $_POST['ie_privacy_list_items'] ) ? wp_unslash( $_POST['ie_privacy_list_items'] ) : [];
    $sections = [];

    if ( is_array( $titles ) ) {
        foreach ( $titles as $i => $title ) {
            $sections[] = [
                'title'      => $title,
                'content'    => $contents[ $i ] ?? '',
                'list_items' => ie_parse_terms_list_items( $lists[ $i ] ?? '' ),
            ];
        }
    }

    update_post_meta( $post_id, '_ie_privacy_sections', wp_json_encode( ie_normalize_terms_sections( $sections ) ) );
}
add_action( 'save_post_page', 'ie_save_privacy_page_meta' );

function ie_enqueue_privacy_admin_assets( $hook ) {
    if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
        return;
    }

    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'page' ) {
        return;
    }

    wp_enqueue_script(
        'ie-admin-privacy',
        ie_asset_uri( 'js/admin-privacy.js' ),
        [ 'jquery' ],
        IE_THEME_VERSION,
        true
    );
}
add_action( 'admin_enqueue_scripts', 'ie_enqueue_privacy_admin_assets' );
