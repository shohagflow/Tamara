<?php
/**
 * Contact page template helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_contact_icon_styles() {
    return [
        'primary' => ie__( 'Primary (Blue)' ),
        'phone'   => ie__( 'Phone (Blue)' ),
        'address' => ie__( 'Address (Orange)' ),
    ];
}

function ie_render_contact_sidebar_card( $item ) {
    $icon_class = $item['icon_class'] ?? 'fa-solid fa-envelope';
    $icon_style = $item['icon_style'] ?? 'primary';
    $label      = $item['label'] ?? '';
    $value      = $item['value'] ?? '';
    $link       = $item['link'] ?? '';
    $hint       = $item['hint'] ?? '';

    if ( $label === '' && $value === '' ) {
        return;
    }

    $allowed_styles = array_keys( ie_get_contact_icon_styles() );
    if ( ! in_array( $icon_style, $allowed_styles, true ) ) {
        $icon_style = 'primary';
    }

    $value_class = 'ie-contact-card__value';
    if ( $link === '' ) {
        $value_class .= ' ie-contact-card__value--text';
    }
    ?>
    <div class="ie-contact-card">
        <div class="ie-contact-card__icon ie-contact-card__icon--<?php echo esc_attr( $icon_style ); ?>">
            <i class="<?php echo esc_attr( $icon_class ); ?>" aria-hidden="true"></i>
        </div>
        <div>
            <?php if ( $label !== '' ) : ?>
                <span class="ie-contact-card__label"><?php echo esc_html( $label ); ?></span>
            <?php endif; ?>

            <?php if ( $value !== '' ) : ?>
                <?php if ( $link !== '' ) : ?>
                    <a href="<?php echo esc_url( $link ); ?>" class="<?php echo esc_attr( $value_class ); ?>"><?php echo esc_html( $value ); ?></a>
                <?php else : ?>
                    <span class="<?php echo esc_attr( $value_class ); ?>"><?php echo esc_html( $value ); ?></span>
                <?php endif; ?>
            <?php endif; ?>

            <?php if ( $hint !== '' ) : ?>
                <p class="ie-contact-card__hint"><?php echo esc_html( $hint ); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

function ie_render_contact_sidebar( $items ) {
    if ( ! $items ) {
        return;
    }
    ?>
    <aside class="ie-contact-sidebar">
        <?php foreach ( $items as $item ) {
            ie_render_contact_sidebar_card( $item );
        } ?>
    </aside>
    <?php
}
