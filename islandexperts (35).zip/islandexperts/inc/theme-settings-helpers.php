<?php
/**
 * Theme Settings – frontend helpers and defaults.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'IE_THEME_SETTINGS_OPTION', 'ie_theme_settings' );

function ie_get_theme_settings_defaults() {
    return [
        'global' => ie_get_theme_global_defaults(),
        'header' => [
            'logo_url'          => ie_image_uri( 'logo.png' ),
            'logo_alt'          => get_bloginfo( 'name' ),
            'background_color'  => '#ffffff',
        ],
        'footer' => [
            'brand' => [
                'logo_url' => '',
                'tagline'  => ie__( 'Connecting you with trusted local professionals right here in Saint Lucia.' ),
                'socials'  => [
                    [
                        'icon'  => 'fa-brands fa-facebook-f',
                        'url'   => 'https://facebook.com/islandexperts',
                        'label' => ie__( 'Facebook' ),
                    ],
                    [
                        'icon'  => 'fa-brands fa-instagram',
                        'url'   => 'https://instagram.com/islandexperts',
                        'label' => ie__( 'Instagram' ),
                    ],
                    [
                        'icon'  => 'fa-brands fa-whatsapp',
                        'url'   => 'https://wa.me/17584880281',
                        'label' => ie__( 'WhatsApp' ),
                    ],
                ],
            ],
            'columns' => [
                [
                    'title' => ie__( 'Company' ),
                    'type'  => 'links',
                    'links' => [
                        [ 'label' => ie__( 'FAQ' ), 'url' => ie_get_theme_page_url( 'faq' ) ],
                        [ 'label' => ie__( 'Contact Us' ), 'url' => ie_get_theme_page_url( 'contact' ) ],
                        [ 'label' => ie__( 'Terms & Conditions' ), 'url' => ie_get_theme_page_url( 'terms' ) ],
                        [ 'label' => ie__( 'Privacy Policy' ), 'url' => ie_get_theme_page_url( 'privacy' ) ],
                    ],
                ],
                [
                    'title' => ie__( 'Provider' ),
                    'type'  => 'links',
                    'links' => [
                        [ 'label' => ie__( 'Become a Provider' ), 'url' => ie_get_provider_register_url() ],
                        [ 'label' => ie__( 'Pricing Plans' ), 'url' => ie_get_theme_page_url( 'price' ) ],
                        [ 'label' => ie__( 'Register as Provider' ), 'url' => home_url( '/register-provider/' ) ],
                        [ 'label' => ie__( 'Provider Account' ), 'url' => ie_get_theme_page_url( 'account' ) ],
                    ],
                ],
                [
                    'title' => ie__( 'Contact' ),
                    'type'  => 'contact',
                    'items' => [
                        [
                            'icon'  => 'fa-solid fa-envelope',
                            'label' => ie__( 'Email' ),
                            'value' => 'islandexperts758@gmail.com',
                            'link'  => 'mailto:islandexperts758@gmail.com',
                        ],
                        [
                            'icon'  => 'fa-solid fa-phone',
                            'label' => ie__( 'Phone' ),
                            'value' => '1 (758) 488-0281',
                            'link'  => 'tel:+17584880281',
                        ],
                        [
                            'icon'  => 'fa-solid fa-location-dot',
                            'label' => ie__( 'Location' ),
                            'value' => ie__( 'Saint Lucia, Caribbean' ),
                            'link'  => '',
                        ],
                    ],
                ],
            ],
            'copyright'        => '',
            'background_color' => '#1B4965',
        ],
    ];
}

function ie_get_theme_settings() {
    $saved = get_option( IE_THEME_SETTINGS_OPTION, [] );
    if ( ! is_array( $saved ) ) {
        $saved = [];
    }

    return ie_merge_theme_settings( ie_get_theme_settings_defaults(), $saved );
}

function ie_merge_theme_settings( $defaults, $saved ) {
    $merged = $defaults;

    if ( isset( $saved['global'] ) && is_array( $saved['global'] ) ) {
        $merged['global'] = array_merge( $merged['global'], $saved['global'] );
    }

    if ( isset( $saved['header'] ) && is_array( $saved['header'] ) ) {
        $merged['header'] = array_merge( $merged['header'], $saved['header'] );
    }

    if ( isset( $saved['footer'] ) && is_array( $saved['footer'] ) ) {
        if ( isset( $saved['footer']['brand'] ) && is_array( $saved['footer']['brand'] ) ) {
            $merged['footer']['brand'] = array_merge( $merged['footer']['brand'], $saved['footer']['brand'] );
            if ( isset( $saved['footer']['brand']['socials'] ) && is_array( $saved['footer']['brand']['socials'] ) ) {
                $merged['footer']['brand']['socials'] = $saved['footer']['brand']['socials'];
            }
        }
        if ( isset( $saved['footer']['columns'] ) && is_array( $saved['footer']['columns'] ) ) {
            $merged['footer']['columns'] = $saved['footer']['columns'];
        }
        if ( array_key_exists( 'copyright', $saved['footer'] ) ) {
            $merged['footer']['copyright'] = (string) $saved['footer']['copyright'];
        }
        if ( array_key_exists( 'background_color', $saved['footer'] ) ) {
            $merged['footer']['background_color'] = (string) $saved['footer']['background_color'];
        }
    }

    return $merged;
}

function ie_get_header_logo_url() {
    $settings = ie_get_theme_settings();
    $url      = $settings['header']['logo_url'] ?? '';

    return $url ?: ie_image_uri( 'logo.png' );
}

function ie_get_header_logo_alt() {
    $settings = ie_get_theme_settings();
    $alt      = trim( (string) ( $settings['header']['logo_alt'] ?? '' ) );

    return $alt ?: get_bloginfo( 'name' );
}

function ie_get_header_background_color() {
    $settings = ie_get_theme_settings();
    $defaults = ie_get_theme_settings_defaults()['header'];

    return ie_sanitize_theme_hex_color(
        $settings['header']['background_color'] ?? '',
        $defaults['background_color']
    );
}

function ie_get_footer_logo_url() {
    $settings = ie_get_theme_settings();
    $url      = trim( (string) ( $settings['footer']['brand']['logo_url'] ?? '' ) );

    return $url ?: ie_get_header_logo_url();
}

function ie_get_footer_background_color() {
    $settings = ie_get_theme_settings();
    $defaults = ie_get_theme_settings_defaults()['footer'];

    return ie_sanitize_theme_hex_color(
        $settings['footer']['background_color'] ?? '',
        $defaults['background_color']
    );
}

function ie_get_theme_global_defaults() {
    return [
        'container_max' => '1300',
        'color_primary' => '#2d6a8f',
        'color_accent'  => '#e87b2e',
        'color_text'    => '#1a1a2e',
        'color_heading' => '#1a1a2e',
        'font_heading'  => 'Poppins',
        'font_body'     => 'Inter',
    ];
}

function ie_get_theme_font_choices() {
    return [
        'Poppins'         => 'Poppins',
        'Inter'           => 'Inter',
        'Roboto'          => 'Roboto',
        'Open Sans'       => 'Open Sans',
        'Lato'            => 'Lato',
        'Montserrat'      => 'Montserrat',
        'Nunito'          => 'Nunito',
        'Playfair Display'=> 'Playfair Display',
        'Merriweather'    => 'Merriweather',
    ];
}

function ie_sanitize_theme_hex_color( $color, $fallback ) {
    $color = sanitize_hex_color( $color );

    return $color ?: $fallback;
}

function ie_theme_hex_to_rgb( $hex ) {
    $hex = ltrim( (string) $hex, '#' );
    if ( strlen( $hex ) === 3 ) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }

    return [
        hexdec( substr( $hex, 0, 2 ) ),
        hexdec( substr( $hex, 2, 2 ) ),
        hexdec( substr( $hex, 4, 2 ) ),
    ];
}

function ie_theme_hex_to_rgb_string( $hex, $fallback = '#000000' ) {
    $rgb = ie_theme_hex_to_rgb( ie_sanitize_theme_hex_color( $hex, $fallback ) );

    return implode( ', ', $rgb );
}

function ie_theme_adjust_hex( $hex, $amount, $mix_with_white = false ) {
    $rgb = ie_theme_hex_to_rgb( $hex );
    $out = [];

    foreach ( $rgb as $channel ) {
        if ( $mix_with_white ) {
            $value = (int) round( $channel + ( 255 - $channel ) * $amount );
        } else {
            $value = (int) round( $channel * ( 1 - $amount ) );
        }
        $out[] = max( 0, min( 255, $value ) );
    }

    return sprintf( '#%02x%02x%02x', $out[0], $out[1], $out[2] );
}

function ie_get_theme_font_stack( $font_name ) {
    $font_name = trim( (string) $font_name );
    if ( $font_name === '' ) {
        $font_name = 'Inter';
    }

    return "'" . str_replace( "'", '', $font_name ) . "', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
}

function ie_get_theme_google_fonts_url() {
    $global       = ie_get_theme_settings()['global'] ?? ie_get_theme_global_defaults();
    $heading_font = $global['font_heading'] ?? 'Poppins';
    $body_font    = $global['font_body'] ?? 'Inter';
    $fonts        = array_values( array_unique( [ $heading_font, $body_font ] ) );
    $query        = [];

    foreach ( $fonts as $font ) {
        $family = str_replace( ' ', '+', trim( (string) $font ) );
        if ( $family === '' ) {
            continue;
        }
        $query[] = 'family=' . $family . ':wght@400;500;600;700';
    }

    if ( ! $query ) {
        $query[] = 'family=Inter:wght@400;500;600;700';
        $query[] = 'family=Poppins:wght@400;500;600;700';
    }

    return 'https://fonts.googleapis.com/css2?' . implode( '&', $query ) . '&display=swap';
}

function ie_get_theme_google_fonts_version() {
    $global = ie_get_theme_settings()['global'] ?? ie_get_theme_global_defaults();

    return md5( ( $global['font_heading'] ?? '' ) . '|' . ( $global['font_body'] ?? '' ) );
}

function ie_get_theme_primary_color() {
    $global   = ie_get_theme_settings()['global'] ?? ie_get_theme_global_defaults();
    $defaults = ie_get_theme_global_defaults();

    return ie_sanitize_theme_hex_color( $global['color_primary'] ?? '', $defaults['color_primary'] );
}

function ie_get_theme_global_css() {
    $global         = ie_get_theme_settings()['global'] ?? ie_get_theme_global_defaults();
    $defaults       = ie_get_theme_global_defaults();
    $container_max  = max( 960, min( 1600, absint( $global['container_max'] ?? $defaults['container_max'] ) ) );
    $color_primary  = ie_sanitize_theme_hex_color( $global['color_primary'] ?? '', $defaults['color_primary'] );
    $color_accent   = ie_sanitize_theme_hex_color( $global['color_accent'] ?? '', $defaults['color_accent'] );
    $color_text     = ie_sanitize_theme_hex_color( $global['color_text'] ?? '', $defaults['color_text'] );
    $color_heading  = ie_sanitize_theme_hex_color( $global['color_heading'] ?? '', $defaults['color_heading'] );
    $font_heading   = ie_get_theme_font_stack( $global['font_heading'] ?? $defaults['font_heading'] );
    $font_body      = ie_get_theme_font_stack( $global['font_body'] ?? $defaults['font_body'] );
    $primary_dark   = ie_theme_adjust_hex( $color_primary, 0.18 );
    $primary_light  = ie_theme_adjust_hex( $color_primary, 0.88, true );
    $accent_dark    = ie_theme_adjust_hex( $color_accent, 0.12 );

    return ie_get_theme_brand_root_css( [
        'color_primary'  => $color_primary,
        'primary_dark'   => $primary_dark,
        'primary_light'  => $primary_light,
        'color_accent'   => $color_accent,
        'accent_dark'    => $accent_dark,
        'color_text'     => $color_text,
        'color_heading'  => $color_heading,
        'container_max'  => $container_max,
        'font_heading'   => $font_heading,
        'font_body'      => $font_body,
    ] ) . "
    body {
        color: var(--color-text);
        font-family: var(--font-body);
    }
    h1, h2, h3, h4, h5, h6 {
        color: var(--color-heading);
        font-family: var(--font-heading);
    }
    .site-header {
        background: var(--header-bg-color);
    }
    .site-footer {
        background: var(--footer-bg-color);
    }";
}

function ie_get_theme_brand_root_css( $vars = null ) {
    if ( ! is_array( $vars ) ) {
        $global   = ie_get_theme_settings()['global'] ?? ie_get_theme_global_defaults();
        $defaults = ie_get_theme_global_defaults();
        $primary  = ie_sanitize_theme_hex_color( $global['color_primary'] ?? '', $defaults['color_primary'] );
        $accent   = ie_sanitize_theme_hex_color( $global['color_accent'] ?? '', $defaults['color_accent'] );

        $vars = [
            'color_primary' => $primary,
            'primary_dark'  => ie_theme_adjust_hex( $primary, 0.18 ),
            'primary_light' => ie_theme_adjust_hex( $primary, 0.88, true ),
            'color_accent'  => $accent,
        ];
    }

    $primary = $vars['color_primary'];
    $accent  = $vars['color_accent'] ?? '#e87b2e';

    $header_bg = ie_get_header_background_color();
    $footer_bg = ie_get_footer_background_color();

    return ":root {
        --container-max: " . (int) ( $vars['container_max'] ?? 1200 ) . "px;
        --header-bg-color: {$header_bg};
        --footer-bg-color: {$footer_bg};
        --color-primary: {$primary};
        --color-primary-dark: {$vars['primary_dark']};
        --color-primary-light: {$vars['primary_light']};
        --color-primary-rgb: " . ie_theme_hex_to_rgb_string( $primary ) . ";
        --color-accent: {$accent};
        --color-accent-dark: " . ( $vars['accent_dark'] ?? '#c9850a' ) . ";
        --color-text: " . ( $vars['color_text'] ?? '#4a5568' ) . ";
        --color-heading: " . ( $vars['color_heading'] ?? '#1a2332' ) . ";
        --font-heading: " . ( $vars['font_heading'] ?? "'Playfair Display', serif" ) . ";
        --font-body: " . ( $vars['font_body'] ?? "'DM Sans', sans-serif" ) . ";
        --btn-gradient: linear-gradient(90deg, {$accent} 0%, {$primary} 100%);
        --btn-gradient-hover: linear-gradient(90deg, {$primary} 0%, {$accent} 100%);
    }";
}

function ie_enqueue_theme_global_styles() {
    if ( ! wp_style_is( 'island-experts-style', 'enqueued' ) ) {
        return;
    }

    wp_add_inline_style( 'island-experts-style', ie_get_theme_global_css() );
}
add_action( 'wp_enqueue_scripts', 'ie_enqueue_theme_global_styles', 20 );

function ie_add_theme_font_preconnect( $urls, $relation_type ) {
    if ( 'preconnect' !== $relation_type ) {
        return $urls;
    }

    $urls[] = [
        'href' => 'https://fonts.googleapis.com',
    ];
    $urls[] = [
        'href'        => 'https://fonts.gstatic.com',
        'crossorigin' => 'anonymous',
    ];

    return $urls;
}
add_filter( 'wp_resource_hints', 'ie_add_theme_font_preconnect', 10, 2 );

function ie_get_footer_copyright_text() {
    $settings = ie_get_theme_settings();
    $custom   = trim( (string) ( $settings['footer']['copyright'] ?? '' ) );

    if ( $custom !== '' ) {
        return str_replace(
            [ '{year}', '{site_name}' ],
            [ date( 'Y' ), get_bloginfo( 'name' ) ],
            $custom
        );
    }

    return sprintf(
        '&copy; %1$s %2$s. %3$s',
        esc_html( date( 'Y' ) ),
        esc_html( get_bloginfo( 'name' ) ),
        esc_html( ie__( 'All rights reserved.' ) )
    );
}

function ie_render_site_footer() {
    $settings = ie_get_theme_settings();
    $brand    = $settings['footer']['brand'] ?? [];
    $columns  = $settings['footer']['columns'] ?? [];
    $col_count = max( 1, count( $columns ) );
    ?>
    <footer class="site-footer">
        <div class="container">
            <div class="footer-grid" style="--footer-extra-cols: <?php echo esc_attr( (string) $col_count ); ?>;">
                <div class="footer-col footer-brand">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer-logo">
                        <img src="<?php echo esc_url( ie_get_footer_logo_url() ); ?>" alt="<?php echo esc_attr( ie_get_header_logo_alt() ); ?>" class="footer-logo-img">
                    </a>
                    <?php if ( ! empty( $brand['tagline'] ) ) : ?>
                        <p class="footer-tagline"><?php echo esc_html( $brand['tagline'] ); ?></p>
                    <?php endif; ?>
                    <?php if ( ! empty( $brand['socials'] ) && is_array( $brand['socials'] ) ) : ?>
                        <div class="footer-socials">
                            <?php foreach ( $brand['socials'] as $social ) :
                                if ( empty( $social['url'] ) ) {
                                    continue;
                                }
                                ?>
                                <a href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-link" aria-label="<?php echo esc_attr( $social['label'] ?? '' ); ?>">
                                    <i class="<?php echo esc_attr( $social['icon'] ?? 'fa-solid fa-link' ); ?>" aria-hidden="true"></i>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <?php foreach ( $columns as $column ) :
                    $title = $column['title'] ?? '';
                    $type  = $column['type'] ?? 'links';
                    if ( $title === '' ) {
                        continue;
                    }
                    ?>
                    <div class="footer-col footer-col-<?php echo esc_attr( $type ); ?>">
                        <h3 class="footer-col-title"><?php echo esc_html( $title ); ?></h3>
                        <?php if ( $type === 'contact' && ! empty( $column['items'] ) ) : ?>
                            <ul class="footer-contact-list">
                                <?php foreach ( $column['items'] as $item ) :
                                    if ( empty( $item['value'] ) && empty( $item['label'] ) ) {
                                        continue;
                                    }
                                    ?>
                                    <li>
                                        <span class="footer-contact-icon"><i class="<?php echo esc_attr( $item['icon'] ?? 'fa-solid fa-circle-info' ); ?>" aria-hidden="true"></i></span>
                                        <div>
                                            <?php if ( ! empty( $item['label'] ) ) : ?>
                                                <span class="footer-contact-label"><?php echo esc_html( $item['label'] ); ?></span>
                                            <?php endif; ?>
                                            <?php if ( ! empty( $item['link'] ) ) : ?>
                                                <a href="<?php echo esc_url( $item['link'] ); ?>"><?php echo esc_html( $item['value'] ?? '' ); ?></a>
                                            <?php else : ?>
                                                <span class="footer-contact-text"><?php echo esc_html( $item['value'] ?? '' ); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php elseif ( ! empty( $column['links'] ) ) : ?>
                            <ul class="footer-nav">
                                <?php foreach ( $column['links'] as $link ) :
                                    if ( empty( $link['label'] ) || empty( $link['url'] ) ) {
                                        continue;
                                    }
                                    ?>
                                    <li><a href="<?php echo esc_url( $link['url'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="footer-bottom">
                <p class="footer-copy"><?php echo wp_kses_post( ie_get_footer_copyright_text() ); ?></p>
            </div>
        </div>
    </footer>
    <?php
}

function ie_get_theme_social_icon_presets() {
    return [
        'fa-brands fa-facebook-f'  => ie__( 'Facebook' ),
        'fa-brands fa-instagram'   => ie__( 'Instagram' ),
        'fa-brands fa-whatsapp'    => ie__( 'WhatsApp' ),
        'fa-brands fa-x-twitter'   => ie__( 'X (Twitter)' ),
        'fa-brands fa-linkedin-in' => ie__( 'LinkedIn' ),
        'fa-brands fa-youtube'     => ie__( 'YouTube' ),
        'fa-brands fa-tiktok'      => ie__( 'TikTok' ),
    ];
}

function ie_sanitize_theme_settings( $input ) {
    $defaults  = ie_get_theme_settings_defaults();
    $sanitized = ie_merge_theme_settings( $defaults, get_option( IE_THEME_SETTINGS_OPTION, [] ) );

    if ( isset( $input['global'] ) && is_array( $input['global'] ) ) {
        $global_defaults = $defaults['global'];
        $container_max     = absint( $input['global']['container_max'] ?? $global_defaults['container_max'] );
        $container_max     = max( 960, min( 1600, $container_max ) );

        $font_choices = array_keys( ie_get_theme_font_choices() );
        $font_heading = sanitize_text_field( $input['global']['font_heading'] ?? $global_defaults['font_heading'] );
        $font_body    = sanitize_text_field( $input['global']['font_body'] ?? $global_defaults['font_body'] );

        if ( ! in_array( $font_heading, $font_choices, true ) ) {
            $font_heading = $global_defaults['font_heading'];
        }
        if ( ! in_array( $font_body, $font_choices, true ) ) {
            $font_body = $global_defaults['font_body'];
        }

        $sanitized['global'] = [
            'container_max' => (string) $container_max,
            'color_primary' => ie_sanitize_theme_hex_color( $input['global']['color_primary'] ?? '', $global_defaults['color_primary'] ),
            'color_accent'  => ie_sanitize_theme_hex_color( $input['global']['color_accent'] ?? '', $global_defaults['color_accent'] ),
            'color_text'    => ie_sanitize_theme_hex_color( $input['global']['color_text'] ?? '', $global_defaults['color_text'] ),
            'color_heading' => ie_sanitize_theme_hex_color( $input['global']['color_heading'] ?? '', $global_defaults['color_heading'] ),
            'font_heading'  => $font_heading,
            'font_body'     => $font_body,
        ];
    }

    if ( isset( $input['header'] ) && is_array( $input['header'] ) ) {
        $sanitized['header']['logo_url']         = esc_url_raw( $input['header']['logo_url'] ?? '' ) ?: $defaults['header']['logo_url'];
        $sanitized['header']['logo_alt']         = sanitize_text_field( $input['header']['logo_alt'] ?? '' );
        $sanitized['header']['background_color'] = ie_sanitize_theme_hex_color(
            $input['header']['background_color'] ?? '',
            $defaults['header']['background_color']
        );
    }

    if ( isset( $input['footer'] ) && is_array( $input['footer'] ) ) {
        if ( isset( $input['footer']['brand'] ) && is_array( $input['footer']['brand'] ) ) {
            $sanitized['footer']['brand']['logo_url'] = esc_url_raw( $input['footer']['brand']['logo_url'] ?? '' );
            $sanitized['footer']['brand']['tagline']  = sanitize_textarea_field( $input['footer']['brand']['tagline'] ?? '' );

            $socials = [];
            if ( ! empty( $input['footer']['brand']['socials'] ) && is_array( $input['footer']['brand']['socials'] ) ) {
                foreach ( $input['footer']['brand']['socials'] as $social ) {
                    $url = esc_url_raw( $social['url'] ?? '' );
                    if ( $url === '' ) {
                        continue;
                    }
                    $socials[] = [
                        'icon'  => sanitize_text_field( $social['icon'] ?? 'fa-solid fa-link' ),
                        'url'   => $url,
                        'label' => sanitize_text_field( $social['label'] ?? '' ),
                    ];
                }
            }
            $sanitized['footer']['brand']['socials'] = $socials;
        }

        $columns = [];
        if ( ! empty( $input['footer']['columns'] ) && is_array( $input['footer']['columns'] ) ) {
            foreach ( $input['footer']['columns'] as $column ) {
                $title = sanitize_text_field( $column['title'] ?? '' );
                $type  = sanitize_key( $column['type'] ?? 'links' );
                if ( $title === '' ) {
                    continue;
                }
                if ( ! in_array( $type, [ 'links', 'contact' ], true ) ) {
                    $type = 'links';
                }

                $entry = [
                    'title' => $title,
                    'type'  => $type,
                ];

                if ( $type === 'contact' ) {
                    $items = [];
                    if ( ! empty( $column['items'] ) && is_array( $column['items'] ) ) {
                        foreach ( $column['items'] as $item ) {
                            $value = sanitize_text_field( $item['value'] ?? '' );
                            $label = sanitize_text_field( $item['label'] ?? '' );
                            if ( $value === '' && $label === '' ) {
                                continue;
                            }
                            $items[] = [
                                'icon'  => sanitize_text_field( $item['icon'] ?? 'fa-solid fa-circle-info' ),
                                'label' => $label,
                                'value' => $value,
                                'link'  => esc_url_raw( $item['link'] ?? '' ),
                            ];
                        }
                    }
                    $entry['items'] = $items;
                } else {
                    $links = [];
                    if ( ! empty( $column['links'] ) && is_array( $column['links'] ) ) {
                        foreach ( $column['links'] as $link ) {
                            $label = sanitize_text_field( $link['label'] ?? '' );
                            $url   = esc_url_raw( $link['url'] ?? '' );
                            if ( $label === '' || $url === '' ) {
                                continue;
                            }
                            $links[] = [
                                'label' => $label,
                                'url'   => $url,
                            ];
                        }
                    }
                    $entry['links'] = $links;
                }

                $columns[] = $entry;
            }
        }
        $sanitized['footer']['columns'] = $columns;
        $sanitized['footer']['copyright'] = sanitize_text_field( $input['footer']['copyright'] ?? '' );
        $sanitized['footer']['background_color'] = ie_sanitize_theme_hex_color(
            $input['footer']['background_color'] ?? '',
            $defaults['footer']['background_color']
        );
    }

    return $sanitized;
}
