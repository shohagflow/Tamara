<?php
/**
 * Provider ↔ Client offer system (chat-integrated).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_register_offer_cpt() {
    register_post_type( 'ie_offer', [
        'labels'   => [
            'name'          => ie__( 'Offers' ),
            'singular_name' => ie__( 'Offer' ),
        ],
        'public'   => false,
        'show_ui'  => false,
        'supports' => [ 'title' ],
    ] );
}
add_action( 'init', 'ie_register_offer_cpt', 11 );

function ie_offer_statuses() {
    return [
        'pending'           => ie__( 'Pending' ),
        'accepted'          => ie__( 'Accepted' ),
        'rejected'          => ie__( 'Rejected' ),
        'awaiting_approval' => ie__( 'Awaiting Approval' ),
        'completed'         => ie__( 'Completed' ),
    ];
}

function ie_format_offer_price( $price ) {
    $price = (float) $price;
    if ( $price <= 0 ) {
        return '$0';
    }

    return '$' . rtrim( rtrim( number_format( $price, 2, '.', ',' ), '0' ), '.' );
}

function ie_get_offer_meta( $offer_id ) {
    $offer_id = (int) $offer_id;
    if ( ! $offer_id ) {
        return null;
    }

    $post = get_post( $offer_id );
    if ( ! $post || $post->post_type !== 'ie_offer' ) {
        return null;
    }

    $status = sanitize_key( get_post_meta( $offer_id, '_ie_offer_status', true ) ?: 'pending' );
    if ( ! array_key_exists( $status, ie_offer_statuses() ) ) {
        $status = 'pending';
    }

    $customer_id = (int) get_post_meta( $offer_id, '_ie_offer_customer_id', true );
    $provider_id = (int) get_post_meta( $offer_id, '_ie_offer_provider_id', true );
    $customer    = $customer_id ? get_userdata( $customer_id ) : null;
    $provider    = $provider_id ? ie_get_provider_data( $provider_id ) : null;

    return [
        'id'              => $offer_id,
        'project_name'    => get_the_title( $offer_id ),
        'description'     => (string) get_post_meta( $offer_id, '_ie_project_description', true ),
        'delivery_days'   => max( 1, (int) get_post_meta( $offer_id, '_ie_delivery_days', true ) ),
        'price'           => (float) get_post_meta( $offer_id, '_ie_offer_price', true ),
        'price_label'     => ie_format_offer_price( get_post_meta( $offer_id, '_ie_offer_price', true ) ),
        'status'          => $status,
        'status_label'    => ie_offer_statuses()[ $status ],
        'customer_id'     => $customer_id,
        'provider_id'     => $provider_id,
        'customer_name'   => $customer ? $customer->display_name : '',
        'provider_name'   => $provider ? ie_get_provider_card_display_name( $provider_id, $provider ) : '',
        'created_at'      => get_post_meta( $offer_id, '_ie_offer_created_at', true ) ?: $post->post_date,
        'accepted_at'     => get_post_meta( $offer_id, '_ie_offer_accepted_at', true ),
        'completed_at'    => get_post_meta( $offer_id, '_ie_offer_completed_at', true ),
        'review_rating'   => (int) get_post_meta( $offer_id, '_ie_offer_review_rating', true ),
        'review_message'  => (string) get_post_meta( $offer_id, '_ie_offer_review_message', true ),
        'reviewed_at'     => (string) get_post_meta( $offer_id, '_ie_offer_reviewed_at', true ),
        'review_comment_id' => (int) get_post_meta( $offer_id, '_ie_offer_review_comment_id', true ),
        'has_review'      => (bool) get_post_meta( $offer_id, '_ie_offer_review_rating', true ),
        'progress'        => ie_get_offer_progress( $status ),
        'progress_label'  => ie_get_offer_progress_label( $status, 'customer' ),
    ];
}

function ie_get_offer_progress( $status ) {
    switch ( $status ) {
        case 'accepted':
            return 50;
        case 'awaiting_approval':
            return 85;
        case 'completed':
            return 100;
        default:
            return 0;
    }
}

function ie_get_offer_progress_label( $status, $role = 'customer' ) {
    $role = $role === 'provider' ? 'provider' : 'customer';

    if ( $status === 'accepted' ) {
        return ie__( 'Work in progress' );
    }

    if ( $status === 'awaiting_approval' ) {
        return $role === 'provider'
            ? ie__( 'Awaiting client approval' )
            : ie__( 'Review completed work' );
    }

    if ( $status === 'completed' ) {
        return ie__( 'Project completed' );
    }

    return '';
}

function ie_user_can_access_offer( $offer_id, $user_id = 0 ) {
    $offer = ie_get_offer_meta( $offer_id );
    $user_id = (int) ( $user_id ?: get_current_user_id() );

    if ( ! $offer || ! $user_id ) {
        return false;
    }

    if ( (int) $offer['customer_id'] === $user_id ) {
        return true;
    }

    if ( ie_get_user_type( $user_id ) === 'provider' ) {
        $provider_post = ie_get_provider_post_by_user( $user_id );
        return $provider_post && (int) $provider_post->ID === (int) $offer['provider_id'];
    }

    return false;
}

function ie_get_offer_for_chat( $offer_id, $user_id = 0 ) {
    if ( ! ie_user_can_access_offer( $offer_id, $user_id ) ) {
        return null;
    }

    $offer = ie_get_offer_meta( $offer_id );
    if ( ! $offer ) {
        return null;
    }

    $role = ie_get_user_type( $user_id ) === 'provider' ? 'provider' : 'customer';
    $offer['progress_label'] = ie_get_offer_progress_label( $offer['status'], $role );
    $offer['can_accept']     = $role === 'customer' && $offer['status'] === 'pending';
    $offer['can_reject']     = $role === 'customer' && $offer['status'] === 'pending';
    $offer['can_complete']   = $role === 'provider' && $offer['status'] === 'accepted';
    $offer['can_approve']    = $role === 'customer' && $offer['status'] === 'awaiting_approval';
    $offer['can_review']     = $role === 'customer' && $offer['status'] === 'completed' && ! $offer['has_review'];
    $offer['can_edit_review'] = ie_user_can_edit_offer_review( $offer_id, $user_id );
    $offer['can_reply_review'] = ie_user_can_reply_to_offer_review( $offer_id, $user_id );
    $offer['review_reply']   = ie_get_offer_review_reply( $offer_id );
    $offer['review_replied_at'] = ie_get_offer_review_replied_at( $offer_id );

    return $offer;
}

function ie_create_offer( $customer_id, $provider_id, $data ) {
    $customer_id = (int) $customer_id;
    $provider_id = (int) $provider_id;
    $name        = sanitize_text_field( $data['project_name'] ?? '' );
    $description = sanitize_textarea_field( $data['description'] ?? '' );
    $days        = max( 1, (int) ( $data['delivery_days'] ?? 1 ) );
    $price       = max( 0, (float) ( $data['price'] ?? 0 ) );

    if ( ! $customer_id || ! $provider_id || ! $name || $price <= 0 ) {
        return new WP_Error( 'invalid_offer', ie__( 'Please fill in all required offer fields.' ) );
    }

    $offer_id = wp_insert_post( [
        'post_type'   => 'ie_offer',
        'post_status' => 'publish',
        'post_title'  => $name,
    ] );

    if ( is_wp_error( $offer_id ) || ! $offer_id ) {
        return new WP_Error( 'create_failed', ie__( 'Failed to create offer.' ) );
    }

    update_post_meta( $offer_id, '_ie_offer_customer_id', $customer_id );
    update_post_meta( $offer_id, '_ie_offer_provider_id', $provider_id );
    update_post_meta( $offer_id, '_ie_project_description', $description );
    update_post_meta( $offer_id, '_ie_delivery_days', $days );
    update_post_meta( $offer_id, '_ie_offer_price', $price );
    update_post_meta( $offer_id, '_ie_offer_status', 'pending' );
    update_post_meta( $offer_id, '_ie_offer_created_at', current_time( 'mysql' ) );

    return (int) $offer_id;
}

function ie_update_offer_status( $offer_id, $status ) {
    $statuses = ie_offer_statuses();
    if ( ! array_key_exists( $status, $statuses ) ) {
        return false;
    }

    update_post_meta( $offer_id, '_ie_offer_status', $status );

    if ( $status === 'accepted' ) {
        update_post_meta( $offer_id, '_ie_offer_accepted_at', current_time( 'mysql' ) );
    }

    if ( in_array( $status, [ 'awaiting_approval', 'completed' ], true ) ) {
        update_post_meta( $offer_id, '_ie_offer_completed_at', current_time( 'mysql' ) );
    }

    return true;
}

function ie_save_offer_chat_message( $customer_id, $provider_id, $offer_id, $message_type, $sender = 'provider', $event_type = '' ) {
    $customer_id  = (int) $customer_id;
    $provider_id  = (int) $provider_id;
    $offer_id     = (int) $offer_id;
    $message_type = sanitize_key( $message_type );
    $sender       = $sender === 'customer' ? 'customer' : 'provider';
    $event_type   = sanitize_key( $event_type );

    $offer = ie_get_offer_meta( $offer_id );
    if ( ! $offer ) {
        return 0;
    }

    $body = '';
    if ( $message_type === 'offer' ) {
        $body = sprintf(
            ie__( 'Offer: %1$s — %2$s' ),
            $offer['project_name'],
            $offer['price_label']
        );
    } elseif ( $message_type === 'offer_event' && $event_type ) {
        $body = ie_get_offer_event_text( $event_type, $offer );
    }

    $message_id = wp_insert_post( [
        'post_type'    => 'ie_message',
        'post_status'  => 'publish',
        'post_author'  => $customer_id,
        'post_content' => $body,
        'post_title'   => sprintf( 'Offer %s — %d', $message_type, $offer_id ),
    ] );

    if ( is_wp_error( $message_id ) || ! $message_id ) {
        return 0;
    }

    update_post_meta( $message_id, '_ie_user_id', $customer_id );
    update_post_meta( $message_id, '_ie_provider_id', $provider_id );
    update_post_meta( $message_id, '_ie_sender', $sender );
    update_post_meta( $message_id, '_ie_created_at', current_time( 'mysql' ) );
    update_post_meta( $message_id, '_ie_message_type', $message_type );
    update_post_meta( $message_id, '_ie_offer_id', $offer_id );

    if ( $event_type ) {
        update_post_meta( $message_id, '_ie_event_type', $event_type );
    }

    return (int) $message_id;
}

function ie_get_offer_event_text( $event_type, $offer ) {
    switch ( $event_type ) {
        case 'offer_accepted':
            return sprintf( ie__( 'Offer accepted: %s' ), $offer['project_name'] );
        case 'offer_rejected':
            return sprintf( ie__( 'Offer rejected: %s' ), $offer['project_name'] );
        case 'work_completed':
            return sprintf( ie__( 'Work completed for: %s' ), $offer['project_name'] );
        case 'work_accepted':
            return sprintf( ie__( 'Completed work approved: %s' ), $offer['project_name'] );
        case 'review_prompt':
            return sprintf( ie__( 'Please leave a review for: %s' ), $offer['project_name'] );
        case 'review_submitted':
            return sprintf( ie__( 'Review submitted for: %s' ), $offer['project_name'] );
        default:
            return $offer['project_name'];
    }
}

function ie_get_offer_event_icon( $event_type ) {
    switch ( $event_type ) {
        case 'offer_accepted':
        case 'work_accepted':
            return 'fa-circle-check';
        case 'offer_rejected':
            return 'fa-circle-xmark';
        case 'work_completed':
            return 'fa-briefcase';
        case 'review_prompt':
            return 'fa-star';
        case 'review_submitted':
            return 'fa-star-half-stroke';
        default:
            return 'fa-bell';
    }
}

function ie_enrich_chat_message_row( $row, $message ) {
    if ( ! $message instanceof WP_Post ) {
        return $row;
    }

    $row['message_type'] = get_post_meta( $message->ID, '_ie_message_type', true ) ?: 'text';
    $row['offer_id']      = (int) get_post_meta( $message->ID, '_ie_offer_id', true );
    $row['event_type']     = get_post_meta( $message->ID, '_ie_event_type', true ) ?: '';

    if ( $row['offer_id'] ) {
        $row['offer'] = ie_get_offer_for_chat( $row['offer_id'], get_current_user_id() );
    }

    return $row;
}
add_filter( 'ie_chat_message_row', 'ie_enrich_chat_message_row', 10, 2 );

function ie_offer_chat_message_preview( $preview, $message ) {
    $type = get_post_meta( $message->ID, '_ie_message_type', true );
    if ( $type === 'offer' ) {
        $offer_id = (int) get_post_meta( $message->ID, '_ie_offer_id', true );
        $offer    = ie_get_offer_meta( $offer_id );
        if ( $offer ) {
            return sprintf( ie__( 'Offer: %1$s — %2$s' ), $offer['project_name'], $offer['price_label'] );
        }
    }

    if ( $type === 'offer_event' ) {
        $offer_id = (int) get_post_meta( $message->ID, '_ie_offer_id', true );
        $offer    = ie_get_offer_meta( $offer_id );
        $event    = get_post_meta( $message->ID, '_ie_event_type', true );
        if ( $offer && $event ) {
            return ie_get_offer_event_text( $event, $offer );
        }
    }

    return $preview;
}
add_filter( 'ie_chat_message_preview', 'ie_offer_chat_message_preview', 10, 2 );

function ie_render_special_chat_bubble( $message ) {
    $type = $message['message_type'] ?? 'text';

    if ( $type === 'offer' && ! empty( $message['offer'] ) ) {
        return ie_render_offer_card_html( $message['offer'], ie_get_user_type() === 'provider' ? 'provider' : 'customer', (int) ( $message['id'] ?? 0 ) );
    }

    if ( $type === 'offer_event' ) {
        return ie_render_offer_event_html( $message['event_type'] ?? '', $message['offer'] ?? null, $message['body'] ?? '' );
    }

    return null;
}

function ie_render_offer_card_html( $offer, $role, $message_id = 0 ) {
    if ( ! $offer ) {
        return '';
    }

    $role          = $role === 'provider' ? 'provider' : 'customer';
    $status        = $offer['status'] ?? 'pending';
    $status_class  = esc_attr( $status );
    $description   = trim( $offer['description'] ?? '' );
    $message_attr  = $message_id ? ' data-message-id="' . esc_attr( (string) $message_id ) . '"' : '';

    ob_start();
    ?>
    <div class="ie-chat-offer-card" data-offer-id="<?php echo esc_attr( (string) $offer['id'] ); ?>"<?php echo $message_attr; ?>>
        <div class="ie-chat-offer-card__head">
            <span class="ie-chat-offer-card__badge"><i class="fa-solid fa-handshake" aria-hidden="true"></i><?php echo esc_html( ie__( 'Project Offer' ) ); ?></span>
            <span class="ie-chat-offer-card__status is-<?php echo $status_class; ?>"><?php echo esc_html( $offer['status_label'] ?? '' ); ?></span>
        </div>
        <h4 class="ie-chat-offer-card__title"><?php echo esc_html( $offer['project_name'] ?? '' ); ?></h4>
        <?php if ( $description ) : ?>
            <p class="ie-chat-offer-card__desc"><?php echo esc_html( $description ); ?></p>
        <?php endif; ?>
        <div class="ie-chat-offer-card__meta">
            <span><i class="fa-regular fa-clock" aria-hidden="true"></i><?php echo esc_html( sprintf( _n( '%d day', '%d days', (int) $offer['delivery_days'], IE_TEXT_DOMAIN ), (int) $offer['delivery_days'] ) ); ?></span>
            <strong class="ie-chat-offer-card__price"><?php echo esc_html( $offer['price_label'] ?? '' ); ?></strong>
        </div>
        <?php if ( $role === 'customer' && $status === 'pending' ) : ?>
            <div class="ie-chat-offer-card__actions">
                <button type="button" class="ie-chat-offer-btn ie-chat-offer-btn--accept" data-offer-action="accept" data-offer-id="<?php echo esc_attr( (string) $offer['id'] ); ?>">
                    <?php echo esc_html( ie__( 'Accept Offer' ) ); ?>
                </button>
                <button type="button" class="ie-chat-offer-btn ie-chat-offer-btn--reject" data-offer-action="reject" data-offer-id="<?php echo esc_attr( (string) $offer['id'] ); ?>">
                    <?php echo esc_html( ie__( 'Reject Offer' ) ); ?>
                </button>
            </div>
        <?php elseif ( $role === 'customer' && $status === 'awaiting_approval' ) : ?>
            <div class="ie-chat-offer-card__actions">
                <button type="button" class="ie-chat-offer-btn ie-chat-offer-btn--accept" data-offer-action="approve_work" data-offer-id="<?php echo esc_attr( (string) $offer['id'] ); ?>">
                    <?php echo esc_html( ie__( 'Accept Completed Work' ) ); ?>
                </button>
            </div>
        <?php elseif ( $role === 'customer' && $status === 'completed' && empty( $offer['has_review'] ) ) : ?>
            <div class="ie-chat-offer-card__actions">
                <button type="button" class="ie-chat-offer-btn ie-chat-offer-btn--review" data-offer-action="review" data-offer-id="<?php echo esc_attr( (string) $offer['id'] ); ?>">
                    <?php echo esc_html( ie__( 'Leave Review' ) ); ?>
                </button>
            </div>
        <?php elseif ( $role === 'customer' && ! empty( $offer['can_edit_review'] ) ) : ?>
            <div class="ie-chat-offer-card__actions">
                <button type="button" class="ie-chat-offer-btn ie-chat-offer-btn--review" data-offer-action="edit_review" data-offer-id="<?php echo esc_attr( (string) $offer['id'] ); ?>">
                    <?php echo esc_html( ie__( 'Edit Review' ) ); ?>
                </button>
            </div>
        <?php elseif ( ! empty( $offer['can_complete'] ) ) : ?>
            <div class="ie-chat-offer-card__actions">
                <button type="button" class="ie-chat-offer-btn ie-chat-offer-btn--accept" data-offer-action="complete" data-offer-id="<?php echo esc_attr( (string) $offer['id'] ); ?>">
                    <?php echo esc_html( ie__( 'Complete Work' ) ); ?>
                </button>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

function ie_render_offer_event_html( $event_type, $offer, $body = '' ) {
    $icon = ie_get_offer_event_icon( $event_type );
    $text = $body ?: ( $offer ? ie_get_offer_event_text( $event_type, $offer ) : '' );

    ob_start();
    ?>
    <div class="ie-chat-offer-event is-<?php echo esc_attr( sanitize_html_class( $event_type ) ); ?>">
        <span class="ie-chat-offer-event__icon"><i class="fa-solid <?php echo esc_attr( $icon ); ?>" aria-hidden="true"></i></span>
        <span class="ie-chat-offer-event__text"><?php echo esc_html( $text ); ?></span>
    </div>
    <?php
    return ob_get_clean();
}

function ie_get_user_active_projects( $user_id = 0, $user_type = '' ) {
    $user_id   = (int) ( $user_id ?: get_current_user_id() );
    $user_type = $user_type ?: ie_get_user_type( $user_id );

    if ( ! $user_id || ! in_array( $user_type, [ 'customer', 'provider' ], true ) ) {
        return [];
    }

    $meta_query = [
        [
            'key'     => '_ie_offer_status',
            'value'   => [ 'accepted', 'awaiting_approval' ],
            'compare' => 'IN',
        ],
    ];

    if ( $user_type === 'customer' ) {
        $meta_query[] = [
            'key'   => '_ie_offer_customer_id',
            'value' => $user_id,
        ];
    } else {
        $provider_post = ie_get_provider_post_by_user( $user_id );
        if ( ! $provider_post ) {
            return [];
        }
        $meta_query[] = [
            'key'   => '_ie_offer_provider_id',
            'value' => (int) $provider_post->ID,
        ];
    }

    $offers = get_posts( [
        'post_type'      => 'ie_offer',
        'post_status'    => 'publish',
        'posts_per_page' => 20,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'meta_query'     => $meta_query,
    ] );

    $out  = [];
    $role = $user_type === 'provider' ? 'provider' : 'customer';

    foreach ( $offers as $offer_post ) {
        $offer = ie_get_offer_meta( $offer_post->ID );
        if ( ! $offer || $offer['status'] === 'completed' ) {
            continue;
        }

        $offer['progress_label'] = ie_get_offer_progress_label( $offer['status'], $role );
        $offer['can_complete']   = $role === 'provider' && $offer['status'] === 'accepted';
        $offer['can_approve']    = $role === 'customer' && $offer['status'] === 'awaiting_approval';
        $offer['can_review']     = $role === 'customer' && $offer['status'] === 'completed' && ! $offer['has_review'];
        $out[] = $offer;
    }

    return $out;
}

function ie_review_edit_window_seconds() {
    return 12 * HOUR_IN_SECONDS;
}

function ie_get_offer_review_comment_id( $offer_id ) {
    $offer_id   = (int) $offer_id;
    $comment_id = (int) get_post_meta( $offer_id, '_ie_offer_review_comment_id', true );

    if ( $comment_id && get_comment( $comment_id ) ) {
        return $comment_id;
    }

    $comments = get_comments( [
        'number'     => 1,
        'type'       => 'ie_review',
        'meta_key'   => '_ie_offer_id',
        'meta_value' => $offer_id,
    ] );

    if ( ! $comments ) {
        return 0;
    }

    $comment_id = (int) $comments[0]->comment_ID;
    update_post_meta( $offer_id, '_ie_offer_review_comment_id', $comment_id );

    return $comment_id;
}

function ie_get_offer_review_reply( $offer_id ) {
    $comment_id = ie_get_offer_review_comment_id( $offer_id );

    if ( ! $comment_id ) {
        return '';
    }

    return (string) get_comment_meta( $comment_id, '_ie_review_reply', true );
}

function ie_get_offer_review_replied_at( $offer_id ) {
    $comment_id = ie_get_offer_review_comment_id( $offer_id );

    if ( ! $comment_id ) {
        return '';
    }

    return (string) get_comment_meta( $comment_id, '_ie_review_replied_at', true );
}

function ie_user_can_edit_offer_review( $offer_id, $user_id = 0 ) {
    $offer   = ie_get_offer_meta( $offer_id );
    $user_id = (int) ( $user_id ?: get_current_user_id() );

    if ( ! $offer || ! $offer['has_review'] || (int) $offer['customer_id'] !== $user_id ) {
        return false;
    }

    $reviewed_at = $offer['reviewed_at'] ?: get_post_meta( $offer_id, '_ie_offer_reviewed_at', true );
    if ( ! $reviewed_at ) {
        return false;
    }

    return ( time() - strtotime( $reviewed_at ) ) <= ie_review_edit_window_seconds();
}

function ie_user_can_reply_to_offer_review( $offer_id, $user_id = 0 ) {
    $offer   = ie_get_offer_meta( $offer_id );
    $user_id = (int) ( $user_id ?: get_current_user_id() );

    if ( ! $offer || ! $offer['has_review'] || ie_get_user_type( $user_id ) !== 'provider' ) {
        return false;
    }

    $provider_post = ie_get_provider_post_by_user( $user_id );
    if ( ! $provider_post || (int) $provider_post->ID !== (int) $offer['provider_id'] ) {
        return false;
    }

    return ie_get_offer_review_reply( $offer_id ) === '';
}

function ie_recalculate_provider_rating( $provider_id ) {
    $provider_id = (int) $provider_id;
    $all         = get_comments( [
        'post_id' => $provider_id,
        'status'  => 'approve',
        'type'    => 'ie_review',
    ] );
    $total = 0;
    $count = count( $all );

    foreach ( $all as $review ) {
        $total += (int) ( get_comment_meta( $review->comment_ID, '_ie_review_rating', true ) ?: 5 );
    }

    $avg = $count > 0 ? round( $total / $count, 1 ) : 0;
    update_post_meta( $provider_id, '_ie_rating', $avg );
    update_post_meta( $provider_id, '_ie_review_count', $count );
}

function ie_submit_offer_review( $offer_id, $user_id, $rating, $message ) {
    $offer = ie_get_offer_meta( $offer_id );
    $user  = get_userdata( $user_id );

    if ( ! $offer || ! $user || (int) $offer['customer_id'] !== (int) $user_id ) {
        return new WP_Error( 'forbidden', ie__( 'You cannot review this project.' ) );
    }

    if ( $offer['status'] !== 'completed' ) {
        return new WP_Error( 'not_completed', ie__( 'You can review only after approving completed work.' ) );
    }

    if ( $offer['has_review'] ) {
        return new WP_Error( 'already_reviewed', ie__( 'You have already reviewed this project.' ) );
    }

    $rating  = min( 5, max( 1, (int) $rating ) );
    $message = sanitize_textarea_field( $message );

    if ( ! $message ) {
        return new WP_Error( 'missing_review', ie__( 'Please write your review.' ) );
    }

    $comment_id = wp_insert_comment( [
        'comment_post_ID'      => (int) $offer['provider_id'],
        'comment_author'       => $user->display_name,
        'comment_author_email' => $user->user_email,
        'comment_content'      => $message,
        'comment_type'         => 'ie_review',
        'comment_approved'     => 1,
        'user_id'              => $user_id,
    ] );

    if ( ! $comment_id ) {
        return new WP_Error( 'review_failed', ie__( 'Failed to submit review.' ) );
    }

    add_comment_meta( $comment_id, '_ie_review_rating', $rating );
    add_comment_meta( $comment_id, '_ie_offer_id', (int) $offer_id );

    update_post_meta( $offer_id, '_ie_offer_review_rating', $rating );
    update_post_meta( $offer_id, '_ie_offer_review_message', $message );
    update_post_meta( $offer_id, '_ie_offer_reviewed_at', current_time( 'mysql' ) );
    update_post_meta( $offer_id, '_ie_offer_review_comment_id', (int) $comment_id );

    ie_recalculate_provider_rating( (int) $offer['provider_id'] );

    ie_save_offer_chat_message(
        (int) $offer['customer_id'],
        (int) $offer['provider_id'],
        (int) $offer_id,
        'offer_event',
        'customer',
        'review_submitted'
    );

    return true;
}

function ie_update_offer_review( $offer_id, $user_id, $rating, $message ) {
    $offer = ie_get_offer_meta( $offer_id );
    $user  = get_userdata( $user_id );

    if ( ! $offer || ! $user || (int) $offer['customer_id'] !== (int) $user_id ) {
        return new WP_Error( 'forbidden', ie__( 'You cannot edit this review.' ) );
    }

    if ( ! ie_user_can_edit_offer_review( $offer_id, $user_id ) ) {
        return new WP_Error( 'edit_expired', ie__( 'Reviews can only be edited within 12 hours of submission.' ) );
    }

    $comment_id = ie_get_offer_review_comment_id( $offer_id );
    if ( ! $comment_id ) {
        return new WP_Error( 'review_missing', ie__( 'Review not found.' ) );
    }

    $rating  = min( 5, max( 1, (int) $rating ) );
    $message = sanitize_textarea_field( $message );

    if ( ! $message ) {
        return new WP_Error( 'missing_review', ie__( 'Please write your review.' ) );
    }

    $updated = wp_update_comment( [
        'comment_ID'      => $comment_id,
        'comment_content' => $message,
    ] );

    if ( ! $updated ) {
        return new WP_Error( 'review_failed', ie__( 'Failed to update review.' ) );
    }

    update_comment_meta( $comment_id, '_ie_review_rating', $rating );
    update_post_meta( $offer_id, '_ie_offer_review_rating', $rating );
    update_post_meta( $offer_id, '_ie_offer_review_message', $message );
    update_post_meta( $offer_id, '_ie_offer_review_edited_at', current_time( 'mysql' ) );

    ie_recalculate_provider_rating( (int) $offer['provider_id'] );

    return true;
}

function ie_submit_review_reply( $offer_id, $user_id, $reply ) {
    $offer = ie_get_offer_meta( $offer_id );
    $user  = get_userdata( $user_id );

    if ( ! $offer || ! $user || ! $offer['has_review'] ) {
        return new WP_Error( 'forbidden', ie__( 'You cannot reply to this review.' ) );
    }

    if ( ! ie_user_can_reply_to_offer_review( $offer_id, $user_id ) ) {
        if ( ie_get_offer_review_reply( $offer_id ) ) {
            return new WP_Error( 'already_replied', ie__( 'You have already replied to this review.' ) );
        }

        return new WP_Error( 'forbidden', ie__( 'You cannot reply to this review.' ) );
    }

    $reply = sanitize_textarea_field( $reply );
    if ( ! $reply ) {
        return new WP_Error( 'missing_reply', ie__( 'Please write your reply.' ) );
    }

    $comment_id = ie_get_offer_review_comment_id( $offer_id );
    if ( ! $comment_id ) {
        return new WP_Error( 'review_missing', ie__( 'Review not found.' ) );
    }

    update_comment_meta( $comment_id, '_ie_review_reply', $reply );
    update_comment_meta( $comment_id, '_ie_review_replied_at', current_time( 'mysql' ) );
    update_comment_meta( $comment_id, '_ie_review_reply_user_id', (int) $user_id );

    return true;
}

function ie_render_project_progress_section( $user_id = 0, $user_type = '' ) {
    $projects = ie_get_user_active_projects( $user_id, $user_type );
    if ( ! $projects ) {
        return;
    }

    $role = ( $user_type ?: ie_get_user_type( $user_id ) ) === 'provider' ? 'provider' : 'customer';
    ?>
    <section class="ie-project-progress-section" id="ie-project-progress-section" aria-label="<?php echo esc_attr( ie__( 'Active projects' ) ); ?>">
        <div class="ie-project-progress-section__head">
            <h2 class="ie-project-progress-section__title"><?php echo esc_html( ie__( 'Project Progress' ) ); ?></h2>
            <p class="ie-project-progress-section__desc"><?php echo esc_html( ie__( 'Active projects in progress only.' ) ); ?></p>
        </div>
        <div class="ie-project-progress-list" id="ie-project-progress-list">
            <?php foreach ( $projects as $project ) : ?>
                <?php echo ie_render_project_progress_card_html( $project, $role ); ?>
            <?php endforeach; ?>
        </div>
    </section>
    <?php
}

function ie_render_project_progress_card_html( $project, $role = 'customer' ) {
    if ( ! $project ) {
        return '';
    }

    $progress = (int) ( $project['progress'] ?? 0 );
    $role     = $role === 'provider' ? 'provider' : 'customer';

    ob_start();
    $party_name = $role === 'provider' ? ( $project['customer_name'] ?? '' ) : ( $project['provider_name'] ?? '' );
    ?>
    <article class="ie-project-progress-card"
             data-offer-id="<?php echo esc_attr( (string) $project['id'] ); ?>"
             data-offer-role="<?php echo esc_attr( $role ); ?>">
        <div class="ie-project-progress-card__content">
            <strong class="ie-project-progress-card__title"><?php echo esc_html( $project['project_name'] ?? '' ); ?></strong>
            <div class="ie-project-progress-card__meta">
                <span class="ie-project-progress-card__party"><?php echo esc_html( $party_name ); ?></span>
                <span class="ie-project-progress-card__price"><?php echo esc_html( $project['price_label'] ?? '' ); ?></span>
            </div>
            <div class="ie-project-progress-card__bar" aria-hidden="true">
                <span class="ie-project-progress-card__bar-fill" style="width: <?php echo esc_attr( (string) $progress ); ?>%;"></span>
            </div>
        </div>
        <div class="ie-project-progress-card__aside">
            <span class="ie-project-progress-card__status is-<?php echo esc_attr( $project['status'] ?? '' ); ?>">
                <?php echo esc_html( $project['progress_label'] ?? '' ); ?>
            </span>
            <button type="button" class="ie-project-progress-card__view" data-offer-view>
                <?php echo esc_html( ie__( 'View' ) ); ?>
            </button>
        </div>
    </article>
    <?php
    return ob_get_clean();
}

function ie_get_provider_completed_jobs( $user_id = 0, $limit = 50 ) {
    $user_id = (int) ( $user_id ?: get_current_user_id() );
    $provider_post = ie_get_provider_post_by_user( $user_id );

    if ( ! $provider_post ) {
        return [];
    }

    $offers = get_posts( [
        'post_type'      => 'ie_offer',
        'post_status'    => 'publish',
        'posts_per_page' => max( 1, (int) $limit ),
        'orderby'        => 'meta_value',
        'meta_key'       => '_ie_offer_completed_at',
        'order'          => 'DESC',
        'meta_query'     => [
            [
                'key'   => '_ie_offer_provider_id',
                'value' => (int) $provider_post->ID,
            ],
            [
                'key'   => '_ie_offer_status',
                'value' => 'completed',
            ],
        ],
    ] );

    $jobs = [];

    foreach ( $offers as $offer_post ) {
        $offer = ie_get_offer_meta( $offer_post->ID );
        if ( ! $offer ) {
            continue;
        }

        $offer['reviewed_at']      = (string) get_post_meta( $offer_post->ID, '_ie_offer_reviewed_at', true );
        $offer['customer_avatar']  = ie_get_user_profile_image_url( (int) $offer['customer_id'], 'thumbnail' );
        $offer['completed_label']  = $offer['completed_at']
            ? date_i18n( get_option( 'date_format' ), strtotime( $offer['completed_at'] ) )
            : '';
        $offer['reviewed_label']   = $offer['reviewed_at']
            ? date_i18n( get_option( 'date_format' ), strtotime( $offer['reviewed_at'] ) )
            : '';
        $offer['review_reply']     = ie_get_offer_review_reply( $offer_post->ID );
        $offer['review_replied_at'] = ie_get_offer_review_replied_at( $offer_post->ID );
        $offer['review_replied_label'] = $offer['review_replied_at']
            ? date_i18n( get_option( 'date_format' ), strtotime( $offer['review_replied_at'] ) )
            : '';
        $offer['can_reply_review'] = ie_user_can_reply_to_offer_review( $offer_post->ID, $user_id );
        $jobs[] = $offer;
    }

    return $jobs;
}

function ie_render_completed_job_star_rating( $rating, $max = 5 ) {
    $rating = max( 0, min( $max, (int) $rating ) );
    $html   = '<span class="provider-completed-job__stars" aria-label="' . esc_attr( sprintf( ie__( '%1$d of %2$d stars' ), $rating, $max ) ) . '">';

    for ( $i = 1; $i <= $max; $i++ ) {
        $icon_class = $i <= $rating ? 'fa-solid fa-star is-filled' : 'fa-regular fa-star';
        $html      .= '<i class="' . esc_attr( $icon_class ) . '" aria-hidden="true"></i>';
    }

    $html .= '</span>';

    return $html;
}

function ie_render_provider_completed_job_card_html( $job ) {
    if ( ! $job ) {
        return '';
    }

    $customer_initial = strtoupper( substr( (string) ( $job['customer_name'] ?? 'C' ), 0, 1 ) );
    $has_review       = ! empty( $job['has_review'] );

    ob_start();
    ?>
    <article class="provider-completed-job-card">
        <div class="provider-completed-job-card__main">
            <div class="provider-completed-job-card__project">
                <h3 class="provider-completed-job-card__title"><?php echo esc_html( $job['project_name'] ?? '' ); ?></h3>
                <?php if ( ! empty( $job['description'] ) ) : ?>
                    <p class="provider-completed-job-card__desc"><?php echo esc_html( $job['description'] ); ?></p>
                <?php endif; ?>
                <div class="provider-completed-job-card__meta">
                    <?php if ( ! empty( $job['completed_label'] ) ) : ?>
                        <span><i class="fa-regular fa-calendar-check" aria-hidden="true"></i><?php echo esc_html( $job['completed_label'] ); ?></span>
                    <?php endif; ?>
                    <span><i class="fa-solid fa-tag" aria-hidden="true"></i><?php echo esc_html( $job['price_label'] ?? '' ); ?></span>
                </div>
            </div>
            <span class="provider-completed-job-card__status"><?php echo esc_html( ie__( 'Completed' ) ); ?></span>
        </div>

        <div class="provider-completed-job-card__client">
            <div class="provider-completed-job-card__client-avatar" aria-hidden="true">
                <?php if ( ! empty( $job['customer_avatar'] ) ) : ?>
                    <img src="<?php echo esc_url( $job['customer_avatar'] ); ?>" alt="">
                <?php else : ?>
                    <span><?php echo esc_html( $customer_initial ); ?></span>
                <?php endif; ?>
            </div>
            <div class="provider-completed-job-card__client-body">
                <span class="provider-completed-job-card__client-label"><?php echo esc_html( ie__( 'Client' ) ); ?></span>
                <strong class="provider-completed-job-card__client-name"><?php echo esc_html( $job['customer_name'] ?? ie__( 'Customer' ) ); ?></strong>
            </div>
        </div>

        <div class="provider-completed-job-card__review<?php echo $has_review ? ' has-review' : ' is-empty'; ?>">
            <?php if ( $has_review ) : ?>
                <div class="provider-completed-job-card__review-head">
                    <?php echo ie_render_completed_job_star_rating( (int) ( $job['review_rating'] ?? 0 ) ); ?>
                    <?php if ( ! empty( $job['reviewed_label'] ) ) : ?>
                        <span class="provider-completed-job-card__review-date"><?php echo esc_html( $job['reviewed_label'] ); ?></span>
                    <?php endif; ?>
                </div>
                <?php if ( ! empty( $job['review_message'] ) ) : ?>
                    <blockquote class="provider-completed-job-card__review-text"><?php echo esc_html( $job['review_message'] ); ?></blockquote>
                <?php endif; ?>
                <?php if ( ! empty( $job['review_reply'] ) ) : ?>
                    <div class="provider-completed-job-card__reply">
                        <div class="provider-completed-job-card__reply-head">
                            <strong><?php echo esc_html( ie__( 'Your Reply' ) ); ?></strong>
                            <?php if ( ! empty( $job['review_replied_label'] ) ) : ?>
                                <span><?php echo esc_html( $job['review_replied_label'] ); ?></span>
                            <?php endif; ?>
                        </div>
                        <p class="provider-completed-job-card__reply-text"><?php echo esc_html( $job['review_reply'] ); ?></p>
                    </div>
                <?php elseif ( ! empty( $job['can_reply_review'] ) ) : ?>
                    <form class="provider-completed-job-card__reply-form" data-review-reply-form data-offer-id="<?php echo esc_attr( (string) ( $job['id'] ?? 0 ) ); ?>">
                        <label class="provider-completed-job-card__reply-label" for="review-reply-<?php echo esc_attr( (string) ( $job['id'] ?? 0 ) ); ?>">
                            <?php echo esc_html( ie__( 'Reply to Review' ) ); ?>
                        </label>
                        <textarea id="review-reply-<?php echo esc_attr( (string) ( $job['id'] ?? 0 ) ); ?>" name="reply" rows="3" maxlength="800" placeholder="<?php echo esc_attr( ie__( 'Write a professional response to this client review...' ) ); ?>" required></textarea>
                        <button type="submit" class="provider-completed-job-card__reply-submit"><?php echo esc_html( ie__( 'Post Reply' ) ); ?></button>
                    </form>
                <?php endif; ?>
            <?php else : ?>
                <p class="provider-completed-job-card__review-empty"><?php echo esc_html( ie__( 'No review submitted yet by this client.' ) ); ?></p>
            <?php endif; ?>
        </div>
    </article>
    <?php
    return ob_get_clean();
}

function ie_render_provider_completed_jobs_list( $user_id = 0 ) {
    $jobs           = ie_get_provider_completed_jobs( $user_id );
    $reviewed_count = count( array_filter( $jobs, static function ( $job ) {
        return ! empty( $job['has_review'] );
    } ) );
    ?>
    <div class="dashboard-panel-body provider-completed-jobs">
        <?php if ( ! $jobs ) : ?>
            <div class="provider-completed-jobs__empty">
                <i class="fa-solid fa-briefcase" aria-hidden="true"></i>
                <p><?php echo esc_html( ie__( 'No completed jobs yet.' ) ); ?></p>
                <span><?php echo esc_html( ie__( 'Completed projects and client reviews will appear here after work is approved.' ) ); ?></span>
            </div>
        <?php else : ?>
            <div class="provider-completed-jobs__summary">
                <span class="provider-completed-jobs__stat">
                    <strong><?php echo esc_html( (string) count( $jobs ) ); ?></strong>
                    <?php echo esc_html( ie__( 'Completed Jobs' ) ); ?>
                </span>
                <span class="provider-completed-jobs__stat">
                    <strong><?php echo esc_html( (string) $reviewed_count ); ?></strong>
                    <?php echo esc_html( ie__( 'Client Reviews' ) ); ?>
                </span>
            </div>
            <div class="provider-completed-jobs__list">
                <?php foreach ( $jobs as $job ) : ?>
                    <?php echo ie_render_provider_completed_job_card_html( $job ); ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

function ie_render_offer_modals() {
    ?>
    <div class="ie-offer-modal" id="ie-offer-create-modal" hidden>
        <div class="ie-offer-modal__backdrop" data-close-offer-modal></div>
        <div class="ie-offer-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="ie-offer-create-title">
            <div class="ie-offer-modal__head">
                <h3 id="ie-offer-create-title"><?php echo esc_html( ie__( 'Send Offer' ) ); ?></h3>
                <button type="button" class="ie-offer-modal__close" data-close-offer-modal aria-label="<?php echo esc_attr( ie__( 'Close' ) ); ?>">
                    <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                </button>
            </div>
            <form class="ie-offer-modal__body" id="ie-offer-create-form">
                <label class="ie-offer-field">
                    <span><?php echo esc_html( ie__( 'Project Name' ) ); ?> <em>*</em></span>
                    <input type="text" name="project_name" id="ie-offer-project-name" required maxlength="120">
                </label>
                <label class="ie-offer-field">
                    <span><?php echo esc_html( ie__( 'Project Description' ) ); ?></span>
                    <textarea name="description" id="ie-offer-project-description" rows="3" maxlength="600" placeholder="<?php echo esc_attr( ie__( 'Optional project details...' ) ); ?>"></textarea>
                </label>
                <div class="ie-offer-field-row">
                    <label class="ie-offer-field">
                        <span><?php echo esc_html( ie__( 'Delivery Date' ) ); ?> <em>*</em></span>
                        <input type="date"
                               name="delivery_date"
                               id="ie-offer-delivery-date"
                               min="<?php echo esc_attr( date( 'Y-m-d' ) ); ?>"
                               max="<?php echo esc_attr( date( 'Y-m-d', strtotime( '+365 days' ) ) ); ?>"
                               value="<?php echo esc_attr( date( 'Y-m-d', strtotime( '+7 days' ) ) ); ?>"
                               required>
                    </label>
                    <label class="ie-offer-field">
                        <span><?php echo esc_html( ie__( 'Price' ) ); ?> <em>*</em></span>
                        <input type="number" name="price" id="ie-offer-price" min="1" step="0.01" required placeholder="0.00">
                    </label>
                </div>
                <div class="ie-offer-modal__actions">
                    <button type="button" class="ie-offer-modal__btn ie-offer-modal__btn--ghost" data-close-offer-modal><?php echo esc_html( ie__( 'Cancel' ) ); ?></button>
                    <button type="submit" class="ie-offer-modal__btn ie-offer-modal__btn--primary" id="ie-offer-create-submit"><?php echo esc_html( ie__( 'Send Offer' ) ); ?></button>
                </div>
            </form>
        </div>
    </div>

    <div class="ie-offer-modal" id="ie-offer-detail-modal" hidden>
        <div class="ie-offer-modal__backdrop" data-close-offer-modal></div>
        <div class="ie-offer-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="ie-offer-detail-title">
            <div class="ie-offer-modal__head">
                <h3 id="ie-offer-detail-title"><?php echo esc_html( ie__( 'Project Details' ) ); ?></h3>
                <button type="button" class="ie-offer-modal__close" data-close-offer-modal aria-label="<?php echo esc_attr( ie__( 'Close' ) ); ?>">
                    <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                </button>
            </div>
            <div class="ie-offer-modal__body" id="ie-offer-detail-body">
                <div class="ie-offer-detail-loading"><div class="spinner"></div></div>
            </div>
            <div class="ie-offer-modal__actions" id="ie-offer-detail-actions" hidden></div>
        </div>
    </div>

    <div class="ie-offer-modal" id="ie-offer-review-modal" hidden>
        <div class="ie-offer-modal__backdrop" data-close-offer-modal></div>
        <div class="ie-offer-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="ie-offer-review-title">
            <div class="ie-offer-modal__head">
                <h3 id="ie-offer-review-title"><?php echo esc_html( ie__( 'Leave a Review' ) ); ?></h3>
                <button type="button" class="ie-offer-modal__close" data-close-offer-modal aria-label="<?php echo esc_attr( ie__( 'Close' ) ); ?>">
                    <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                </button>
            </div>
            <form class="ie-offer-modal__body" id="ie-offer-review-form">
                <input type="hidden" name="offer_id" id="ie-offer-review-offer-id" value="">
                <input type="hidden" name="review_mode" id="ie-offer-review-mode" value="create">
                <div class="ie-offer-review-stars" id="ie-offer-review-stars" role="radiogroup" aria-label="<?php echo esc_attr( ie__( 'Rating' ) ); ?>">
                    <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                        <button type="button" class="ie-offer-review-star" data-rating="<?php echo esc_attr( (string) $i ); ?>" aria-label="<?php echo esc_attr( sprintf( ie__( '%d stars' ), $i ) ); ?>">
                            <i class="fa-regular fa-star" aria-hidden="true"></i>
                        </button>
                    <?php endfor; ?>
                </div>
                <input type="hidden" name="rating" id="ie-offer-review-rating" value="5">
                <label class="ie-offer-field">
                    <span><?php echo esc_html( ie__( 'Review Message' ) ); ?> <em>*</em></span>
                    <textarea name="review" id="ie-offer-review-message" rows="4" required maxlength="800" placeholder="<?php echo esc_attr( ie__( 'Share your experience with this provider...' ) ); ?>"></textarea>
                </label>
                <div class="ie-offer-modal__actions">
                    <button type="button" class="ie-offer-modal__btn ie-offer-modal__btn--ghost" data-close-offer-modal><?php echo esc_html( ie__( 'Cancel' ) ); ?></button>
                    <button type="submit" class="ie-offer-modal__btn ie-offer-modal__btn--primary" id="ie-offer-review-submit"><?php echo esc_html( ie__( 'Submit Review' ) ); ?></button>
                </div>
            </form>
        </div>
    </div>
    <?php
}

/* === AJAX === */

function ie_ajax_send_offer() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $user_id = get_current_user_id();

    if ( ! ie_provider_has_plan_benefits( $user_id ) ) {
        wp_send_json_error( [ 'message' => ie_provider_plan_error( 'subscription' ) ] );
    }

    if ( ! ie_provider_can_send_message( $user_id ) ) {
        wp_send_json_error( [ 'message' => ie_provider_plan_error( 'messaging_limited' ) ] );
    }

    $customer_id = (int) ( $_POST['customer_id'] ?? 0 );
    $provider_post = ie_get_provider_post_by_user( $user_id );

    if ( ! $provider_post || ! $customer_id ) {
        wp_send_json_error( [ 'message' => ie__( 'Invalid conversation.' ) ] );
    }

    $customer = get_userdata( $customer_id );
    if ( ! $customer || ie_get_user_type( $customer_id ) !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Customer not found.' ) ] );
    }

    $offer_id = ie_create_offer( $customer_id, $provider_post->ID, [
        'project_name'  => $_POST['project_name'] ?? '',
        'description'   => $_POST['description'] ?? '',
        'delivery_days' => $_POST['delivery_days'] ?? 1,
        'price'         => $_POST['price'] ?? 0,
    ] );

    if ( is_wp_error( $offer_id ) ) {
        wp_send_json_error( [ 'message' => $offer_id->get_error_message() ] );
    }

    $message_id = ie_save_offer_chat_message( $customer_id, $provider_post->ID, $offer_id, 'offer', 'provider' );
    if ( ! $message_id ) {
        wp_send_json_error( [ 'message' => ie__( 'Failed to send offer message.' ) ] );
    }

    $saved = get_post( $message_id );
    $row   = $saved ? ie_format_chat_message_row( $saved ) : null;

    wp_send_json_success( [
        'message'  => ie__( 'Offer sent successfully!' ),
        'offer_id' => $offer_id,
        'chat'     => $row,
    ] );
}
add_action( 'wp_ajax_ie_send_offer', 'ie_ajax_send_offer' );

function ie_ajax_respond_offer() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $offer_id = (int) ( $_POST['offer_id'] ?? 0 );
    $action   = sanitize_key( $_POST['offer_action'] ?? '' );

    if ( ! $offer_id || ! in_array( $action, [ 'accept', 'reject' ], true ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Invalid request.' ) ] );
    }

    if ( ! ie_user_can_access_offer( $offer_id ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Offer not found.' ) ] );
    }

    $offer = ie_get_offer_meta( $offer_id );
    if ( ! $offer || $offer['status'] !== 'pending' ) {
        wp_send_json_error( [ 'message' => ie__( 'This offer can no longer be updated.' ) ] );
    }

    $new_status = $action === 'accept' ? 'accepted' : 'rejected';
    ie_update_offer_status( $offer_id, $new_status );

    $event = $action === 'accept' ? 'offer_accepted' : 'offer_rejected';
    ie_save_offer_chat_message(
        (int) $offer['customer_id'],
        (int) $offer['provider_id'],
        $offer_id,
        'offer_event',
        'customer',
        $event
    );

    wp_send_json_success( [
        'message' => $action === 'accept' ? ie__( 'Offer accepted.' ) : ie__( 'Offer rejected.' ),
        'offer'   => ie_get_offer_for_chat( $offer_id ),
        'projects'=> ie_get_user_active_projects(),
    ] );
}
add_action( 'wp_ajax_ie_respond_offer', 'ie_ajax_respond_offer' );

function ie_ajax_complete_offer_work() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $offer_id = (int) ( $_POST['offer_id'] ?? 0 );
    if ( ! $offer_id || ! ie_user_can_access_offer( $offer_id ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Offer not found.' ) ] );
    }

    $offer = ie_get_offer_meta( $offer_id );
    if ( ! $offer || $offer['status'] !== 'accepted' ) {
        wp_send_json_error( [ 'message' => ie__( 'This project is not ready to complete.' ) ] );
    }

    ie_update_offer_status( $offer_id, 'awaiting_approval' );
    ie_save_offer_chat_message(
        (int) $offer['customer_id'],
        (int) $offer['provider_id'],
        $offer_id,
        'offer_event',
        'provider',
        'work_completed'
    );

    wp_send_json_success( [
        'message'  => ie__( 'Work marked as completed. Waiting for client approval.' ),
        'offer'    => ie_get_offer_for_chat( $offer_id ),
        'projects' => ie_get_user_active_projects(),
    ] );
}
add_action( 'wp_ajax_ie_complete_offer_work', 'ie_ajax_complete_offer_work' );

function ie_ajax_accept_completed_work() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $offer_id = (int) ( $_POST['offer_id'] ?? 0 );
    if ( ! $offer_id || ! ie_user_can_access_offer( $offer_id ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Offer not found.' ) ] );
    }

    $offer = ie_get_offer_meta( $offer_id );
    if ( ! $offer || $offer['status'] !== 'awaiting_approval' ) {
        wp_send_json_error( [ 'message' => ie__( 'This project is not awaiting approval.' ) ] );
    }

    ie_update_offer_status( $offer_id, 'completed' );
    ie_save_offer_chat_message(
        (int) $offer['customer_id'],
        (int) $offer['provider_id'],
        $offer_id,
        'offer_event',
        'customer',
        'work_accepted'
    );
    ie_save_offer_chat_message(
        (int) $offer['customer_id'],
        (int) $offer['provider_id'],
        $offer_id,
        'offer_event',
        'provider',
        'review_prompt'
    );

    wp_send_json_success( [
        'message'       => ie__( 'Completed work accepted.' ),
        'offer'         => ie_get_offer_for_chat( $offer_id ),
        'projects'      => ie_get_user_active_projects(),
        'open_review'   => true,
        'review_offer_id' => $offer_id,
    ] );
}
add_action( 'wp_ajax_ie_accept_completed_work', 'ie_ajax_accept_completed_work' );

function ie_ajax_submit_offer_review() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $offer_id = (int) ( $_POST['offer_id'] ?? 0 );
    $rating   = (int) ( $_POST['rating'] ?? 5 );
    $review   = sanitize_textarea_field( $_POST['review'] ?? '' );

    $result = ie_submit_offer_review( $offer_id, get_current_user_id(), $rating, $review );
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( [ 'message' => $result->get_error_message() ] );
    }

    wp_send_json_success( [
        'message'  => ie__( 'Thank you! Your review has been submitted.' ),
        'offer'    => ie_get_offer_for_chat( $offer_id ),
        'projects' => ie_get_user_active_projects(),
    ] );
}
add_action( 'wp_ajax_ie_submit_offer_review', 'ie_ajax_submit_offer_review' );

function ie_ajax_update_offer_review() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'customer' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $offer_id = (int) ( $_POST['offer_id'] ?? 0 );
    $rating   = (int) ( $_POST['rating'] ?? 5 );
    $review   = sanitize_textarea_field( $_POST['review'] ?? '' );

    $result = ie_update_offer_review( $offer_id, get_current_user_id(), $rating, $review );
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( [ 'message' => $result->get_error_message() ] );
    }

    wp_send_json_success( [
        'message'  => ie__( 'Your review has been updated.' ),
        'offer'    => ie_get_offer_for_chat( $offer_id ),
        'projects' => ie_get_user_active_projects(),
    ] );
}
add_action( 'wp_ajax_ie_update_offer_review', 'ie_ajax_update_offer_review' );

function ie_ajax_submit_review_reply() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() || ie_get_user_type() !== 'provider' ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $offer_id = (int) ( $_POST['offer_id'] ?? 0 );
    $reply    = sanitize_textarea_field( $_POST['reply'] ?? '' );

    $result = ie_submit_review_reply( $offer_id, get_current_user_id(), $reply );
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( [ 'message' => $result->get_error_message() ] );
    }

    $offer = ie_get_offer_meta( $offer_id );
    $offer['review_reply'] = ie_get_offer_review_reply( $offer_id );
    $offer['review_replied_at'] = ie_get_offer_review_replied_at( $offer_id );
    $offer['review_replied_label'] = $offer['review_replied_at']
        ? date_i18n( get_option( 'date_format' ), strtotime( $offer['review_replied_at'] ) )
        : '';

    wp_send_json_success( [
        'message' => ie__( 'Reply posted successfully.' ),
        'offer'   => $offer,
    ] );
}
add_action( 'wp_ajax_ie_submit_review_reply', 'ie_ajax_submit_review_reply' );

function ie_ajax_get_offer_details() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $offer_id = (int) ( $_POST['offer_id'] ?? 0 );
    if ( ! $offer_id || ! ie_user_can_access_offer( $offer_id ) ) {
        wp_send_json_error( [ 'message' => ie__( 'Offer not found.' ) ] );
    }

    wp_send_json_success( [
        'offer' => ie_get_offer_for_chat( $offer_id ),
    ] );
}
add_action( 'wp_ajax_ie_get_offer_details', 'ie_ajax_get_offer_details' );

function ie_ajax_get_active_projects() {
    check_ajax_referer( 'ie_nonce', 'nonce' );

    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => ie__( 'Not allowed.' ) ] );
    }

    $user_type = ie_get_user_type();
    $projects  = ie_get_user_active_projects( get_current_user_id(), $user_type );
    $role      = $user_type === 'provider' ? 'provider' : 'customer';
    $html      = '';

    foreach ( $projects as $project ) {
        $html .= ie_render_project_progress_card_html( $project, $role );
    }

    wp_send_json_success( [
        'projects' => $projects,
        'html'     => $html,
        'count'    => count( $projects ),
    ] );
}
add_action( 'wp_ajax_ie_get_active_projects', 'ie_ajax_get_active_projects' );
