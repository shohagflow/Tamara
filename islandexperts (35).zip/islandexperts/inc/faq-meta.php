<?php
/**
 * FAQ page meta fields (banner + repeater).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_faq_default_banner() {
    return [
        'icon'     => 'fa-regular fa-circle-question',
        'title'    => ie__( 'Frequently Asked Questions' ),
        'subtitle' => ie__( 'Everything you need to know about Island Experts' ),
    ];
}

function ie_get_faq_default_items() {
    return [
        [
            'question' => ie__( 'Who can register on Island Experts?' ),
            'answer'   => ie__( 'Any legitimate service provider, freelancer, skilled tradesperson, or business operating in Saint Lucia — electricians, plumbers, carpenters, HVAC technicians, hairdressers, tutors, caterers, event planners, photographers, cleaners, mechanics, graphic designers, and more.' ),
        ],
        [
            'question' => ie__( 'How do I register my business?' ),
            'answer'   => ie__( 'Create a Service Provider account, choose a subscription plan, complete your business profile, and submit for review. Our team typically approves listings within 24 hours.' ),
        ],
        [
            'question' => ie__( 'Is there a registration fee?' ),
            'answer'   => ie__( 'Plans start at $9.99/month. Launch promotions may offer free listings for early providers — check our Pricing page for current offers.' ),
        ],
        [
            'question' => ie__( 'What information do I need to register?' ),
            'answer'   => ie__( 'Business name, contact info (phone & email), service description, category, profile photo, service area, years of experience, starting price, and optionally your website URL.' ),
        ],
        [
            'question' => ie__( 'How will customers find me?' ),
            'answer'   => ie__( 'Your profile appears in relevant search results and categories. Customers can filter by service type, location, price, and availability — making it easy to find and contact you.' ),
        ],
        [
            'question' => ie__( 'Can I update my profile after registration?' ),
            'answer'   => ie__( 'Yes. Update your contact info, services, pricing, photos, and business details at any time through your provider dashboard.' ),
        ],
        [
            'question' => ie__( 'Why should I join Island Experts?' ),
            'answer'   => ie__( 'Increase your online visibility, reach customers actively looking for your services, build credibility through verified reviews, spend less on advertising, and grow your business locally across Saint Lucia.' ),
        ],
        [
            'question' => ie__( 'How do I receive customer inquiries?' ),
            'answer'   => ie__( 'Customers can contact you through your profile contact information or via our built-in messaging system.' ),
        ],
    ];
}

function ie_normalize_faq_items( $items ) {
    if ( ! is_array( $items ) ) {
        return [];
    }

    $normalized = [];

    foreach ( $items as $item ) {
        if ( is_array( $item ) && isset( $item[0], $item[1] ) ) {
            $question = sanitize_text_field( $item[0] );
            $answer   = sanitize_textarea_field( $item[1] );
        } else {
            $question = sanitize_text_field( $item['question'] ?? '' );
            $answer   = sanitize_textarea_field( $item['answer'] ?? '' );
        }

        if ( $question === '' && $answer === '' ) {
            continue;
        }

        $normalized[] = [
            'question' => $question,
            'answer'   => $answer,
        ];
    }

    return $normalized;
}

function ie_get_faq_items_for_template( $post_id = null ) {
    $post_id = $post_id ?: get_queried_object_id();
    $raw     = get_post_meta( $post_id, '_ie_faq_items', true );
    $items   = [];

    if ( is_string( $raw ) && $raw !== '' ) {
        $decoded = json_decode( $raw, true );
        if ( is_array( $decoded ) ) {
            $items = ie_normalize_faq_items( $decoded );
        }
    } elseif ( is_array( $raw ) ) {
        $items = ie_normalize_faq_items( $raw );
    }

    if ( ! $items ) {
        $items = ie_get_faq_default_items();
    }

    return array_map(
        static function ( $item ) {
            return [ $item['question'], $item['answer'] ];
        },
        $items
    );
}

function ie_get_faq_page_data( $post_id = null ) {
    $post_id = $post_id ?: get_queried_object_id();
    $defaults = ie_get_faq_default_banner();

    $banner = [
        'icon'     => get_post_meta( $post_id, '_ie_faq_banner_icon', true ) ?: $defaults['icon'],
        'title'    => get_post_meta( $post_id, '_ie_faq_banner_title', true ) ?: $defaults['title'],
        'subtitle' => get_post_meta( $post_id, '_ie_faq_banner_subtitle', true ) ?: $defaults['subtitle'],
    ];

    return [
        'banner' => $banner,
        'items'  => ie_get_faq_items_for_template( $post_id ),
    ];
}

function ie_seed_faq_page_defaults( $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id || get_post_type( $post_id ) !== 'page' ) {
        return;
    }

    $defaults = ie_get_faq_default_banner();

    if ( ! get_post_meta( $post_id, '_ie_faq_banner_icon', true ) ) {
        update_post_meta( $post_id, '_ie_faq_banner_icon', $defaults['icon'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_faq_banner_title', true ) ) {
        update_post_meta( $post_id, '_ie_faq_banner_title', $defaults['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_faq_banner_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_faq_banner_subtitle', $defaults['subtitle'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_faq_items', true ) ) {
        update_post_meta( $post_id, '_ie_faq_items', wp_json_encode( ie_get_faq_default_items() ) );
    }
}

function ie_add_faq_page_meta_box( $post_type, $post ) {
    if ( $post_type !== 'page' || ! $post instanceof WP_Post ) {
        return;
    }

    if ( ! ie_page_uses_template( $post->ID, 'faq.php' ) ) {
        return;
    }

    add_meta_box(
        'ie_faq_page_settings',
        ie__( 'FAQ Page Settings' ),
        'ie_faq_page_meta_box_cb',
        'page',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'ie_add_faq_page_meta_box', 10, 2 );

function ie_faq_page_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_faq_page', 'ie_faq_page_nonce' );

    $banner = ie_get_faq_page_data( $post->ID )['banner'];
    $items  = ie_normalize_faq_items( json_decode( (string) get_post_meta( $post->ID, '_ie_faq_items', true ), true ) );

    if ( ! $items ) {
        $items = ie_get_faq_default_items();
    }
    ?>
    <style>
        .ie-faq-meta-section { margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid #dcdcde; }
        .ie-faq-meta-section:last-child { border-bottom: 0; margin-bottom: 0; padding-bottom: 0; }
        .ie-faq-meta-section h4 { margin: 0 0 12px; font-size: 14px; }
        .ie-faq-meta-field { margin-bottom: 14px; }
        .ie-faq-meta-field label { display: block; font-weight: 600; margin-bottom: 6px; }
        .ie-faq-meta-field input[type="text"],
        .ie-faq-meta-field textarea { width: 100%; }
        .ie-faq-meta-hint { color: #646970; font-size: 12px; margin-top: 4px; }
        .ie-faq-repeater { display: flex; flex-direction: column; gap: 12px; }
        .ie-faq-repeater-item { padding: 14px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 4px; }
        .ie-faq-repeater-item__head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
        .ie-faq-repeater-item__head strong { font-size: 13px; }
        .ie-faq-remove-item { color: #b32d2e; border: 0; background: none; cursor: pointer; font-weight: 600; }
        .ie-faq-add-item { margin-top: 12px; }
    </style>

    <div class="ie-faq-meta-section">
        <h4><?php echo esc_html( ie__( 'Banner Section' ) ); ?></h4>

        <div class="ie-faq-meta-field">
            <label for="ie_faq_banner_icon"><?php echo esc_html( ie__( 'Icon Class' ) ); ?></label>
            <input type="text" id="ie_faq_banner_icon" name="_ie_faq_banner_icon" value="<?php echo esc_attr( $banner['icon'] ); ?>">
            <p class="ie-faq-meta-hint"><?php echo esc_html( ie__( 'Font Awesome class, e.g. fa-regular fa-circle-question' ) ); ?></p>
        </div>

        <div class="ie-faq-meta-field">
            <label for="ie_faq_banner_title"><?php echo esc_html( ie__( 'Banner Title' ) ); ?></label>
            <input type="text" id="ie_faq_banner_title" name="_ie_faq_banner_title" value="<?php echo esc_attr( $banner['title'] ); ?>">
        </div>

        <div class="ie-faq-meta-field">
            <label for="ie_faq_banner_subtitle"><?php echo esc_html( ie__( 'Banner Subtitle' ) ); ?></label>
            <textarea id="ie_faq_banner_subtitle" name="_ie_faq_banner_subtitle" rows="3"><?php echo esc_textarea( $banner['subtitle'] ); ?></textarea>
        </div>
    </div>

    <div class="ie-faq-meta-section">
        <h4><?php echo esc_html( ie__( 'FAQ Items' ) ); ?></h4>
        <p class="ie-faq-meta-hint"><?php echo esc_html( ie__( 'Add questions and answers. They appear in order on the FAQ page.' ) ); ?></p>

        <div id="ie-faq-repeater" class="ie-faq-repeater">
            <?php foreach ( $items as $index => $item ) : ?>
                <?php ie_render_faq_repeater_row( $index, $item ); ?>
            <?php endforeach; ?>
        </div>

        <button type="button" class="button ie-faq-add-item" id="ie-faq-add-item">
            <?php echo esc_html( ie__( 'Add FAQ Item' ) ); ?>
        </button>
    </div>

    <script type="text/template" id="ie-faq-row-template">
        <?php ie_render_faq_repeater_row( '__INDEX__', [ 'question' => '', 'answer' => '' ], true ); ?>
    </script>
    <?php
}

function ie_render_faq_repeater_row( $index, $item, $is_template = false ) {
    $question = $item['question'] ?? '';
    $answer   = $item['answer'] ?? '';
    $label    = is_numeric( $index ) ? ( (int) $index + 1 ) : '__NUM__';
    ?>
    <div class="ie-faq-repeater-item" data-index="<?php echo esc_attr( $index ); ?>">
        <div class="ie-faq-repeater-item__head">
            <strong><?php echo esc_html( ie__( 'FAQ' ) ); ?> #<span class="ie-faq-item-num"><?php echo esc_html( $label ); ?></span></strong>
            <button type="button" class="ie-faq-remove-item"><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
        </div>
        <div class="ie-faq-meta-field">
            <label><?php echo esc_html( ie__( 'Question' ) ); ?></label>
            <input type="text" name="ie_faq_question[]" value="<?php echo $is_template ? '' : esc_attr( $question ); ?>">
        </div>
        <div class="ie-faq-meta-field">
            <label><?php echo esc_html( ie__( 'Answer' ) ); ?></label>
            <textarea name="ie_faq_answer[]" rows="4"><?php echo $is_template ? '' : esc_textarea( $answer ); ?></textarea>
        </div>
    </div>
    <?php
}

function ie_save_faq_page_meta( $post_id ) {
    if ( ! isset( $_POST['ie_faq_page_nonce'] ) || ! wp_verify_nonce( $_POST['ie_faq_page_nonce'], 'ie_save_faq_page' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( get_post_type( $post_id ) !== 'page' ) {
        return;
    }
    if ( ! ie_page_uses_template( $post_id, 'faq.php' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['_ie_faq_banner_icon'] ) ) {
        update_post_meta( $post_id, '_ie_faq_banner_icon', sanitize_text_field( wp_unslash( $_POST['_ie_faq_banner_icon'] ) ) );
    }
    if ( isset( $_POST['_ie_faq_banner_title'] ) ) {
        update_post_meta( $post_id, '_ie_faq_banner_title', sanitize_text_field( wp_unslash( $_POST['_ie_faq_banner_title'] ) ) );
    }
    if ( isset( $_POST['_ie_faq_banner_subtitle'] ) ) {
        update_post_meta( $post_id, '_ie_faq_banner_subtitle', sanitize_textarea_field( wp_unslash( $_POST['_ie_faq_banner_subtitle'] ) ) );
    }

    $questions = isset( $_POST['ie_faq_question'] ) ? wp_unslash( $_POST['ie_faq_question'] ) : [];
    $answers   = isset( $_POST['ie_faq_answer'] ) ? wp_unslash( $_POST['ie_faq_answer'] ) : [];
    $items     = [];

    if ( is_array( $questions ) ) {
        foreach ( $questions as $i => $question ) {
            $items[] = [
                'question' => sanitize_text_field( $questions[ $i ] ?? '' ),
                'answer'   => sanitize_textarea_field( $answers[ $i ] ?? '' ),
            ];
        }
    }

    update_post_meta( $post_id, '_ie_faq_items', wp_json_encode( ie_normalize_faq_items( $items ) ) );
}
add_action( 'save_post_page', 'ie_save_faq_page_meta' );

function ie_enqueue_faq_admin_assets( $hook ) {
    if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
        return;
    }

    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'page' ) {
        return;
    }

    wp_enqueue_script(
        'ie-admin-faq',
        ie_asset_uri( 'js/admin-faq.js' ),
        [ 'jquery' ],
        IE_THEME_VERSION,
        true
    );
}
add_action( 'admin_enqueue_scripts', 'ie_enqueue_faq_admin_assets' );
