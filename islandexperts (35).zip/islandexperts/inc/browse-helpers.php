<?php
/**
 * Browse page template helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_render_browse_hero( $header ) {
    if ( empty( $header['title'] ) && empty( $header['subtitle'] ) ) {
        return;
    }
    ?>
    <div class="browse-hero">
        <?php if ( ! empty( $header['title'] ) ) : ?>
            <h1 class="browse-page-title"><?php echo esc_html( $header['title'] ); ?></h1>
        <?php endif; ?>
        <?php if ( ! empty( $header['subtitle'] ) ) : ?>
            <p class="browse-page-subtitle"><?php echo esc_html( $header['subtitle'] ); ?></p>
        <?php endif; ?>
    </div>
    <?php
}
