<?php
/**
 * Terms page meta fields (banner, notice, sections repeater).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_terms_default_banner() {
    return [
        'icon'          => 'fa-solid fa-file-contract',
        'title'         => ie__( 'Terms and Conditions' ),
        'subtitle'      => ie__( 'Please read these terms carefully before using Island Experts' ),
        'last_updated'  => ie__( 'Last updated: June 2025' ),
    ];
}

function ie_get_terms_default_notice() {
    return [
        'label' => ie__( 'Interim Notice:' ),
        'text'  => ie__( 'These Terms and Conditions are a standard interim document prepared for the launch of Island Experts. They will be reviewed and updated by qualified legal counsel prior to or shortly after the platform official launch.' ),
    ];
}

function ie_get_terms_default_sections() {
    return [
        [
            'slug'       => 'acceptance',
            'title'      => ie__( '1. Acceptance of Terms' ),
            'content'    => ie__( 'By accessing or using Island Experts, you agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use our platform.' ),
            'list_items' => [],
        ],
        [
            'slug'       => 'about',
            'title'      => ie__( '2. About Island Experts' ),
            'content'    => ie__( 'Island Experts is an online marketplace that connects customers in Saint Lucia with local service providers. We provide the platform and technology to facilitate these connections but are not a party to any agreement between customers and service providers.' ),
            'list_items' => [],
        ],
        [
            'slug'       => 'accounts',
            'title'      => ie__( '3. User Accounts' ),
            'content'    => ie__( 'To access certain features, you must create an account. You agree to:' ),
            'list_items' => [
                ie__( 'Provide accurate and truthful information during registration' ),
                ie__( 'Keep your login credentials secure and confidential' ),
                ie__( 'Notify us immediately of any unauthorised use of your account' ),
                ie__( 'Be responsible for all activity that occurs under your account' ),
            ],
        ],
        [
            'slug'       => 'customers',
            'title'      => ie__( '4. Customer Terms' ),
            'content'    => ie__( 'As a customer using Island Experts, you agree to:' ),
            'list_items' => [
                ie__( 'Use the platform only to find and connect with legitimate service providers' ),
                ie__( 'Communicate respectfully with service providers' ),
                ie__( 'Leave honest and fair reviews based on your actual experience' ),
                ie__( 'Not misuse the contact or booking features of the platform' ),
            ],
        ],
        [
            'slug'       => 'providers',
            'title'      => ie__( '5. Service Provider Terms' ),
            'content'    => ie__( 'As a registered service provider on Island Experts, you agree to:' ),
            'list_items' => [
                ie__( 'Provide accurate and up-to-date information about your business, services, and pricing' ),
                ie__( 'Operate legally and hold any required licences or certifications for your trade' ),
                ie__( 'Deliver services in a professional and timely manner' ),
                ie__( 'Respond to customer inquiries and booking requests promptly' ),
                ie__( 'Not engage in misleading, fraudulent, or deceptive practices' ),
                ie__( 'Pay applicable listing fees in accordance with your chosen subscription plan' ),
            ],
        ],
        [
            'slug'       => 'payments',
            'title'      => ie__( '6. Listing Fees and Payments' ),
            'content'    => ie__( 'Service providers are required to purchase a listing plan to appear on the platform. All payments are processed securely through PayPal. By purchasing a plan, you agree to the pricing displayed at the time of purchase. Island Experts reserves the right to update pricing with reasonable notice. Refund requests are handled on a case-by-case basis — please contact support for assistance.' ),
            'list_items' => [],
        ],
        [
            'slug'       => 'content',
            'title'      => ie__( '7. Content and Listings' ),
            'content'    => ie__( 'All provider profiles are reviewed and approved by Island Experts before going live. We reserve the right to remove, edit, or reject any listing or content that:' ),
            'list_items' => [
                ie__( 'Contains false, misleading, or inaccurate information' ),
                ie__( 'Violates any applicable laws or regulations' ),
                ie__( 'Is offensive, inappropriate, or harmful' ),
                ie__( 'Infringes on the rights of any third party' ),
            ],
        ],
    ];
}

function ie_parse_terms_list_items( $text ) {
    if ( ! is_string( $text ) || trim( $text ) === '' ) {
        return [];
    }

    $lines = preg_split( '/\r\n|\r|\n/', $text );
    $items = [];

    foreach ( $lines as $line ) {
        $line = trim( $line );
        if ( $line !== '' ) {
            $items[] = $line;
        }
    }

    return $items;
}

function ie_format_terms_list_items( $items ) {
    if ( ! is_array( $items ) || ! $items ) {
        return '';
    }

    return implode( "\n", array_map( 'strval', $items ) );
}

function ie_normalize_terms_sections( $sections ) {
    if ( ! is_array( $sections ) ) {
        return [];
    }

    $normalized = [];

    foreach ( $sections as $section ) {
        $title   = sanitize_text_field( $section['title'] ?? '' );
        $content = sanitize_textarea_field( $section['content'] ?? '' );
        $slug    = $title !== '' ? sanitize_title( $title ) : 'section-' . ( count( $normalized ) + 1 );

        $list_items = [];
        if ( isset( $section['list_items'] ) && is_array( $section['list_items'] ) ) {
            foreach ( $section['list_items'] as $item ) {
                $item = sanitize_text_field( $item );
                if ( $item !== '' ) {
                    $list_items[] = $item;
                }
            }
        } elseif ( isset( $section['list_items'] ) && is_string( $section['list_items'] ) ) {
            foreach ( ie_parse_terms_list_items( $section['list_items'] ) as $item ) {
                $list_items[] = sanitize_text_field( $item );
            }
        }

        if ( $title === '' && $content === '' && ! $list_items ) {
            continue;
        }

        $normalized[] = [
            'slug'       => $slug ?: 'section-' . ( count( $normalized ) + 1 ),
            'title'      => $title,
            'content'    => $content,
            'list_items' => $list_items,
        ];
    }

    return $normalized;
}

function ie_get_terms_sections( $post_id = null ) {
    $post_id = $post_id ?: get_queried_object_id();
    $raw     = get_post_meta( $post_id, '_ie_terms_sections', true );
    $items   = [];

    if ( is_string( $raw ) && $raw !== '' ) {
        $decoded = json_decode( $raw, true );
        if ( is_array( $decoded ) ) {
            $items = ie_normalize_terms_sections( $decoded );
        }
    } elseif ( is_array( $raw ) ) {
        $items = ie_normalize_terms_sections( $raw );
    }

    if ( ! $items ) {
        $items = ie_get_terms_default_sections();
    }

    return $items;
}

function ie_get_terms_page_data( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_terms_default_banner();
    $notice   = ie_get_terms_default_notice();

    return [
        'banner'   => [
            'icon'         => get_post_meta( $post_id, '_ie_terms_banner_icon', true ) ?: $defaults['icon'],
            'title'        => get_post_meta( $post_id, '_ie_terms_banner_title', true ) ?: $defaults['title'],
            'subtitle'     => get_post_meta( $post_id, '_ie_terms_banner_subtitle', true ) ?: $defaults['subtitle'],
            'last_updated' => get_post_meta( $post_id, '_ie_terms_last_updated', true ) ?: $defaults['last_updated'],
        ],
        'notice'   => [
            'label' => get_post_meta( $post_id, '_ie_terms_notice_label', true ) ?: $notice['label'],
            'text'  => get_post_meta( $post_id, '_ie_terms_notice_text', true ) ?: $notice['text'],
        ],
        'sections' => ie_get_terms_sections( $post_id ),
    ];
}

function ie_seed_terms_page_defaults( $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id || get_post_type( $post_id ) !== 'page' ) {
        return;
    }

    $banner = ie_get_terms_default_banner();
    $notice = ie_get_terms_default_notice();

    if ( ! get_post_meta( $post_id, '_ie_terms_banner_icon', true ) ) {
        update_post_meta( $post_id, '_ie_terms_banner_icon', $banner['icon'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_terms_banner_title', true ) ) {
        update_post_meta( $post_id, '_ie_terms_banner_title', $banner['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_terms_banner_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_terms_banner_subtitle', $banner['subtitle'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_terms_last_updated', true ) ) {
        update_post_meta( $post_id, '_ie_terms_last_updated', $banner['last_updated'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_terms_notice_label', true ) ) {
        update_post_meta( $post_id, '_ie_terms_notice_label', $notice['label'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_terms_notice_text', true ) ) {
        update_post_meta( $post_id, '_ie_terms_notice_text', $notice['text'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_terms_sections', true ) ) {
        update_post_meta( $post_id, '_ie_terms_sections', wp_json_encode( ie_get_terms_default_sections() ) );
    }
}

function ie_add_terms_page_meta_box( $post_type, $post ) {
    if ( $post_type !== 'page' || ! $post instanceof WP_Post ) {
        return;
    }

    if ( ! ie_page_uses_template( $post->ID, 'terms.php' ) ) {
        return;
    }

    add_meta_box(
        'ie_terms_page_settings',
        ie__( 'Terms Page Settings' ),
        'ie_terms_page_meta_box_cb',
        'page',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'ie_add_terms_page_meta_box', 10, 2 );

function ie_terms_page_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_terms_page', 'ie_terms_page_nonce' );

    $data     = ie_get_terms_page_data( $post->ID );
    $banner   = $data['banner'];
    $notice   = $data['notice'];
    $sections = ie_normalize_terms_sections( json_decode( (string) get_post_meta( $post->ID, '_ie_terms_sections', true ), true ) );

    if ( ! $sections ) {
        $sections = ie_get_terms_default_sections();
    }
    ?>
    <style>
        .ie-terms-meta-section { margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid #dcdcde; }
        .ie-terms-meta-section:last-child { border-bottom: 0; margin-bottom: 0; padding-bottom: 0; }
        .ie-terms-meta-section h4 { margin: 0 0 12px; font-size: 14px; }
        .ie-terms-meta-field { margin-bottom: 14px; }
        .ie-terms-meta-field label { display: block; font-weight: 600; margin-bottom: 6px; }
        .ie-terms-meta-field input[type="text"],
        .ie-terms-meta-field textarea { width: 100%; }
        .ie-terms-meta-hint { color: #646970; font-size: 12px; margin-top: 4px; }
        .ie-terms-repeater { display: flex; flex-direction: column; gap: 12px; }
        .ie-terms-repeater-item { padding: 14px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 4px; }
        .ie-terms-repeater-item__head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
        .ie-terms-repeater-item__head strong { font-size: 13px; }
        .ie-terms-remove-item { color: #b32d2e; border: 0; background: none; cursor: pointer; font-weight: 600; }
        .ie-terms-add-item { margin-top: 12px; }
    </style>

    <div class="ie-terms-meta-section">
        <h4><?php echo esc_html( ie__( 'Banner Section' ) ); ?></h4>

        <div class="ie-terms-meta-field">
            <label for="ie_terms_banner_icon"><?php echo esc_html( ie__( 'Icon Class' ) ); ?></label>
            <input type="text" id="ie_terms_banner_icon" name="_ie_terms_banner_icon" value="<?php echo esc_attr( $banner['icon'] ); ?>">
            <p class="ie-terms-meta-hint"><?php echo esc_html( ie__( 'Font Awesome class, e.g. fa-solid fa-file-contract' ) ); ?></p>
        </div>

        <div class="ie-terms-meta-field">
            <label for="ie_terms_banner_title"><?php echo esc_html( ie__( 'Banner Title' ) ); ?></label>
            <input type="text" id="ie_terms_banner_title" name="_ie_terms_banner_title" value="<?php echo esc_attr( $banner['title'] ); ?>">
        </div>

        <div class="ie-terms-meta-field">
            <label for="ie_terms_banner_subtitle"><?php echo esc_html( ie__( 'Banner Subtitle' ) ); ?></label>
            <textarea id="ie_terms_banner_subtitle" name="_ie_terms_banner_subtitle" rows="2"><?php echo esc_textarea( $banner['subtitle'] ); ?></textarea>
        </div>

        <div class="ie-terms-meta-field">
            <label for="ie_terms_last_updated"><?php echo esc_html( ie__( 'Last Updated Text' ) ); ?></label>
            <input type="text" id="ie_terms_last_updated" name="_ie_terms_last_updated" value="<?php echo esc_attr( $banner['last_updated'] ); ?>">
        </div>
    </div>

    <div class="ie-terms-meta-section">
        <h4><?php echo esc_html( ie__( 'Notice Banner' ) ); ?></h4>

        <div class="ie-terms-meta-field">
            <label for="ie_terms_notice_label"><?php echo esc_html( ie__( 'Notice Label' ) ); ?></label>
            <input type="text" id="ie_terms_notice_label" name="_ie_terms_notice_label" value="<?php echo esc_attr( $notice['label'] ); ?>">
        </div>

        <div class="ie-terms-meta-field">
            <label for="ie_terms_notice_text"><?php echo esc_html( ie__( 'Notice Text' ) ); ?></label>
            <textarea id="ie_terms_notice_text" name="_ie_terms_notice_text" rows="3"><?php echo esc_textarea( $notice['text'] ); ?></textarea>
        </div>
    </div>

    <div class="ie-terms-meta-section">
        <h4><?php echo esc_html( ie__( 'Terms Sections' ) ); ?></h4>
        <p class="ie-terms-meta-hint"><?php echo esc_html( ie__( 'Add each section with a title, content, and optional bullet points (one per line).' ) ); ?></p>

        <div id="ie-terms-repeater" class="ie-terms-repeater">
            <?php foreach ( $sections as $index => $section ) : ?>
                <?php ie_render_terms_repeater_row( $index, $section ); ?>
            <?php endforeach; ?>
        </div>

        <button type="button" class="button ie-terms-add-item" id="ie-terms-add-item">
            <?php echo esc_html( ie__( 'Add Section' ) ); ?>
        </button>
    </div>

    <script type="text/template" id="ie-terms-row-template">
        <?php ie_render_terms_repeater_row( '__INDEX__', ie_get_terms_default_sections()[0], true ); ?>
    </script>
    <?php
}

function ie_render_terms_repeater_row( $index, $section, $is_template = false ) {
    $num = is_numeric( $index ) ? ( (int) $index + 1 ) : '__NUM__';
    ?>
    <div class="ie-terms-repeater-item" data-index="<?php echo esc_attr( $index ); ?>">
        <div class="ie-terms-repeater-item__head">
            <strong><?php echo esc_html( ie__( 'Section' ) ); ?> #<span class="ie-terms-item-num"><?php echo esc_html( $num ); ?></span></strong>
            <button type="button" class="ie-terms-remove-item"><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
        </div>

        <div class="ie-terms-meta-field">
            <label><?php echo esc_html( ie__( 'Section Title' ) ); ?></label>
            <input type="text" name="ie_terms_title[]" value="<?php echo $is_template ? '' : esc_attr( $section['title'] ?? '' ); ?>">
        </div>

        <div class="ie-terms-meta-field">
            <label><?php echo esc_html( ie__( 'Section Content' ) ); ?></label>
            <textarea name="ie_terms_content[]" rows="4"><?php echo $is_template ? '' : esc_textarea( $section['content'] ?? '' ); ?></textarea>
        </div>

        <div class="ie-terms-meta-field">
            <label><?php echo esc_html( ie__( 'Bullet Points (one per line)' ) ); ?></label>
            <textarea name="ie_terms_list_items[]" rows="4"><?php echo $is_template ? '' : esc_textarea( ie_format_terms_list_items( $section['list_items'] ?? [] ) ); ?></textarea>
        </div>
    </div>
    <?php
}

function ie_save_terms_page_meta( $post_id ) {
    if ( ! isset( $_POST['ie_terms_page_nonce'] ) || ! wp_verify_nonce( $_POST['ie_terms_page_nonce'], 'ie_save_terms_page' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( get_post_type( $post_id ) !== 'page' ) {
        return;
    }
    if ( ! ie_page_uses_template( $post_id, 'terms.php' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
        return;
    }

    $text_fields = [
        '_ie_terms_banner_icon'     => 'sanitize_text_field',
        '_ie_terms_banner_title'    => 'sanitize_text_field',
        '_ie_terms_banner_subtitle' => 'sanitize_textarea_field',
        '_ie_terms_last_updated'    => 'sanitize_text_field',
        '_ie_terms_notice_label'    => 'sanitize_text_field',
        '_ie_terms_notice_text'     => 'sanitize_textarea_field',
    ];

    foreach ( $text_fields as $key => $callback ) {
        if ( isset( $_POST[ $key ] ) ) {
            update_post_meta( $post_id, $key, $callback( wp_unslash( $_POST[ $key ] ) ) );
        }
    }

    $titles   = isset( $_POST['ie_terms_title'] ) ? wp_unslash( $_POST['ie_terms_title'] ) : [];
    $contents = isset( $_POST['ie_terms_content'] ) ? wp_unslash( $_POST['ie_terms_content'] ) : [];
    $lists    = isset( $_POST['ie_terms_list_items'] ) ? wp_unslash( $_POST['ie_terms_list_items'] ) : [];
    $sections = [];

    if ( is_array( $titles ) ) {
        foreach ( $titles as $i => $title ) {
            $sections[] = [
                'title'      => $title,
                'content'    => $contents[ $i ] ?? '',
                'list_items' => ie_parse_terms_list_items( $lists[ $i ] ?? '' ),
            ];
        }
    }

    update_post_meta( $post_id, '_ie_terms_sections', wp_json_encode( ie_normalize_terms_sections( $sections ) ) );
}
add_action( 'save_post_page', 'ie_save_terms_page_meta' );

function ie_enqueue_terms_admin_assets( $hook ) {
    if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
        return;
    }

    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'page' ) {
        return;
    }

    wp_enqueue_script(
        'ie-admin-terms',
        ie_asset_uri( 'js/admin-terms.js' ),
        [ 'jquery' ],
        IE_THEME_VERSION,
        true
    );
}
add_action( 'admin_enqueue_scripts', 'ie_enqueue_terms_admin_assets' );
