<?php
/**
 * Contact page meta fields (banner + sidebar repeater).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_contact_default_banner() {
    return [
        'icon'     => 'fa-regular fa-envelope',
        'title'    => ie__( 'Get in Touch' ),
        'subtitle' => ie__( "We'd love to hear from you. Reach out and we'll get back to you as soon as possible." ),
    ];
}

function ie_get_contact_default_sidebar_items() {
    return [
        [
            'icon_class' => 'fa-solid fa-envelope',
            'icon_style' => 'primary',
            'label'      => ie__( 'Email Us' ),
            'value'      => 'islandexperts758@gmail.com',
            'link'       => 'mailto:islandexperts758@gmail.com',
            'hint'       => ie__( 'We reply within 24 hours' ),
        ],
        [
            'icon_class' => 'fa-solid fa-phone',
            'icon_style' => 'phone',
            'label'      => ie__( 'Phone' ),
            'value'      => '1 (758) 488-0281',
            'link'       => 'tel:+17584880281',
            'hint'       => ie__( 'Call us during support hours' ),
        ],
        [
            'icon_class' => 'fa-solid fa-location-dot',
            'icon_style' => 'address',
            'label'      => ie__( 'Address' ),
            'value'      => ie__( 'Saint Lucia, Caribbean' ),
            'link'       => '',
            'hint'       => ie__( 'Serving customers across the island' ),
        ],
    ];
}

function ie_normalize_contact_sidebar_items( $items ) {
    if ( ! is_array( $items ) ) {
        return [];
    }

    $allowed_styles = array_keys( ie_get_contact_icon_styles() );
    $normalized     = [];

    foreach ( $items as $item ) {
        $icon_class = sanitize_text_field( $item['icon_class'] ?? '' );
        $icon_style = sanitize_key( $item['icon_style'] ?? 'primary' );
        $label      = sanitize_text_field( $item['label'] ?? '' );
        $value      = sanitize_text_field( $item['value'] ?? '' );
        $link       = esc_url_raw( $item['link'] ?? '' );
        $hint       = sanitize_text_field( $item['hint'] ?? '' );

        if ( ! in_array( $icon_style, $allowed_styles, true ) ) {
            $icon_style = 'primary';
        }

        if ( $label === '' && $value === '' && $hint === '' ) {
            continue;
        }

        $normalized[] = [
            'icon_class' => $icon_class ?: 'fa-solid fa-envelope',
            'icon_style' => $icon_style,
            'label'      => $label,
            'value'      => $value,
            'link'       => $link,
            'hint'       => $hint,
        ];
    }

    return $normalized;
}

function ie_get_contact_sidebar_items( $post_id = null ) {
    $post_id = $post_id ?: get_queried_object_id();
    $raw     = get_post_meta( $post_id, '_ie_contact_sidebar_items', true );
    $items   = [];

    if ( is_string( $raw ) && $raw !== '' ) {
        $decoded = json_decode( $raw, true );
        if ( is_array( $decoded ) ) {
            $items = ie_normalize_contact_sidebar_items( $decoded );
        }
    } elseif ( is_array( $raw ) ) {
        $items = ie_normalize_contact_sidebar_items( $raw );
    }

    if ( ! $items ) {
        $items = ie_get_contact_default_sidebar_items();
    }

    return $items;
}

function ie_get_contact_page_data( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_contact_default_banner();

    $banner = [
        'icon'     => get_post_meta( $post_id, '_ie_contact_banner_icon', true ) ?: $defaults['icon'],
        'title'    => get_post_meta( $post_id, '_ie_contact_banner_title', true ) ?: $defaults['title'],
        'subtitle' => get_post_meta( $post_id, '_ie_contact_banner_subtitle', true ) ?: $defaults['subtitle'],
    ];

    return [
        'banner'  => $banner,
        'sidebar' => ie_get_contact_sidebar_items( $post_id ),
    ];
}

function ie_seed_contact_page_defaults( $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id || get_post_type( $post_id ) !== 'page' ) {
        return;
    }

    $defaults = ie_get_contact_default_banner();

    if ( ! get_post_meta( $post_id, '_ie_contact_banner_icon', true ) ) {
        update_post_meta( $post_id, '_ie_contact_banner_icon', $defaults['icon'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_contact_banner_title', true ) ) {
        update_post_meta( $post_id, '_ie_contact_banner_title', $defaults['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_contact_banner_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_contact_banner_subtitle', $defaults['subtitle'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_contact_sidebar_items', true ) ) {
        update_post_meta( $post_id, '_ie_contact_sidebar_items', wp_json_encode( ie_get_contact_default_sidebar_items() ) );
    }
}

function ie_add_contact_page_meta_box( $post_type, $post ) {
    if ( $post_type !== 'page' || ! $post instanceof WP_Post ) {
        return;
    }

    if ( ! ie_page_uses_template( $post->ID, 'contact.php' ) ) {
        return;
    }

    add_meta_box(
        'ie_contact_page_settings',
        ie__( 'Contact Page Settings' ),
        'ie_contact_page_meta_box_cb',
        'page',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'ie_add_contact_page_meta_box', 10, 2 );

function ie_contact_page_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_contact_page', 'ie_contact_page_nonce' );

    $data   = ie_get_contact_page_data( $post->ID );
    $banner = $data['banner'];
    $items  = ie_normalize_contact_sidebar_items( json_decode( (string) get_post_meta( $post->ID, '_ie_contact_sidebar_items', true ), true ) );

    if ( ! $items ) {
        $items = ie_get_contact_default_sidebar_items();
    }

    $icon_styles = ie_get_contact_icon_styles();
    ?>
    <style>
        .ie-contact-meta-section { margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid #dcdcde; }
        .ie-contact-meta-section:last-child { border-bottom: 0; margin-bottom: 0; padding-bottom: 0; }
        .ie-contact-meta-section h4 { margin: 0 0 12px; font-size: 14px; }
        .ie-contact-meta-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
        .ie-contact-meta-field { margin-bottom: 14px; }
        .ie-contact-meta-field label { display: block; font-weight: 600; margin-bottom: 6px; }
        .ie-contact-meta-field input[type="text"],
        .ie-contact-meta-field input[type="url"],
        .ie-contact-meta-field textarea,
        .ie-contact-meta-field select { width: 100%; }
        .ie-contact-meta-hint { color: #646970; font-size: 12px; margin-top: 4px; }
        .ie-contact-repeater { display: flex; flex-direction: column; gap: 12px; }
        .ie-contact-repeater-item { padding: 14px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 4px; }
        .ie-contact-repeater-item__head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
        .ie-contact-repeater-item__head strong { font-size: 13px; }
        .ie-contact-remove-item { color: #b32d2e; border: 0; background: none; cursor: pointer; font-weight: 600; }
        .ie-contact-add-item { margin-top: 12px; }
        @media (max-width: 782px) { .ie-contact-meta-grid { grid-template-columns: 1fr; } }
    </style>

    <div class="ie-contact-meta-section">
        <h4><?php echo esc_html( ie__( 'Banner Section' ) ); ?></h4>

        <div class="ie-contact-meta-field">
            <label for="ie_contact_banner_icon"><?php echo esc_html( ie__( 'Icon Class' ) ); ?></label>
            <input type="text" id="ie_contact_banner_icon" name="_ie_contact_banner_icon" value="<?php echo esc_attr( $banner['icon'] ); ?>">
            <p class="ie-contact-meta-hint"><?php echo esc_html( ie__( 'Font Awesome class, e.g. fa-regular fa-envelope' ) ); ?></p>
        </div>

        <div class="ie-contact-meta-field">
            <label for="ie_contact_banner_title"><?php echo esc_html( ie__( 'Banner Title' ) ); ?></label>
            <input type="text" id="ie_contact_banner_title" name="_ie_contact_banner_title" value="<?php echo esc_attr( $banner['title'] ); ?>">
        </div>

        <div class="ie-contact-meta-field">
            <label for="ie_contact_banner_subtitle"><?php echo esc_html( ie__( 'Banner Subtitle' ) ); ?></label>
            <textarea id="ie_contact_banner_subtitle" name="_ie_contact_banner_subtitle" rows="3"><?php echo esc_textarea( $banner['subtitle'] ); ?></textarea>
        </div>
    </div>

    <div class="ie-contact-meta-section">
        <h4><?php echo esc_html( ie__( 'Sidebar Contact Cards' ) ); ?></h4>
        <p class="ie-contact-meta-hint"><?php echo esc_html( ie__( 'Add contact info cards shown in the left sidebar. Leave Link URL empty for plain text values (e.g. address).' ) ); ?></p>

        <div id="ie-contact-repeater" class="ie-contact-repeater">
            <?php foreach ( $items as $index => $item ) : ?>
                <?php ie_render_contact_repeater_row( $index, $item, $icon_styles ); ?>
            <?php endforeach; ?>
        </div>

        <button type="button" class="button ie-contact-add-item" id="ie-contact-add-item">
            <?php echo esc_html( ie__( 'Add Contact Card' ) ); ?>
        </button>
    </div>

    <script type="text/template" id="ie-contact-row-template">
        <?php ie_render_contact_repeater_row( '__INDEX__', ie_get_contact_default_sidebar_items()[0], $icon_styles, true ); ?>
    </script>
    <?php
}

function ie_render_contact_repeater_row( $index, $item, $icon_styles, $is_template = false ) {
    $label = $is_template ? '' : ( $item['label'] ?? '' );
    $num   = is_numeric( $index ) ? ( (int) $index + 1 ) : '__NUM__';
    ?>
    <div class="ie-contact-repeater-item" data-index="<?php echo esc_attr( $index ); ?>">
        <div class="ie-contact-repeater-item__head">
            <strong><?php echo esc_html( ie__( 'Card' ) ); ?> #<span class="ie-contact-item-num"><?php echo esc_html( $num ); ?></span></strong>
            <button type="button" class="ie-contact-remove-item"><?php echo esc_html( ie__( 'Remove' ) ); ?></button>
        </div>

        <div class="ie-contact-meta-grid">
            <div class="ie-contact-meta-field">
                <label><?php echo esc_html( ie__( 'Icon Class' ) ); ?></label>
                <input type="text" name="ie_contact_icon_class[]" value="<?php echo $is_template ? '' : esc_attr( $item['icon_class'] ?? '' ); ?>">
            </div>
            <div class="ie-contact-meta-field">
                <label><?php echo esc_html( ie__( 'Icon Style' ) ); ?></label>
                <select name="ie_contact_icon_style[]">
                    <?php foreach ( $icon_styles as $style_key => $style_label ) : ?>
                        <option value="<?php echo esc_attr( $style_key ); ?>" <?php selected( $is_template ? 'primary' : ( $item['icon_style'] ?? 'primary' ), $style_key ); ?>>
                            <?php echo esc_html( $style_label ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="ie-contact-meta-field">
                <label><?php echo esc_html( ie__( 'Label' ) ); ?></label>
                <input type="text" name="ie_contact_label[]" value="<?php echo $is_template ? '' : esc_attr( $item['label'] ?? '' ); ?>">
            </div>
            <div class="ie-contact-meta-field">
                <label><?php echo esc_html( ie__( 'Value' ) ); ?></label>
                <input type="text" name="ie_contact_value[]" value="<?php echo $is_template ? '' : esc_attr( $item['value'] ?? '' ); ?>">
            </div>
            <div class="ie-contact-meta-field">
                <label><?php echo esc_html( ie__( 'Link URL' ) ); ?></label>
                <input type="url" name="ie_contact_link[]" value="<?php echo $is_template ? '' : esc_attr( $item['link'] ?? '' ); ?>" placeholder="mailto: / tel: / https://">
            </div>
            <div class="ie-contact-meta-field">
                <label><?php echo esc_html( ie__( 'Hint Text' ) ); ?></label>
                <input type="text" name="ie_contact_hint[]" value="<?php echo $is_template ? '' : esc_attr( $item['hint'] ?? '' ); ?>">
            </div>
        </div>
    </div>
    <?php
}

function ie_save_contact_page_meta( $post_id ) {
    if ( ! isset( $_POST['ie_contact_page_nonce'] ) || ! wp_verify_nonce( $_POST['ie_contact_page_nonce'], 'ie_save_contact_page' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( get_post_type( $post_id ) !== 'page' ) {
        return;
    }
    if ( ! ie_page_uses_template( $post_id, 'contact.php' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['_ie_contact_banner_icon'] ) ) {
        update_post_meta( $post_id, '_ie_contact_banner_icon', sanitize_text_field( wp_unslash( $_POST['_ie_contact_banner_icon'] ) ) );
    }
    if ( isset( $_POST['_ie_contact_banner_title'] ) ) {
        update_post_meta( $post_id, '_ie_contact_banner_title', sanitize_text_field( wp_unslash( $_POST['_ie_contact_banner_title'] ) ) );
    }
    if ( isset( $_POST['_ie_contact_banner_subtitle'] ) ) {
        update_post_meta( $post_id, '_ie_contact_banner_subtitle', sanitize_textarea_field( wp_unslash( $_POST['_ie_contact_banner_subtitle'] ) ) );
    }

    $icon_classes = isset( $_POST['ie_contact_icon_class'] ) ? wp_unslash( $_POST['ie_contact_icon_class'] ) : [];
    $icon_styles  = isset( $_POST['ie_contact_icon_style'] ) ? wp_unslash( $_POST['ie_contact_icon_style'] ) : [];
    $labels       = isset( $_POST['ie_contact_label'] ) ? wp_unslash( $_POST['ie_contact_label'] ) : [];
    $values       = isset( $_POST['ie_contact_value'] ) ? wp_unslash( $_POST['ie_contact_value'] ) : [];
    $links        = isset( $_POST['ie_contact_link'] ) ? wp_unslash( $_POST['ie_contact_link'] ) : [];
    $hints        = isset( $_POST['ie_contact_hint'] ) ? wp_unslash( $_POST['ie_contact_hint'] ) : [];
    $items        = [];

    if ( is_array( $icon_classes ) ) {
        foreach ( $icon_classes as $i => $icon_class ) {
            $items[] = [
                'icon_class' => $icon_class,
                'icon_style' => $icon_styles[ $i ] ?? 'primary',
                'label'      => $labels[ $i ] ?? '',
                'value'      => $values[ $i ] ?? '',
                'link'       => $links[ $i ] ?? '',
                'hint'       => $hints[ $i ] ?? '',
            ];
        }
    }

    update_post_meta( $post_id, '_ie_contact_sidebar_items', wp_json_encode( ie_normalize_contact_sidebar_items( $items ) ) );
}
add_action( 'save_post_page', 'ie_save_contact_page_meta' );

function ie_enqueue_contact_admin_assets( $hook ) {
    if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
        return;
    }

    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'page' ) {
        return;
    }

    wp_enqueue_script(
        'ie-admin-contact',
        ie_asset_uri( 'js/admin-contact.js' ),
        [ 'jquery' ],
        IE_THEME_VERSION,
        true
    );
}
add_action( 'admin_enqueue_scripts', 'ie_enqueue_contact_admin_assets' );
