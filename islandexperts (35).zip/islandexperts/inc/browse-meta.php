<?php
/**
 * Browse page meta fields (page header).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ie_get_browse_default_header() {
    return [
        'title'    => ie__( 'Service Providers' ),
        'subtitle' => ie__( 'Find trusted local service providers across St. Lucia' ),
    ];
}

function ie_get_browse_page_data( $post_id = null ) {
    $post_id  = $post_id ?: get_queried_object_id();
    $defaults = ie_get_browse_default_header();

    return [
        'header' => [
            'title'    => get_post_meta( $post_id, '_ie_browse_title', true ) ?: $defaults['title'],
            'subtitle' => get_post_meta( $post_id, '_ie_browse_subtitle', true ) ?: $defaults['subtitle'],
        ],
    ];
}

function ie_seed_browse_page_defaults( $post_id ) {
    $post_id = (int) $post_id;
    if ( ! $post_id || get_post_type( $post_id ) !== 'page' ) {
        return;
    }

    $defaults = ie_get_browse_default_header();

    if ( ! get_post_meta( $post_id, '_ie_browse_title', true ) ) {
        update_post_meta( $post_id, '_ie_browse_title', $defaults['title'] );
    }
    if ( ! get_post_meta( $post_id, '_ie_browse_subtitle', true ) ) {
        update_post_meta( $post_id, '_ie_browse_subtitle', $defaults['subtitle'] );
    }
}

function ie_add_browse_page_meta_box( $post_type, $post ) {
    if ( $post_type !== 'page' || ! $post instanceof WP_Post ) {
        return;
    }

    if ( ! ie_page_uses_template( $post->ID, 'browse.php' ) ) {
        return;
    }

    add_meta_box(
        'ie_browse_page_settings',
        ie__( 'Browse Page Settings' ),
        'ie_browse_page_meta_box_cb',
        'page',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'ie_add_browse_page_meta_box', 10, 2 );

function ie_browse_page_meta_box_cb( $post ) {
    wp_nonce_field( 'ie_save_browse_page', 'ie_browse_page_nonce' );

    $header = ie_get_browse_page_data( $post->ID )['header'];
    ?>
    <style>
        .ie-browse-meta-field { margin-bottom: 14px; }
        .ie-browse-meta-field label { display: block; font-weight: 600; margin-bottom: 6px; }
        .ie-browse-meta-field input[type="text"],
        .ie-browse-meta-field textarea { width: 100%; }
    </style>

    <div class="ie-browse-meta-field">
        <label for="ie_browse_title"><?php echo esc_html( ie__( 'Page Title' ) ); ?></label>
        <input type="text" id="ie_browse_title" name="_ie_browse_title" value="<?php echo esc_attr( $header['title'] ); ?>">
    </div>

    <div class="ie-browse-meta-field">
        <label for="ie_browse_subtitle"><?php echo esc_html( ie__( 'Page Subtitle' ) ); ?></label>
        <textarea id="ie_browse_subtitle" name="_ie_browse_subtitle" rows="2"><?php echo esc_textarea( $header['subtitle'] ); ?></textarea>
    </div>
    <?php
}

function ie_save_browse_page_meta( $post_id ) {
    if ( ! isset( $_POST['ie_browse_page_nonce'] ) || ! wp_verify_nonce( $_POST['ie_browse_page_nonce'], 'ie_save_browse_page' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( get_post_type( $post_id ) !== 'page' ) {
        return;
    }
    if ( ! ie_page_uses_template( $post_id, 'browse.php' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
        return;
    }

    if ( isset( $_POST['_ie_browse_title'] ) ) {
        update_post_meta( $post_id, '_ie_browse_title', sanitize_text_field( wp_unslash( $_POST['_ie_browse_title'] ) ) );
    }
    if ( isset( $_POST['_ie_browse_subtitle'] ) ) {
        update_post_meta( $post_id, '_ie_browse_subtitle', sanitize_textarea_field( wp_unslash( $_POST['_ie_browse_subtitle'] ) ) );
    }
}
add_action( 'save_post_page', 'ie_save_browse_page_meta' );

function ie_get_browse_content_post_id() {
    if ( is_page() ) {
        return get_queried_object_id();
    }

    $page = get_page_by_path( 'browse' );

    return $page ? (int) $page->ID : 0;
}
