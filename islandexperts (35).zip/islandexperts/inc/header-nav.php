<?php
/**
 * Header navigation – WordPress menu integration.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IE_Header_Nav_Walker extends Walker_Nav_Menu {

    public function start_lvl( &$output, $depth = 0, $args = null ) {
    }

    public function end_lvl( &$output, $depth = 0, $args = null ) {
    }

    public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        if ( $depth > 0 ) {
            return;
        }

        $classes = empty( $item->classes ) ? [] : (array) $item->classes;
        $classes = array_filter( $classes );
        $class_attr = $classes ? ' class="' . esc_attr( implode( ' ', $classes ) ) . '"' : '';

        $output .= '<a href="' . esc_url( $item->url ) . '"' . $class_attr . '>';
        $output .= esc_html( $item->title );
        $output .= '</a>';
    }

    public function end_el( &$output, $item, $depth = 0, $args = null ) {
    }
}

function ie_render_header_nav() {
    if ( has_nav_menu( 'primary' ) ) {
        wp_nav_menu(
            [
                'theme_location' => 'primary',
                'container'      => false,
                'items_wrap'     => '%3$s',
                'depth'          => 1,
                'fallback_cb'    => false,
                'walker'         => new IE_Header_Nav_Walker(),
            ]
        );
        return;
    }

    foreach ( ie_get_header_nav_items() as $label => $url ) {
        $class = ie_is_header_nav_active( $label ) ? 'active' : '';
        ?>
        <a href="<?php echo esc_url( $url ); ?>" class="<?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></a>
        <?php
    }
}
