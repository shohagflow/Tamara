(function ($) {
    'use strict';

    const i18n = window.IE_HOME_ADMIN || {};

    function renumberHomeWhyItems() {
        $('#ie-home-why-repeater .ie-home-repeater-item').each(function (index) {
            $(this).find('.ie-home-item-num').text(index + 1);
        });
    }

    function renumberHomeSlides() {
        $('#ie-home-slides .ie-home-slide-item').each(function (index) {
            $(this).find('.ie-home-slide-num').text(index + 1);
        });
    }

    function getHomeWhyRowHtml() {
        var template = $('#ie-home-why-row-template').html();
        if (!template) {
            return '';
        }
        var index = $('#ie-home-why-repeater .ie-home-repeater-item').length;
        return template.replace(/__INDEX__/g, index).replace(/__NUM__/g, index + 1);
    }

    function getHomeSlideRowHtml() {
        var template = $('#ie-home-slide-template').html();
        if (!template) {
            return '';
        }
        var index = $('#ie-home-slides .ie-home-slide-item').length;
        return template.replace(/__INDEX__/g, index).replace(/__NUM__/g, index + 1);
    }

    function setSlidePreview($item, url) {
        const $preview = $item.find('.ie-home-slide-preview');
        const noImageText = i18n.noImage || 'No image';

        if (url) {
            $preview.removeClass('is-empty').html('<img src="' + url + '" alt="">');
        } else {
            $preview.addClass('is-empty').text(noImageText);
        }

        $item.find('input[name="ie_home_hero_slide_url[]"]').val(url);
    }

    function openSlideMediaFrame($item) {
        const frame = wp.media({
            title: i18n.selectImage || 'Select Slide Image',
            button: { text: i18n.useImage || 'Use this image' },
            library: { type: 'image' },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            const url = attachment.url || '';
            setSlidePreview($item, url);
        });

        frame.open();
    }

    $(document).on('click', '#ie-home-add-why-item', function () {
        var html = getHomeWhyRowHtml();
        if (!html) {
            return;
        }
        $('#ie-home-why-repeater').append(html);
        renumberHomeWhyItems();
    });

    $(document).on('click', '#ie-home-add-slide', function () {
        var html = getHomeSlideRowHtml();
        if (!html) {
            return;
        }
        $('#ie-home-slides').append(html);
        renumberHomeSlides();
    });

    $(document).on('click', '.ie-home-upload-slide', function (e) {
        e.preventDefault();
        openSlideMediaFrame($(this).closest('.ie-home-slide-item'));
    });

    $(document).on('click', '.ie-home-clear-slide', function (e) {
        e.preventDefault();
        setSlidePreview($(this).closest('.ie-home-slide-item'), '');
    });

    $(document).on('click', '.ie-home-remove-slide', function (e) {
        e.preventDefault();
        var $items = $('#ie-home-slides .ie-home-slide-item');
        if ($items.length <= 1) {
            setSlidePreview($items.first(), '');
            return;
        }
        $(this).closest('.ie-home-slide-item').remove();
        renumberHomeSlides();
    });

    $(document).on('click', '.ie-home-remove-item', function () {
        var $items = $('#ie-home-why-repeater .ie-home-repeater-item');
        if ($items.length <= 1) {
            $(this).closest('.ie-home-repeater-item').find('input, textarea').val('');
            return;
        }
        $(this).closest('.ie-home-repeater-item').remove();
        renumberHomeWhyItems();
    });
})(jQuery);
