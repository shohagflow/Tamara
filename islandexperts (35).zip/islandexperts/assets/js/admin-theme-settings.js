(function ($) {
    'use strict';

    const i18n = window.IE_THEME_SETTINGS_ADMIN || {};

    function setLogoPreview($preview, url, emptyText) {
        if (url) {
            $preview.removeClass('is-empty').html('<img src="' + url + '" alt="">');
        } else {
            $preview.addClass('is-empty').text(emptyText || i18n.noImage || 'No logo selected');
        }
    }

    function openLogoFrame($input, $preview) {
        const frame = wp.media({
            title: i18n.selectImage || 'Select Logo',
            button: { text: i18n.useImage || 'Use this logo' },
            library: { type: 'image' },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            const url = attachment.url || '';
            $input.val(url);
            setLogoPreview($preview, url);
        });

        frame.open();
    }

    function renumberSocialItems() {
        $('#ie-ts-social-repeater .ie-ts-social-item').each(function (index) {
            $(this).find('.ie-ts-item-num').text(index + 1);
        });
    }

    function renumberColumns() {
        $('#ie-ts-columns-repeater .ie-ts-column-item').each(function (colIndex) {
            const $column = $(this);
            $column.attr('data-column-index', colIndex);
            $column.find('.ie-ts-column-num').text(colIndex + 1);

            $column.find('[name]').each(function () {
                const name = $(this).attr('name');
                if (!name) {
                    return;
                }
                $(this).attr(
                    'name',
                    name.replace(/ie_theme_settings\[footer\]\[columns\]\[\d+\]/, 'ie_theme_settings[footer][columns][' + colIndex + ']')
                );
            });
        });
    }

    function getTemplate(id) {
        return $('#' + id).html() || '';
    }

    function replaceColumnTokens(html, colIndex) {
        return html.replace(/__COL__/g, colIndex).replace(/__LINK__/g, '0').replace(/__ITEM__/g, '0');
    }

    function nextSubIndex($list, selector) {
        return $list.find(selector).length;
    }

    function toggleColumnType($column) {
        const type = $column.find('.ie-ts-column-type').val();
        $column.find('.ie-ts-column-links').toggleClass('is-hidden', type !== 'links');
        $column.find('.ie-ts-column-contact').toggleClass('is-hidden', type !== 'contact');
    }

    $(document).on('click', '.ie-ts-upload-logo', function (event) {
        event.preventDefault();
        const target = $(this).data('target');
        const preview = $(this).data('preview');
        openLogoFrame($('#' + target), $(preview));
    });

    $(document).on('click', '.ie-ts-remove-logo', function (event) {
        event.preventDefault();
        const target = $(this).data('target');
        const preview = $(this).data('preview');
        const $preview = $(preview);
        const emptyText = preview === '.ie-ts-footer-logo-preview'
            ? 'Uses header logo'
            : (i18n.noImage || 'No logo selected');

        $('#' + target).val('');
        setLogoPreview($preview, '', emptyText);
    });

    $(document).on('click', '#ie-ts-add-social', function () {
        const template = getTemplate('ie-ts-social-template');
        if (!template) {
            return;
        }
        const index = $('#ie-ts-social-repeater .ie-ts-social-item').length;
        $('#ie-ts-social-repeater').append(template.replace(/__INDEX__/g, index));
        renumberSocialItems();
    });

    $(document).on('click', '.ie-ts-remove-social', function () {
        const $items = $('#ie-ts-social-repeater .ie-ts-social-item');
        if ($items.length <= 1) {
            $(this).closest('.ie-ts-social-item').find('input, select').val('');
            return;
        }
        $(this).closest('.ie-ts-social-item').remove();
        renumberSocialItems();
    });

    $(document).on('click', '#ie-ts-add-column', function () {
        const template = getTemplate('ie-ts-column-template');
        if (!template) {
            return;
        }
        const colIndex = $('#ie-ts-columns-repeater .ie-ts-column-item').length;
        $('#ie-ts-columns-repeater').append(replaceColumnTokens(template, colIndex));
        renumberColumns();
    });

    $(document).on('click', '.ie-ts-remove-column', function () {
        const $items = $('#ie-ts-columns-repeater .ie-ts-column-item');
        if ($items.length <= 1) {
            return;
        }
        $(this).closest('.ie-ts-column-item').remove();
        renumberColumns();
    });

    $(document).on('change', '.ie-ts-column-type', function () {
        toggleColumnType($(this).closest('.ie-ts-column-item'));
    });

    $(document).on('click', '.ie-ts-add-link', function () {
        const $column = $(this).closest('.ie-ts-column-item');
        const colIndex = $column.index();
        const linkIndex = nextSubIndex($column.find('.ie-ts-link-list'), '.ie-ts-link-item');
        let html = getTemplate('ie-ts-link-template');
        html = html.replace(/__COL__/g, colIndex).replace(/__LINK__/g, linkIndex);
        $column.find('.ie-ts-link-list').append(html);
        renumberColumns();
    });

    $(document).on('click', '.ie-ts-remove-link', function () {
        const $list = $(this).closest('.ie-ts-link-list');
        if ($list.find('.ie-ts-link-item').length <= 1) {
            $(this).closest('.ie-ts-link-item').find('input').val('');
            return;
        }
        $(this).closest('.ie-ts-link-item').remove();
        renumberColumns();
    });

    $(document).on('click', '.ie-ts-add-contact', function () {
        const $column = $(this).closest('.ie-ts-column-item');
        const colIndex = $column.index();
        const itemIndex = nextSubIndex($column.find('.ie-ts-contact-list'), '.ie-ts-contact-item');
        let html = getTemplate('ie-ts-contact-template');
        html = html.replace(/__COL__/g, colIndex).replace(/__ITEM__/g, itemIndex);
        $column.find('.ie-ts-contact-list').append(html);
        renumberColumns();
    });

    $(document).on('click', '.ie-ts-remove-contact', function () {
        const $list = $(this).closest('.ie-ts-contact-list');
        if ($list.find('.ie-ts-contact-item').length <= 1) {
            $(this).closest('.ie-ts-contact-item').find('input').val('');
            return;
        }
        $(this).closest('.ie-ts-contact-item').remove();
        renumberColumns();
    });

    function updateFontPreview() {
        const headingFont = $('#ie-global-font-heading').val() || 'Poppins';
        const bodyFont = $('#ie-global-font-body').val() || 'Inter';
        const headingStack = "'" + headingFont.replace(/'/g, '') + "', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
        const bodyStack = "'" + bodyFont.replace(/'/g, '') + "', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";

        loadGoogleFont(headingFont);
        loadGoogleFont(bodyFont);

        $('#ie-ts-font-preview-heading').css('font-family', headingStack);
        $('#ie-ts-font-preview-body').css('font-family', bodyStack);
    }

    function loadGoogleFont(family) {
        if (!family) {
            return;
        }

        const id = 'ie-gf-' + family.replace(/\s+/g, '-').toLowerCase();
        if (document.getElementById(id)) {
            return;
        }

        const link = document.createElement('link');
        link.id = id;
        link.rel = 'stylesheet';
        link.href = 'https://fonts.googleapis.com/css2?family=' + encodeURIComponent(family).replace(/%20/g, '+') + ':wght@400;500;600;700&display=swap';
        document.head.appendChild(link);
    }

    $(document).on('change', '#ie-global-font-heading, #ie-global-font-body', updateFontPreview);

    $(function () {
        if ($.fn.wpColorPicker) {
            $('.ie-ts-color-picker').wpColorPicker();
        }

        $('#ie-ts-columns-repeater .ie-ts-column-item').each(function () {
            toggleColumnType($(this));
        });

        updateFontPreview();
    });
}(jQuery));
