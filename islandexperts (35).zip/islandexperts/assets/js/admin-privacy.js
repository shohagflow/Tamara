(function ($) {
    'use strict';

    function renumberPrivacyItems() {
        $('#ie-privacy-repeater .ie-privacy-repeater-item').each(function (index) {
            $(this).find('.ie-privacy-item-num').text(index + 1);
        });
    }

    function getPrivacyRowHtml() {
        var template = $('#ie-privacy-row-template').html();
        if (!template) {
            return '';
        }
        var index = $('#ie-privacy-repeater .ie-privacy-repeater-item').length;
        return template.replace(/__INDEX__/g, index).replace(/__NUM__/g, index + 1);
    }

    $(document).on('click', '#ie-privacy-add-item', function () {
        var html = getPrivacyRowHtml();
        if (!html) {
            return;
        }
        $('#ie-privacy-repeater').append(html);
        renumberPrivacyItems();
    });

    $(document).on('click', '.ie-privacy-remove-item', function () {
        var $items = $('#ie-privacy-repeater .ie-privacy-repeater-item');
        if ($items.length <= 1) {
            $(this).closest('.ie-privacy-repeater-item').find('input, textarea').val('');
            return;
        }
        $(this).closest('.ie-privacy-repeater-item').remove();
        renumberPrivacyItems();
    });
})(jQuery);
