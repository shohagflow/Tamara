(function ($) {
    'use strict';

    function renumberFaqItems() {
        $('#ie-faq-repeater .ie-faq-repeater-item').each(function (index) {
            $(this).find('.ie-faq-item-num').text(index + 1);
        });
    }

    function getFaqRowHtml() {
        var template = $('#ie-faq-row-template').html();
        if (!template) {
            return '';
        }
        var index = $('#ie-faq-repeater .ie-faq-repeater-item').length;
        return template.replace(/__INDEX__/g, index).replace(/__NUM__/g, index + 1);
    }

    $(document).on('click', '#ie-faq-add-item', function () {
        var html = getFaqRowHtml();
        if (!html) {
            return;
        }
        $('#ie-faq-repeater').append(html);
        renumberFaqItems();
    });

    $(document).on('click', '.ie-faq-remove-item', function () {
        var $items = $('#ie-faq-repeater .ie-faq-repeater-item');
        if ($items.length <= 1) {
            $(this).closest('.ie-faq-repeater-item').find('input, textarea').val('');
            return;
        }
        $(this).closest('.ie-faq-repeater-item').remove();
        renumberFaqItems();
    });
})(jQuery);
