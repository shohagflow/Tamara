(function ($) {
    'use strict';

    function renumberTermsItems() {
        $('#ie-terms-repeater .ie-terms-repeater-item').each(function (index) {
            $(this).find('.ie-terms-item-num').text(index + 1);
        });
    }

    function getTermsRowHtml() {
        var template = $('#ie-terms-row-template').html();
        if (!template) {
            return '';
        }
        var index = $('#ie-terms-repeater .ie-terms-repeater-item').length;
        return template.replace(/__INDEX__/g, index).replace(/__NUM__/g, index + 1);
    }

    $(document).on('click', '#ie-terms-add-item', function () {
        var html = getTermsRowHtml();
        if (!html) {
            return;
        }
        $('#ie-terms-repeater').append(html);
        renumberTermsItems();
    });

    $(document).on('click', '.ie-terms-remove-item', function () {
        var $items = $('#ie-terms-repeater .ie-terms-repeater-item');
        if ($items.length <= 1) {
            $(this).closest('.ie-terms-repeater-item').find('input, textarea').val('');
            return;
        }
        $(this).closest('.ie-terms-repeater-item').remove();
        renumberTermsItems();
    });
})(jQuery);
