(function ($) {
    'use strict';

    function renumberContactItems() {
        $('#ie-contact-repeater .ie-contact-repeater-item').each(function (index) {
            $(this).find('.ie-contact-item-num').text(index + 1);
        });
    }

    function getContactRowHtml() {
        var template = $('#ie-contact-row-template').html();
        if (!template) {
            return '';
        }
        var index = $('#ie-contact-repeater .ie-contact-repeater-item').length;
        return template.replace(/__INDEX__/g, index).replace(/__NUM__/g, index + 1);
    }

    $(document).on('click', '#ie-contact-add-item', function () {
        var html = getContactRowHtml();
        if (!html) {
            return;
        }
        $('#ie-contact-repeater').append(html);
        renumberContactItems();
    });

    $(document).on('click', '.ie-contact-remove-item', function () {
        var $items = $('#ie-contact-repeater .ie-contact-repeater-item');
        if ($items.length <= 1) {
            $(this).closest('.ie-contact-repeater-item').find('input, select').val('');
            return;
        }
        $(this).closest('.ie-contact-repeater-item').remove();
        renumberContactItems();
    });
})(jQuery);
